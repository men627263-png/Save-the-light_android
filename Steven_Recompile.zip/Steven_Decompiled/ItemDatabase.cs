using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class ItemDatabase : ScriptableObject
{
	[SerializeField]
	private List<ItemDefinition> _items;

	[SerializeField]
	private int _nextId = -1;

	public List<ItemDefinition> items => _items;

	private int nextId
	{
		get
		{
			_nextId++;
			return _nextId;
		}
	}

	private void OnEnable()
	{
		if (_items == null)
		{
			_items = new List<ItemDefinition>();
		}
	}

	public ItemDefinition GetItem(int uid)
	{
		return _items.Find((ItemDefinition obj) => (Object)(object)obj != (Object)null && obj.uid == uid);
	}

	public List<ItemDefinition> GetItems(List<int> uids)
	{
		List<ItemDefinition> list = new List<ItemDefinition>();
		int count = uids.Count;
		for (int i = 0; i < count; i++)
		{
			list.Add(_items.Find((ItemDefinition obj) => (Object)(object)obj != (Object)null && obj.uid == uids[i]));
		}
		return list;
	}

	public int GetKeyUIDForType(KeyType keyType)
	{
		ItemDefinition itemDefinition = GetKeys().Find((ItemDefinition obj) => ((Key)obj).keyType == keyType);
		if ((Object)(object)itemDefinition != (Object)null)
		{
			return itemDefinition.uid;
		}
		return -1;
	}

	public List<ItemDefinition> GetAllItems()
	{
		return _items.FindAll((ItemDefinition obj) => obj is Consumable || obj is QuestItem || obj is BadgeDefinition || obj is Key || obj is Weapon || obj is CraftingConsumable);
	}

	public List<ItemDefinition> GetConsumables()
	{
		return _items.FindAll((ItemDefinition obj) => obj is Consumable);
	}

	public List<ItemDefinition> GetQuestItems()
	{
		return _items.FindAll((ItemDefinition obj) => obj is QuestItem);
	}

	public List<ItemDefinition> GetBadges()
	{
		return _items.FindAll((ItemDefinition obj) => obj is BadgeDefinition);
	}

	public List<ItemDefinition> GetKeys()
	{
		return _items.FindAll((ItemDefinition obj) => obj is Key);
	}

	public List<ItemDefinition> GetWeapons()
	{
		return _items.FindAll((ItemDefinition obj) => obj is Weapon);
	}

	public List<ItemDefinition> GetCraftingConsumables()
	{
		return _items.FindAll((ItemDefinition obj) => obj is CraftingConsumable);
	}
}
