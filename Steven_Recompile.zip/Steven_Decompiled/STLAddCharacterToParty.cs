using HutongGames.PlayMaker;

[Tooltip("Attempts to add the specified character to the current player's data, and optionally add said character to their active party if possible.")]
public class STLAddCharacterToParty : FsmStateAction
{
	public CharacterName character;

	public FsmBool addToActiveParty;

	public override void Reset()
	{
		character = CharacterName.None;
		addToActiveParty = FsmBool.op_Implicit(false);
	}

	public override void OnEnter()
	{
		if (character != CharacterName.None)
		{
			PlayerGameState.Instance.AddCharacterToParty(character, addToActiveParty.Value);
		}
		((FsmStateAction)this).Finish();
	}
}
