using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using DG.Tweening.Core;
using Grumpyface;
using UnityEngine;

public class AmbushTrigger : MonoBehaviour
{
	public Transform ambushPosition;

	public bool forceAmbush;

	[Tooltip("Turn on to require another collider to be triggered for ambush to activate")]
	public bool requiresOtherTrigger;

	[Header("Colliders")]
	public Collider activationCollider;

	public Collider requiredCollider;

	public Collider hintCollider;

	[Header("Scene Animation")]
	public Animator animatorTriggered;

	public string activationTrigger;

	public string hintTrigger;

	public ParticleSystem particleSystem;

	[Header("Second Scene Animation")]
	public Animator secondAnimatorTriggered;

	public string secondActivationTrigger;

	public string secondHintTrigger;

	[Header("Path Settings")]
	public bool usePath;

	public DOTweenPath tweenPath;

	[Header("Loop Settings")]
	public bool loopsPath;

	public float loopDelay = 1f;

	public Animator loopAnimator;

	public ParticleSystem loopParticles;

	[Header("Enemy Settings")]
	public float spawnDelay;

	public CharacterAnimationNamePair enemyAmbushAnimation;

	public int startFrame;

	public Battlefield overrideBattlefield;

	public List<EnemySpawn> enemies = new List<EnemySpawn>();

	private List<BaseCharacter> enemyList = new List<BaseCharacter>();

	private int playerLayer;

	private bool startedAmbush;

	private bool hitOtherTrigger;

	private TriggerCollider normalTriggerCollider;

	private TriggerCollider otherTriggerCollider;

	private TriggerCollider tellTriggerCollider;

	private GameObject objectOnPath;

	private bool ambushInitiated;

	private bool playingBackwards;

	private void Start()
	{
		playerLayer = LayerMask.NameToLayer("Player");
		if (requiresOtherTrigger && (Object)(object)requiredCollider != (Object)null)
		{
			otherTriggerCollider = ((Component)requiredCollider).gameObject.GetComponent<TriggerCollider>();
			otherTriggerCollider.Entered += OnOtherTriggerEnter;
		}
		if ((Object)(object)activationCollider != (Object)null)
		{
			normalTriggerCollider = ((Component)activationCollider).gameObject.GetComponent<TriggerCollider>();
			normalTriggerCollider.Entered += OnTriggerEnter;
		}
		if ((Object)(object)hintCollider != (Object)null)
		{
			tellTriggerCollider = ((Component)hintCollider).gameObject.GetComponent<TriggerCollider>();
			tellTriggerCollider.Entered += OnTellTriggerEnter;
		}
	}

	private void OnDestroy()
	{
		if (requiresOtherTrigger)
		{
			otherTriggerCollider.Entered -= OnOtherTriggerEnter;
		}
		if ((Object)(object)hintCollider != (Object)null)
		{
			tellTriggerCollider.Entered -= OnTellTriggerEnter;
		}
		if ((Object)(object)normalTriggerCollider != (Object)null)
		{
			normalTriggerCollider.Entered -= OnTriggerEnter;
		}
	}

	private void OnOtherTriggerEnter(Collider other)
	{
		if ((GameControllerState)(object)GameController.Instance.CurrentState == GameControllerState.Exploration_Waiting)
		{
			PlayerCharacter partyLeader = GameController.Instance.partyLeader;
			if (!startedAmbush && ((Component)other).gameObject.layer == playerLayer && ((object)((Component)other).gameObject).Equals((object?)((Component)partyLeader).gameObject))
			{
				hitOtherTrigger = true;
			}
		}
	}

	private void OnTellTriggerEnter(Collider other)
	{
		if ((GameControllerState)(object)GameController.Instance.CurrentState != GameControllerState.Exploration_Waiting)
		{
			return;
		}
		PlayerCharacter partyLeader = GameController.Instance.partyLeader;
		if (!startedAmbush && ((Component)other).gameObject.layer == playerLayer && ((object)((Component)other).gameObject).Equals((object?)((Component)partyLeader).gameObject) && (!requiresOtherTrigger || (requiresOtherTrigger && hitOtherTrigger)))
		{
			if ((Object)(object)animatorTriggered != (Object)null && !string.IsNullOrEmpty(hintTrigger))
			{
				animatorTriggered.SetTrigger(hintTrigger);
			}
			if ((Object)(object)secondAnimatorTriggered != (Object)null && !string.IsNullOrEmpty(secondHintTrigger))
			{
				secondAnimatorTriggered.SetTrigger(secondHintTrigger);
			}
		}
	}

	private void OnTriggerEnter(Collider other)
	{
		if ((GameControllerState)(object)GameController.Instance.CurrentState == GameControllerState.Exploration_Waiting)
		{
			PlayerCharacter partyLeader = GameController.Instance.partyLeader;
			if (((Component)other).gameObject.layer == playerLayer && ((object)((Component)other).gameObject).Equals((object?)((Component)partyLeader).gameObject) && !startedAmbush && enemies.Count > 0 && (Object)(object)ambushPosition != (Object)null && (!requiresOtherTrigger || (requiresOtherTrigger && hitOtherTrigger)))
			{
				startedAmbush = true;
				((MonoBehaviour)this).StartCoroutine("StartAmbush");
			}
		}
	}

	public List<BaseCharacter> TriggerFromBattlefield()
	{
		if (!startedAmbush)
		{
			startedAmbush = true;
			ambushInitiated = true;
			BuildEnemiesList();
			foreach (BaseCharacter enemy in enemyList)
			{
				((Behaviour)enemy).enabled = true;
			}
			if ((Object)(object)objectOnPath != (Object)null)
			{
				objectOnPath.transform.parent = null;
			}
			objectOnPath = null;
			if ((Object)(object)animatorTriggered != (Object)null)
			{
				((Behaviour)animatorTriggered).enabled = false;
			}
			if ((Object)(object)secondAnimatorTriggered != (Object)null)
			{
				((Behaviour)secondAnimatorTriggered).enabled = false;
			}
			return enemyList;
		}
		if (startedAmbush && !ambushInitiated && usePath)
		{
			((MonoBehaviour)this).StopCoroutine("StartLoopBackwards");
			((MonoBehaviour)this).StopCoroutine("StartLoopFoward");
			foreach (BaseCharacter enemy2 in enemyList)
			{
				((Behaviour)enemy2).enabled = true;
			}
			if ((Object)(object)objectOnPath != (Object)null)
			{
				BaseEnemy component = objectOnPath.GetComponent<BaseEnemy>();
				component.ChangeState(CharacterState.Chase, false);
				objectOnPath.SetActive(true);
				objectOnPath.transform.parent = null;
			}
			objectOnPath = null;
			return enemyList;
		}
		return null;
	}

	private void BuildEnemiesList()
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		if (enemyList.Count != 0)
		{
			return;
		}
		for (int i = 0; i < enemies.Count; i++)
		{
			EnemySpawn enemySpawn = enemies[i];
			if ((Object)(object)enemySpawn.enemyPrefab == (Object)null)
			{
				continue;
			}
			BaseEnemy baseEnemy = ObjectPool.GetObject<BaseEnemy>(enemySpawn.enemyPrefab, default(Vector3), true);
			if ((Object)(object)baseEnemy == (Object)null)
			{
				continue;
			}
			baseEnemy.overrideBattlefield = overrideBattlefield;
			baseEnemy.InitWithEnemySpawn(enemySpawn, baseEnemy);
			((Component)baseEnemy).transform.position = ambushPosition.position;
			baseEnemy.ambushBattle = true;
			baseEnemy.ambushTrigger = this;
			if (enemySpawn.spawnInBattlefield)
			{
				baseEnemy.spawnInBattle = true;
				((Component)baseEnemy).gameObject.SetActive(false);
			}
			else if (usePath)
			{
				objectOnPath = ((Component)baseEnemy).gameObject;
				objectOnPath.transform.parent = ((Component)tweenPath).transform;
				objectOnPath.transform.localPosition = Vector3.zero;
				((Behaviour)baseEnemy).enabled = false;
				baseEnemy.FaceTarget(((Component)GameController.Instance.partyLeader).transform);
				if (objectOnPath.layer == LayerMask.NameToLayer("Enemy"))
				{
					RichAI2D component = objectOnPath.GetComponent<RichAI2D>();
					if ((Object)(object)component != (Object)null)
					{
						component.CancelPathfinding();
						component.SetTarget(null, Vector3.zero, 0f);
					}
				}
				baseEnemy.PlayAnimFromFrame(enemyAmbushAnimation, startFrame, clearQueue: true);
				baseEnemy.ChangeState(CharacterState.AmbushAttack, false);
				((ABSAnimationComponent)tweenPath).DOPlay();
			}
			else if (baseEnemy is AxeEnemy)
			{
				((AxeEnemy)baseEnemy).ForceChase(GameController.Instance.partyLeader);
			}
			LootDropperProperties loot = enemies[i].loot;
			LootDropper lootDropper = ((Component)baseEnemy).GetComponent<LootDropper>();
			if ((Object)(object)lootDropper == (Object)null)
			{
				lootDropper = ((Component)baseEnemy).gameObject.AddComponent<LootDropper>();
			}
			lootDropper.SetLootProperties(loot);
			enemyList.Add(baseEnemy);
		}
	}

	private IEnumerator StartAmbush()
	{
		if ((Object)(object)animatorTriggered != (Object)null && !string.IsNullOrEmpty(activationTrigger))
		{
			animatorTriggered.SetTrigger(activationTrigger);
		}
		if ((Object)(object)secondAnimatorTriggered != (Object)null && !string.IsNullOrEmpty(secondActivationTrigger))
		{
			secondAnimatorTriggered.SetTrigger(secondActivationTrigger);
		}
		yield return (object)new WaitForSeconds(spawnDelay);
		if ((Object)(object)secondAnimatorTriggered != (Object)null)
		{
			((Component)secondAnimatorTriggered).gameObject.SetActive(false);
		}
		float particleWaitTime = 0.1f;
		BuildEnemiesList();
		if (forceAmbush)
		{
			foreach (BaseCharacter enemy in enemyList)
			{
				((Behaviour)enemy).enabled = true;
			}
			EventMessenger.Instance.Raise(new InstigateBattleEvent(GameController.Instance.partyLeader, enemyList.ToArray(), InstigateBattleReason.Ambush));
		}
		if ((Object)(object)particleSystem != (Object)null)
		{
			yield return (object)new WaitForSeconds(particleWaitTime);
			((Component)particleSystem).gameObject.SetActive(true);
			particleSystem.Play();
		}
	}

	public void InitiateAmbushEvent()
	{
		if (enemyList.Count > 0)
		{
			foreach (BaseCharacter enemy in enemyList)
			{
				((Behaviour)enemy).enabled = true;
			}
			EventMessenger.Instance.Raise(new InstigateBattleEvent(GameController.Instance.partyLeader, enemyList.ToArray(), InstigateBattleReason.Ambush));
		}
		ambushInitiated = true;
		if ((Object)(object)objectOnPath != (Object)null)
		{
			objectOnPath.transform.parent = null;
		}
		objectOnPath = null;
	}

	public void PathComplete()
	{
		if (ambushInitiated || !((Object)(object)objectOnPath != (Object)null))
		{
			return;
		}
		if (objectOnPath.layer == LayerMask.NameToLayer("Enemy"))
		{
			BaseEnemy component = objectOnPath.GetComponent<BaseEnemy>();
			if ((Object)(object)component != (Object)null)
			{
				component.FaceTarget(((Component)GameController.Instance.partyLeader).transform);
				if (!loopsPath)
				{
					((Behaviour)component).enabled = true;
					if (component.CurrentState.Equals(CharacterState.Chase))
					{
						component.ChangeState(CharacterState.Patrol, false);
					}
					component.ResetPatrol();
					if (component is AxeEnemy)
					{
						((AxeEnemy)component).ForceChase(GameController.Instance.partyLeader);
					}
				}
			}
		}
		if (loopsPath)
		{
			if (!playingBackwards)
			{
				((MonoBehaviour)this).StartCoroutine("StartLoopBackwards");
			}
			else
			{
				((MonoBehaviour)this).StartCoroutine("StartLoopFoward");
			}
		}
		else
		{
			objectOnPath.transform.parent = null;
			objectOnPath = null;
		}
	}

	private IEnumerator StartLoopFoward()
	{
		if (!ambushInitiated)
		{
			if ((Object)(object)objectOnPath != (Object)null)
			{
				objectOnPath.SetActive(false);
			}
			if ((Object)(object)animatorTriggered != (Object)null && !string.IsNullOrEmpty(activationTrigger))
			{
				animatorTriggered.SetTrigger(activationTrigger);
			}
			yield return (object)new WaitForSeconds(loopDelay);
			objectOnPath.SetActive(true);
			if ((Object)(object)particleSystem != (Object)null)
			{
				yield return (object)new WaitForSeconds(0.1f);
				((Component)particleSystem).gameObject.SetActive(true);
				particleSystem.Play();
			}
			if ((Object)(object)animatorTriggered != (Object)null && !string.IsNullOrEmpty(activationTrigger))
			{
				animatorTriggered.SetTrigger(activationTrigger);
			}
			playingBackwards = false;
			TweenExtensions.Restart(((ABSAnimationComponent)tweenPath).tween, true);
			((ABSAnimationComponent)tweenPath).DOPlay();
			BaseEnemy enemy = objectOnPath.GetComponent<BaseEnemy>();
			enemy.PlayAnimFromFrame(enemyAmbushAnimation, startFrame, clearQueue: true);
			enemy.directionVector = -((Component)enemy).transform.forward;
		}
	}

	private IEnumerator StartLoopBackwards()
	{
		if (!ambushInitiated)
		{
			if ((Object)(object)objectOnPath != (Object)null)
			{
				objectOnPath.SetActive(false);
			}
			if ((Object)(object)loopAnimator != (Object)null)
			{
				loopAnimator.SetTrigger(activationTrigger);
			}
			yield return (object)new WaitForSeconds(loopDelay);
			objectOnPath.SetActive(true);
			if ((Object)(object)loopParticles != (Object)null)
			{
				((Component)loopParticles).gameObject.SetActive(true);
				loopParticles.Play();
			}
			if ((Object)(object)loopAnimator != (Object)null)
			{
				loopAnimator.SetTrigger(activationTrigger);
			}
			playingBackwards = true;
			((ABSAnimationComponent)tweenPath).DOPlayBackwards();
			TweenSettingsExtensions.OnRewind<Tween>(tweenPath.GetTween(), (TweenCallback)(() =>
			{
				PathComplete();
			}));
			BaseEnemy enemy = objectOnPath.GetComponent<BaseEnemy>();
			enemy.PlayAnimFromFrame(enemyAmbushAnimation, startFrame, clearQueue: true);
			enemy.directionVector = ((Component)enemy).transform.forward;
		}
	}
}
