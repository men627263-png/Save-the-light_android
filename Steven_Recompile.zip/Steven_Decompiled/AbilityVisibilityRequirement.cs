using System;

[Serializable]
public class AbilityVisibilityRequirement
{
	public enum RequirementType
	{
		RelationshipFull,
		PerkUnlocked,
		WeaponUpgradeUnlocked,
		BadgeEquipped
	}

	public RequirementType type;

	public int intValue;

	public float floatValue;

	public CharacterName characterName1;

	public CharacterName characterName2;

	public AbilityVisibilityRequirement(RequirementType type)
	{
		this.type = type;
	}
}
