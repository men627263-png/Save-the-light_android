using System;
using System.Collections.Generic;

[Serializable]
public class PlatformButtonSpritesGroup
{
	public List<PlatformButtonSprites> platformButtonSprites = new List<PlatformButtonSprites>();

	public List<UIGamepadButtonType> platformButtonTypes = new List<UIGamepadButtonType>();

	public PlatformButtonSprites GetPlatformSpriteForButtonType(UIGamepadButtonType buttonType)
	{
		for (int i = 0; i < platformButtonTypes.Count; i++)
		{
			if (buttonType == platformButtonTypes[i])
			{
				return platformButtonSprites[i];
			}
		}
		return null;
	}

	public bool ContainsButtonType(UIGamepadButtonType buttonType)
	{
		for (int i = 0; i < platformButtonTypes.Count; i++)
		{
			if (buttonType == platformButtonTypes[i])
			{
				return true;
			}
		}
		return false;
	}
}
