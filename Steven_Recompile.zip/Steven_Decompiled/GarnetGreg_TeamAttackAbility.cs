using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Grumpyface;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Abilities/Player Characters/Garnet/Garnet-Greg Team Attack")]
public class GarnetGreg_TeamAttackAbility : BaseAbility, IFusionAbility
{
	[Serializable]
	private class AbilityData
	{
		public Shockwave.ShockwaveData casterInitialShockwaveData = default;

		public Shockwave.ShockwaveData targetInitialShockwaveData = default;

		public ScreenShakeData initialShockwaveScreenShake = default;

		public float syncDelay;

		public Greg_SongAbility.SongSettingsOverride gregSongSettingsOverride;

		[Header("Camera Settings")]
		public float garnetCameraInfluence;

		public float gregCameraInfluence;

		public float gregGarnetFocusedZoom;

		public float battlefieldFocusedZoom;

		[Header("Prefabs")]
		public GameObject bgEffectPrefab;

		public GameObject shockwavePrfab;

		[Header("Animations")]
		public CharacterAnimationNamePair garnetIntroAnim = default;

		public CharacterAnimationNamePair garnetLoopAnim = default;

		public CharacterAnimationNamePair gregIntroAnim = default;

		public CharacterAnimationNamePair gregLoopAnim = default;

		[Header("Abilities")]
		public BaseAbility garnetAbility;

		public BaseAbility gregAbility;

		[Header("Audio")]
		public DelayedAudioEvent voClip = default;

		public GuitarSound[] guitarSounds;
	}

	[SerializeField]
	private AbilityData abilityData;

	public float bgFadeInTime = 0.5f;

	public float bgFadeOutTime = 0.5f;

	public float holdTime = 4f;

	[NonSerialized]
	private GarnetPC garnet;

	[NonSerialized]
	private GregPC greg;

	[NonSerialized]
	private AbstractBattleBG bgEffect;

	public CharacterName[] members => new CharacterName[2]
	{
		CharacterName.Greg,
		CharacterName.Garnet
	};

	protected override void OnInit()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		base.OnInit();
		bgEffect = ObjectPool.GetObject<AbstractBattleBG>(abilityData.bgEffectPrefab, default(Vector3), true);
		((Component)bgEffect).gameObject.SetActive(false);
	}

	public override IEnumerator Play()
	{
		PlayerCharacter member = null;
		for (int i = 0; i < GameController.Instance.Players.Count; i++)
		{
			member = (PlayerCharacter)GameController.Instance.Players[i];
			if (member.characterName == CharacterName.Garnet && member.IsAlive)
			{
				garnet = (GarnetPC)member;
			}
			else if (member.characterName == CharacterName.Greg && member.IsAlive)
			{
				greg = (GregPC)member;
			}
		}
		BaseCharacter target = ((!object.ReferenceEquals(caster, garnet)) ? ((PlayerCharacter)garnet) : ((PlayerCharacter)greg));
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)garnet).transform, abilityData.garnetCameraInfluence)));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)greg).transform, abilityData.gregCameraInfluence)));
		EventMessenger.Instance.Raise(new CameraZoomEvent(abilityData.gregGarnetFocusedZoom));
		while (GameCamera.instance.battleCamera.isMoving)
		{
			yield return null;
		}
		garnet.PlayAnim(abilityData.garnetIntroAnim);
		garnet.AddAnimToQueue(abilityData.garnetLoopAnim);
		greg.PlayAnim(abilityData.gregIntroAnim);
		greg.AddAnimToQueue(abilityData.gregLoopAnim);
		((MonoBehaviour)caster).StartCoroutine(WaitUntilPlayingLoopAnim(target));
		if ((Object)(object)abilityData.voClip.audioEvent != (Object)null)
		{
			abilityData.voClip.Play();
		}
		ToggleUI(0.5f, (Ease)26);
		((Component)bgEffect).gameObject.SetActive(true);
		ParticleSystem[] particleSystems = ((Component)bgEffect).GetComponentsInChildren<ParticleSystem>();
		Color[] rendererStartAlpha = new Color[particleSystems.Length];
		int colorID = Shader.PropertyToID("_Color");
		foreach (ParticleSystem val in particleSystems)
		{
			Renderer component = ((Component)val).GetComponent<Renderer>();
			Color color = component.material.GetColor(colorID);
			component.material.SetColor(colorID, Color.clear);
			TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOColor(component.material, color, bgFadeInTime), (Ease)1);
		}
		tk2dSprite bgSprite = ((Component)bgEffect).GetComponentInChildren<tk2dSprite>();
		bgSprite.color = new Color(1f, 1f, 1f, 0f);
		TweenSettingsExtensions.SetEase<Tweener>(bgSprite.DOFade(1f, bgFadeInTime), (Ease)1);
		bgEffect.AddTargets(caster, target);
		bgEffect.AddTargets(GameController.Instance.Enemies.ConvertAll((Converter<BaseCharacter, ITargetable>)((BaseCharacter character) => character)));
		yield return (object)new WaitForSeconds(holdTime);
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new CameraZoomEvent(abilityData.battlefieldFocusedZoom));
		yield return (object)new WaitForSeconds(0.45f);
		Shockwave casterShockwave = ObjectPool.GetObject<Shockwave>(abilityData.shockwavePrfab, default(Vector3), true);
		casterShockwave.Init(caster, abilityData.casterInitialShockwaveData);
		((Component)casterShockwave).gameObject.SetLayerRecursively(LayerMask.NameToLayer("BossTitleCard"));
		Shockwave targetShockwave = ObjectPool.GetObject<Shockwave>(abilityData.shockwavePrfab, default(Vector3), true);
		targetShockwave.Init(target, abilityData.targetInitialShockwaveData);
		((Component)targetShockwave).gameObject.SetLayerRecursively(LayerMask.NameToLayer("BossTitleCard"));
		EventMessenger.Instance.Raise(new ScreenShakeEvent(abilityData.initialShockwaveScreenShake));
		while (((Component)targetShockwave).gameObject.activeInHierarchy && targetShockwave.targetsHitCount < GameController.Instance.Enemies.Count)
		{
			yield return null;
		}
		yield return (object)new WaitForSeconds(1f);
		foreach (ParticleSystem val2 in particleSystems)
		{
			Renderer psRenderer = ((Component)val2).GetComponent<Renderer>();
			Color originalColor = psRenderer.material.GetColor(colorID);
			TweenSettingsExtensions.OnComplete<Tweener>(TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOColor(psRenderer.material, Color.clear, bgFadeOutTime), (Ease)1), (TweenCallback)(() =>
			{
				//IL_0017: Unknown result type (might be due to invalid IL or missing references)
				psRenderer.material.SetColor(colorID, originalColor);
			}));
		}
		Tweener bgFadeTween = TweenSettingsExtensions.OnComplete<Tweener>(TweenSettingsExtensions.SetEase<Tweener>(bgSprite.DOFade(0f, bgFadeOutTime), (Ease)1), (TweenCallback)(() =>
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			bgSprite.color = Color.white;
			bgEffect.ReturnAllActiveTargets();
			((Component)bgEffect).gameObject.SetActive(false);
		}));
		yield return TweenExtensions.WaitForCompletion((Tween)(object)bgFadeTween);
		yield return (object)new WaitForSeconds(0.1f);
		ToggleUI(0.3f, (Ease)27);
		EventMessenger.Instance.Raise(new CameraZoomEvent(1f));
		greg.isTuned = true;
		((Component)casterShockwave).gameObject.SetLayerRecursively(LayerMask.NameToLayer("Default"));
		((Component)targetShockwave).gameObject.SetLayerRecursively(LayerMask.NameToLayer("Default"));
		garnet.ChangeBattleWaitingSubState(CharacterState.BattleWaiting_Channeling, abilityData.garnetAbility, new List<ITargetable> { garnet }, garnet, false);
		greg.ChangeBattleWaitingSubState(CharacterState.BattleWaiting_Channeling, abilityData.gregAbility, new List<ITargetable> { greg }, greg, false);
	}

	private IEnumerator WaitUntilPlayingLoopAnim(BaseCharacter target)
	{
		yield return (object)new WaitWhile((Func<bool>)(() => greg.IsAnimPlaying(abilityData.gregIntroAnim)));
		Debug.Log((object)"Play Greg Music track");
		PlayGregMusic();
	}

	private void PlayGregMusic()
	{
		AudioSource musicBattleSource = GameController.Instance.musicBattleSource;
		AudioSource val = null;
		if ((Object)(object)musicBattleSource != (Object)null)
		{
			AudioEvent audioEvent = null;
			for (int i = 0; i < abilityData.guitarSounds.Length; i++)
			{
				if (((Object)musicBattleSource.clip).name.Equals(abilityData.guitarSounds[i].mainMusicClipName))
				{
					audioEvent = abilityData.guitarSounds[i].guitarAccompaniment;
					break;
				}
			}
			if ((Object)(object)audioEvent != (Object)null)
			{
				val = audioEvent.Play();
			}
			if ((Object)(object)val != (Object)null)
			{
				TweenSettingsExtensions.SetUpdate<Tweener>(TweenSettingsExtensions.From<Tweener>(ShortcutExtensions.DOFade(val, 0f, 0.15f)), true);
			}
		}
		Greg_SongAbility greg_SongAbility = (Greg_SongAbility)abilityData.gregAbility;
		if ((Object)(object)greg_SongAbility != (Object)null)
		{
			greg_SongAbility.SetGuitarSource(greg, val, musicBattleSource);
			greg_SongAbility.SetSongSettingsOverride(abilityData.gregSongSettingsOverride);
			AbilityEventController.instance.AddLoadedAbilityAsset(greg_SongAbility);
		}
	}

	public override IEnumerator Cancel()
	{
		yield return null;
	}

	protected override void OnCleanUp()
	{
		if ((Object)(object)bgEffect != (Object)null)
		{
			ObjectPool.PoolObject(((Component)bgEffect).gameObject);
			bgEffect = null;
		}
		garnet = null;
		greg = null;
	}

	public override void ResetForReUse()
	{
		EventMessenger.Instance.Raise(new StopScreenShakeEvent());
		garnet = null;
		greg = null;
		bgEffect = null;
		base.ResetForReUse();
	}

	private void ToggleUI(float time, Ease ease = (Ease)26)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Expected Obj, but got Unknown
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Expected Obj, but got Unknown
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Expected Obj, but got Unknown
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		RectTransform val = (RectTransform)((Component)GameController.Instance.battlePortraits).transform;
		RectTransform val2 = (RectTransform)((Component)UIStarMeter.instance).transform;
		RectTransform val3 = (RectTransform)((Component)GameController.Instance.cheeseburgerBackpack).transform;
		TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions46.DOAnchorPosY(val, 0f - val.anchoredPosition.y, time, false), ease);
		if ((Object)(object)UIStarMeter.instance != (Object)null)
		{
			TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions46.DOAnchorPosY(val2, 0f - val2.anchoredPosition.y, time, false), ease);
		}
		TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions46.DOAnchorPosY(val3, 0f - val3.anchoredPosition.y, time, false), ease);
	}

	public bool CanFuse()
	{
		return true;
	}
}
