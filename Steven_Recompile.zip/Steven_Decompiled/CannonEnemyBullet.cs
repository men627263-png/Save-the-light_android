using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Core.PathCore;
using DG.Tweening.Plugins.Options;
using UnityEngine;

public class CannonEnemyBullet : Projectile
{
	public float projectileSpeedOutOfBattle = 10f;

	public float projectileSpeedInBattle = 20f;

	public float arcYOffset = 1f;

	public SphereCollider sphereCollider;

	public ParticleSystem particleSystem;

	public Transform scaleGroup;

	private Vector3 moveDirection;

	private Dictionary<IImpactReactor, float> impactTracker = new Dictionary<IImpactReactor, float>();

	private Collider[] playerHits = new Collider[10];

	private bool waitingToDie;

	public Tweener bulletTween { get; private set; }

	protected override void OnInit()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Expected Obj, but got Unknown
		((Component)this).transform.position = startPosition;
		Vector3 val = target.gameObject.transform.position - ((Component)shooter).transform.position;
		moveDirection = val.normalized;
		Vector3 val2 = ((!inBattle) ? (new Vector3(1f * moveDirection.x, 0f) * (float)((!inBattle) ? 1 : 0)) : targetPositionOffset);
		Vector3[] array = new Vector3[3]
		{
			startPosition,
			default,
			target.gameObject.transform.position + val2
		};
		ref Vector3 reference = ref array[1];
		reference = (array[0] + array[2]) / 2f + new Vector3(0f, arcYOffset);
		float num = ((!inBattle) ? projectileSpeedOutOfBattle : projectileSpeedInBattle);
		bulletTween = (Tweener)(object)TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Path, PathOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Path, PathOptions>>(TweenSettingsExtensions.SetSpeedBased<TweenerCore<Vector3, Path, PathOptions>>(ShortcutExtensions.DOPath(((Component)this).transform, array, num, (PathType)1, (PathMode)1, 10, (Nullable)null)), (Ease)1), (TweenCallback)OnTargetReached);
		TweenExtensions.ForceInit((Tween)(object)bulletTween);
	}

	protected override void Update_IB()
	{
	}

	protected override void Update_OOB()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		if (waitingToDie)
		{
			return;
		}
		Bounds bounds = ((Collider)sphereCollider).bounds;
		int num = Physics.OverlapSphereNonAlloc(bounds.center, sphereCollider.radius, playerHits, LayerMask.GetMask(new string[1] { "TransparentFX" }));
		if (num <= 0)
		{
			return;
		}
		List<BaseCharacter> list = new List<BaseCharacter>();
		Component[] array = null;
		IImpactReactor impactReactor = null;
		impactTracker.Clear();
		bool flag = false;
		Collider val = null;
		for (int i = 0; i < num; i++)
		{
			val = playerHits[i];
			array = ((Component)val).GetComponentsInParent(typeof(IImpactReactor));
			for (int j = 0; j < array.Length; j++)
			{
				impactReactor = (IImpactReactor)array[j];
				if (!impactTracker.ContainsKey(impactReactor) && impactReactor is BaseCharacter && ((Component)(BaseCharacter)impactReactor).tag == "Player" && (Object)(object)(BaseCharacter)impactReactor == (Object)(object)GameController.Instance.partyLeader && ((Component)val).tag == "HurtBox")
				{
					IImpactReactor impactReactor2 = impactReactor;
					BaseCharacter source = shooter;
					Vector3 val2 = impactReactor.transform.position - ((Component)this).transform.position;
					impactReactor2.IncomingImpact(new ImpactResult(source, ImpactResultType.Blunt, val2.normalized, 0f));
					impactTracker.Add(impactReactor, Time.time);
					list.Add((BaseCharacter)impactReactor);
					flag = true;
					break;
				}
			}
			if (flag)
			{
				break;
			}
		}
		if (list.Count > 0)
		{
			EventMessenger.Instance.Raise(new InstigateBattleEvent(shooter, list.ToArray(), InstigateBattleReason.Ambush));
		}
		if (flag)
		{
			((MonoBehaviour)this).StartCoroutine(WaitToDie());
		}
	}

	protected override void OnTargetReached()
	{
		base.OnTargetReached();
		if (!inBattle)
		{
			((MonoBehaviour)this).StartCoroutine(WaitToDie());
		}
	}

	private IEnumerator WaitToDie()
	{
		waitingToDie = true;
		((Component)sphereCollider).GetComponent<Renderer>().enabled = false;
		particleSystem.EnableEmission(enabled: false);
		yield return (object)new WaitForSeconds(1.5f);
		waitingToDie = true;
		((Component)sphereCollider).GetComponent<Renderer>().enabled = true;
		particleSystem.EnableEmission(enabled: false);
		Object.Destroy((Object)(object)((Component)this).gameObject);
	}
}
