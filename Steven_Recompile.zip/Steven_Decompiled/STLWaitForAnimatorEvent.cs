using HutongGames.PlayMaker;
using UnityEngine;

[ActionCategory(/*Could not decode attribute arguments.*/)]
public class STLWaitForAnimatorEvent : FsmStateAction
{
	[RequiredField]
	public AnimatorEventListener animatorEventListener;

	[RequiredField]
	public FsmString stringParameter;

	public FsmEvent fireEvent;

	public override void Reset()
	{
		animatorEventListener = null;
		fireEvent = null;
	}

	public override void OnEnter()
	{
		animatorEventListener.EventTriggered += HandleEventTriggered;
	}

	private void HandleEventTriggered(AnimationEvent evt)
	{
		if (evt.stringParameter.Equals(stringParameter.Value))
		{
			animatorEventListener.EventTriggered -= HandleEventTriggered;
			((FsmStateAction)this).Finish();
			if (fireEvent != null)
			{
				((FsmStateAction)this).Fsm.Event(fireEvent);
			}
		}
	}
}
