public class ReadyForFeederEvent : GameEvent
{
	public IInsectisawFeeder feeder { get; private set; }

	public ReadyForFeederEvent(IInsectisawFeeder feeder)
	{
		this.feeder = feeder;
	}
}
