public class EnemyDiedLateEvent : GameEvent
{
	public BaseCharacter deadEnemy { get; set; }

	public EnemyDiedLateEvent(BaseCharacter deadEnemy)
	{
		this.deadEnemy = deadEnemy;
	}
}
