using System.Collections.Generic;
using UnityEngine;

public class DebugUnlockBadges : MonoBehaviour
{
	public void UnlockAllBadges()
	{
		List<ItemDefinition> badges = GameController.Instance.itemDatabase.GetBadges();
		for (int i = 0; i < badges.Count; i++)
		{
			PlayerGameState.Instance.UnlockBadge(badges[i].uid, save: false);
		}
	}

	public void UnlockAll()
	{
		List<ItemDefinition> badges = GameController.Instance.itemDatabase.GetBadges();
		for (int i = 0; i < badges.Count; i++)
		{
			PlayerGameState.Instance.UnlockBadge(badges[i].uid, save: false);
		}
		AddCharacterToParty(0);
		AddCharacterToParty(1);
		AddCharacterToParty(4);
		AddCharacterToParty(6);
		AddCharacterToParty(7);
		AddCharacterToParty(22);
		AddCharacterToParty(18);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Steven, 1, save: false);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Steven, 2, save: false);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Connie, 1, save: false);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Connie, 2, save: false);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Greg, 1, save: false);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Greg, 2, save: false);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Garnet, 1, save: false);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Garnet, 2, save: false);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Pearl, 1, save: false);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Pearl, 2, save: false);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Amethyst, 1, save: false);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Amethyst, 2, save: false);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Peridot, 1, save: false);
		PlayerGameState.Instance.UnlockWeapon(CharacterName.Peridot, 2, save: false);
		for (int j = 0; j < GameController.Instance.gameplayDatabase.events.Count; j++)
		{
			GamePlayEventDefinition gameplayEventDef = GameController.Instance.gameplayDatabase.events[j];
			if ((Object)(object)gameplayEventDef != (Object)null)
			{
				GamePlayEventData gamePlayEventData = PlayerGameState.Instance.GamePlayEvents.Find((GamePlayEventData x) => x.eventUID.Equals(gameplayEventDef.uid));
				if (gamePlayEventData == null)
				{
					gamePlayEventData = new GamePlayEventData();
					gamePlayEventData.eventUID = gameplayEventDef.uid;
					gamePlayEventData.currentState = gameplayEventDef.debugAllCompleteState;
					gamePlayEventData.currentCount = gameplayEventDef.debugAllCompleteCount;
					PlayerGameState.Instance.GamePlayEvents.Add(gamePlayEventData);
				}
				else
				{
					gamePlayEventData.eventUID = gameplayEventDef.uid;
					gamePlayEventData.currentState = gameplayEventDef.debugAllCompleteState;
					gamePlayEventData.currentCount = gameplayEventDef.debugAllCompleteCount;
				}
			}
		}
		for (int num = 0; num < GameController.Instance.gameplayDatabase.levels.Count; num++)
		{
			int uid = GameController.Instance.gameplayDatabase.levels[num].uid;
			PlayerGameState.Instance.AddToLevelsVisited(uid);
			GamePlayLevelDefinition level = GameController.Instance.gameplayDatabase.GetLevel(uid);
			for (int num2 = 0; num2 < level.chestUIDs.Count; num2++)
			{
				PlayerGameState.Instance.OpenChest(level.chestUIDs[num2]);
			}
			for (int num3 = 0; num3 < level.shopItemUIDs.Count; num3++)
			{
				PlayerGameState.Instance.PurchasedShopItem(level.shopItemUIDs[num3]);
			}
			for (int num4 = 0; num4 < level.secretAreaUIDs.Count; num4++)
			{
				PlayerGameState.Instance.FoundSecretArea(level.secretAreaUIDs[num4]);
			}
			for (int num5 = 0; num5 < level.glintUIDs.Count; num5++)
			{
				PlayerGameState.Instance.CollectGlint(level.glintUIDs[num5]);
			}
			for (int num6 = 0; num6 < level.lightStevenUIDs.Count; num6++)
			{
				PlayerGameState.Instance.CollectGlintSteven(level.lightStevenUIDs[num6]);
			}
			for (int num7 = 0; num7 < level.uniqueItemUIDs.Count; num7++)
			{
				PlayerGameState.Instance.CollectUniqueItem(level.uniqueItemUIDs[num7]);
			}
		}
		PlayerGameState.Save();
	}

	private void AddCharacterToParty(int characterUID)
	{
		PlayerGameState.Instance.AddCharacterToParty(characterUID, addToActiveParty: false);
		PlayerGameState.Instance.AddCharacterData(GameResources.instance.characterDatabase.GetCharacter(characterUID));
		PlayerGameState.Instance.AddCharacterToActiveParty(characterUID);
	}
}
