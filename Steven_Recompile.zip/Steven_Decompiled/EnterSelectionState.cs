public class EnterSelectionState : GameEvent
{
}
