using System;
using System.Collections;
using UnityEngine;

public class Shield_RestoreShieldAbility : BaseAbility
{
	public CharacterAnimationNamePair restoreAnim;

	public override IEnumerator Play()
	{
		yield return (object)new WaitForSeconds(0.5f);
		caster.PlayAnim(restoreAnim);
		yield return (object)new WaitWhile((Func<bool>)(() => caster.animatorTk2d.Playing));
		((IShielder)caster).HasShield = true;
		caster.PlayAnim(caster.GetIdleAnimation());
	}

	public override IEnumerator Cancel()
	{
		yield break;
	}
}
