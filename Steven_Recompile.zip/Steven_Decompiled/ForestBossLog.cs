using Grumpyface;
using UnityEngine;

public class ForestBossLog : MonoBehaviour, IPoolable
{
	public Transform log;

	public Vector3[] logRotations;

	private int logIndex;

	public void Init(int logIndex)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		this.logIndex = Mathf.Clamp(logIndex, 0, logRotations.Length - 1);
		log.localRotation = Quaternion.Euler(logRotations[logIndex]);
	}

	public void ResetObject()
	{
		Init(0);
	}
}
