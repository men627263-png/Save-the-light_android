using DG.Tweening;
using UnityEngine;

public class Sequences : MonoBehaviour
{
	public Transform target;

	private void Start()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		Sequence val = DOTween.Sequence();
		TweenSettingsExtensions.Append(val, (Tween)(object)ShortcutExtensions.DOMoveY(target, 2f, 1f, false));
		TweenSettingsExtensions.Join(val, (Tween)(object)ShortcutExtensions.DORotate(target, new Vector3(0f, 135f, 0f), 1f, (RotateMode)0));
		TweenSettingsExtensions.Append(val, (Tween)(object)ShortcutExtensions.DOScaleY(target, 0.2f, 1f));
		TweenSettingsExtensions.Insert(val, 0f, (Tween)(object)TweenSettingsExtensions.SetRelative<Tweener>(ShortcutExtensions.DOMoveX(target, 4f, TweenExtensions.Duration((Tween)(object)val, true), false)));
		TweenSettingsExtensions.SetLoops<Sequence>(val, 4, (LoopType)1);
	}
}
