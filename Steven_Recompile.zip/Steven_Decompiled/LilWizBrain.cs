using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Brains/Enemies/Lil Wiz")]
public class LilWizBrain : BattleBrain
{
	[SerializeField]
	[Tooltip("The Heal Shockwave ability will not be in consideration until team health ratio is equal to or less than the max value. A health ratio at or below the min value will apply the maximum Heal Weight Bonus.")]
	private RangedFloat healthThreshold;

	[SerializeField]
	private int healMaxWeightBonus;

	public override Decision MakeDecision(BaseCharacter caster, List<BaseCharacter> playerParty, List<BaseCharacter> enemyParty, List<ITargetable> playerMinions, List<ITargetable> enemyMinions, List<ITargetable> neutralTargets)
	{
		BaseAbility chosenAbility = null;
		List<ITargetable> targets = null;
		bool moveToTargets = false;
		List<AbilityEntry> list = new List<AbilityEntry>();
		for (int i = 0; i < abilities.Length; i++)
		{
			if (abilities[i].weight <= 0)
			{
				continue;
			}
			list.Add(abilities[i]);
			if (abilities[i].ability.abilityType == AbilityType.Heal)
			{
				float healthRatio = GetHealthRatio(enemyParty);
				if (healthRatio <= healthThreshold.maxValue)
				{
					AbilityEntry lastItem = list.GetLastItem();
					float num = 1f - (Mathf.Max(healthThreshold.minValue, healthRatio) - healthThreshold.minValue) / (healthThreshold.maxValue - healthThreshold.minValue);
					lastItem.weight = abilities[i].weight + Mathf.RoundToInt((float)healMaxWeightBonus * num);
					list[list.Count - 1] = lastItem;
				}
			}
		}
		while ((Object)(object)chosenAbility == (Object)null && list.Count > 0)
		{
			chosenAbility = GetRandomAbilityWeighted(list);
			if (chosenAbility.abilityType == AbilityType.Heal)
			{
				float healthRatio2 = GetHealthRatio(enemyParty);
				if (healthRatio2 > healthThreshold.maxValue)
				{
					list.Remove(list.Find((AbilityEntry x) => (Object)(object)x.ability == (Object)(object)chosenAbility));
					chosenAbility = null;
				}
			}
			else
			{
				if (chosenAbility.abilityType != AbilityType.Buff)
				{
					continue;
				}
				int num2 = 0;
				for (int num3 = 0; num3 < enemyParty.Count; num3++)
				{
					if (!(enemyParty[num3] is LilWiz))
					{
						num2++;
					}
				}
				if (num2 == 0)
				{
					list.Remove(list.Find((AbilityEntry x) => (Object)(object)x.ability == (Object)(object)chosenAbility));
					chosenAbility = null;
				}
			}
		}
		if ((Object)(object)chosenAbility != (Object)null)
		{
			targets = GetTargets(caster, chosenAbility, playerParty, enemyParty, playerMinions, enemyMinions, neutralTargets);
			moveToTargets = list.Find((AbilityEntry x) => (Object)(object)x.ability == (Object)(object)chosenAbility).moveToTargets;
		}
		return new Decision(chosenAbility, targets, moveToTargets);
	}

	public float GetHealthRatio(List<BaseCharacter> characters)
	{
		int num = 0;
		int num2 = 0;
		for (int i = 0; i < characters.Count; i++)
		{
			num += characters[i].currentHealth;
			num2 += characters[i].Stats.MaxHealthStat.Value;
		}
		return (float)num / (float)num2;
	}
}
