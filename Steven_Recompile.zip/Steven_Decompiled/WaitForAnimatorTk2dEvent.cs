using System;
using UnityEngine;

public class WaitForAnimatorTk2dEvent : CustomYieldInstruction
{
	private string targetInfo = string.Empty;

	private bool _keepWaiting = true;

	public override bool keepWaiting => _keepWaiting;

	public WaitForAnimatorTk2dEvent(tk2dSpriteAnimator animator, string eventInfo)
	{
		animator.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Combine(animator.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEventTriggered));
		targetInfo = eventInfo;
		_keepWaiting = true;
	}

	private void HandleAnimationEventTriggered(tk2dSpriteAnimator animator, tk2dSpriteAnimationClip clip, int frame)
	{
		if (clip.GetFrame(frame).eventInfo == targetInfo)
		{
			animator.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Remove(animator.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEventTriggered));
			_keepWaiting = false;
		}
	}
}
