using UnityEngine;

public class LilWizShockwaveDamage : LilWizShockwave
{
	protected override void OnTargetReached(ITargetable target, float progress)
	{
		float damageValue = Mathf.Lerp(shockwaveData.maxValue, shockwaveData.minValue, progress);
		BattleHelper.DoDamage(source, target.damageReceiver, new DamageInfo(DamageInfo.ValueType.AttackModifier, damageValue, CombatType.Ranged), allowDeath: true);
	}
}
