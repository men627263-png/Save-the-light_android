using System;
using UnityEngine;

[Serializable]
public class AEFrame
{
	public int index;

	public Vector3 scale;

	public Vector3 pivot;

	public float rotation;

	public float opacity;

	public Vector3 position;

	public Vector3 positionUnity;

	public bool isVisible;

	public bool isNothingChanged;

	public bool isScaleChanged = true;

	public bool isPivotChanged = true;

	public bool isRotationChanged = true;

	public bool isOpacityChanged = true;

	public bool isPositionChanged = true;

	public bool isVisibilityChanged = true;

	public void SetPosition(Vector3 pos)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		position = pos;
		positionUnity = position;
		positionUnity.y = 0f - positionUnity.y;
	}

	public void CompareToFrame(AEFrame lastFrame)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		if (lastFrame != null)
		{
			isScaleChanged = !V3Equal(scale, lastFrame.scale);
			isPivotChanged = !V3Equal(pivot, lastFrame.pivot);
			isPositionChanged = !V3Equal(positionUnity, lastFrame.positionUnity);
			isRotationChanged = !FCompare(rotation, lastFrame.rotation);
			isOpacityChanged = !FCompare(opacity, lastFrame.opacity);
			isVisibilityChanged = isVisible != lastFrame.isVisible;
			isNothingChanged = !isScaleChanged && !isPivotChanged && !isPositionChanged && !isRotationChanged && !isOpacityChanged && !isVisibilityChanged;
		}
	}

	private static bool V3Equal(Vector3 a, Vector3 b)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		return Vector3.SqrMagnitude(a - b) < 0.0001f;
	}

	private static bool FCompare(float a, float b)
	{
		return Mathf.Abs(a - b) < 0.0001f;
	}
}
