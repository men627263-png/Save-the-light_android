using UnityEngine;

public class Stun : StatusEffect
{
	private BaseCharacter character;

	private float duration;

	private bool removeOnDamage;

	private float timer;

	public sealed override StatusEffectType type => StatusEffectType.Debuff;

	public sealed override StatusEffectName effectName => StatusEffectName.Stun;

	public sealed override bool isResettable => true;

	public sealed override bool isStackable => false;

	public sealed override bool isPersistent => false;

	public override bool isSavable => false;

	public override bool isOwnerValid => owner is BaseCharacter;

	public Stun(ITargetable owner, float duration, bool removeOnDamage = true)
		: base(owner)
	{
		this.duration = duration;
		this.removeOnDamage = removeOnDamage;
	}

	protected sealed override void InitEffect()
	{
		character = (BaseCharacter)owner;
		timer = duration;
		if (removeOnDamage)
		{
			character.DamageReceived += HandleDamageReceived;
		}
		character.InterruptCasting(force: true);
		character.InterruptChanneling(force: true);
		character.DisableBattleWaitingSubState();
		if (!character.CurrentState.Equals(CharacterState.KnockedBack))
		{
			character.ReturnToBattleWaiting();
			character.PlayAnim(character.GetIdleAnimation(), clearQueue: true);
		}
	}

	protected sealed override void UpdateEffect()
	{
		if (timer >= 0f)
		{
			timer -= Time.deltaTime;
			if (timer <= 0f)
			{
				Remove();
			}
		}
	}

	protected sealed override void ResetEffect()
	{
		timer = duration;
	}

	protected sealed override void RemoveEffect()
	{
	}

	protected sealed override void CleanUp()
	{
		if ((Object)(object)character != (Object)null)
		{
			character.DamageReceived -= HandleDamageReceived;
		}
		character = null;
	}

	protected sealed override void InitSaveData(StatusEffectSaveData saveData)
	{
		saveData.startingData.floatValue1 = duration;
		saveData.data.floatValue1 = timer;
	}

	public sealed override void LoadSaveData(StatusEffectData data)
	{
		timer = data.floatValue1;
	}

	private void HandleDamageReceived(DamageResult obj)
	{
		if (obj.totalDamage > 0)
		{
			Remove();
		}
	}
}
