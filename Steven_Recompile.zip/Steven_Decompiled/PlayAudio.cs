using UnityEngine;

public class PlayAudio : MonoBehaviour
{
	public DelayedAudioEvent audioEvent;

	private void OnEnable()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		audioEvent.Play(((Component)this).transform.position);
	}
}
