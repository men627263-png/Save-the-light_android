public class PauseEvent : GameEvent
{
	public bool isPaused { get; private set; }

	public PauseEvent(bool isPaused)
	{
		this.isPaused = isPaused;
	}
}
