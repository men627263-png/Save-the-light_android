using System;
using System.Collections;
using DG.Tweening;
using DG.Tweening.Core;
using Grumpyface;
using UnityEngine;

public class GarnetPC : PlayerCharacter
{
	[Serializable]
	public class CharacterProperties
	{
		[Header("Object References")]
		public GameObject deathEffect;
	}

	[Serializable]
	private struct ActionData
	{
		public float impactForce;

		public CharacterAnimationNamePair punchAnim;

		public DelayedAudioEvent punchSound;

		public DamageInfo damageInfo;
	}

	[Header("Garnet Specific")]
	[SerializeField]
	private CharacterProperties _characterProperties;

	[SerializeField]
	private ActionData actionData;

	private bool ignoreHit;

	public CharacterProperties characterProperties => _characterProperties;

	protected override DamageInfo actionDamageInfo => actionData.damageInfo;

	protected override void Awake()
	{
		base.Awake();
		characterName = CharacterName.Garnet;
		AddTransitionsToState(CharacterState.Action, new Enum[5]
		{
			CharacterState.Stand,
			CharacterState.Fall,
			CharacterState.Land,
			CharacterState.KnockedBack,
			CharacterState.Hurt
		});
		AddTransitionsToState(CharacterState.Stand, new Enum[1] { CharacterState.Action });
		AddTransitionsToState(CharacterState.Walk, new Enum[1] { CharacterState.Action });
		AddTransitionsToState(CharacterState.Run, new Enum[1] { CharacterState.Action });
		AddTransitionsToState(CharacterState.Fall, new Enum[1] { CharacterState.Action });
		AddTransitionsToState(CharacterState.Land, new Enum[1] { CharacterState.Action });
		_characterProperties.deathEffect.SetActive(false);
	}

	protected virtual void EnterAction(Enum previous, params object[] args)
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		doUpdateMovement = false;
		ignoreHit = false;
		if ((Object)(object)hitBoxManager != (Object)null)
		{
			hitBoxManager.OnHit += HandleOnHit;
		}
		PlayAnim(actionData.punchAnim);
		AddAnimToQueue(GetIdleAnimation());
		actionData.punchSound.Play(((Component)this).transform.position);
	}

	protected virtual void UpdateAction()
	{
		if (!IsAnimPlaying(actionData.punchAnim))
		{
			if (grounded)
			{
				ChangeState(CharacterState.Stand, false);
			}
			else
			{
				ChangeState(CharacterState.Fall, false);
			}
		}
	}

	protected void ExitAction(Enum next)
	{
		doAllowInput = true;
		allowAIInput = false;
		doUpdateMovement = true;
		doUpdateDirection = true;
		if ((Object)(object)hitBoxManager != (Object)null)
		{
			hitBoxManager.OnHit -= HandleOnHit;
		}
	}

	protected override void EnterDeath(Enum previous, object[] args)
	{
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		doUpdateMovement = false;
		doUpdateDirection = false;
		InterruptReturningToBattlefield();
		DisableBattleWaitingSubState();
		hasBeenDefeatedThisBattle = true;
		((Component)AnimatorTransform).gameObject.SetActive(false);
		((Component)shadow).gameObject.SetActive(false);
		_characterProperties.deathEffect.SetActive(true);
		if ((Object)(object)characterSounds.deathSound.audioEvent != (Object)null)
		{
			characterSounds.deathSound.Play(((Component)this).transform.position);
		}
	}

	protected override IEnumerator ReviveSequence(float reviveHealthPercent)
	{
		if ((Object)(object)fallenRadialTimer != (Object)null)
		{
			ObjectPool.PoolObject(((Component)fallenRadialTimer).gameObject);
			fallenRadialTimer = null;
		}
		_characterProperties.deathEffect.SetActive(false);
		((Component)AnimatorTransform).gameObject.SetActive(true);
		((Component)shadow).gameObject.SetActive(true);
		PlayAnim(GetIdleAnimation());
		animatorTk2d.Sprite.color = new Color(1f, 1f, 1f, 0f);
		shadow.Alpha = 0f;
		reviveTween = DOTween.ToAlpha((DOGetter<Color>)(() =>
		{
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			return animatorTk2d.Sprite.color;
		}), (DOSetter<Color>)((Color x) =>
		{
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			animatorTk2d.Sprite.color = x;
		}), 1f, 0.75f);
		DOTween.To((DOGetter<float>)(() => shadow.Alpha), (DOSetter<float>)((float x) =>
		{
			shadow.Alpha = x;
		}), 1f, 0.75f);
		yield return TweenExtensions.WaitForCompletion((Tween)(object)reviveTween);
		yield return (object)new WaitForSeconds(0.25f);
		reviveHealthPercent = Mathf.Clamp01(reviveHealthPercent);
		currentHealth = Mathf.CeilToInt((float)Stats.MaxHealthStat.Value * reviveHealthPercent);
		PlayAnim(GetIdleAnimation());
		ReturnToBattleWaiting();
		doUpdateDirection = true;
		doUpdateMovement = true;
		EventMessenger.Instance.Raise(new PlayerCharacterRevivedEvent(this));
	}

	protected override IEnumerator BattleReviveSequence(float reviveHealthPercent)
	{
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)this).transform, 1.5f)));
		EventMessenger.Instance.Raise(new CameraZoomEvent(1.2f));
		yield return (object)new WaitForSeconds(0.5f);
		if ((Object)(object)fallenRadialTimer != (Object)null)
		{
			ObjectPool.PoolObject(((Component)fallenRadialTimer).gameObject);
			fallenRadialTimer = null;
		}
		_characterProperties.deathEffect.SetActive(false);
		((Component)AnimatorTransform).gameObject.SetActive(true);
		((Component)shadow).gameObject.SetActive(true);
		PlayAnim(GetIdleAnimation());
		if ((Object)(object)characterSounds.revivedVOSound != (Object)null && !GameController.Instance.CurrentState.Equals(GameControllerState.Battle_Victory))
		{
			characterSounds.revivedVOSound.Play();
		}
		animatorTk2d.Sprite.color = new Color(1f, 1f, 1f, 0f);
		shadow.Alpha = 0f;
		reviveTween = DOTween.ToAlpha((DOGetter<Color>)(() =>
		{
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			return animatorTk2d.Sprite.color;
		}), (DOSetter<Color>)((Color x) =>
		{
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			animatorTk2d.Sprite.color = x;
		}), 1f, 0.75f);
		DOTween.To((DOGetter<float>)(() => shadow.Alpha), (DOSetter<float>)((float x) =>
		{
			shadow.Alpha = x;
		}), 1f, 0.75f);
		yield return TweenExtensions.WaitForCompletion((Tween)(object)reviveTween);
		yield return (object)new WaitForSeconds(0.25f);
		reviveHealthPercent = Mathf.Clamp01(reviveHealthPercent);
		currentHealth = Mathf.CeilToInt((float)Stats.MaxHealthStat.Value * reviveHealthPercent);
		if (!V3Equal(((Component)this).transform.position, battlePosition) && Vector3.Distance(((Component)this).transform.position, battlePosition) > RichAI2D.endReachedDistance)
		{
			RichAI2D.MoveToPosition(battlePosition, baseMovementSpeed);
			yield return new WaitUntilAIReachedTarget(RichAI2D);
		}
		PlayAnim(GetIdleAnimation());
		ReturnToBattleWaiting();
		doUpdateDirection = true;
		doUpdateMovement = true;
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new CameraZoomEvent(1f));
		EventMessenger.Instance.Raise(new PlayerCharacterRevivedEvent(this));
	}

	public override void OnOutgoingDamage(DamageResult damageResult)
	{
		if (HasPerkUnlocked(6) && !damageResult.isCritical)
		{
			float num = (float)damageResult.target.CurrentHealthValue / (float)damageResult.target.MaxHealthValue;
			if (num <= 0.2f)
			{
				DamageResult other = BattleHelper.CalculateDamage(damageResult.source, damageResult.target, damageResult.damageInfo, damageResult.allowDeath, damageResult.sourceAbility, forceCritical: true);
				damageResult.Copy(other);
			}
		}
		if (HasPerkUnlocked(5) && !damageResult.isCritical && damageResult.target is BaseCharacter && ((BaseCharacter)damageResult.target).StatusEffectManager.HasStatusEffect(StatusEffectName.Stun))
		{
			DamageResult other2 = BattleHelper.CalculateDamage(damageResult.source, damageResult.target, damageResult.damageInfo, damageResult.allowDeath, damageResult.sourceAbility, forceCritical: true);
			damageResult.Copy(other2);
		}
		base.OnOutgoingDamage(damageResult);
	}

	public override void OnIncomingDamage(DamageResult damageResult)
	{
		base.OnIncomingDamage(damageResult);
		if (HasPerkUnlocked(2) && damageResult.impactResult != null)
		{
			damageResult.impactResult.force = 0f;
		}
	}

	public override void OnDamageReceived(DamageResult damageResult)
	{
		base.OnDamageReceived(damageResult);
		if (HasPerkUnlocked(3) && damageResult.combatType == CombatType.Melee && damageResult.starBonusType == AbilityStarBonusType.Perfect && damageResult.source != null && damageResult.source is IDamageReceiver)
		{
			DamageInfo damageInfo = new DamageInfo(DamageInfo.ValueType.FlatAmount, Mathf.RoundToInt((float)damageResult.totalDamage * 0.25f), CombatType.None);
			BattleHelper.DoDamage(this, (IDamageReceiver)damageResult.source, damageInfo, allowDeath: true);
		}
	}

	protected override void HandleStatusEffectAdded(StatusEffect effect)
	{
		base.HandleStatusEffectAdded(effect);
		if (HasPerkUnlocked(2) && effect.effectName.Equals(StatusEffectName.Stun))
		{
			effect.Remove();
		}
	}

	public override void ResetObject()
	{
		base.ResetObject();
		_characterProperties.deathEffect.SetActive(false);
		((Component)AnimatorTransform).gameObject.SetActive(true);
		((Component)shadow).gameObject.SetActive(true);
	}
}
