using UnityEngine;

public class PrismWindowBG : MonoBehaviour
{
	public tk2dSprite bgSprite;

	public ParticleSystem particles;

	public Color onTrackColor = Color.white;

	public Color offTrackColor = Color.white;

	public float leftBounds = -120f;

	public float rightBounds = -60f;

	public float nearBounds = 70f;

	private PlayerCharacter _stevenCharacter;

	private CrystalVignette _crystalVignette;

	private PlayerCharacter stevenCharacter
	{
		get
		{
			if ((Object)(object)_stevenCharacter == (Object)null)
			{
				_stevenCharacter = GameController.Instance.GetCharacterFromActiveParty(CharacterName.Steven);
			}
			return _stevenCharacter;
		}
	}

	private CrystalVignette crystalVignette
	{
		get
		{
			if ((Object)(object)_crystalVignette == (Object)null)
			{
				_crystalVignette = ((Component)GameCamera.instance.cameraTk2d).gameObject.GetComponent<CrystalVignette>();
			}
			return _crystalVignette;
		}
	}

	public PrismWindowBG()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Update()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)stevenCharacter != (Object)null)
		{
			if (((Component)stevenCharacter).transform.position.x < leftBounds || ((Component)stevenCharacter).transform.position.x > rightBounds || ((Component)stevenCharacter).transform.position.z < nearBounds)
			{
				bgSprite.color = Color.Lerp(bgSprite.color, offTrackColor, Time.deltaTime);
				crystalVignette.Alpha = Mathf.Lerp(crystalVignette.Alpha, 0f, Time.deltaTime);
			}
			else
			{
				bgSprite.color = Color.Lerp(bgSprite.color, onTrackColor, Time.deltaTime);
				crystalVignette.Alpha = Mathf.Lerp(crystalVignette.Alpha, 1f, Time.deltaTime);
			}
		}
	}
}
