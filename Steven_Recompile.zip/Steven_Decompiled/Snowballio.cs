using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Snowballio : BaseEnemy
{
	public enum SnowballioSize
	{
		Small,
		Large
	}

	public enum SnowballioState
	{
		None,
		Spiked
	}

	[Serializable]
	private class CharacterProperties
	{
		[Header("Animations")]
		public CharacterAnimationNamePair idleLargeAnim = default;

		public CharacterAnimationNamePair walkLargeAnim = default;

		public CharacterAnimationNamePair runLargeAnim = default;

		public CharacterAnimationNamePair hurtLargeAnim = default;

		public CharacterAnimationNamePair deathLargeAnim = default;

		public CharacterAnimationNamePair stunnedLargeAnim = default;

		public CharacterAnimationNamePair growAnim = default;

		public CharacterAnimationNamePair shrinkAnim = default;

		public CharacterAnimationNamePair spikeIntroSmallAnim = default;

		public CharacterAnimationNamePair spikeIdleSmallAnim = default;

		public CharacterAnimationNamePair spikeAttackSmallAnim = default;

		public CharacterAnimationNamePair spikeIntroLargeAnim = default;

		public CharacterAnimationNamePair spikeIdleLargeAnim = default;

		public CharacterAnimationNamePair spikeAttackLargeAnim = default;

		[Header("Sound")]
		public DelayedAudioEvent growSound = default;

		public DelayedAudioEvent spikesAppearSound = default;

		public DelayedAudioEvent spikesLaunchSound = default;

		[Header("Tweakables")]
		public int maxLargeHealth;

		public int defenseBonus;

		public Vector2 largeCenterTopOffset;

		public Vector3 largeCenterOffset;

		public DamageInfo spikeCounterDamageSmall;

		public DamageInfo spikeCounterDamageLarge;
	}

	[SerializeField]
	private EnemyPatrolProperties patrolProperties;

	[SerializeField]
	private EnemyChaseProperties chaseProperties;

	[SerializeField]
	private ActionData actionData;

	[SerializeField]
	private CharacterProperties characterProperties;

	[SerializeField]
	private SnowballioSize activeSize;

	[SerializeField]
	private SnowballioState activeState;

	private int largeHealth;

	private bool isIdle;

	private bool isMoving;

	private float idleStartTime;

	private List<Vector3> directions = new List<Vector3>(8);

	private Collider[] playerHits = new Collider[4];

	private PlayerCharacter chaseTargetCharacter;

	private Vector3 chaseStartPos;

	private bool returningToPatrolPos;

	private bool battleInstigated;

	private Vector3 instigateBattleTargetPos = Vector3.zero;

	private int moveCount;

	public sealed override Vector3 centerTopPosition
	{
		get
		{
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_004c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Unknown result type (might be due to invalid IL or missing references)
			if (activeSize == SnowballioSize.Large)
			{
				return AnimatorTransform.TransformPoint(new Vector3(characterProperties.largeCenterTopOffset.x * (float)((horizontalDir != Direction.Left) ? 1 : (-1)), characterProperties.largeCenterTopOffset.y, 0f));
			}
			return base.centerTopPosition;
		}
	}

	public sealed override Vector3 CenterPosition
	{
		get
		{
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			if (activeSize == SnowballioSize.Large)
			{
				return base.CenterPosition + characterProperties.largeCenterOffset;
			}
			return base.CenterPosition;
		}
	}

	public SnowballioSize ActiveSize => activeSize;

	public SnowballioState ActiveState => activeState;

	public Snowballio()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
	}

	protected sealed override void Awake()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		base.Awake();
		patrolProperties.patrolAreaPos = ((Component)this).transform.position;
	}

	protected sealed override void HandleOnHit(Collider[] hits)
	{
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		List<BaseCharacter> list = new List<BaseCharacter>();
		Component[] array = null;
		IImpactReactor impactReactor = null;
		int num = hits.Length;
		for (int i = 0; i < num; i++)
		{
			array = ((Component)hits[i]).GetComponentsInParent(typeof(IImpactReactor));
			if (array.Length <= 0)
			{
				continue;
			}
			for (int j = 0; j < array.Length; j++)
			{
				impactReactor = (IImpactReactor)array[j];
				if (impactTracker.ContainsKey(impactReactor))
				{
					continue;
				}
				Vector3 position;
				if (impactReactor is BaseCharacter)
				{
					if (((Component)(BaseCharacter)impactReactor).tag == "Player" && ((Component)hits[i]).tag == "HurtBox")
					{
						IImpactReactor impactReactor2 = impactReactor;
						Vector3 val = impactReactor.transform.position - ((Component)this).transform.position;
						Vector3 normalized = val.normalized;
						float impactForce = actionData.impactForce;
						position = default;
						impactReactor2.IncomingImpact(new ImpactResult(this, ImpactResultType.Blunt, normalized, impactForce, position));
						impactTracker.Add(impactReactor, Time.time);
						list.Add((BaseCharacter)impactReactor);
					}
				}
				else
				{
					IImpactReactor impactReactor3 = impactReactor;
					position = impactReactor.transform.position - ((Component)this).transform.position;
					impactReactor3.IncomingImpact(new ImpactResult(this, ImpactResultType.Blunt, position.normalized, actionData.impactForce));
					impactTracker.Add(impactReactor, Time.time);
				}
			}
		}
		if (list.Count > 0)
		{
			if (ambushBattle && (Object)(object)ambushTrigger != (Object)null)
			{
				ambushTrigger.InitiateAmbushEvent();
			}
			else
			{
				EventMessenger.Instance.Raise(new InstigateBattleEvent(this, list.ToArray(), InstigateBattleReason.Ambush));
			}
		}
	}

	public void SetActiveState(SnowballioState newState)
	{
		if (newState != activeState)
		{
			activeState = newState;
		}
	}

	protected sealed override void EnterStand(Enum previous, object[] args)
	{
		base.EnterStand(previous, args);
		PlayAnim(GetIdleAnimation());
	}

	protected void EnterPatrol(Enum previous, params object[] args)
	{
		isIdle = true;
		isMoving = false;
		idleStartTime = -1f;
		PlayAnim(GetIdleAnimation());
		RichAI2D richAI2D = base.richAI2D;
		richAI2D.targetReached = (Action)Delegate.Combine(richAI2D.targetReached, new Action(OnPatrolTargetReached));
	}

	protected void UpdatePatrol()
	{
		//IL_029a: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_034b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_035b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0360: Unknown result type (might be due to invalid IL or missing references)
		//IL_0364: Unknown result type (might be due to invalid IL or missing references)
		//IL_0369: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		if (isIdle && Time.time > idleStartTime + patrolProperties.idleTime)
		{
			directions.Clear();
			float num = Random.Range(patrolProperties.minPatrolDist, patrolProperties.patrolRadius);
			directions.Add(Vector3.right * num);
			List<Vector3> list = directions;
			Vector3 val = Vector3.right + Vector3.forward;
			list.Add(val.normalized * num);
			directions.Add(Vector3.forward * num);
			List<Vector3> list2 = directions;
			Vector3 val2 = Vector3.left + Vector3.forward;
			list2.Add(val2.normalized * num);
			directions.Add(Vector3.left * num);
			List<Vector3> list3 = directions;
			Vector3 val3 = Vector3.left + Vector3.back;
			list3.Add(val3.normalized * num);
			directions.Add(Vector3.back * num);
			List<Vector3> list4 = directions;
			Vector3 val4 = Vector3.right + Vector3.back;
			list4.Add(val4.normalized * num);
			for (int num2 = directions.Count - 1; num2 >= 0; num2--)
			{
				Vector3 val5 = directions[num2];
				if (Vector3.Distance(patrolProperties.patrolAreaPos, ((Component)this).transform.position + val5) > patrolProperties.patrolRadius)
				{
					directions.RemoveAt(num2);
				}
			}
			Vector3 zero = Vector3.zero;
			zero = ((directions.Count <= 0) ? patrolProperties.patrolAreaPos : (((Component)this).transform.position + directions[Random.Range(0, directions.Count)]));
			if (patrolProperties.startLeft && !patrolProperties.startLeftTriggered)
			{
				zero = ((Component)this).transform.position + Vector3.left * num;
				patrolProperties.startLeftTriggered = true;
			}
			FaceTarget(zero);
			PlayAnim(GetWalkAnimation());
			isIdle = false;
			isMoving = true;
			richAI2D.MoveToPosition(zero, patrolProperties.patrolMoveSpeed, allowAnimation: false);
		}
		float num3 = Mathf.Atan2(richAI2D.CurrentMoveDirection.z, richAI2D.CurrentMoveDirection.x) * 57.29578f;
		int num4 = Physics.OverlapSphereNonAlloc(((Component)this).transform.position, aggroProperties.aggroDist, playerHits, LayerMask.GetMask(new string[1] { "Player" }));
		PlayerCharacter playerCharacter = null;
		Collider val6 = null;
		for (int i = 0; i < num4; i++)
		{
			val6 = playerHits[i];
			playerCharacter = ((Component)val6).GetComponent<PlayerCharacter>();
			if ((Object)(object)playerCharacter != (Object)null && (Object)(object)playerCharacter == (Object)(object)GameController.Instance.partyLeader)
			{
				Vector3 val7 = ((Component)val6).transform.position - ((Component)this).transform.position;
				Vector3 normalized = val7.normalized;
				float num5 = Mathf.Atan2(normalized.z, normalized.x) * 57.29578f;
				float num6 = Mathf.DeltaAngle(num3, num5);
				if (Mathf.Abs(num6) <= aggroProperties.aggroViewConeAngle / 2f)
				{
					ChangeState(CharacterState.Chase, false, playerCharacter);
					break;
				}
			}
		}
	}

	protected void ExitPatrol(Enum next)
	{
		RichAI2D richAI2D = base.richAI2D;
		richAI2D.targetReached = (Action)Delegate.Remove(richAI2D.targetReached, new Action(OnPatrolTargetReached));
		base.richAI2D.CancelPathfinding();
	}

	public override void ResetPatrol()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		patrolProperties.patrolAreaPos = ((Component)this).transform.position;
		OnPatrolTargetReached();
	}

	private void OnPatrolTargetReached()
	{
		isIdle = true;
		isMoving = false;
		idleStartTime = Time.time;
		PlayAnim(GetIdleAnimation());
	}

	protected void EnterChase(Enum previous, params object[] args)
	{
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		if (args.Length > 0)
		{
			chaseTargetCharacter = (PlayerCharacter)args[0];
		}
		returningToPatrolPos = false;
		RichAI2D richAI2D = base.richAI2D;
		richAI2D.targetReached = (Action)Delegate.Combine(richAI2D.targetReached, new Action(OnChaseTargetReached));
		hitBoxManager.OnHit += HandleOnHit;
		if (previous.Equals(CharacterState.Action) || previous.Equals(CharacterState.Land))
		{
			base.richAI2D.SetPathfindingAllowed(allowed: true);
			base.richAI2D.SetTarget(((Component)chaseTargetCharacter).transform, Vector3.zero, chaseProperties.chaseSpeed);
			return;
		}
		base.richAI2D.SetPathfindingAllowed(allowed: false);
		PlayAnim(chaseProperties.alert);
		chaseProperties.alertSound.Play(((Component)this).transform.position);
		tk2dSpriteAnimatorPlus tk2dSpriteAnimatorPlus2 = animatorTk2d;
		tk2dSpriteAnimatorPlus2.AnimationCompleted = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>)Delegate.Combine(tk2dSpriteAnimatorPlus2.AnimationCompleted, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>(AlertFinished));
		chaseStartPos = ((Component)this).transform.position;
	}

	protected void UpdateChase()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		if (Vector3.Distance(((Component)this).transform.position, chaseStartPos) > chaseProperties.maxChaseDist && !returningToPatrolPos)
		{
			MoveToChaseStart();
		}
		if (jump)
		{
			ChangeState(CharacterState.Jump, false);
		}
	}

	protected void ExitChase(Enum next)
	{
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		tk2dSpriteAnimatorPlus tk2dSpriteAnimatorPlus2 = animatorTk2d;
		tk2dSpriteAnimatorPlus2.AnimationCompleted = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>)Delegate.Remove(tk2dSpriteAnimatorPlus2.AnimationCompleted, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>(AlertFinished));
		hitBoxManager.OnHit -= HandleOnHit;
		if (!next.Equals(CharacterState.Jump))
		{
			RichAI2D richAI2D = base.richAI2D;
			richAI2D.targetReached = (Action)Delegate.Remove(richAI2D.targetReached, new Action(OnChaseTargetReached));
			base.richAI2D.SetPathfindingAllowed(allowed: true);
			base.richAI2D.SetTarget(null, Vector3.zero, chaseProperties.chaseSpeed);
			base.richAI2D.CancelPathfinding();
		}
	}

	private void AlertFinished(tk2dSpriteAnimator animator, tk2dSpriteAnimationClip clip)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		animator.AnimationCompleted = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>)Delegate.Remove(animator.AnimationCompleted, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>(AlertFinished));
		richAI2D.SetPathfindingAllowed(allowed: true);
		richAI2D.SetTarget(((Component)chaseTargetCharacter).transform, Vector3.zero, chaseProperties.chaseSpeed);
	}

	private void OnChaseTargetReached()
	{
		if (returningToPatrolPos)
		{
			returningToPatrolPos = false;
			ChangeState(CharacterState.Patrol, false);
		}
		else
		{
			MoveToChaseStart();
		}
	}

	private void MoveToChaseStart()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		richAI2D.MoveToPosition(chaseStartPos, chaseProperties.chaseSpeed);
		returningToPatrolPos = true;
	}

	protected void EnterAction(Enum previous, params object[] args)
	{
		richAI2D.SetPathfindingAllowed(allowed: false);
		battleInstigated = false;
		if ((Object)(object)hitBoxManager != (Object)null)
		{
			hitBoxManager.OnHit += HandleOnHit;
		}
		PlayAnim(chaseProperties.attack);
		EventMessenger.Instance.AddListener<InstigateBattleEvent>(HandleInstigateBattleEvent);
	}

	protected void UpdateAction()
	{
		if (!animatorTk2d.Playing)
		{
			if (!battleInstigated)
			{
				ChangeState(CharacterState.Chase, false);
				return;
			}
			PlayAnim(GetIdleAnimation());
			ReturnToBattleWaiting(new object[0]);
		}
	}

	protected void ExitAction(Enum next)
	{
		if ((Object)(object)hitBoxManager != (Object)null)
		{
			hitBoxManager.OnHit -= HandleOnHit;
		}
		richAI2D.SetPathfindingAllowed(allowed: true);
		EventMessenger.Instance.RemoveListener<InstigateBattleEvent>(HandleInstigateBattleEvent);
	}

	private void HandleInstigateBattleEvent(InstigateBattleEvent evt)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		battleInstigated = true;
		instigateBattleTargetPos = ((Component)evt.targets[0]).transform.position;
	}

	protected sealed override void MakeDecision()
	{
		float value = Random.value;
		if (activeState == SnowballioState.Spiked)
		{
			DisableBattleWaitingSubState();
			currentAbility = abilities[0];
			EventMessenger.Instance.Raise(new ExecuteAbilityEvent(this, new List<ITargetable>(currentTargets), currentAbility));
		}
		else if (activeSize.Equals(SnowballioSize.Small) && value <= 0.3f)
		{
			EventMessenger.Instance.Raise(new BattleScriptedSequenceEvent(GrowSequence()));
		}
		else if (moveCount > 0 && value <= 0.7f)
		{
			moveCount = 0;
			EventMessenger.Instance.Raise(new BattleScriptedSequenceEvent(SpawnSpikesSequence()));
		}
		else if (moveCount == 0)
		{
			base.MakeDecision();
		}
	}

	protected sealed override void OnBattleMoveTargetReached()
	{
		CancelBattleMovement();
		PlayAnim(GetIdleAnimation(), clearQueue: true);
		moveCount++;
		FaceTarget(currentTargets[0].transform);
		DisableBattleWaitingSubState(returnToBattleWaiting: true);
	}

	private IEnumerator GrowSequence()
	{
		ResumeAnimator();
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)this).transform, 1f)));
		EventMessenger.Instance.Raise(new CameraZoomEvent(1.3f));
		yield return (object)new WaitForSeconds(0.5f);
		activeSize = SnowballioSize.Large;
		largeHealth = characterProperties.maxLargeHealth;
		Stats.AddStatModifier(new CharacterStatModifier(CharacterStatModifier.Types.BaseValueAdd, CharacterStatType.Defense, characterProperties.defenseBonus, string.Empty));
		PlayAnim(characterProperties.growAnim, clearQueue: true);
		AddAnimToQueue(GetIdleAnimation());
		characterProperties.growSound.Play(((Component)this).transform.position);
		yield return (object)new WaitWhile((Func<bool>)(() => IsAnimPlaying(characterProperties.growAnim)));
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new CameraZoomEvent(1f));
		yield return (object)new WaitForSeconds(0.5f);
		DisableBattleWaitingSubState();
	}

	private IEnumerator SpawnSpikesSequence()
	{
		ResumeAnimator();
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)this).transform, 1f)));
		EventMessenger.Instance.Raise(new CameraZoomEvent(1.3f));
		yield return (object)new WaitForSeconds(0.5f);
		SetActiveState(SnowballioState.Spiked);
		CharacterAnimationNamePair spikeIntro = GetSpikeIntroAnimation();
		PlayAnim(spikeIntro, clearQueue: true);
		AddAnimToQueue(GetIdleAnimation());
		characterProperties.spikesAppearSound.Play(((Component)this).transform.position);
		yield return (object)new WaitWhile((Func<bool>)(() => IsAnimPlaying(spikeIntro)));
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new CameraZoomEvent(1f));
		yield return (object)new WaitForSeconds(0.5f);
		DisableBattleWaitingSubState();
	}

	protected sealed override void HandleDamageResult(DamageResult damageResult)
	{
		if (activeSize == SnowballioSize.Large || activeState == SnowballioState.Spiked)
		{
			if (damageResult.totalDamage <= 0)
			{
				return;
			}
			if (IsAlive || !damageResult.allowDeath)
			{
				if (IsAlive && activeState == SnowballioState.Spiked && damageResult.combatType == CombatType.Melee && damageResult.source is IDamageReceiver && !(damageResult.source is IFusion) && !(damageResult.sourceAbility is IFusionAbility))
				{
					DamageInfo damageInfo = ((activeSize != SnowballioSize.Large) ? characterProperties.spikeCounterDamageSmall : characterProperties.spikeCounterDamageLarge);
					BattleHelper.DoDamage(this, (IDamageReceiver)damageResult.source, damageInfo, allowDeath: true);
				}
				if (activeSize == SnowballioSize.Large)
				{
					largeHealth -= damageResult.totalDamage;
					if (largeHealth <= 0)
					{
						activeSize = SnowballioSize.Small;
						Stats.RemoveStatModifier(new CharacterStatModifier(CharacterStatModifier.Types.BaseValueAdd, CharacterStatType.Defense, characterProperties.defenseBonus, string.Empty));
						PlayAnim(characterProperties.shrinkAnim, clearQueue: true);
						AddAnimToQueue(GetIdleAnimation());
					}
					else if (activeState != SnowballioState.Spiked)
					{
						ChangeState(CharacterState.Hurt, false, damageResult);
					}
				}
				else if (activeState != SnowballioState.Spiked)
				{
					ChangeState(CharacterState.Hurt, false, damageResult);
				}
			}
			else if (damageResult.allowDeath)
			{
				ChangeState(CharacterState.Death, false, damageResult.source);
			}
		}
		else
		{
			base.HandleDamageResult(damageResult);
		}
	}

	public sealed override CharacterAnimationNamePair GetIdleAnimation()
	{
		if (activeSize == SnowballioSize.Large)
		{
			return (activeState != SnowballioState.Spiked) ? characterProperties.idleLargeAnim : characterProperties.spikeIdleLargeAnim;
		}
		return (activeState != SnowballioState.Spiked) ? base.GetIdleAnimation() : characterProperties.spikeIdleSmallAnim;
	}

	public sealed override CharacterAnimationNamePair GetHurtAnimation()
	{
		if (activeSize == SnowballioSize.Large)
		{
			return characterProperties.hurtLargeAnim;
		}
		return base.GetHurtAnimation();
	}

	public sealed override CharacterAnimationNamePair GetWalkAnimation()
	{
		if (activeSize == SnowballioSize.Large)
		{
			return characterProperties.walkLargeAnim;
		}
		return base.GetWalkAnimation();
	}

	public sealed override CharacterAnimationNamePair GetRunAnimation()
	{
		if (CurrentState.Equals(CharacterState.Patrol))
		{
			return GetWalkAnimation();
		}
		if (activeSize == SnowballioSize.Large)
		{
			return characterProperties.runLargeAnim;
		}
		return base.GetRunAnimation();
	}

	public sealed override CharacterAnimationNamePair GetDeathAnimation()
	{
		if (activeSize == SnowballioSize.Large)
		{
			return characterProperties.deathLargeAnim;
		}
		return base.GetDeathAnimation();
	}

	public CharacterAnimationNamePair GetSpikeIntroAnimation()
	{
		return (activeSize != SnowballioSize.Large) ? characterProperties.spikeIntroSmallAnim : characterProperties.spikeIntroLargeAnim;
	}

	public CharacterAnimationNamePair GetSpikeAttackAnimation()
	{
		return (activeSize != SnowballioSize.Large) ? characterProperties.spikeAttackSmallAnim : characterProperties.spikeAttackLargeAnim;
	}

	public void PlaySpikeAttackAudio()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		characterProperties.spikesLaunchSound.Play(((Component)this).transform.position);
	}

	public sealed override void ResetObject()
	{
		if (activeSize == SnowballioSize.Large)
		{
			activeSize = SnowballioSize.Small;
		}
		activeState = SnowballioState.None;
		base.ResetObject();
	}
}
