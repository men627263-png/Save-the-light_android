using UnityEngine;

public class Explosion : MonoBehaviour
{
	[SerializeField]
	private VibrationManager.Vibration vibration;

	[SerializeField]
	private ScreenShakeData shakeData;

	private void OnEnable()
	{
		EventMessenger.Instance.Raise(new VibrationEvent(vibration));
		EventMessenger.Instance.Raise(new ScreenShakeEvent(shakeData));
	}
}
