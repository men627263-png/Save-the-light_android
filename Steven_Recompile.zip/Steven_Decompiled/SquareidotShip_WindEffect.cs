using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Grumpyface;
using UnityEngine;

public class SquareidotShip_WindEffect : MonoBehaviour
{
	[SerializeField]
	private ParticleSystem pillParticles;

	[SerializeField]
	private WindZone windZone;

	[SerializeField]
	private BoxCollider influenceArea;

	[SerializeField]
	[MinMaxRange(0, 50)]
	private RangedFloat influenceRange;

	[SerializeField]
	private tk2dSpriteAnimator[] curlyWisps;

	[SerializeField]
	private float wispDelay;

	private float maxWindMain;

	private float maxStartLifetime;

	private float wispDelayTimer;

	private List<tk2dSpriteAnimator> wispPool = new List<tk2dSpriteAnimator>();

	private List<GreatNorthTree> treesInRange = new List<GreatNorthTree>();

	private bool _isOn;

	private float _strength = 1f;

	public float strength
	{
		get
		{
			return _strength;
		}
		set
		{
			_strength = Mathf.Clamp01(value);
		}
	}

	private void Awake()
	{
		pillParticles.EnableEmission(enabled: false);
		((Component)windZone).gameObject.SetActive(false);
		maxWindMain = windZone.windMain;
		maxStartLifetime = pillParticles.startLifetime;
		for (int i = 0; i < curlyWisps.Length; i++)
		{
			((Component)curlyWisps[i]).gameObject.SetActive(false);
			wispPool.Add(curlyWisps[i]);
		}
	}

	private void Update()
	{
		if (_isOn)
		{
			wispDelayTimer -= Time.deltaTime;
			if (wispDelayTimer <= 0f && wispPool.Count > 0)
			{
				wispDelayTimer += wispDelay;
				int index = Random.Range(0, wispPool.Count);
				tk2dSpriteAnimator tk2dSpriteAnimator2 = wispPool[index];
				wispPool.RemoveAt(index);
				tk2dSpriteAnimator2.AnimationCompleted = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>)Delegate.Combine(tk2dSpriteAnimator2.AnimationCompleted, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>(HandleAnimationCompleted));
				((Component)tk2dSpriteAnimator2).gameObject.SetActive(true);
				tk2dSpriteAnimator2.PlayFromFrame(0);
			}
		}
	}

	public void TurnOn(float strength = 1f)
	{
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		if (_isOn)
		{
			return;
		}
		_isOn = true;
		this.strength = strength;
		wispDelayTimer = wispDelay;
		pillParticles.EnableEmission(enabled: true);
		((Component)windZone).gameObject.SetActive(true);
		windZone.windMain = maxWindMain * strength;
		pillParticles.startLifetime = maxStartLifetime * (1f / strength);
		Collider[] array = Physics.OverlapBox(((Component)influenceArea).transform.TransformPoint(influenceArea.center), influenceArea.size / 2f, Quaternion.identity, LayerMask.GetMask(new string[1] { "Ignore Raycast" }), (QueryTriggerInteraction)2);
		for (int i = 0; i < array.Length; i++)
		{
			if (((Component)array[i]).tag == "GNTree")
			{
				GreatNorthTree tree = ((Component)array[i]).GetComponent<GreatNorthTree>();
				float num = Vector3.Distance(((Component)this).transform.position, ((Component)tree).transform.position);
				float num2 = 1f - Mathf.Clamp01((num - influenceRange.minValue) / (influenceRange.maxValue - influenceRange.minValue));
				tree.blowingWeight = 0f;
				tree.animator.Play((!(Random.value <= 0.5f)) ? "loop_02" : "loop_01");
				TweenSettingsExtensions.SetDelay<TweenerCore<float, float, FloatOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<float, float, FloatOptions>>(DOTween.To((DOGetter<float>)(() => tree.blowingWeight), (DOSetter<float>)((float x) =>
				{
					tree.blowingWeight = x;
				}), num2 * _strength, 0.5f), (Ease)3), 0.05f * (num / 3f));
				treesInRange.Add(tree);
			}
		}
	}

	public void TurnOff(bool pool = false)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		if (_isOn)
		{
			_isOn = false;
			pillParticles.EnableEmission(enabled: false);
			((Component)windZone).gameObject.SetActive(false);
			for (int i = 0; i < treesInRange.Count; i++)
			{
				GreatNorthTree greatNorthTree = treesInRange[i];
				float num = Vector3.Distance(((Component)this).transform.position, ((Component)greatNorthTree).transform.position);
				((MonoBehaviour)greatNorthTree).StartCoroutine(DelayedTreeOutro(greatNorthTree, 0.025f * (num / 3f)));
			}
			treesInRange.Clear();
			if (pool)
			{
				((MonoBehaviour)this).StartCoroutine(WaitToPool());
			}
		}
	}

	private IEnumerator DelayedTreeOutro(GreatNorthTree tree, float delay)
	{
		yield return (object)new WaitForSeconds(delay);
		tree.animator.Play((!tree.animator.IsName("loop_01")) ? "outro_02" : "outro_01");
	}

	private IEnumerator WaitToPool()
	{
		yield return (object)new WaitWhile((Func<bool>)(() => pillParticles.particleCount > 0 || wispPool.Count < curlyWisps.Length));
		ObjectPool.PoolObject(((Component)this).gameObject);
	}

	private void HandleAnimationCompleted(tk2dSpriteAnimator animator, tk2dSpriteAnimationClip clip)
	{
		animator.AnimationCompleted = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>)Delegate.Remove(animator.AnimationCompleted, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>(HandleAnimationCompleted));
		wispPool.Add(animator);
		((Component)animator).gameObject.SetActive(false);
	}
}
