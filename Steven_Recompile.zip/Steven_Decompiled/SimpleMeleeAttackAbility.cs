using System;
using System.Collections;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Abilities/Simple Melee Attack")]
public class SimpleMeleeAttackAbility : BaseAbility
{
	[Serializable]
	private class AbilityData
	{
		[Header("Animations")]
		public CharacterAnimationNamePair alertAnim = default;

		public CharacterAnimationNamePair attackAnim = default;

		[Header("Tweakables")]
		public DamageInfo damage;

		[Tooltip("Speed at which the caster will approach the target before attacking")]
		public float movementSpeed;

		[Tooltip("Speed at which the caster will return to its original position after attacking the target")]
		public float returnSpeed;

		[Header("Sounds")]
		public DelayedAudioEvent attackSound = default;
	}

	[SerializeField]
	private BonusStarData bonusStarData;

	[SerializeField]
	private AbilityData abilityData;

	[NonSerialized]
	private ITargetable target;

	[NonSerialized]
	private Vector3 originalPosition;

	[NonSerialized]
	private float prevTimeScale = -1f;

	public override IEnumerator Play()
	{
		prevTimeScale = -1f;
		target = targets[0];
		SimpleMeleeAttackAbility simpleMeleeAttackAbility = this;
		Vector3 battleStartPosition = caster.battleStartPosition;
		caster.battlePosition = battleStartPosition;
		simpleMeleeAttackAbility.originalPosition = battleStartPosition;
		caster.RichAI2D.CancelPathfinding();
		Vector3 destination = target.GetClosestSidePosition(((Component)caster).transform.position);
		caster.RichAI2D.MoveToPosition(destination, abilityData.movementSpeed);
		yield return new WaitUntilAIReachedTarget(caster.RichAI2D);
		caster.FaceTarget(target.transform);
		caster.PlayAnim(abilityData.attackAnim);
		abilityData.attackSound.Play();
		int hitFrame = caster.animatorTk2d.CurrentClip.GetFrameWithEventInfo("hit");
		StarBonusCheck bonusCheck = StartBonusCheck(Time.time + (caster.animatorTk2d.CurrentClip.GetFrameTime(hitFrame) - caster.animatorTk2d.ClipTimeSeconds), bonusStarData);
		yield return (object)new WaitWhile((Func<bool>)(() => caster.animatorTk2d.CurrentFrame < hitFrame));
		LastFrameBonusCheck(bonusCheck);
		BattleHelper.DoDamage(caster, target.damageReceiver, abilityData.damage, allowDeath: true, this, bonusCheck);
		caster.ProcessBadgeEffects(BadgeEffectCondition.OnAttack, this, new ITargetable[1] { target });
		if (bonusCheck.isBonusPerfectSuccess)
		{
			EventMessenger.Instance.Raise(new PerfectAttackEvent(bonusStarMeterOnPerfect));
			if (!preventFreezeDuration)
			{
				yield return (object)new WaitWhile((Func<bool>)(() => Time.timeScale == 0f));
				prevTimeScale = Time.timeScale;
				Time.timeScale = 0f;
				yield return new WaitForSecondsIndependentUnpaused(bonusStarData.bonusPerfectFreezeDuration);
				Time.timeScale = prevTimeScale;
			}
		}
		yield return (object)new WaitWhile((Func<bool>)(() => caster.IsAnimPlaying(abilityData.attackAnim)));
		caster.RichAI2D.MoveToPosition(originalPosition, abilityData.returnSpeed);
		yield return new WaitUntilAIReachedTarget(caster.RichAI2D);
		caster.FaceTarget(target.transform);
	}

	public override IEnumerator Cancel()
	{
		if (prevTimeScale > 0f)
		{
			Time.timeScale = prevTimeScale;
		}
		caster.RichAI2D.CancelPathfinding();
		yield return (object)new WaitWhile((Func<bool>)(() => caster.CurrentState.Equals(CharacterState.KnockedBack) || caster.CurrentState.Equals(CharacterState.Hurt)));
		if (caster.isAlive)
		{
			caster.battlePosition = originalPosition;
			caster.RichAI2D.MoveToPosition(originalPosition, abilityData.returnSpeed);
			yield return new WaitUntilAIReachedTarget(caster.RichAI2D);
			caster.FaceTarget(target.transform);
		}
	}

	protected override void OnCleanUp()
	{
		base.OnCleanUp();
	}

	public override void ResetForReUse()
	{
		target = null;
		base.ResetForReUse();
	}
}
