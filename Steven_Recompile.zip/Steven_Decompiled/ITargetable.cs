using UnityEngine;

public interface ITargetable : ITinter
{
	IDamageReceiver damageReceiver { get; }

	Transform transform { get; }

	GameObject gameObject { get; }

	Vector3 FrontPosition { get; }

	Vector3 BackPosition { get; }

	Vector3 CenterPosition { get; }

	Vector3 CenterTopPosition { get; }

	CharacterStats Stats { get; }

	HitBoxManager HitBoxManager { get; }

	StatusEffectManager StatusEffectManager { get; }

	StatusEffectName[] InnateImmunities { get; }

	bool IsTargetable { get; }

	bool CanBlock { get; }

	bool IsFlying { get; }

	bool IsDead { get; }

	bool IsAlive { get; }

	float EffectScale { get; }

	Renderer[] AllRenderers { get; }

	void Kill(IDamageSender source);

	Vector3 GetClosestSidePosition(Vector3 fromPosition);

	bool CanBeTargetedByAbility(BaseAbility ability);
}
