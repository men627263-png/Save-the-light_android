using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Grumpyface;
using UnityEngine;

public class MortMortarDropGroup : MonoBehaviour, IPoolable
{
	[Serializable]
	public struct DropGroupData(float mortarDelay, float secondsUntilShadows, float shadowsDuration, float shadowGrowthRate, float shadowPercentMax, float explosionRadius, DamageInfo damage)
	{
		public float mortarDelay = mortarDelay;

		public float secondsUntilShadows = secondsUntilShadows;

		public float shadowsDuration = shadowsDuration;

		public float shadowGrowthRate = shadowGrowthRate;

		public float shadowPercentMax = shadowPercentMax;

		public float explosionRadius = explosionRadius;

		public DamageInfo damage = damage;
	}

	[SerializeField]
	private GameObject mortarPrefab;

	[SerializeField]
	private GameObject explosionPrefab;

	[SerializeField]
	private GameObject shadowPrefab;

	[SerializeField]
	private float dropHeight = 5f;

	[SerializeField]
	private float dropSpeed = 10f;

	[SerializeField]
	private float delayAfterLastMortar = 1f;

	private Battlefield battlefield;

	private BaseCharacter owner;

	private int mortarCount;

	private float mortarDelay;

	private float secondsUntilShadows;

	private float shadowsDuration;

	private float shadowGrowthRate;

	private float shadowMax;

	private float explosionRadius;

	private DamageInfo damage;

	private bool canUpdate;

	private List<Vector3> dropPositions = new List<Vector3>();

	private List<MortMortarShadow> shadows = new List<MortMortarShadow>();

	private int curDropPositionIndex;

	private float mortarDelayTimer;

	private List<Transform> mortars = new List<Transform>();

	private void OnEnable()
	{
		EventMessenger.Instance.AddListener<BattleWaitingEvent>(HandleBattleWaitingEvent);
		EventMessenger.Instance.AddListener<BattleFinishedEvent>(HandleBattleFinishedEvent);
		canUpdate = GameController.Instance.CurrentState.Equals(GameControllerState.Battle_Waiting);
	}

	private void OnDisable()
	{
		EventMessenger.Instance.RemoveListener<BattleWaitingEvent>(HandleBattleWaitingEvent);
		EventMessenger.Instance.RemoveListener<BattleFinishedEvent>(HandleBattleFinishedEvent);
	}

	private void Update()
	{
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		if (!canUpdate)
		{
			return;
		}
		if (secondsUntilShadows > 0f)
		{
			secondsUntilShadows -= Time.deltaTime;
			if (secondsUntilShadows <= 0f)
			{
				curDropPositionIndex = 0;
				mortarDelayTimer = 0f;
			}
			return;
		}
		bool flag = true;
		for (int i = 0; i < shadows.Count; i++)
		{
			shadows[i].percent += shadowGrowthRate * Time.deltaTime;
			if (shadows[i].percent < shadowMax)
			{
				flag = false;
			}
		}
		if (curDropPositionIndex == dropPositions.Count)
		{
			if (flag)
			{
				shadowsDuration -= Time.deltaTime;
				if (shadowsDuration <= 0f)
				{
					EventMessenger.Instance.Raise(new BattleScriptedSequenceEvent(DropSequence()));
				}
			}
			return;
		}
		mortarDelayTimer -= Time.deltaTime;
		if (mortarDelayTimer <= 0f)
		{
			MortMortarShadow mortMortarShadow = ObjectPool.GetObject<MortMortarShadow>(shadowPrefab, default(Vector3), true);
			((Component)mortMortarShadow).transform.position = dropPositions[curDropPositionIndex] + new Vector3(0f, 5f, 0f);
			mortMortarShadow.percent = 0f;
			shadows.Add(mortMortarShadow);
			mortarDelayTimer += mortarDelay;
			curDropPositionIndex++;
		}
	}

	public void Init(Battlefield battlefield, BaseCharacter owner, int mortarCount, DropGroupData dropGroupData)
	{
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		this.battlefield = battlefield;
		this.owner = owner;
		this.mortarCount = mortarCount;
		mortarDelay = dropGroupData.mortarDelay;
		secondsUntilShadows = dropGroupData.secondsUntilShadows;
		shadowsDuration = dropGroupData.shadowsDuration;
		shadowGrowthRate = dropGroupData.shadowGrowthRate;
		shadowMax = dropGroupData.shadowPercentMax;
		explosionRadius = dropGroupData.explosionRadius;
		damage = dropGroupData.damage;
		shadows.Clear();
		dropPositions.Clear();
		Vector3 val = new Vector3(((Component)owner).transform.position.x, ((Component)battlefield).transform.position.y, ((Component)owner).transform.position.z);
		for (int i = 0; i < mortarCount; i++)
		{
			Vector3 position;
			do
			{
				position = ((Component)battlefield).transform.position;
				position += ((Component)battlefield).transform.right * Random.Range(0f - battlefield.battlefieldSize.x, battlefield.battlefieldSize.x) * 0.5f;
				position += ((Component)battlefield).transform.forward * Random.Range(0f - battlefield.battlefieldSize.z, battlefield.battlefieldSize.z) * 0.5f;
			}
			while (Vector3.Distance(position, val) <= explosionRadius);
			dropPositions.Add(position);
		}
	}

	private void HandleBattleWaitingEvent(BattleWaitingEvent evt)
	{
		canUpdate = evt.didEnter;
	}

	private void HandleBattleFinishedEvent(BattleFinishedEvent evt)
	{
		ObjectPool.PoolObject(((Component)this).gameObject);
	}

	private IEnumerator DropSequence()
	{
		EventMessenger.Instance.Raise(new CameraZoomEvent(1.1f));
		yield return (object)new WaitForSeconds(0.25f);
		int mortarsRemaining = mortarCount;
		int positionIndex = 0;
		mortars.Clear();
		Transform mortar = null;
		RaycastHit hit = default;
		while (mortarsRemaining > 0)
		{
			bool hitGround = false;
			Vector3 startPosition;
			if (Physics.Raycast(((Component)shadows[positionIndex]).transform.position, Vector3.down, ref hit, 20f, LayerMask.GetMask(new string[3] { "Ground", "Ground2", "GroundNoAstar" })))
			{
				startPosition = hit.point + new Vector3(0f, dropHeight, 0f);
				hitGround = true;
			}
			else
			{
				startPosition = dropPositions[positionIndex] + new Vector3(0f, dropHeight, 0f);
			}
			mortar = ObjectPool.GetObject(mortarPrefab, startPosition).transform;
			mortars.Add(mortar);
			((MonoBehaviour)this).StartCoroutine(SingleMortarDrop(mortar, shadows[positionIndex], hitGround));
			mortarsRemaining--;
			positionIndex++;
			yield return (object)new WaitForSeconds(mortarDelay);
		}
		yield return (object)new WaitWhile((Func<bool>)(() => mortars.Count > 0));
		yield return (object)new WaitForSeconds(delayAfterLastMortar);
		ObjectPool.PoolObject(((Component)this).gameObject);
	}

	private IEnumerator SingleMortarDrop(Transform mortar, MortMortarShadow shadow, bool hitGround)
	{
		Tweener tween = null;
		tween = ((!hitGround) ? TweenSettingsExtensions.SetEase<Tweener>(TweenSettingsExtensions.SetRelative<Tweener>(TweenSettingsExtensions.SetSpeedBased<Tweener>(ShortcutExtensions.DOMoveY(mortar, (0f - dropHeight) * 2f, dropSpeed, false))), (Ease)1) : TweenSettingsExtensions.SetEase<Tweener>(TweenSettingsExtensions.SetRelative<Tweener>(TweenSettingsExtensions.SetSpeedBased<Tweener>(ShortcutExtensions.DOMoveY(mortar, 0f - dropHeight, dropSpeed, false))), (Ease)1));
		yield return TweenExtensions.WaitForCompletion((Tween)(object)tween);
		ObjectPool.PoolObject(((Component)shadow).gameObject);
		if (hitGround)
		{
			ObjectPool.GetObject(explosionPrefab, mortar.position).transform.forward = ((Component)battlefield).transform.forward;
			Collider[] array = Physics.OverlapSphere(mortar.position, explosionRadius, LayerMask.GetMask(new string[2] { "Player", "Enemy" }));
			if (array.Length > 0)
			{
				for (int i = 0; i < array.Length; i++)
				{
					ITargetable component = ((Component)array[i]).GetComponent<ITargetable>();
					if (component != null && component.IsAlive && Vector3.Distance(component.transform.PositionXZ(), mortar.PositionXZ()) <= explosionRadius && (!(component is PlayerCharacter) || (component is PlayerCharacter && GameController.Instance.IsCharacterInBattleParty(((PlayerCharacter)component).characterName))))
					{
						BattleHelper.DoDamage(owner, component.damageReceiver, damage, allowDeath: true);
					}
				}
			}
		}
		ObjectPool.PoolObject(((Component)mortar).gameObject);
		mortars.Remove(mortar);
	}

	public void ResetObject()
	{
		battlefield = null;
		owner = null;
		dropPositions.Clear();
		while (shadows.Count > 0)
		{
			ObjectPool.PoolObject(((Component)shadows.Pop()).gameObject);
		}
		while (mortars.Count > 0)
		{
			ObjectPool.PoolObject(((Component)mortars.Pop()).gameObject);
		}
		canUpdate = false;
	}
}
