using System;
using UnityEngine;
using UnityEngine.Serialization;

public class GameCamera : MonoBehaviour
{
	[SerializeField]
	private Camera _camera;

	[SerializeField]
	private Transform _anchor;

	[SerializeField]
	private Transform _container;

	[SerializeField]
	private BattleCamera _battleCamera;

	private float targetZoomFactor = 1f;

	private float zoomVelocity;

	private Vector3 _containerPositionTarget = Vector3.zero;

	[SerializeField]
	[FormerlySerializedAs("target")]
	private Transform _target;

	public float zoomDamping = 0.2f;

	private Transform _cameraTransform;

	private tk2dCamera _cameraTk2d;

	public static GameCamera instance { get; private set; }

	public Camera camera => _camera;

	public Transform anchor => _anchor;

	public Transform container => _container;

	public BattleCamera battleCamera => _battleCamera;

	public Transform target
	{
		get
		{
			return _target;
		}
		set
		{
			SetTarget(value);
		}
	}

	public Transform cameraTransform
	{
		get
		{
			if ((Object)(object)_cameraTransform == (Object)null)
			{
				_cameraTransform = ((Component)_camera).transform;
			}
			return _cameraTransform;
		}
	}

	public bool isMoving
	{
		get
		{
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			return !V3Equal(container.position, _containerPositionTarget);
		}
	}

	public tk2dCamera cameraTk2d
	{
		get
		{
			if ((Object)(object)_cameraTk2d == (Object)null)
			{
				_cameraTk2d = ((Component)camera).GetComponent<tk2dCamera>();
			}
			return _cameraTk2d;
		}
	}

	public event Action<Transform> TargetChanged;

	public GameCamera()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Awake()
	{
		instance = this;
		if ((Object)(object)_camera == (Object)null)
		{
			_camera = ((Component)this).GetComponentInChildren<Camera>();
		}
		if ((Object)(object)_anchor == (Object)null)
		{
			_anchor = ((Component)this).transform;
		}
		if ((Object)(object)_battleCamera == (Object)null)
		{
			_battleCamera = ((Component)this).GetComponentInChildren<BattleCamera>();
		}
	}

	private void Start()
	{
		targetZoomFactor = cameraTk2d.ZoomFactor;
		EventMessenger.Instance.AddListener<CameraZoomEventOOB>(HandleCameraZoomEvent);
	}

	private void OnDestroy()
	{
		EventMessenger.Instance.RemoveListener<CameraZoomEventOOB>(HandleCameraZoomEvent);
	}

	private void Reset()
	{
		_anchor = ((Component)this).transform;
	}

	public void SetTarget(Transform newTarget)
	{
		if ((Object)(object)newTarget != (Object)(object)_target)
		{
			_target = newTarget;
			if (TargetChanged != null)
			{
				TargetChanged(newTarget);
			}
		}
	}

	public void SetContainerPositionTarget(Vector3 newPosTarget)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		_containerPositionTarget = newPosTarget;
	}

	private void LateUpdate()
	{
		if (Time.deltaTime != 0f && cameraTk2d.ZoomFactor != targetZoomFactor && !((Behaviour)battleCamera).enabled)
		{
			cameraTk2d.ZoomFactor = Mathf.SmoothDamp(cameraTk2d.ZoomFactor, targetZoomFactor, ref zoomVelocity, zoomDamping);
		}
	}

	private void HandleCameraZoomEvent(CameraZoomEventOOB evt)
	{
		targetZoomFactor = evt.zoomFactor;
	}

	private bool V3Equal(Vector3 a, Vector3 b)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		return (double)Vector3.SqrMagnitude(a - b) < 0.0001;
	}
}
