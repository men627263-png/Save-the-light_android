using System.Collections.Generic;
using Pathfinding;
using UnityEngine;

public class NodeLinkGenerator : GraphModifier
{
	private struct NodeLinkSpawnInfo(Vector3 newLinkStartPos, Vector3 newLinkEndPos)
	{
		public Vector3 nodeLinkStartPos = newLinkStartPos;

		public Vector3 nodeLinkEndPos = newLinkEndPos;
	}

	public CharacterNodeLink nodeLinkPrefab;

	[Tooltip("The general jump height of the characters in the game. Determines which links characters can jump up/across to.")]
	public float jumpHeight = 3.1f;

	[Tooltip("How wide the characters are generally. Its safe to make this slightly larger than most characters.")]
	public float characterRadius = 0.7f;

	[Tooltip("The start of a dropdown link begins at the edge of a node. The end of a dropdown node is then placed at a distance going away from the edge equal to ((characterRadius * 2) + this variable)")]
	public float extraDropdownDistance;

	public bool hasInitiallyScanned;

	public bool hasFinishedGeneration;

	public List<LinkedGraphNodes> linkedNodes = new List<LinkedGraphNodes>();

	public List<CharacterNodeLink> nodeLinkObjs = new List<CharacterNodeLink>();

	private List<NodeLinkSpawnInfo> nodeLinkSpawnInfo = new List<NodeLinkSpawnInfo>();

	private int checkCount;

	private List<NavmeshCut> allNavmeshCuts;

	private GameObject parentCap;

	private static NodeLinkGenerator instance;

	public bool showInternalEditorVariables { get; set; }

	public static NodeLinkGenerator Instance
	{
		get
		{
			if ((Object)(object)instance == (Object)null)
			{
				instance = Object.FindObjectOfType<NodeLinkGenerator>();
			}
			return instance;
		}
	}

	private void Awake()
	{
	}

	public override void OnPostScan()
	{
		if (!Application.isEditor || Application.isPlaying)
		{
			return;
		}
		if (!hasInitiallyScanned)
		{
			Debug.Log((object)"Generating Node Links...");
		}
		if (!((Component)this).gameObject.activeInHierarchy || !((Behaviour)this).enabled || !hasInitiallyScanned || hasFinishedGeneration)
		{
			return;
		}
		if (AstarPath.active.isScanning)
		{
			CreateFinalNodeLinks();
			hasFinishedGeneration = true;
			return;
		}
		AstarPath.active.AddWorkItem(new AstarPath.AstarWorkItem((bool force) =>
		{
			CreateFinalNodeLinks();
			hasFinishedGeneration = true;
			return true;
		}));
	}

	public override void OnLatePostScan()
	{
		if (Application.isEditor && !Application.isPlaying && ((Component)this).gameObject.activeInHierarchy && ((Behaviour)this).enabled && !hasInitiallyScanned)
		{
			Debug.Log((object)"Late Post Scan for initial scan...");
			hasInitiallyScanned = true;
			linkedNodes.Clear();
			nodeLinkSpawnInfo.Clear();
			InternalOnPostScan();
			AstarPath.active.Scan();
		}
	}

	private void InternalOnPostScan()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		if (!((Component)this).gameObject.activeInHierarchy)
		{
			return;
		}
		allNavmeshCuts = new List<NavmeshCut>(Object.FindObjectsOfType<NavmeshCut>());
		Bounds tileBounds = new Bounds(Vector3.zero, Vector3.one * 0.1f);
		AstarPath.active.astarData.recastGraph.GetNodes((GraphNode node) =>
		{
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_005f: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0079: Unknown result type (might be due to invalid IL or missing references)
			//IL_009c: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0115: Unknown result type (might be due to invalid IL or missing references)
			//IL_0162: Unknown result type (might be due to invalid IL or missing references)
			//IL_0167: Unknown result type (might be due to invalid IL or missing references)
			//IL_05f7: Unknown result type (might be due to invalid IL or missing references)
			//IL_05fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_05fe: Unknown result type (might be due to invalid IL or missing references)
			//IL_0603: Unknown result type (might be due to invalid IL or missing references)
			//IL_0605: Unknown result type (might be due to invalid IL or missing references)
			//IL_060a: Unknown result type (might be due to invalid IL or missing references)
			//IL_060c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0611: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c7e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c8f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ca8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0cb9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0cd2: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ce3: Unknown result type (might be due to invalid IL or missing references)
			//IL_0632: Unknown result type (might be due to invalid IL or missing references)
			//IL_0637: Unknown result type (might be due to invalid IL or missing references)
			//IL_0693: Unknown result type (might be due to invalid IL or missing references)
			//IL_06a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_06a8: Unknown result type (might be due to invalid IL or missing references)
			//IL_06ad: Unknown result type (might be due to invalid IL or missing references)
			//IL_06bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_06c2: Unknown result type (might be due to invalid IL or missing references)
			//IL_06cf: Unknown result type (might be due to invalid IL or missing references)
			//IL_06df: Unknown result type (might be due to invalid IL or missing references)
			//IL_06e4: Unknown result type (might be due to invalid IL or missing references)
			//IL_06e8: Unknown result type (might be due to invalid IL or missing references)
			//IL_06ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d14: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d19: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d1a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d1f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d23: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d28: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d2c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d34: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d39: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d40: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d45: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d5a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d5f: Unknown result type (might be due to invalid IL or missing references)
			//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d6e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d73: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d7e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d85: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d8a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d8f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0da9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dae: Unknown result type (might be due to invalid IL or missing references)
			//IL_0daf: Unknown result type (might be due to invalid IL or missing references)
			//IL_0db4: Unknown result type (might be due to invalid IL or missing references)
			//IL_0db8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dbd: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dc1: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dc8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dcd: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dd2: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dd6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ddb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0df3: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e0e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e13: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e15: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e1e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e20: Unknown result type (might be due to invalid IL or missing references)
			//IL_0658: Unknown result type (might be due to invalid IL or missing references)
			//IL_065d: Unknown result type (might be due to invalid IL or missing references)
			//IL_065f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0661: Unknown result type (might be due to invalid IL or missing references)
			//IL_0715: Unknown result type (might be due to invalid IL or missing references)
			//IL_071a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e39: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e32: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e3b: Unknown result type (might be due to invalid IL or missing references)
			//IL_023d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0242: Unknown result type (might be due to invalid IL or missing references)
			//IL_0244: Unknown result type (might be due to invalid IL or missing references)
			//IL_0251: Unknown result type (might be due to invalid IL or missing references)
			//IL_0256: Unknown result type (might be due to invalid IL or missing references)
			//IL_0258: Unknown result type (might be due to invalid IL or missing references)
			//IL_025d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0261: Unknown result type (might be due to invalid IL or missing references)
			//IL_0266: Unknown result type (might be due to invalid IL or missing references)
			//IL_0273: Unknown result type (might be due to invalid IL or missing references)
			//IL_027d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0287: Unknown result type (might be due to invalid IL or missing references)
			//IL_028c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0291: Unknown result type (might be due to invalid IL or missing references)
			//IL_073b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0740: Unknown result type (might be due to invalid IL or missing references)
			//IL_0744: Unknown result type (might be due to invalid IL or missing references)
			//IL_074b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0750: Unknown result type (might be due to invalid IL or missing references)
			//IL_0752: Unknown result type (might be due to invalid IL or missing references)
			//IL_0817: Unknown result type (might be due to invalid IL or missing references)
			//IL_081c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0878: Unknown result type (might be due to invalid IL or missing references)
			//IL_0884: Unknown result type (might be due to invalid IL or missing references)
			//IL_0889: Unknown result type (might be due to invalid IL or missing references)
			//IL_088e: Unknown result type (might be due to invalid IL or missing references)
			//IL_089e: Unknown result type (might be due to invalid IL or missing references)
			//IL_08a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_08ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_08b8: Unknown result type (might be due to invalid IL or missing references)
			//IL_08bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_08c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_08c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_075e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0760: Unknown result type (might be due to invalid IL or missing references)
			//IL_0762: Unknown result type (might be due to invalid IL or missing references)
			//IL_0764: Unknown result type (might be due to invalid IL or missing references)
			//IL_0766: Unknown result type (might be due to invalid IL or missing references)
			//IL_0768: Unknown result type (might be due to invalid IL or missing references)
			//IL_0778: Unknown result type (might be due to invalid IL or missing references)
			//IL_0788: Unknown result type (might be due to invalid IL or missing references)
			//IL_078d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0792: Unknown result type (might be due to invalid IL or missing references)
			//IL_0796: Unknown result type (might be due to invalid IL or missing references)
			//IL_079b: Unknown result type (might be due to invalid IL or missing references)
			//IL_07aa: Unknown result type (might be due to invalid IL or missing references)
			//IL_07b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_07bb: Unknown result type (might be due to invalid IL or missing references)
			//IL_07c2: Unknown result type (might be due to invalid IL or missing references)
			//IL_07c7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e4d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e52: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e54: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e56: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e75: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e7a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e7f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e81: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e83: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e98: Unknown result type (might be due to invalid IL or missing references)
			//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
			//IL_02b7: Unknown result type (might be due to invalid IL or missing references)
			//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
			//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
			//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
			//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
			//IL_02d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_02db: Unknown result type (might be due to invalid IL or missing references)
			//IL_02e8: Unknown result type (might be due to invalid IL or missing references)
			//IL_02f2: Unknown result type (might be due to invalid IL or missing references)
			//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_0301: Unknown result type (might be due to invalid IL or missing references)
			//IL_0306: Unknown result type (might be due to invalid IL or missing references)
			//IL_0308: Unknown result type (might be due to invalid IL or missing references)
			//IL_030a: Unknown result type (might be due to invalid IL or missing references)
			//IL_030c: Unknown result type (might be due to invalid IL or missing references)
			//IL_030e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0313: Unknown result type (might be due to invalid IL or missing references)
			//IL_0317: Unknown result type (might be due to invalid IL or missing references)
			//IL_031c: Unknown result type (might be due to invalid IL or missing references)
			//IL_031e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0325: Unknown result type (might be due to invalid IL or missing references)
			//IL_032f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0334: Unknown result type (might be due to invalid IL or missing references)
			//IL_0339: Unknown result type (might be due to invalid IL or missing references)
			//IL_0349: Unknown result type (might be due to invalid IL or missing references)
			//IL_034e: Unknown result type (might be due to invalid IL or missing references)
			//IL_036a: Unknown result type (might be due to invalid IL or missing references)
			//IL_036f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0378: Unknown result type (might be due to invalid IL or missing references)
			//IL_038c: Unknown result type (might be due to invalid IL or missing references)
			//IL_038e: Unknown result type (might be due to invalid IL or missing references)
			//IL_03a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_03a5: Unknown result type (might be due to invalid IL or missing references)
			//IL_0839: Unknown result type (might be due to invalid IL or missing references)
			//IL_083e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0840: Unknown result type (might be due to invalid IL or missing references)
			//IL_0842: Unknown result type (might be due to invalid IL or missing references)
			//IL_08ea: Unknown result type (might be due to invalid IL or missing references)
			//IL_08ef: Unknown result type (might be due to invalid IL or missing references)
			//IL_0eaf: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ecb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ed0: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ed5: Unknown result type (might be due to invalid IL or missing references)
			//IL_03c3: Unknown result type (might be due to invalid IL or missing references)
			//IL_03c8: Unknown result type (might be due to invalid IL or missing references)
			//IL_03b7: Unknown result type (might be due to invalid IL or missing references)
			//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_040c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0411: Unknown result type (might be due to invalid IL or missing references)
			//IL_0413: Unknown result type (might be due to invalid IL or missing references)
			//IL_0421: Unknown result type (might be due to invalid IL or missing references)
			//IL_0426: Unknown result type (might be due to invalid IL or missing references)
			//IL_0428: Unknown result type (might be due to invalid IL or missing references)
			//IL_042d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0431: Unknown result type (might be due to invalid IL or missing references)
			//IL_0436: Unknown result type (might be due to invalid IL or missing references)
			//IL_0444: Unknown result type (might be due to invalid IL or missing references)
			//IL_044e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0458: Unknown result type (might be due to invalid IL or missing references)
			//IL_045d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0462: Unknown result type (might be due to invalid IL or missing references)
			//IL_09d8: Unknown result type (might be due to invalid IL or missing references)
			//IL_09dd: Unknown result type (might be due to invalid IL or missing references)
			//IL_09df: Unknown result type (might be due to invalid IL or missing references)
			//IL_09e4: Unknown result type (might be due to invalid IL or missing references)
			//IL_09e6: Unknown result type (might be due to invalid IL or missing references)
			//IL_09eb: Unknown result type (might be due to invalid IL or missing references)
			//IL_09ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_09f2: Unknown result type (might be due to invalid IL or missing references)
			//IL_09f4: Unknown result type (might be due to invalid IL or missing references)
			//IL_09f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_09fd: Unknown result type (might be due to invalid IL or missing references)
			//IL_09ff: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f01: Unknown result type (might be due to invalid IL or missing references)
			//IL_090c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0911: Unknown result type (might be due to invalid IL or missing references)
			//IL_0915: Unknown result type (might be due to invalid IL or missing references)
			//IL_091c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0921: Unknown result type (might be due to invalid IL or missing references)
			//IL_0923: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a20: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a22: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a24: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a26: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a28: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a2a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a2c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a2e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a0b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a0d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a0f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a11: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a13: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a15: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a17: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a19: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f10: Unknown result type (might be due to invalid IL or missing references)
			//IL_0484: Unknown result type (might be due to invalid IL or missing references)
			//IL_0489: Unknown result type (might be due to invalid IL or missing references)
			//IL_048b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0499: Unknown result type (might be due to invalid IL or missing references)
			//IL_049e: Unknown result type (might be due to invalid IL or missing references)
			//IL_04a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_04a5: Unknown result type (might be due to invalid IL or missing references)
			//IL_04a9: Unknown result type (might be due to invalid IL or missing references)
			//IL_04ae: Unknown result type (might be due to invalid IL or missing references)
			//IL_04bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_04c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_04d0: Unknown result type (might be due to invalid IL or missing references)
			//IL_04d5: Unknown result type (might be due to invalid IL or missing references)
			//IL_04da: Unknown result type (might be due to invalid IL or missing references)
			//IL_04dc: Unknown result type (might be due to invalid IL or missing references)
			//IL_04de: Unknown result type (might be due to invalid IL or missing references)
			//IL_04e0: Unknown result type (might be due to invalid IL or missing references)
			//IL_04e2: Unknown result type (might be due to invalid IL or missing references)
			//IL_04e7: Unknown result type (might be due to invalid IL or missing references)
			//IL_04eb: Unknown result type (might be due to invalid IL or missing references)
			//IL_04f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_04f2: Unknown result type (might be due to invalid IL or missing references)
			//IL_04f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0503: Unknown result type (might be due to invalid IL or missing references)
			//IL_0508: Unknown result type (might be due to invalid IL or missing references)
			//IL_050d: Unknown result type (might be due to invalid IL or missing references)
			//IL_051c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0521: Unknown result type (might be due to invalid IL or missing references)
			//IL_053c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0541: Unknown result type (might be due to invalid IL or missing references)
			//IL_054a: Unknown result type (might be due to invalid IL or missing references)
			//IL_055e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0560: Unknown result type (might be due to invalid IL or missing references)
			//IL_0573: Unknown result type (might be due to invalid IL or missing references)
			//IL_0578: Unknown result type (might be due to invalid IL or missing references)
			//IL_092f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0931: Unknown result type (might be due to invalid IL or missing references)
			//IL_0933: Unknown result type (might be due to invalid IL or missing references)
			//IL_0935: Unknown result type (might be due to invalid IL or missing references)
			//IL_0937: Unknown result type (might be due to invalid IL or missing references)
			//IL_0939: Unknown result type (might be due to invalid IL or missing references)
			//IL_0949: Unknown result type (might be due to invalid IL or missing references)
			//IL_0955: Unknown result type (might be due to invalid IL or missing references)
			//IL_095a: Unknown result type (might be due to invalid IL or missing references)
			//IL_095f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0963: Unknown result type (might be due to invalid IL or missing references)
			//IL_0968: Unknown result type (might be due to invalid IL or missing references)
			//IL_0973: Unknown result type (might be due to invalid IL or missing references)
			//IL_097f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0984: Unknown result type (might be due to invalid IL or missing references)
			//IL_098b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0990: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a37: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a39: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a3b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a40: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f27: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f29: Unknown result type (might be due to invalid IL or missing references)
			//IL_0596: Unknown result type (might be due to invalid IL or missing references)
			//IL_059b: Unknown result type (might be due to invalid IL or missing references)
			//IL_058a: Unknown result type (might be due to invalid IL or missing references)
			//IL_058f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f40: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f42: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a5b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a5d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a5f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a61: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a66: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a6a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a71: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a79: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a7e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a83: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a85: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a87: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a89: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a8b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a90: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a92: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a94: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a96: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a98: Unknown result type (might be due to invalid IL or missing references)
			//IL_0aaf: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ac9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ace: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ad0: Unknown result type (might be due to invalid IL or missing references)
			//IL_0bcb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0bde: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b25: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b27: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b29: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b2e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b32: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b0e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b10: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b12: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b17: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b1b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0bf1: Unknown result type (might be due to invalid IL or missing references)
			//IL_0bf3: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b37: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b39: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b40: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b45: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c2c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c2e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b5e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b60: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b62: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b67: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b4e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b50: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b52: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b57: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b69: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b6b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b6d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b6f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b73: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b9d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b89: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b94: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b99: Unknown result type (might be due to invalid IL or missing references)
			//IL_0bb3: Unknown result type (might be due to invalid IL or missing references)
			//IL_0bbe: Unknown result type (might be due to invalid IL or missing references)
			//IL_0bc3: Unknown result type (might be due to invalid IL or missing references)
			TriangleMeshNode meshNode = node as TriangleMeshNode;
			Vector3 val = (Vector3)meshNode.position;
			if (meshNode.connections.Length < 3 && !IsPositionInsideCollider(val))
			{
				tileBounds.center = (Vector3)meshNode.position;
				tileBounds.size = Vector3.one * 0.1f;
				for (int i = 0; i < 3; i++)
				{
					tileBounds.Encapsulate((Vector3)meshNode.GetVertex(i));
				}
				ref Bounds reference = ref tileBounds;
				reference.size += new Vector3(12f, 12f, 12f);
				ref Bounds reference2 = ref tileBounds;
				reference2.center += new Vector3(0f, -3f, 0f);
				List<TriangleMeshNode> nodesInBounds = AstarPath.active.astarData.recastGraph.GetNodesInBounds(tileBounds);
				for (int num = nodesInBounds.Count - 1; num >= 0; num--)
				{
					TriangleMeshNode triNode = nodesInBounds[num];
					Vector3 pos = (Vector3)triNode.position;
					LinkedGraphNodes linkedGraphNodes = linkedNodes.Find((LinkedGraphNodes pair) => (pair.node1 == meshNode && pair.node2 == triNode) || (pair.node1 == triNode && pair.node2 == meshNode));
					if (meshNode.Area == triNode.Area || triNode == meshNode || meshNode.ContainsConnection(triNode) || linkedGraphNodes != null || Mathf.Abs(val.y - pos.y) > jumpHeight || IsPositionInsideCollider(pos))
					{
						nodesInBounds.RemoveAt(num);
					}
					else
					{
						List<GraphNode> list = new List<GraphNode>();
						bool flag = false;
						GraphHitInfo hit;
						for (int num2 = 0; num2 < 3; num2++)
						{
							list.Clear();
							Vector3 val2 = (Vector3)meshNode.GetVertex(num2);
							Vector3 val3 = val2;
							Vector3 val4 = (Vector3)meshNode.position - val2;
							val2 = val3 + val4.normalized * Vector3.Distance(val2, (Vector3)meshNode.position) * 0.01f;
							Vector3 val5 = (Vector3)meshNode.GetVertex((num2 + 1 <= 2) ? (num2 + 1) : 0);
							Vector3 val6 = val5;
							Vector3 val7 = (Vector3)meshNode.position - val5;
							val5 = val6 + val7.normalized * Vector3.Distance(val5, (Vector3)meshNode.position) * 0.01f;
							Vector3 val8 = val2;
							Vector3 val9 = val5 - val2;
							Vector3 tmp_origin = val8 + val9.normalized * Vector3.Distance(val2, val5) * 0.5f;
							Vector3 tmp_end = new Vector3(((Vector3)triNode.position).x, tmp_origin.y, ((Vector3)triNode.position).z);
							AstarPath.active.astarData.recastGraph.Linecast(tmp_origin, tmp_end, meshNode, out hit, list);
							Color white = Color.white;
							if (list.Count <= 1)
							{
								flag = true;
								white = Color.cyan;
								break;
							}
							white = Color.red;
						}
						if (!flag)
						{
							nodesInBounds.RemoveAt(num);
						}
						else
						{
							flag = false;
							for (int num3 = 0; num3 < 3; num3++)
							{
								list.Clear();
								Vector3 val10 = (Vector3)triNode.GetVertex(num3);
								Vector3 val11 = val10;
								Vector3 val12 = (Vector3)triNode.position - val10;
								val10 = val11 + val12.normalized * Vector3.Distance(val10, (Vector3)triNode.position) * 0.01f;
								Vector3 val13 = (Vector3)triNode.GetVertex((num3 + 1 <= 2) ? (num3 + 1) : 0);
								Vector3 val14 = val13;
								Vector3 val15 = (Vector3)triNode.position - val13;
								val13 = val14 + val15.normalized * Vector3.Distance(val13, (Vector3)triNode.position) * 0.01f;
								Vector3 val16 = val10;
								Vector3 val17 = val13 - val10;
								Vector3 tmp_origin2 = val16 + val17.normalized * Vector3.Distance(val10, val13) * 0.5f;
								Vector3 tmp_end2 = new Vector3(((Vector3)meshNode.position).x, tmp_origin2.y, ((Vector3)meshNode.position).z);
								AstarPath.active.astarData.recastGraph.Linecast(tmp_origin2, tmp_end2, triNode, out hit, list);
								Color white2 = Color.white;
								if (list.Count <= 1)
								{
									flag = true;
									white2 = Color.cyan;
									break;
								}
								white2 = Color.cyan;
							}
							if (!flag)
							{
								nodesInBounds.RemoveAt(num);
							}
						}
					}
				}
				RecastGraph recastGraph = AstarPath.active.astarData.recastGraph;
				for (int num4 = nodesInBounds.Count - 1; num4 >= 0; num4--)
				{
					TriangleMeshNode triangleMeshNode = nodesInBounds[num4];
					Vector3 val18 = Vector3.zero;
					Vector3 val19 = Vector3.zero;
					Vector3 val20 = Vector3.zero;
					Vector3 val21 = Vector3.zero;
					bool flag2 = false;
					float num5 = 0f;
					for (int num6 = 0; num6 < 3; num6++)
					{
						Vector3 val22 = (Vector3)meshNode.GetVertex(num6);
						Vector3 val23 = (Vector3)meshNode.GetVertex((num6 + 1 <= 2) ? (num6 + 1) : 0);
						float num7 = Vector3.Distance(val22, val23);
						num5 = ((!(num7 > num5)) ? num5 : num7);
					}
					Vector3 val24 = (Vector3)triangleMeshNode.position - (Vector3)meshNode.position;
					val24.y = 0f;
					val24 = val24.normalized;
					LineSegment lineSegment = new LineSegment((Vector3)meshNode.position, (Vector3)meshNode.position + val24 * num5);
					List<GraphNode> list2 = new List<GraphNode>();
					for (int num8 = 0; num8 < 3; num8++)
					{
						Vector3 val25 = (Vector3)meshNode.GetVertex(num8);
						Vector3 val26 = (Vector3)meshNode.GetVertex((num8 + 1 <= 2) ? (num8 + 1) : 0);
						if (VectorMath.SegmentsIntersectXZ(lineSegment.v1, lineSegment.v2, val25, val26))
						{
							val18 = val25;
							val19 = val26;
							LineSegment lineSegment2 = new LineSegment(val18, val19);
							Vector3 val27 = lineSegment2.GetPointPercent(0.5f) - (Vector3)meshNode.position;
							Vector3 normalized = val27.normalized;
							recastGraph.Linecast((Vector3)meshNode.position, lineSegment2.GetPointPercent(0.5f) + normalized * 0.5f, meshNode, out var _, list2);
							if (list2.Count > 1)
							{
								flag2 = true;
							}
							break;
						}
					}
					float num9 = 0f;
					for (int num10 = 0; num10 < 3; num10++)
					{
						Vector3 val28 = (Vector3)triangleMeshNode.GetVertex(num10);
						Vector3 val29 = (Vector3)triangleMeshNode.GetVertex((num10 + 1 <= 2) ? (num10 + 1) : 0);
						float num11 = Vector3.Distance(val28, val29);
						num9 = ((!(num11 > num9)) ? num9 : num11);
					}
					Vector3 val30 = (Vector3)meshNode.position - (Vector3)triangleMeshNode.position;
					val30.y = 0f;
					val30 = val30.normalized;
					LineSegment lineSegment3 = new LineSegment((Vector3)triangleMeshNode.position, (Vector3)triangleMeshNode.position + val30 * num9);
					List<GraphNode> list3 = new List<GraphNode>();
					for (int num12 = 0; num12 < 3; num12++)
					{
						Vector3 val31 = (Vector3)triangleMeshNode.GetVertex(num12);
						Vector3 val32 = (Vector3)triangleMeshNode.GetVertex((num12 + 1 <= 2) ? (num12 + 1) : 0);
						if (VectorMath.SegmentsIntersectXZ(lineSegment3.v1, lineSegment3.v2, val31, val32))
						{
							val20 = val31;
							val21 = val32;
							LineSegment lineSegment4 = new LineSegment(val20, val21);
							Vector3 val33 = lineSegment4.GetPointPercent(0.5f) - (Vector3)triangleMeshNode.position;
							Vector3 normalized2 = val33.normalized;
							recastGraph.Linecast((Vector3)triangleMeshNode.position, lineSegment4.GetPointPercent(0.5f) + normalized2 * 0.5f, triangleMeshNode, out var _, list3);
							if (list3.Count > 1)
							{
								flag2 = true;
							}
							break;
						}
					}
					if (flag2)
					{
						nodesInBounds.RemoveAt(num4);
					}
					else
					{
						Vector3 zero = Vector3.zero;
						Vector3 zero2 = Vector3.zero;
						Vector3 zero3 = Vector3.zero;
						Vector3 zero4 = Vector3.zero;
						if (Vector3.Distance(val18, val19) < Vector3.Distance(val20, val21))
						{
							zero = val18;
							zero2 = val19;
							zero3 = val20;
							zero4 = val21;
						}
						else
						{
							zero = val20;
							zero2 = val21;
							zero3 = val18;
							zero4 = val19;
						}
						float num13 = 1.25f;
						Vector3 val34 = zero2 - zero;
						int num14 = Mathf.RoundToInt(val34.magnitude / num13);
						for (int num15 = 1; num15 < num14; num15++)
						{
							Vector3 val35 = zero;
							Vector3 val36 = zero2 - zero;
							Vector3 val37 = val35 + val36.normalized * num13 * (float)num15;
							Vector3 val38 = VectorMath.ClosestPointOnSegment(zero3, zero4, val37);
							Vector3 val39 = val37;
							Vector3 val40 = val38;
							Vector3 val41 = new Vector3(val39.x, 0f, val39.z);
							Vector3 val42 = new Vector3(val40.x, 0f, val40.z);
							float num16 = Vector3.Distance(val41, val42);
							float num17 = characterRadius * 2f;
							if (num16 < num17)
							{
								bool flag3 = val38.y < val37.y;
								Vector3 normalized3;
								if (flag3)
								{
									Vector3 val43 = val42 - val41;
									normalized3 = val43.normalized;
								}
								else
								{
									Vector3 val44 = val41 - val42;
									normalized3 = val44.normalized;
								}
								Vector3 val45 = normalized3;
								Vector3 val46 = val45 * (num17 - num16);
								if (flag3)
								{
									val40 += val46;
								}
								else
								{
									val39 += val46;
								}
								val37 = val39;
								val38 = val40;
								if (recastGraph.PointOnNavmesh(val37, NNConstraint.None) == null)
								{
									val37 = AstarPath.active.GetNearest(val37).clampedPosition;
								}
								if (recastGraph.PointOnNavmesh(val38, NNConstraint.None) == null)
								{
									val38 = AstarPath.active.GetNearest(val38).clampedPosition;
								}
							}
							if (!IsPositionInsideCollider_CanStand(val37) && !IsPositionInsideCollider_CanStand(val38) && IsNodeLinkEnabled(val37, val38))
							{
								linkedNodes.Add(new LinkedGraphNodes(meshNode, triangleMeshNode));
								nodeLinkSpawnInfo.Add(new NodeLinkSpawnInfo(val37, val38));
								checkCount++;
							}
						}
					}
				}
				LineSegment[] array = new LineSegment[3]
				{
					new LineSegment((Vector3)meshNode.GetVertex(0), (Vector3)meshNode.GetVertex(1)),
					new LineSegment((Vector3)meshNode.GetVertex(1), (Vector3)meshNode.GetVertex(2)),
					new LineSegment((Vector3)meshNode.GetVertex(2), (Vector3)meshNode.GetVertex(0))
				};
				List<GraphNode> list4 = new List<GraphNode>();
				RaycastHit val55 = default;
				foreach (LineSegment lineSegment5 in array)
				{
					list4.Clear();
					Vector3 val47 = lineSegment5.GetPointPercent(0.5f) - val;
					Vector3 normalized4 = val47.normalized;
					recastGraph.Linecast(val, lineSegment5.GetPointPercent(0.5f) + normalized4 * 0.5f, meshNode, out var _, list4);
					Color magenta = Color.magenta;
					if (list4.Count <= 1)
					{
						magenta = Color.cyan;
						float num19 = 1.25f;
						Vector3 val48 = lineSegment5.v2 - lineSegment5.v1;
						int num20 = Mathf.RoundToInt(val48.magnitude / num19);
						Vector3 val49 = lineSegment5.GetPointPercent(0.5f) - val;
						Vector3 normalized5 = val49.normalized;
						Vector3 val50 = lineSegment5.v2 - lineSegment5.v1;
						Vector3 normalized6 = val50.normalized;
						Vector3 val51 = new Vector3(0f - normalized6.z, 0f, normalized6.x);
						Vector3 val52 = new Vector3(normalized6.z, 0f, 0f - normalized6.x);
						float num21 = Vector3.Dot(val51, normalized5);
						float num22 = Vector3.Dot(val52, normalized5);
						Vector3 val53 = ((!(num21 < num22)) ? val51 : val52);
						for (int num23 = 1; num23 < num20; num23++)
						{
							Vector3 point = lineSegment5.GetPoint(num19 * (float)num23);
							Vector3 val54 = point + val53 * (characterRadius * 2f + extraDropdownDistance);
							if (Physics.Raycast(val54, Vector3.down, ref val55, recastGraph.forcedBoundsSize.y, LayerMask.op_Implicit(recastGraph.mask), (QueryTriggerInteraction)1))
							{
								Vector3 val56 = val55.point + new Vector3(0f, recastGraph.cellHeight * 2f, 0f);
								if (Mathf.Abs(val56.y - point.y) > jumpHeight && !IsPositionInsideCollider_CanStand(val56) && recastGraph.PointOnNavmesh(val56, NNConstraint.None) != null && IsNodeLinkEnabled(point, val56))
								{
									nodeLinkSpawnInfo.Add(new NodeLinkSpawnInfo(point, val56));
								}
							}
						}
					}
				}
			}
			return true;
		});
		allNavmeshCuts.Clear();
		allNavmeshCuts.TrimExcess();
	}

	private void CreateFinalNodeLinks()
	{
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		nodeLinkObjs.RemoveAll((CharacterNodeLink x) => (Object)(object)x == (Object)null || x.isLinkActive);
		for (int num = 0; num < this.nodeLinkSpawnInfo.Count; num++)
		{
			NodeLinkSpawnInfo nodeLinkSpawnInfo = this.nodeLinkSpawnInfo[num];
			CharacterNodeLink characterNodeLink = Object.Instantiate<CharacterNodeLink>(nodeLinkPrefab);
			((Object)characterNodeLink).name = "CharacterNodeLink" + num;
			((Component)characterNodeLink).transform.position = nodeLinkSpawnInfo.nodeLinkStartPos;
			characterNodeLink.end.position = nodeLinkSpawnInfo.nodeLinkEndPos;
			characterNodeLink.oneWayToStart = false;
			characterNodeLink.oneWayToEnd = false;
			float num2 = ((Component)characterNodeLink).transform.position.y - characterNodeLink.end.position.y;
			if (Mathf.Abs(num2) > jumpHeight)
			{
				if (num2 < 0f)
				{
					characterNodeLink.oneWayToStart = true;
				}
				else if (num2 > 0f)
				{
					characterNodeLink.oneWayToEnd = true;
				}
			}
			((Component)characterNodeLink).transform.parent = ((Component)this).transform;
			characterNodeLink.OnPostScan();
			nodeLinkObjs.Add(characterNodeLink);
		}
		Debug.Log((object)"Finished Generating Node Links");
	}

	private bool IsPositionInsideCollider(Vector3 pos)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		int layerMask = LayerMask.op_Implicit(AstarPath.active.astarData.recastGraph.mask);
		return IsPositionInsideCollider(pos, layerMask);
	}

	private bool IsPositionInsideCollider(Vector3 pos, int layerMask)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = pos + new Vector3(0f, AstarPath.active.astarData.recastGraph.cellHeight * 2f, 0f);
		Ray val2 = new Ray(val, Vector3.up);
		float y = AstarPath.active.astarData.recastGraph.forcedBoundsSize.y;
		if (layerMask == -1)
		{
			layerMask = -5;
		}
		RaycastHit val3 = default;
		if (Physics.Raycast(val2, ref val3, y, layerMask, (QueryTriggerInteraction)1))
		{
			val2.origin = val3.point + Vector3.down;
		}
		else
		{
			val2.origin = val2.GetPoint(y);
		}
		val2.direction = Vector3.down;
		if (Physics.Raycast(val2, Vector3.Distance(val, val2.origin), layerMask, (QueryTriggerInteraction)1))
		{
			return true;
		}
		return false;
	}

	private bool IsPositionInsideCollider_CanStand(Vector3 pos, int layerMask = -1)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		if (layerMask == -1)
		{
			layerMask = -5;
		}
		float num = 2.5f;
		float num2 = 0.05f;
		Vector3 val = pos;
		val.y += AstarPath.active.astarData.recastGraph.cellHeight * 2f + num2;
		Vector3 val2 = pos;
		val2.y += AstarPath.active.astarData.recastGraph.cellHeight * 2f + (num - num2);
		Collider[] array = Physics.OverlapCapsule(val, val2, num2, layerMask, (QueryTriggerInteraction)1);
		foreach (Collider val3 in array)
		{
			if ((Object)(object)val3 != (Object)null && !val3.isTrigger)
			{
				return true;
			}
		}
		return IsPointIntersectingNavmeshCuts(pos);
	}

	private bool IsNodeInsideCollider(MeshNode node)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		bool result = true;
		for (int i = 0; i < 3; i++)
		{
			if (!IsPositionInsideCollider((Vector3)node.GetVertex(i)))
			{
				result = false;
				break;
			}
		}
		return result;
	}

	private bool IsPointIntersectingNavmeshCuts(Vector3 point)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < allNavmeshCuts.Count; i++)
		{
			NavmeshCut navmeshCut = allNavmeshCuts[i];
			if (((Behaviour)navmeshCut).enabled && ((Component)navmeshCut).gameObject.activeInHierarchy && navmeshCut.ContainsPointOBB(point))
			{
				return true;
			}
		}
		return false;
	}

	private bool IsNodeLinkEnabled(Vector3 startPoint, Vector3 endPoint)
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		float num = CharacterNodeLink.NodeLinkRadius * CharacterNodeLink.NodeLinkRadius;
		for (int i = 0; i < nodeLinkObjs.Count; i++)
		{
			CharacterNodeLink characterNodeLink = nodeLinkObjs[i];
			if (characterNodeLink.isLinkActive)
			{
				continue;
			}
			Vector3 val = startPoint - ((Component)characterNodeLink).transform.position;
			if (val.sqrMagnitude <= num)
			{
				Vector3 val2 = endPoint - characterNodeLink.end.position;
				if (val2.sqrMagnitude <= num)
				{
					Debug.Log((object)string.Concat(new object[4] { "Node Link Failed, it is disabled. Start Pos: ", startPoint, ", End Pos: ", endPoint }));
					return false;
				}
			}
		}
		return true;
	}

	public void ResetScanned()
	{
		hasInitiallyScanned = false;
		hasFinishedGeneration = false;
		if (!Application.isEditor || nodeLinkObjs == null || nodeLinkObjs.Count <= 0)
		{
			return;
		}
		for (int num = nodeLinkObjs.Count - 1; num >= 0; num--)
		{
			CharacterNodeLink characterNodeLink = nodeLinkObjs[num];
			if ((Object)(object)characterNodeLink != (Object)null && !characterNodeLink.isManualLink && characterNodeLink.isLinkActive)
			{
				Object.DestroyImmediate((Object)(object)((Component)characterNodeLink).gameObject);
			}
		}
		nodeLinkObjs.RemoveAll((CharacterNodeLink x) => (Object)(object)x == (Object)null);
	}

	private int DescendingOrder(float a, float b)
	{
		return b.CompareTo(a);
	}
}
