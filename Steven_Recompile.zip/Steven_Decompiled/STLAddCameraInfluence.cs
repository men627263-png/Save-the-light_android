using HutongGames.PlayMaker;
using UnityEngine;

[ActionCategory(/*Could not decode attribute arguments.*/)]
public class STLAddCameraInfluence : FsmStateAction
{
	public FsmGameObject influenceTarget;

	public FsmVector3 influenceAmount;

	public override void Reset()
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		influenceTarget = null;
		influenceAmount = FsmVector3.op_Implicit(Vector3.zero);
	}

	public override void OnEnter()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)influenceTarget.Value != (Object)null)
		{
			EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(influenceTarget.Value.transform, influenceAmount.Value)));
		}
		((FsmStateAction)this).Finish();
	}
}
