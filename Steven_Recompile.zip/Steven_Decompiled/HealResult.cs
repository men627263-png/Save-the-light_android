using UnityEngine;

public class HealResult
{
	public IHealSender source;

	public IDamageReceiver target;

	public int baseHealAmount;

	public int criticalHealAmount;

	public bool isCritical;

	public bool canOverheal;

	public float overhealPercentageAllowed;

	public HealInfo healInfo;

	public BaseAbility sourceAbility;

	public StarBonusCheck starBonus;

	public int totalHealAmount => Mathf.Max((!isNullified) ? 1 : 0, baseHealAmount + criticalHealAmount);

	public int totalRawHealAmount => baseHealAmount + criticalHealAmount;

	public bool isNullified { get; private set; }

	public HealResult(IHealSender source, IDamageReceiver target, float healAmount, bool isCritical = false, bool canOverheal = false, HealInfo healInfo = null, BaseAbility sourceAbility = null)
	{
		this.source = source;
		this.target = target;
		this.isCritical = isCritical;
		this.canOverheal = canOverheal;
		this.healInfo = healInfo;
		this.sourceAbility = sourceAbility;
		overhealPercentageAllowed = healInfo?.overhealPercentageAllowed ?? 0f;
		baseHealAmount = (int)healAmount;
		criticalHealAmount = 0;
	}

	public void Copy(HealResult other)
	{
		source = other.source;
		target = other.target;
		baseHealAmount = other.baseHealAmount;
		criticalHealAmount = other.criticalHealAmount;
		isCritical = other.isCritical;
		canOverheal = other.canOverheal;
		overhealPercentageAllowed = other.overhealPercentageAllowed;
		healInfo = other.healInfo;
		sourceAbility = other.sourceAbility;
	}

	public void ModifyBaseHeal(float multiplier)
	{
		baseHealAmount = Mathf.Max(0, Mathf.RoundToInt((float)baseHealAmount * multiplier));
	}

	public void ModifyCriticalHeal(float multiplier)
	{
		criticalHealAmount = Mathf.Max(0, Mathf.RoundToInt((float)criticalHealAmount * multiplier));
	}

	public void ModifyTotalHeal(float multiplier)
	{
		if (multiplier <= 0f)
		{
			NullifyTotalHeal();
			return;
		}
		baseHealAmount = Mathf.Max(0, Mathf.RoundToInt((float)baseHealAmount * multiplier));
		criticalHealAmount = Mathf.Max(0, Mathf.RoundToInt((float)criticalHealAmount * multiplier));
	}

	public void NullifyTotalHeal()
	{
		baseHealAmount = 0;
		criticalHealAmount = 0;
		isNullified = true;
	}
}
