using Grumpyface;
using UnityEngine;

public class BattleFXManager : MonoBehaviour
{
	[SerializeField]
	private GameObject sparksPrefab;

	[SerializeField]
	private GameObject hitParticlePrefab;

	private void OnEnable()
	{
		EventMessenger.Instance.AddListener<DamageResultEvent>(HandleDamageResultEvent);
		EventMessenger.Instance.AddListener<ImpactEvent>(HandleImpactEvent);
	}

	private void OnDisable()
	{
		EventMessenger.Instance.RemoveListener<DamageResultEvent>(HandleDamageResultEvent);
		EventMessenger.Instance.RemoveListener<ImpactEvent>(HandleImpactEvent);
	}

	private void HandleDamageResultEvent(DamageResultEvent evt)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		if (evt.result.impactResult == null)
		{
			return;
		}
		Vector3 destination = evt.result.impactResult.position;
		object obj = Vector3.zero;
		if (((object)destination/*cast due to constrained. prefix*/).Equals(obj) && evt.result.target is ITargetable)
		{
			destination = ((ITargetable)evt.result.target).CenterPosition;
		}
		BattleFX_ImpactSpark battleFX_ImpactSpark = ObjectPool.GetObject<BattleFX_ImpactSpark>(sparksPrefab, destination, false);
		battleFX_ImpactSpark.Init(evt.result.impactResult.type);
		if (evt.result.target is ITargetable)
		{
			ITargetable targetable = (ITargetable)evt.result.target;
			if (targetable.AllRenderers.Length > 0)
			{
				((Component)battleFX_ImpactSpark.Animator).gameObject.layer = ((Component)targetable.AllRenderers[0]).gameObject.layer;
			}
		}
		Vector3 direction = evt.result.impactResult.direction;
		direction.y = 0f;
		direction.Normalize();
		Direction direction2 = ((!(Vector3.Angle(direction, ((Component)GameCamera.instance.camera).transform.right) < 90f)) ? Direction.Left : Direction.Right);
		battleFX_ImpactSpark.Animator.Sprite.FlipX = direction2 == Direction.Right;
		((Component)battleFX_ImpactSpark).gameObject.SetActive(true);
		if (evt.result.target is BaseEnemy)
		{
			ParticleSystem componentInChildren = ObjectPool.GetObject(hitParticlePrefab, destination).GetComponentInChildren<ParticleSystem>();
			if (evt.result.target is BaseEnemy3D)
			{
				((Component)componentInChildren).gameObject.SetLayerRecursively(((Component)((BaseEnemy3D)evt.result.target).animator).gameObject.layer);
			}
			else
			{
				((Component)componentInChildren).gameObject.SetLayerRecursively(((Component)((BaseEnemy)evt.result.target).animatorTk2d).gameObject.layer);
			}
			MainModule main = componentInChildren.main;
			main.startColor = MinMaxGradient.op_Implicit(Color.white);
		}
	}

	private void HandleImpactEvent(ImpactEvent evt)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		Vector3 destination = evt.impactResult.position;
		object obj = Vector3.zero;
		if (((object)destination/*cast due to constrained. prefix*/).Equals(obj) && evt.reactor is ITargetable)
		{
			destination = ((ITargetable)evt.reactor).CenterPosition;
		}
		BattleFX_ImpactSpark battleFX_ImpactSpark = ObjectPool.GetObject<BattleFX_ImpactSpark>(sparksPrefab, destination, false);
		battleFX_ImpactSpark.Init(evt.impactResult.type);
		Vector3 direction = evt.impactResult.direction;
		direction.y = 0f;
		direction.Normalize();
		Direction direction2 = ((!(Vector3.Angle(direction, ((Component)GameCamera.instance.camera).transform.right) < 90f)) ? Direction.Left : Direction.Right);
		battleFX_ImpactSpark.Animator.Sprite.FlipX = direction2 == Direction.Right;
		((Component)battleFX_ImpactSpark).gameObject.SetActive(true);
		if (evt.reactor is BaseEnemy)
		{
			ParticleSystem componentInChildren = ObjectPool.GetObject(hitParticlePrefab, destination).GetComponentInChildren<ParticleSystem>();
			MainModule main = componentInChildren.main;
			main.startColor = MinMaxGradient.op_Implicit(Color.white);
		}
	}
}
