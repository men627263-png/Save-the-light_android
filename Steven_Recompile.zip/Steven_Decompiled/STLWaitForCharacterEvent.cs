using HutongGames.PlayMaker;
using UnityEngine;

[ActionCategory(/*Could not decode attribute arguments.*/)]
public class STLWaitForCharacterEvent : FsmStateAction
{
	public BaseCharacter character;

	public CharacterName characterName;

	public FsmEvent onHealthUpdated;

	public FsmEvent onOutgoingDamage;

	public FsmEvent onIncomingDamage;

	public FsmEvent onDamageReceived;

	public FsmEvent onIncomingHeal;

	public FsmEvent onHealReceived;

	public override void Reset()
	{
		character = null;
		characterName = CharacterName.Steven;
		onHealthUpdated = null;
		onOutgoingDamage = null;
		onIncomingDamage = null;
		onDamageReceived = null;
		onIncomingHeal = null;
		onHealReceived = null;
	}

	public override void OnEnter()
	{
		if ((Object)(object)character != (Object)null)
		{
			if (onHealthUpdated != null)
			{
				character.HealthUpdated += HandleHealthUpdated;
			}
			if (onOutgoingDamage != null)
			{
				character.OutgoingDamage += HandleOutgoingDamage;
			}
			if (onIncomingDamage != null)
			{
				character.IncomingDamage += HandleIncomingDamage;
			}
			if (onDamageReceived != null)
			{
				character.DamageReceived += HandleDamageReceived;
			}
			if (onIncomingHeal != null)
			{
				character.IncomingHeal += HandleIncomingHeal;
			}
			if (onHealReceived != null)
			{
				character.HealReceived += HandleHealReceived;
			}
		}
		((FsmStateAction)this).Finish();
	}

	public override void OnExit()
	{
		if ((Object)(object)character != (Object)null)
		{
			character.HealthUpdated += HandleHealthUpdated;
			character.OutgoingDamage += HandleOutgoingDamage;
			character.IncomingDamage += HandleIncomingDamage;
			character.DamageReceived += HandleDamageReceived;
			character.IncomingHeal += HandleIncomingHeal;
			character.HealReceived += HandleHealReceived;
		}
	}

	private void HandleHealthUpdated(int delta)
	{
		((FsmStateAction)this).Fsm.Event(onHealthUpdated);
	}

	private void HandleOutgoingDamage(DamageResult obj)
	{
		((FsmStateAction)this).Fsm.Event(onOutgoingDamage);
	}

	private void HandleIncomingDamage(DamageResult obj)
	{
		((FsmStateAction)this).Fsm.Event(onIncomingDamage);
	}

	private void HandleDamageReceived(DamageResult obj)
	{
		((FsmStateAction)this).Fsm.Event(onDamageReceived);
	}

	private void HandleIncomingHeal(HealResult obj)
	{
		((FsmStateAction)this).Fsm.Event(onIncomingHeal);
	}

	private void HandleHealReceived(HealResult obj)
	{
		((FsmStateAction)this).Fsm.Event(onHealReceived);
	}
}
