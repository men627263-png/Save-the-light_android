public class ShockwaveGeneric : Shockwave
{
	protected override void OnTargetReached(ITargetable target, float progress)
	{
	}
}
