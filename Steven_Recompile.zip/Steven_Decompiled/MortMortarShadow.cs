using UnityEngine;

public class MortMortarShadow : MonoBehaviour
{
	[SerializeField]
	private Projector projector;

	[SerializeField]
	private float startSize;

	[SerializeField]
	private float endSize;

	private float _percent;

	public float percent
	{
		get
		{
			return _percent;
		}
		set
		{
			_percent = Mathf.Clamp01(value);
			projector.orthographicSize = startSize + (endSize - startSize) * _percent;
		}
	}
}
