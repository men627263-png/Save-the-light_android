using System.Collections;
using DG.Tweening;
using Grumpyface;
using TMPro;
using UnityEngine;

public class UICurrency : MonoBehaviour
{
	public static UICurrency Instance;

	public GameObject lightBitsGroup;

	public TextMeshProUGUI lightBitsText;

	public GameObject keyGroup;

	public TextMeshProUGUI keyGreenAmountText;

	public TextMeshProUGUI keyBlueAmountText;

	public TextMeshProUGUI keyIndigoAmountText;

	public TextMeshProUGUI keyOrangeAmountText;

	public TextMeshProUGUI keyRedAmountText;

	public TextMeshProUGUI keyVioletAmountText;

	public TextMeshProUGUI keyYellowAmountText;

	public ParticleAttractor lightBitParticleAtractor;

	[Header("Light Bit Properties")]
	public float autoHideLightBitsAfterSeconds = 6f;

	public float lightBitMarginRight = 150f;

	public float bumpDuration = 0.35f;

	public float bumpCountForEveryBump = 10f;

	[Header("Key Properties")]
	public float keyDisplayTime = 3f;

	public float keySpaceFromLightBit = 200f;

	public float keyLayoutStartX;

	public float keyLayoutSpacing = -160f;

	[Header("Shared Properties")]
	public float moveInTime = 0.2f;

	public float moveInPosition = -130f;

	private Tweener lightBitsMoveTween;

	private Tweener lightBitsScaleTween;

	private int currentLightBitsShowing;

	private Coroutine animateLightBits;

	private RectTransform _lightBitsAmountRectTransform;

	private RectTransform _keyAmountRectTransform;

	private Canvas _canvas;

	private RectTransform lightBitsAmountRectTransform
	{
		get
		{
			if ((Object)(object)_lightBitsAmountRectTransform == (Object)null)
			{
				_lightBitsAmountRectTransform = ((Component)lightBitsText).gameObject.GetComponent<RectTransform>();
			}
			return _lightBitsAmountRectTransform;
		}
	}

	private RectTransform keyAmountRectTransform
	{
		get
		{
			if ((Object)(object)_keyAmountRectTransform == (Object)null)
			{
				_keyAmountRectTransform = keyGroup.GetComponent<RectTransform>();
			}
			return _keyAmountRectTransform;
		}
	}

	private Canvas canvas
	{
		get
		{
			if ((Object)(object)_canvas == (Object)null)
			{
				_canvas = ((Component)this).GetComponentInParent<Canvas>();
			}
			return _canvas;
		}
	}

	private void Awake()
	{
		Instance = this;
		PlayerGameState.Instance.KeyUpdated += KeyUpdate;
		PlayerGameState.Instance.LightBitsUpdated += LightBitsUpdate;
		PlayerGameState.Instance.PlayerDataChanged += HandlePlayerDataChanged;
		HandlePlayerDataChanged();
	}

	private void OnDestroy()
	{
		Instance = null;
		PlayerGameState.Instance.KeyUpdated -= KeyUpdate;
		PlayerGameState.Instance.LightBitsUpdated -= LightBitsUpdate;
		PlayerGameState.Instance.PlayerDataChanged -= HandlePlayerDataChanged;
	}

	private void HandlePlayerDataChanged()
	{
		currentLightBitsShowing = PlayerGameState.Instance.GetLightBitsAmount();
		lightBitsText.text = currentLightBitsShowing.ToString();
		keyBlueAmountText.text = PlayerGameState.Instance.GetKeyTypeCount(KeyType.Blue).ToString();
		keyGreenAmountText.text = PlayerGameState.Instance.GetKeyTypeCount(KeyType.Green).ToString();
		keyIndigoAmountText.text = PlayerGameState.Instance.GetKeyTypeCount(KeyType.Indigo).ToString();
		keyOrangeAmountText.text = PlayerGameState.Instance.GetKeyTypeCount(KeyType.Orange).ToString();
		keyRedAmountText.text = PlayerGameState.Instance.GetKeyTypeCount(KeyType.Red).ToString();
		keyVioletAmountText.text = PlayerGameState.Instance.GetKeyTypeCount(KeyType.Violet).ToString();
		keyYellowAmountText.text = PlayerGameState.Instance.GetKeyTypeCount(KeyType.Yellow).ToString();
	}

	private void LightBitsUpdate(int newAmount)
	{
		if (animateLightBits != null)
		{
			((MonoBehaviour)this).StopCoroutine(animateLightBits);
		}
		else
		{
			currentLightBitsShowing = newAmount;
		}
		animateLightBits = ((MonoBehaviour)this).StartCoroutine(AnimateToNewAmount(newAmount));
	}

	private IEnumerator AnimateToNewAmount(int amountTotal)
	{
		float targetCoins = amountTotal;
		float currentCoins = currentLightBitsShowing;
		float coinsNeeded = targetCoins - currentCoins;
		float bumpTimeDuration = coinsNeeded / bumpCountForEveryBump * bumpDuration;
		float coinsPerFrame = coinsNeeded / bumpTimeDuration;
		yield return (object)new WaitForSeconds(moveInTime);
		if (targetCoins < currentCoins)
		{
			BumpLightBits();
		}
		else
		{
			BumpLightBits((int)(bumpTimeDuration / bumpDuration) + 1);
		}
		while (currentCoins < targetCoins)
		{
			currentCoins += coinsPerFrame * Time.deltaTime;
			if (currentCoins > targetCoins)
			{
				currentCoins = targetCoins;
			}
			lightBitsText.text = ((int)currentCoins/*cast due to constrained. prefix*/).ToString();
			lightBitsText.ForceMeshUpdate();
			currentLightBitsShowing = (int)currentCoins;
			yield return null;
		}
		lightBitsText.text = ((int)targetCoins/*cast due to constrained. prefix*/).ToString();
		UpdateSpacing();
	}

	private void UpdateSpacing()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_031f: Unknown result type (might be due to invalid IL or missing references)
		//IL_037c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0381: Unknown result type (might be due to invalid IL or missing references)
		//IL_0391: Unknown result type (might be due to invalid IL or missing references)
		//IL_0396: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0401: Unknown result type (might be due to invalid IL or missing references)
		//IL_0411: Unknown result type (might be due to invalid IL or missing references)
		//IL_0416: Unknown result type (might be due to invalid IL or missing references)
		//IL_041f: Unknown result type (might be due to invalid IL or missing references)
		RectTransform val = lightBitsAmountRectTransform;
		Bounds textBounds = lightBitsText.textBounds;
		val.anchoredPosition3D = new Vector3(0f - textBounds.size.x - lightBitMarginRight, lightBitsAmountRectTransform.anchoredPosition3D.y, lightBitsAmountRectTransform.anchoredPosition3D.z);
		keyAmountRectTransform.anchoredPosition3D = new Vector3(lightBitsAmountRectTransform.anchoredPosition3D.x - keySpaceFromLightBit, keyAmountRectTransform.anchoredPosition3D.y, keyAmountRectTransform.anchoredPosition3D.z);
		float num = keyLayoutStartX;
		GameObject gameObject = ((Component)keyGreenAmountText.transform.parent).gameObject;
		gameObject.SetActive(false);
		if (PlayerGameState.Instance.GetKeyTypeCount(KeyType.Green) > 0)
		{
			gameObject.SetActive(true);
			gameObject.transform.localPosition = new Vector3(num, gameObject.transform.localPosition.y, gameObject.transform.localPosition.z);
			num += keyLayoutSpacing;
		}
		gameObject = ((Component)keyBlueAmountText.transform.parent).gameObject;
		gameObject.SetActive(false);
		if (PlayerGameState.Instance.GetKeyTypeCount(KeyType.Blue) > 0)
		{
			gameObject.SetActive(true);
			gameObject.transform.localPosition = new Vector3(num, gameObject.transform.localPosition.y, gameObject.transform.localPosition.z);
			num += keyLayoutSpacing;
		}
		gameObject = ((Component)keyIndigoAmountText.transform.parent).gameObject;
		gameObject.SetActive(false);
		if (PlayerGameState.Instance.GetKeyTypeCount(KeyType.Indigo) > 0)
		{
			gameObject.SetActive(true);
			gameObject.transform.localPosition = new Vector3(num, gameObject.transform.localPosition.y, gameObject.transform.localPosition.z);
			num += keyLayoutSpacing;
		}
		gameObject = ((Component)keyOrangeAmountText.transform.parent).gameObject;
		gameObject.SetActive(false);
		if (PlayerGameState.Instance.GetKeyTypeCount(KeyType.Orange) > 0)
		{
			gameObject.SetActive(true);
			gameObject.transform.localPosition = new Vector3(num, gameObject.transform.localPosition.y, gameObject.transform.localPosition.z);
			num += keyLayoutSpacing;
		}
		gameObject = ((Component)keyRedAmountText.transform.parent).gameObject;
		gameObject.SetActive(false);
		if (PlayerGameState.Instance.GetKeyTypeCount(KeyType.Red) > 0)
		{
			gameObject.SetActive(true);
			gameObject.transform.localPosition = new Vector3(num, gameObject.transform.localPosition.y, gameObject.transform.localPosition.z);
			num += keyLayoutSpacing;
		}
		gameObject = ((Component)keyVioletAmountText.transform.parent).gameObject;
		gameObject.SetActive(false);
		if (PlayerGameState.Instance.GetKeyTypeCount(KeyType.Violet) > 0)
		{
			gameObject.SetActive(true);
			gameObject.transform.localPosition = new Vector3(num, gameObject.transform.localPosition.y, gameObject.transform.localPosition.z);
			num += keyLayoutSpacing;
		}
		gameObject = ((Component)keyYellowAmountText.transform.parent).gameObject;
		gameObject.SetActive(false);
		if (PlayerGameState.Instance.GetKeyTypeCount(KeyType.Yellow) > 0)
		{
			gameObject.SetActive(true);
			gameObject.transform.localPosition = new Vector3(num, gameObject.transform.localPosition.y, gameObject.transform.localPosition.z);
			num += keyLayoutSpacing;
		}
	}

	private void KeyUpdate(KeyType keyType, int newAmount)
	{
		switch (keyType)
		{
		case KeyType.Blue:
			keyBlueAmountText.text = newAmount.ToString();
			break;
		case KeyType.Green:
			keyGreenAmountText.text = newAmount.ToString();
			break;
		case KeyType.Indigo:
			keyIndigoAmountText.text = newAmount.ToString();
			break;
		case KeyType.Orange:
			keyOrangeAmountText.text = newAmount.ToString();
			break;
		case KeyType.Red:
			keyRedAmountText.text = newAmount.ToString();
			break;
		case KeyType.Violet:
			keyVioletAmountText.text = newAmount.ToString();
			break;
		case KeyType.Yellow:
			keyVioletAmountText.text = newAmount.ToString();
			break;
		}
		UpdateSpacing();
	}

	public void DisplayKeys()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		UpdateSpacing();
		ShortcutExtensions.DOKill((Component)(object)keyAmountRectTransform, false);
		TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions46.DOAnchorPos3D(keyAmountRectTransform, new Vector3(keyAmountRectTransform.anchoredPosition3D.x, moveInPosition, keyAmountRectTransform.anchoredPosition3D.z), moveInTime, false), (Ease)3);
	}

	public void HideKeys()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		ShortcutExtensions.DOKill((Component)(object)keyAmountRectTransform, false);
		TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions46.DOAnchorPos3D(keyAmountRectTransform, new Vector3(keyAmountRectTransform.anchoredPosition3D.x, 0f - moveInPosition, keyAmountRectTransform.anchoredPosition3D.z), moveInTime, false), (Ease)2);
	}

	public void StartDisplayAndHideRoutine()
	{
		((MonoBehaviour)this).StartCoroutine("DisplayKeysInGUIRoutine");
	}

	private IEnumerator DisplayKeysInGUIRoutine()
	{
		yield return (object)new WaitForEndOfFrame();
		while (GameController.Instance.showingFirstItemPopup)
		{
			yield return null;
		}
		if ((Object)(object)Instance != (Object)null)
		{
			Instance.DisplayKeys();
		}
		yield return (object)new WaitForSeconds(keyDisplayTime);
		if ((Object)(object)Instance != (Object)null)
		{
			Instance.HideKeys();
		}
	}

	public void DisplayLightBits(bool autoHide = true)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		UpdateSpacing();
		if (lightBitsMoveTween != null)
		{
			TweenExtensions.Kill((Tween)(object)lightBitsMoveTween, false);
		}
		lightBitsMoveTween = TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions46.DOAnchorPos3D(lightBitsAmountRectTransform, new Vector3(lightBitsAmountRectTransform.anchoredPosition3D.x, moveInPosition, lightBitsAmountRectTransform.anchoredPosition3D.y), moveInTime, false), (Ease)3);
		((MonoBehaviour)this).StopCoroutine("StartAutoHideLightBits");
		if (autoHide)
		{
			((MonoBehaviour)this).StartCoroutine("StartAutoHideLightBits");
		}
	}

	public void HideLightBits()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Expected Obj, but got Unknown
		if (lightBitsMoveTween != null)
		{
			TweenExtensions.Kill((Tween)(object)lightBitsMoveTween, false);
		}
		lightBitsMoveTween = TweenSettingsExtensions.OnComplete<Tweener>(TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions46.DOAnchorPos3D(lightBitsAmountRectTransform, new Vector3(lightBitsAmountRectTransform.anchoredPosition3D.x, 0f - moveInPosition, lightBitsAmountRectTransform.anchoredPosition3D.y), moveInTime, false), (Ease)3), (TweenCallback)(() =>
		{
			currentLightBitsShowing = PlayerGameState.Instance.GetLightBitsAmount();
		}));
	}

	private IEnumerator StartAutoHideLightBits()
	{
		yield return (object)new WaitForSeconds(autoHideLightBitsAfterSeconds);
		HideLightBits();
	}

	public void BumpLightBits(int loops = 0)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		if (lightBitsScaleTween != null)
		{
			TweenExtensions.Kill((Tween)(object)lightBitsScaleTween, false);
		}
		((Transform)lightBitsAmountRectTransform).localScale = Vector3.one;
		lightBitsScaleTween = TweenSettingsExtensions.SetLoops<Tweener>(ShortcutExtensions.DOPunchScale((Transform)(object)lightBitsAmountRectTransform, new Vector3(0.5f, 0.5f, 0.5f), bumpDuration, 1, 1f), loops);
	}

	public void BumpAndHideLightBits()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Expected Obj, but got Unknown
		if (lightBitsScaleTween != null)
		{
			TweenExtensions.Kill((Tween)(object)lightBitsScaleTween, false);
		}
		((Transform)lightBitsAmountRectTransform).localScale = Vector3.one;
		lightBitsScaleTween = TweenSettingsExtensions.OnComplete<Tweener>(ShortcutExtensions.DOPunchScale((Transform)(object)lightBitsAmountRectTransform, new Vector3(0.5f, 0.5f, 0.5f), bumpDuration, 1, 1f), (TweenCallback)(() =>
		{
			HideLightBits();
		}));
	}

	public void SendLightBits(int lightBitsAdded, int maxParticles, Vector3 worldPosition, LightBitType lightBitType)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		string objectType = "UILightBitParticleSystem";
		if (lightBitType == LightBitType.MediumBit)
		{
			objectType = "UILightBitParticleSystemPurple";
		}
		if (lightBitType == LightBitType.LargeBit)
		{
			objectType = "UILightBitParticleSystemGold";
		}
		LightBitParticles lightBitParticles = ObjectPool.GetObject<LightBitParticles>(objectType, default(Vector3), true);
		((Component)lightBitParticles).transform.parent = ((Component)this).transform.parent;
		((Component)lightBitParticles).transform.localPosition = Vector2.op_Implicit(canvas.WorldToCanvas(worldPosition));
		lightBitParticles.Send(lightBitsAdded, maxParticles, lightBitParticleAtractor, 0f);
	}
}
