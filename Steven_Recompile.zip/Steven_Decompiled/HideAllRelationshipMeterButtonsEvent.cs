public class HideAllRelationshipMeterButtonsEvent : GameEvent
{
}
