using UnityEngine;

public class AEAnimationBuilderSprite : MonoBehaviour
{
	public Transform spriteTransform;

	private AELayer _layer;

	private Transform _childAnchor;

	public Transform childAnchor => _childAnchor;

	public AELayer layer => _layer;

	public int layerIndex => _layer.index;

	public void Init(AELayer newLayer)
	{
		_layer = newLayer;
	}

	public void AddChild(AEAnimationBuilderSprite newChild)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)_childAnchor == (Object)null)
		{
			_childAnchor = new GameObject("ChildAnchor").transform;
			_childAnchor.parent = ((Component)this).transform;
			_childAnchor.localPosition = spriteTransform.localPosition;
			((Component)_childAnchor).gameObject.layer = ((Component)this).gameObject.layer;
		}
		((Component)newChild).transform.parent = _childAnchor;
	}

	public void GoToFrameForced(int frameIndex)
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		if (frameIndex < _layer.inFrame || frameIndex >= _layer.outFrame)
		{
			return;
		}
		AEFrame frame = _layer.GetFrame(frameIndex);
		if (frame != null)
		{
			((Component)this).transform.localPosition = frame.positionUnity;
			Vector3 pivot = frame.pivot;
			spriteTransform.localPosition = new Vector3(0f - pivot.x, pivot.y, (float)layer.index);
			if ((Object)(object)_childAnchor != (Object)null)
			{
				_childAnchor.localPosition = new Vector3(spriteTransform.localPosition.x, spriteTransform.localPosition.y, 0f);
			}
			((Component)this).transform.localRotation = Quaternion.Euler(0f, 0f, 0f - frame.rotation);
		}
	}
}
