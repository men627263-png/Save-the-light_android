using UnityEngine;

namespace Pathfinding;

[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_navmesh_clamp.php")]
public class NavmeshClamp : MonoBehaviour
{
	private GraphNode prevNode;

	private Vector3 prevPos;

	private void LateUpdate()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		if (prevNode == null)
		{
			prevNode = AstarPath.active.GetNearest(((Component)this).transform.position).node;
			prevPos = ((Component)this).transform.position;
		}
		if (prevNode == null)
		{
			return;
		}
		if (prevNode != null && AstarData.GetGraph(prevNode) is IRaycastableGraph raycastableGraph)
		{
			if (raycastableGraph.Linecast(prevPos, ((Component)this).transform.position, prevNode, out var hit))
			{
				hit.point.y = ((Component)this).transform.position.y;
				Vector3 val = VectorMath.ClosestPointOnLine(hit.tangentOrigin, hit.tangentOrigin + hit.tangent, ((Component)this).transform.position);
				Vector3 point = hit.point;
				point += Vector3.ClampMagnitude((Vector3)hit.node.position - point, 0.008f);
				if (raycastableGraph.Linecast(point, val, hit.node, out hit))
				{
					hit.point.y = ((Component)this).transform.position.y;
					((Component)this).transform.position = hit.point;
				}
				else
				{
					val.y = ((Component)this).transform.position.y;
					((Component)this).transform.position = val;
				}
			}
			prevNode = hit.node;
		}
		prevPos = ((Component)this).transform.position;
	}
}
