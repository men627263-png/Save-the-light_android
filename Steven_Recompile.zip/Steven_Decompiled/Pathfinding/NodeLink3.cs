using System;
using System.Collections.Generic;
using UnityEngine;

namespace Pathfinding;

[AddComponentMenu("Pathfinding/Link3")]
[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_node_link3.php")]
public class NodeLink3 : GraphModifier
{
	protected static Dictionary<GraphNode, NodeLink3> reference = new Dictionary<GraphNode, NodeLink3>();

	public Transform end;

	public float costFactor = 1f;

	public bool oneWay;

	private NodeLink3Node startNode;

	private NodeLink3Node endNode;

	private MeshNode connectedNode1;

	private MeshNode connectedNode2;

	private Vector3 clamped1;

	private Vector3 clamped2;

	private bool postScanCalled;

	private static readonly Color GizmosColor = new Color(206f / 255f, 8f / 15f, 48f / 255f, 0.5f);

	private static readonly Color GizmosColorSelected = new Color(235f / 255f, 123f / 255f, 32f / 255f, 1f);

	public Transform StartTransform => ((Component)this).transform;

	public Transform EndTransform => end;

	public GraphNode StartNode => startNode;

	public GraphNode EndNode => endNode;

	public static NodeLink3 GetNodeLink(GraphNode node)
	{
		reference.TryGetValue(node, out var value);
		return value;
	}

	public override void OnPostScan()
	{
		if (AstarPath.active.isScanning)
		{
			InternalOnPostScan();
			return;
		}
		AstarPath.active.AddWorkItem(new AstarPath.AstarWorkItem((bool force) =>
		{
			InternalOnPostScan();
			return true;
		}));
	}

	public void InternalOnPostScan()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		if (AstarPath.active.astarData.pointGraph == null)
		{
			AstarPath.active.astarData.AddGraph(new PointGraph());
		}
		startNode = AstarPath.active.astarData.pointGraph.AddNode(new NodeLink3Node(AstarPath.active), (Int3)StartTransform.position);
		startNode.link = this;
		endNode = AstarPath.active.astarData.pointGraph.AddNode(new NodeLink3Node(AstarPath.active), (Int3)EndTransform.position);
		endNode.link = this;
		connectedNode1 = null;
		connectedNode2 = null;
		if (startNode == null || endNode == null)
		{
			startNode = null;
			endNode = null;
			return;
		}
		postScanCalled = true;
		reference[startNode] = this;
		reference[endNode] = this;
		Apply(forceNewCheck: true);
	}

	public override void OnGraphsPostUpdate()
	{
		if (!AstarPath.active.isScanning)
		{
			if (connectedNode1 != null && connectedNode1.Destroyed)
			{
				connectedNode1 = null;
			}
			if (connectedNode2 != null && connectedNode2.Destroyed)
			{
				connectedNode2 = null;
			}
			if (!postScanCalled)
			{
				OnPostScan();
			}
			else
			{
				Apply(forceNewCheck: false);
			}
		}
	}

	protected override void OnEnable()
	{
		base.OnEnable();
		if ((Object)(object)AstarPath.active != (Object)null && AstarPath.active.astarData != null && AstarPath.active.astarData.pointGraph != null)
		{
			OnGraphsPostUpdate();
		}
	}

	protected override void OnDisable()
	{
		base.OnDisable();
		postScanCalled = false;
		if (startNode != null)
		{
			reference.Remove(startNode);
		}
		if (endNode != null)
		{
			reference.Remove(endNode);
		}
		if (startNode != null && endNode != null)
		{
			startNode.RemoveConnection(endNode);
			endNode.RemoveConnection(startNode);
			if (connectedNode1 != null && connectedNode2 != null)
			{
				startNode.RemoveConnection(connectedNode1);
				connectedNode1.RemoveConnection(startNode);
				endNode.RemoveConnection(connectedNode2);
				connectedNode2.RemoveConnection(endNode);
			}
		}
	}

	private void RemoveConnections(GraphNode node)
	{
		node.ClearConnections(alsoReverse: true);
	}

	[ContextMenu("Recalculate neighbours")]
	private void ContextApplyForce()
	{
		if (Application.isPlaying)
		{
			Apply(forceNewCheck: true);
			if ((Object)(object)AstarPath.active != (Object)null)
			{
				AstarPath.active.FloodFill();
			}
		}
	}

	public void Apply(bool forceNewCheck)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0405: Unknown result type (might be due to invalid IL or missing references)
		//IL_040c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0413: Unknown result type (might be due to invalid IL or missing references)
		//IL_0418: Unknown result type (might be due to invalid IL or missing references)
		//IL_041d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0425: Unknown result type (might be due to invalid IL or missing references)
		//IL_0427: Unknown result type (might be due to invalid IL or missing references)
		//IL_0432: Unknown result type (might be due to invalid IL or missing references)
		//IL_0434: Unknown result type (might be due to invalid IL or missing references)
		//IL_043f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0441: Unknown result type (might be due to invalid IL or missing references)
		//IL_044c: Unknown result type (might be due to invalid IL or missing references)
		//IL_044e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0460: Unknown result type (might be due to invalid IL or missing references)
		//IL_046b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0470: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0526: Unknown result type (might be due to invalid IL or missing references)
		//IL_0531: Unknown result type (might be due to invalid IL or missing references)
		//IL_0536: Unknown result type (might be due to invalid IL or missing references)
		NNConstraint none = NNConstraint.None;
		none.distanceXZ = true;
		int graphIndex = (int)startNode.GraphIndex;
		none.graphMask = ~(1 << graphIndex);
		bool flag = true;
		NNInfo nearest = AstarPath.active.GetNearest(StartTransform.position, none);
		flag &= nearest.node == connectedNode1 && nearest.node != null;
		connectedNode1 = nearest.node as MeshNode;
		clamped1 = nearest.clampedPosition;
		if (connectedNode1 != null)
		{
			Debug.DrawRay((Vector3)connectedNode1.position, Vector3.up * 5f, Color.red);
		}
		NNInfo nearest2 = AstarPath.active.GetNearest(EndTransform.position, none);
		flag &= nearest2.node == connectedNode2 && nearest2.node != null;
		connectedNode2 = nearest2.node as MeshNode;
		clamped2 = nearest2.clampedPosition;
		if (connectedNode2 != null)
		{
			Debug.DrawRay((Vector3)connectedNode2.position, Vector3.up * 5f, Color.cyan);
		}
		if (connectedNode2 == null || connectedNode1 == null)
		{
			return;
		}
		startNode.SetPosition((Int3)StartTransform.position);
		endNode.SetPosition((Int3)EndTransform.position);
		if (flag && !forceNewCheck)
		{
			return;
		}
		RemoveConnections(startNode);
		RemoveConnections(endNode);
		uint cost = (uint)Mathf.RoundToInt((float)((Int3)(StartTransform.position - EndTransform.position)).costMagnitude * costFactor);
		startNode.AddConnection(endNode, cost);
		endNode.AddConnection(startNode, cost);
		Int3 rhs = connectedNode2.position - connectedNode1.position;
		for (int i = 0; i < connectedNode1.GetVertexCount(); i++)
		{
			Int3 vertex = connectedNode1.GetVertex(i);
			Int3 vertex2 = connectedNode1.GetVertex((i + 1) % connectedNode1.GetVertexCount());
			if (Int3.DotLong((vertex2 - vertex).Normal2D(), rhs) > 0)
			{
				continue;
			}
			for (int j = 0; j < connectedNode2.GetVertexCount(); j++)
			{
				Int3 vertex3 = connectedNode2.GetVertex(j);
				Int3 vertex4 = connectedNode2.GetVertex((j + 1) % connectedNode2.GetVertexCount());
				if (Int3.DotLong((vertex4 - vertex3).Normal2D(), rhs) >= 0 && (double)Int3.Angle(vertex4 - vertex3, vertex2 - vertex) > 2.967059810956319)
				{
					float val = 0f;
					float val2 = 1f;
					val2 = Math.Min(val2, VectorMath.ClosestPointOnLineFactor(vertex, vertex2, vertex3));
					val = Math.Max(val, VectorMath.ClosestPointOnLineFactor(vertex, vertex2, vertex4));
					if (!(val2 < val))
					{
						Vector3 val3 = (Vector3)(vertex2 - vertex) * val + (Vector3)vertex;
						Vector3 val4 = (Vector3)(vertex2 - vertex) * val2 + (Vector3)vertex;
						startNode.portalA = val3;
						startNode.portalB = val4;
						endNode.portalA = val4;
						endNode.portalB = val3;
						connectedNode1.AddConnection(startNode, (uint)Mathf.RoundToInt((float)((Int3)(clamped1 - StartTransform.position)).costMagnitude * costFactor));
						connectedNode2.AddConnection(endNode, (uint)Mathf.RoundToInt((float)((Int3)(clamped2 - EndTransform.position)).costMagnitude * costFactor));
						startNode.AddConnection(connectedNode1, (uint)Mathf.RoundToInt((float)((Int3)(clamped1 - StartTransform.position)).costMagnitude * costFactor));
						endNode.AddConnection(connectedNode2, (uint)Mathf.RoundToInt((float)((Int3)(clamped2 - EndTransform.position)).costMagnitude * costFactor));
						return;
					}
					Debug.LogError((object)("Wait wut!? " + val + " " + val2 + " " + (string)vertex + " " + (string)vertex2 + " " + (string)vertex3 + " " + (string)vertex4 + "\nTODO, fix this error"));
				}
			}
		}
	}

	private void DrawCircle(Vector3 o, float r, int detail, Color col)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = new Vector3(Mathf.Cos(0f) * r, 0f, Mathf.Sin(0f) * r) + o;
		Gizmos.color = col;
		for (int i = 0; i <= detail; i++)
		{
			float num = (float)i * (float)Math.PI * 2f / (float)detail;
			Vector3 val2 = new Vector3(Mathf.Cos(num) * r, 0f, Mathf.Sin(num) * r) + o;
			Gizmos.DrawLine(val, val2);
			val = val2;
		}
	}

	private void DrawGizmoBezier(Vector3 p1, Vector3 p2)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = p2 - p1;
		if (!(val == Vector3.zero))
		{
			Vector3 val2 = Vector3.Cross(Vector3.up, val);
			Vector3 val3 = Vector3.Cross(val, val2);
			val3 = val3.normalized;
			val3 *= val.magnitude * 0.1f;
			Vector3 p3 = p1 + val3;
			Vector3 p4 = p2 + val3;
			Vector3 val4 = p1;
			for (int i = 1; i <= 20; i++)
			{
				float t = (float)i / 20f;
				Vector3 val5 = AstarSplines.CubicBezier(p1, p3, p4, p2, t);
				Gizmos.DrawLine(val4, val5);
				val4 = val5;
			}
		}
	}

	public virtual void OnDrawGizmosSelected()
	{
		OnDrawGizmos(selected: true);
	}

	public void OnDrawGizmos()
	{
		OnDrawGizmos(selected: false);
	}

	public void OnDrawGizmos(bool selected)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		Color val = ((!selected) ? GizmosColor : GizmosColorSelected);
		if ((Object)(object)StartTransform != (Object)null)
		{
			DrawCircle(StartTransform.position, 0.4f, 10, val);
		}
		if ((Object)(object)EndTransform != (Object)null)
		{
			DrawCircle(EndTransform.position, 0.4f, 10, val);
		}
		if ((Object)(object)StartTransform != (Object)null && (Object)(object)EndTransform != (Object)null)
		{
			Gizmos.color = val;
			DrawGizmoBezier(StartTransform.position, EndTransform.position);
			if (selected)
			{
				Vector3 val2 = Vector3.Cross(Vector3.up, EndTransform.position - StartTransform.position);
				Vector3 normalized = val2.normalized;
				DrawGizmoBezier(StartTransform.position + normalized * 0.1f, EndTransform.position + normalized * 0.1f);
				DrawGizmoBezier(StartTransform.position - normalized * 0.1f, EndTransform.position - normalized * 0.1f);
			}
		}
	}

	static NodeLink3()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
	}
}
