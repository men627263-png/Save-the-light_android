using UnityEngine;

namespace Pathfinding;

public class EndingConditionProximity : ABPathEndingCondition
{
	public float maxDistance = 10f;

	public EndingConditionProximity(ABPath p, float maxDistance)
		: base(p)
	{
		this.maxDistance = maxDistance;
	}

	public override bool TargetFound(PathNode node)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = (Vector3)node.node.position - abPath.originalEndPoint;
		return val.sqrMagnitude <= maxDistance * maxDistance;
	}
}
