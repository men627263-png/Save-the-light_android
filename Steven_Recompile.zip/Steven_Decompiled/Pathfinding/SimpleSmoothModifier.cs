using System;
using System.Collections.Generic;
using Pathfinding.Util;
using UnityEngine;

namespace Pathfinding;

[Serializable]
[AddComponentMenu("Pathfinding/Modifiers/Simple Smooth")]
[RequireComponent(typeof(Seeker))]
[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_simple_smooth_modifier.php")]
public class SimpleSmoothModifier : MonoModifier
{
	public enum SmoothType
	{
		Simple,
		Bezier,
		OffsetSimple,
		CurvedNonuniform
	}

	public SmoothType smoothType;

	[Tooltip("The number of times to subdivide (divide in half) the path segments. [0...inf] (recommended [1...10])")]
	public int subdivisions = 2;

	[Tooltip("Number of times to apply smoothing")]
	public int iterations = 2;

	[Tooltip("Determines how much smoothing to apply in each smooth iteration. 0.5 usually produces the nicest looking curves")]
	public float strength = 0.5f;

	[Tooltip("Toggle to divide all lines in equal length segments")]
	public bool uniformLength = true;

	[Tooltip("The length of each segment in the smoothed path. A high value yields rough paths and low value yields very smooth paths, but is slower")]
	public float maxSegmentLength = 2f;

	[Tooltip("Length factor of the bezier curves' tangents")]
	public float bezierTangentLength = 0.4f;

	[Tooltip("Offset to apply in each smoothing iteration when using Offset Simple")]
	public float offset = 0.2f;

	[Tooltip("How much to smooth the path. A higher value will give a smoother path, but might take the character far off the optimal path.")]
	public float factor = 0.1f;

	public override int Order => 50;

	public override void Apply(Path p)
	{
		if (p.vectorPath == null)
		{
			Debug.LogWarning((object)"Can't process NULL path (has another modifier logged an error?)");
			return;
		}
		List<Vector3> list = null;
		switch (smoothType)
		{
		case SmoothType.Simple:
			list = SmoothSimple(p.vectorPath);
			break;
		case SmoothType.Bezier:
			list = SmoothBezier(p.vectorPath);
			break;
		case SmoothType.OffsetSimple:
			list = SmoothOffsetSimple(p.vectorPath);
			break;
		case SmoothType.CurvedNonuniform:
			list = CurvedNonuniform(p.vectorPath);
			break;
		}
		if (list != p.vectorPath)
		{
			ListPool<Vector3>.Release(p.vectorPath);
			p.vectorPath = list;
		}
	}

	public List<Vector3> CurvedNonuniform(List<Vector3> path)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		if (maxSegmentLength <= 0f)
		{
			Debug.LogWarning((object)"Max Segment Length is <= 0 which would cause DivByZero-exception or other nasty errors (avoid this)");
			return path;
		}
		int num = 0;
		for (int i = 0; i < path.Count - 1; i++)
		{
			Vector3 val = path[i] - path[i + 1];
			float magnitude = val.magnitude;
			for (float num2 = 0f; num2 <= magnitude; num2 += maxSegmentLength)
			{
				num++;
			}
		}
		List<Vector3> list = ListPool<Vector3>.Claim(num);
		Vector3 val2 = path[1] - path[0];
		Vector3 val3 = val2.normalized;
		for (int j = 0; j < path.Count - 1; j++)
		{
			Vector3 val4 = path[j] - path[j + 1];
			float magnitude2 = val4.magnitude;
			Vector3 val5 = val3;
			Vector3 normalized2;
			if (j < path.Count - 2)
			{
				Vector3 val6 = path[j + 2] - path[j + 1];
				Vector3 normalized = val6.normalized;
				Vector3 val7 = path[j] - path[j + 1];
				Vector3 val8 = normalized - val7.normalized;
				normalized2 = val8.normalized;
			}
			else
			{
				Vector3 val9 = path[j + 1] - path[j];
				normalized2 = val9.normalized;
			}
			Vector3 val10 = normalized2;
			Vector3 tan = val5 * magnitude2 * factor;
			Vector3 tan2 = val10 * magnitude2 * factor;
			Vector3 a = path[j];
			Vector3 b = path[j + 1];
			float num3 = 1f / magnitude2;
			for (float num4 = 0f; num4 <= magnitude2; num4 += maxSegmentLength)
			{
				float t = num4 * num3;
				list.Add(GetPointOnCubic(a, b, tan, tan2, t));
			}
			val3 = val10;
		}
		list[list.Count - 1] = path[path.Count - 1];
		return list;
	}

	public static Vector3 GetPointOnCubic(Vector3 a, Vector3 b, Vector3 tan1, Vector3 tan2, float t)
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		float num = t * t;
		float num2 = num * t;
		float num3 = 2f * num2 - 3f * num + 1f;
		float num4 = -2f * num2 + 3f * num;
		float num5 = num2 - 2f * num + t;
		float num6 = num2 - num;
		return num3 * a + num4 * b + num5 * tan1 + num6 * tan2;
	}

	public List<Vector3> SmoothOffsetSimple(List<Vector3> path)
	{
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		if (path.Count <= 2 || iterations <= 0)
		{
			return path;
		}
		if (iterations > 12)
		{
			Debug.LogWarning((object)"A very high iteration count was passed, won't let this one through");
			return path;
		}
		int num = (path.Count - 2) * (int)Mathf.Pow(2f, (float)iterations) + 2;
		List<Vector3> list = ListPool<Vector3>.Claim(num);
		List<Vector3> list2 = ListPool<Vector3>.Claim(num);
		for (int i = 0; i < num; i++)
		{
			list.Add(Vector3.zero);
			list2.Add(Vector3.zero);
		}
		for (int j = 0; j < path.Count; j++)
		{
			list[j] = path[j];
		}
		for (int k = 0; k < iterations; k++)
		{
			int num2 = (path.Count - 2) * (int)Mathf.Pow(2f, (float)k) + 2;
			List<Vector3> list3 = list;
			list = list2;
			list2 = list3;
			for (int l = 0; l < num2 - 1; l++)
			{
				Vector3 val = list2[l];
				Vector3 val2 = list2[l + 1];
				Vector3 val3 = Vector3.Cross(val2 - val, Vector3.up);
				val3 = val3.normalized;
				bool flag = false;
				bool flag2 = false;
				bool flag3 = false;
				bool flag4 = false;
				if (l != 0 && !VectorMath.IsColinearXZ(val, val2, list2[l - 1]))
				{
					flag3 = true;
					flag = VectorMath.RightOrColinearXZ(val, val2, list2[l - 1]);
				}
				if (l < num2 - 1 && !VectorMath.IsColinearXZ(val, val2, list2[l + 2]))
				{
					flag4 = true;
					flag2 = VectorMath.RightOrColinearXZ(val, val2, list2[l + 2]);
				}
				if (flag3)
				{
					list[l * 2] = val + ((!flag) ? (-val3 * offset * 1f) : (val3 * offset * 1f));
				}
				else
				{
					list[l * 2] = val;
				}
				if (flag4)
				{
					list[l * 2 + 1] = val2 + ((!flag2) ? (-val3 * offset * 1f) : (val3 * offset * 1f));
				}
				else
				{
					list[l * 2 + 1] = val2;
				}
			}
			list[(path.Count - 2) * (int)Mathf.Pow(2f, (float)(k + 1)) + 2 - 1] = list2[num2 - 1];
		}
		ListPool<Vector3>.Release(list2);
		return list;
	}

	public List<Vector3> SmoothSimple(List<Vector3> path)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		if (path.Count < 2)
		{
			return path;
		}
		List<Vector3> list;
		if (uniformLength)
		{
			maxSegmentLength = Mathf.Max(maxSegmentLength, 0.005f);
			float num = 0f;
			for (int i = 0; i < path.Count - 1; i++)
			{
				num += Vector3.Distance(path[i], path[i + 1]);
			}
			int num2 = Mathf.FloorToInt(num / maxSegmentLength);
			list = ListPool<Vector3>.Claim(num2 + 2);
			float num3 = 0f;
			for (int j = 0; j < path.Count - 1; j++)
			{
				Vector3 val = path[j];
				Vector3 val2 = path[j + 1];
				float num4;
				for (num4 = Vector3.Distance(val, val2); num3 < num4; num3 += maxSegmentLength)
				{
					list.Add(Vector3.Lerp(val, val2, num3 / num4));
				}
				num3 -= num4;
			}
		}
		else
		{
			subdivisions = Mathf.Max(subdivisions, 0);
			if (subdivisions > 10)
			{
				Debug.LogWarning((object)("Very large number of subdivisions. Cowardly refusing to subdivide every segment into more than " + (1 << subdivisions) + " subsegments"));
				subdivisions = 10;
			}
			int num5 = 1 << subdivisions;
			list = ListPool<Vector3>.Claim((path.Count - 1) * num5 + 1);
			for (int k = 0; k < path.Count - 1; k++)
			{
				for (int l = 0; l < num5; l++)
				{
					list.Add(Vector3.Lerp(path[k], path[k + 1], (float)l / (float)num5));
				}
			}
		}
		list.Add(path[path.Count - 1]);
		if (strength > 0f)
		{
			for (int m = 0; m < iterations; m++)
			{
				Vector3 val3 = list[0];
				for (int n = 1; n < list.Count - 1; n++)
				{
					Vector3 val4 = list[n];
					list[n] = Vector3.Lerp(val4, (val3 + list[n + 1]) / 2f, strength);
					val3 = val4;
				}
			}
		}
		return list;
	}

	public List<Vector3> SmoothBezier(List<Vector3> path)
	{
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		if (subdivisions < 0)
		{
			subdivisions = 0;
		}
		int num = 1 << subdivisions;
		List<Vector3> list = ListPool<Vector3>.Claim();
		for (int i = 0; i < path.Count - 1; i++)
		{
			Vector3 val = ((i != 0) ? (path[i + 1] - path[i - 1]) : (path[i + 1] - path[i]));
			Vector3 val2 = ((i != path.Count - 2) ? (path[i] - path[i + 2]) : (path[i] - path[i + 1]));
			val *= bezierTangentLength;
			val2 *= bezierTangentLength;
			Vector3 val3 = path[i];
			Vector3 p = val3 + val;
			Vector3 val4 = path[i + 1];
			Vector3 p2 = val4 + val2;
			for (int j = 0; j < num; j++)
			{
				list.Add(AstarSplines.CubicBezier(val3, p, p2, val4, (float)j / (float)num));
			}
		}
		list.Add(path[path.Count - 1]);
		return list;
	}
}
