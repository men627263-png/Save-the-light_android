using UnityEngine;

namespace Pathfinding;

public struct NNInfo
{
	public GraphNode node;

	public GraphNode constrainedNode;

	public Vector3 clampedPosition;

	public Vector3 constClampedPosition;

	public NNInfo(GraphNode node)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		this.node = node;
		constrainedNode = null;
		clampedPosition = Vector3.zero;
		constClampedPosition = Vector3.zero;
		UpdateInfo();
	}

	public void SetConstrained(GraphNode constrainedNode, Vector3 clampedPosition)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		this.constrainedNode = constrainedNode;
		constClampedPosition = clampedPosition;
	}

	public void UpdateInfo()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		clampedPosition = ((node == null) ? Vector3.zero : ((Vector3)node.position));
		constClampedPosition = ((constrainedNode == null) ? Vector3.zero : ((Vector3)constrainedNode.position));
	}

	public static explicit operator Vector3(NNInfo ob)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		return ob.clampedPosition;
	}

	public static explicit operator GraphNode(NNInfo ob)
	{
		return ob.node;
	}

	public static explicit operator NNInfo(GraphNode ob)
	{
		return new NNInfo(ob);
	}
}
