using System;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

namespace Pathfinding;

[Serializable]
[AddComponentMenu("Pathfinding/Modifiers/Raycast Simplifier")]
[RequireComponent(typeof(Seeker))]
[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_raycast_modifier.php")]
public class RaycastModifier : MonoModifier
{
	[HideInInspector]
	public bool useRaycasting = true;

	[HideInInspector]
	public LayerMask mask = LayerMask.op_Implicit(-1);

	[HideInInspector]
	public bool thickRaycast;

	[HideInInspector]
	public float thickRaycastRadius;

	[HideInInspector]
	public Vector3 raycastOffset = Vector3.zero;

	[HideInInspector]
	public bool subdivideEveryIter;

	public int iterations = 2;

	[HideInInspector]
	public bool useGraphRaycasting;

	private static List<Vector3> nodes;

	public override int Order => 40;

	public RaycastModifier()
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
	}

	public override void Apply(Path p)
	{
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		if (iterations <= 0)
		{
			return;
		}
		if (nodes == null)
		{
			nodes = new List<Vector3>(p.vectorPath.Count);
		}
		else
		{
			nodes.Clear();
		}
		nodes.AddRange(p.vectorPath);
		for (int i = 0; i < iterations; i++)
		{
			if (subdivideEveryIter && i != 0)
			{
				if (nodes.Capacity < nodes.Count * 3)
				{
					nodes.Capacity = nodes.Count * 3;
				}
				int count = nodes.Count;
				for (int j = 0; j < count - 1; j++)
				{
					nodes.Add(Vector3.zero);
					nodes.Add(Vector3.zero);
				}
				for (int num = count - 1; num > 0; num--)
				{
					Vector3 val = nodes[num];
					Vector3 val2 = nodes[num + 1];
					nodes[num * 3] = nodes[num];
					if (num != count - 1)
					{
						nodes[num * 3 + 1] = Vector3.Lerp(val, val2, 0.33f);
						nodes[num * 3 + 2] = Vector3.Lerp(val, val2, 0.66f);
					}
				}
			}
			int num2 = 0;
			while (num2 < nodes.Count - 2)
			{
				Vector3 v = nodes[num2];
				Vector3 v2 = nodes[num2 + 2];
				Stopwatch stopwatch = Stopwatch.StartNew();
				if (ValidateLine(null, null, v, v2))
				{
					nodes.RemoveAt(num2 + 1);
				}
				else
				{
					num2++;
				}
				stopwatch.Stop();
			}
		}
		p.vectorPath.Clear();
		p.vectorPath.AddRange(nodes);
	}

	public bool ValidateLine(GraphNode n1, GraphNode n2, Vector3 v1, Vector3 v2)
	{
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		if (useRaycasting)
		{
			RaycastHit val5 = default;
			if (thickRaycast && thickRaycastRadius > 0f)
			{
				Vector3 val = v1 + raycastOffset;
				float num = thickRaycastRadius;
				Vector3 val2 = v2 - v1;
				Vector3 val3 = v2 - v1;
				RaycastHit val4 = default;
				if (Physics.SphereCast(val, num, val2, ref val4, val3.magnitude, LayerMask.op_Implicit(mask)))
				{
					return false;
				}
			}
			else if (Physics.Linecast(v1 + raycastOffset, v2 + raycastOffset, ref val5, LayerMask.op_Implicit(mask)))
			{
				return false;
			}
		}
		if (useGraphRaycasting && n1 == null)
		{
			n1 = AstarPath.active.GetNearest(v1).node;
			n2 = AstarPath.active.GetNearest(v2).node;
		}
		if (useGraphRaycasting && n1 != null && n2 != null)
		{
			NavGraph graph = AstarData.GetGraph(n1);
			NavGraph graph2 = AstarData.GetGraph(n2);
			if (graph != graph2)
			{
				return false;
			}
			if (graph != null && graph is IRaycastableGraph raycastableGraph && raycastableGraph.Linecast(v1, v2, n1))
			{
				return false;
			}
		}
		return true;
	}
}
