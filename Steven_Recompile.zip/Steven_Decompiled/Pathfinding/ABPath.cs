using System;
using System.Text;
using UnityEngine;

namespace Pathfinding;

public class ABPath : Path
{
	public bool recalcStartEndCosts = true;

	public GraphNode startNode;

	public GraphNode endNode;

	public GraphNode startHint;

	public GraphNode endHint;

	public Vector3 originalStartPoint;

	public Vector3 originalEndPoint;

	public Vector3 startPoint;

	public Vector3 endPoint;

	public Int3 startIntPoint;

	public bool calculatePartial;

	protected PathNode partialBestTarget;

	protected int[] endNodeCosts;

	protected virtual bool hasEndPoint => true;

	public static ABPath Construct(Vector3 start, Vector3 end, OnPathDelegate callback = null)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		ABPath aBPath = PathPool.GetPath<ABPath>();
		aBPath.Setup(start, end, callback);
		return aBPath;
	}

	protected void Setup(Vector3 start, Vector3 end, OnPathDelegate callbackDelegate)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		callback = callbackDelegate;
		UpdateStartEnd(start, end);
	}

	protected void UpdateStartEnd(Vector3 start, Vector3 end)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		originalStartPoint = start;
		originalEndPoint = end;
		startPoint = start;
		endPoint = end;
		startIntPoint = (Int3)start;
		hTarget = (Int3)end;
	}

	public override uint GetConnectionSpecialCost(GraphNode a, GraphNode b, uint currentCost)
	{
		if (startNode != null && endNode != null)
		{
			if (a == startNode)
			{
				return (uint)((double)(startIntPoint - ((b != endNode) ? b.position : hTarget)).costMagnitude * ((double)currentCost * 1.0 / (double)(a.position - b.position).costMagnitude));
			}
			if (b == startNode)
			{
				return (uint)((double)(startIntPoint - ((a != endNode) ? a.position : hTarget)).costMagnitude * ((double)currentCost * 1.0 / (double)(a.position - b.position).costMagnitude));
			}
			if (a == endNode)
			{
				return (uint)((double)(hTarget - b.position).costMagnitude * ((double)currentCost * 1.0 / (double)(a.position - b.position).costMagnitude));
			}
			if (b == endNode)
			{
				return (uint)((double)(hTarget - a.position).costMagnitude * ((double)currentCost * 1.0 / (double)(a.position - b.position).costMagnitude));
			}
		}
		else
		{
			if (a == startNode)
			{
				return (uint)((double)(startIntPoint - b.position).costMagnitude * ((double)currentCost * 1.0 / (double)(a.position - b.position).costMagnitude));
			}
			if (b == startNode)
			{
				return (uint)((double)(startIntPoint - a.position).costMagnitude * ((double)currentCost * 1.0 / (double)(a.position - b.position).costMagnitude));
			}
		}
		return currentCost;
	}

	public override void Reset()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		base.Reset();
		startNode = null;
		endNode = null;
		startHint = null;
		endHint = null;
		originalStartPoint = Vector3.zero;
		originalEndPoint = Vector3.zero;
		startPoint = Vector3.zero;
		endPoint = Vector3.zero;
		calculatePartial = false;
		partialBestTarget = null;
		startIntPoint = default;
		hTarget = default;
		endNodeCosts = null;
	}

	public override void Prepare()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		nnConstraint.tags = enabledTags;
		NNInfo nearest = AstarPath.active.GetNearest(startPoint, nnConstraint, startHint);
		if (nnConstraint is PathNNConstraint pathNNConstraint)
		{
			pathNNConstraint.SetStart(nearest.node);
		}
		startPoint = nearest.clampedPosition;
		startIntPoint = (Int3)startPoint;
		startNode = nearest.node;
		if (hasEndPoint)
		{
			NNInfo nearest2 = AstarPath.active.GetNearest(endPoint, nnConstraint, endHint);
			endPoint = nearest2.clampedPosition;
			hTarget = (Int3)endPoint;
			endNode = nearest2.node;
			hTargetNode = endNode;
		}
		if (startNode == null && hasEndPoint && endNode == null)
		{
			Error();
			LogError("Couldn't find close nodes to the start point or the end point");
		}
		else if (startNode == null)
		{
			Error();
			LogError("Couldn't find a close node to the start point");
		}
		else if (endNode == null && hasEndPoint)
		{
			Error();
			LogError("Couldn't find a close node to the end point");
		}
		else if (!startNode.Walkable)
		{
			Error();
			LogError("The node closest to the start point is not walkable");
		}
		else if (hasEndPoint && !endNode.Walkable)
		{
			Error();
			LogError("The node closest to the end point is not walkable");
		}
		else if (hasEndPoint && startNode.Area != endNode.Area)
		{
			Error();
			LogError("There is no valid path to the target (start area: " + startNode.Area + ", target area: " + endNode.Area + ")");
		}
	}

	protected virtual void CompletePathIfStartIsValidTarget()
	{
		if (hasEndPoint && startNode == endNode)
		{
			Trace(pathHandler.GetPathNode(startNode));
			CompleteState = PathCompleteState.Complete;
		}
	}

	public override void Initialize()
	{
		if (startNode != null)
		{
			pathHandler.GetPathNode(startNode).flag2 = true;
		}
		if (endNode != null)
		{
			pathHandler.GetPathNode(endNode).flag2 = true;
		}
		PathNode pathNode = pathHandler.GetPathNode(startNode);
		pathNode.node = startNode;
		pathNode.pathID = pathHandler.PathID;
		pathNode.parent = null;
		pathNode.cost = 0u;
		pathNode.G = GetTraversalCost(startNode);
		pathNode.H = CalculateHScore(startNode);
		CompletePathIfStartIsValidTarget();
		if (CompleteState == PathCompleteState.Complete)
		{
			return;
		}
		startNode.Open(this, pathNode, pathHandler);
		searchedNodes++;
		partialBestTarget = pathNode;
		if (pathHandler.HeapEmpty())
		{
			if (!calculatePartial)
			{
				Error();
				LogError("No open points, the start node didn't open any nodes");
				return;
			}
			CompleteState = PathCompleteState.Partial;
			Trace(partialBestTarget);
		}
		currentR = pathHandler.PopNode();
	}

	public override void Cleanup()
	{
		if (startNode != null)
		{
			pathHandler.GetPathNode(startNode).flag2 = false;
		}
		if (endNode != null)
		{
			pathHandler.GetPathNode(endNode).flag2 = false;
		}
	}

	public override void CalculateStep(long targetTick)
	{
		int num = 0;
		while (CompleteState == PathCompleteState.NotCalculated)
		{
			searchedNodes++;
			if (currentR.node == endNode)
			{
				CompleteState = PathCompleteState.Complete;
				break;
			}
			if (currentR.H < partialBestTarget.H)
			{
				partialBestTarget = currentR;
			}
			currentR.node.Open(this, currentR, pathHandler);
			if (pathHandler.HeapEmpty())
			{
				Error();
				LogError("Searched whole area but could not find target");
				return;
			}
			currentR = pathHandler.PopNode();
			if (num > 500)
			{
				if (DateTime.UtcNow.Ticks >= targetTick)
				{
					return;
				}
				num = 0;
				if (searchedNodes > 1000000)
				{
					throw new Exception("Probable infinite loop. Over 1,000,000 nodes searched");
				}
			}
			num++;
		}
		if (CompleteState == PathCompleteState.Complete)
		{
			Trace(currentR);
		}
		else if (calculatePartial && partialBestTarget != null)
		{
			CompleteState = PathCompleteState.Partial;
			Trace(partialBestTarget);
		}
	}

	public void ResetCosts(Path p)
	{
	}

	public override string DebugString(PathLog logMode)
	{
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		if (logMode == PathLog.None || (!error && logMode == PathLog.OnlyErrors))
		{
			return string.Empty;
		}
		StringBuilder stringBuilder = new StringBuilder();
		DebugStringPrefix(logMode, stringBuilder);
		if (!error && logMode == PathLog.Heavy)
		{
			stringBuilder.Append("\nSearch Iterations " + searchIterations);
			if (hasEndPoint && endNode != null)
			{
				PathNode pathNode = pathHandler.GetPathNode(endNode);
				stringBuilder.Append("\nEnd Node\n\tG: ");
				stringBuilder.Append(pathNode.G);
				stringBuilder.Append("\n\tH: ");
				stringBuilder.Append(pathNode.H);
				stringBuilder.Append("\n\tF: ");
				stringBuilder.Append(pathNode.F);
				stringBuilder.Append("\n\tPoint: ");
				Vector3 val = endPoint;
				stringBuilder.Append(((object)val/*cast due to constrained. prefix*/).ToString());
				stringBuilder.Append("\n\tGraph: ");
				stringBuilder.Append(endNode.GraphIndex);
			}
			stringBuilder.Append("\nStart Node");
			stringBuilder.Append("\n\tPoint: ");
			Vector3 val2 = startPoint;
			stringBuilder.Append(((object)val2/*cast due to constrained. prefix*/).ToString());
			stringBuilder.Append("\n\tGraph: ");
			if (startNode != null)
			{
				stringBuilder.Append(startNode.GraphIndex);
			}
			else
			{
				stringBuilder.Append("< null startNode >");
			}
		}
		DebugStringSuffix(logMode, stringBuilder);
		return stringBuilder.ToString();
	}

	public Vector3 GetMovementVector(Vector3 point)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		if (vectorPath == null || vectorPath.Count == 0)
		{
			return Vector3.zero;
		}
		if (vectorPath.Count == 1)
		{
			return vectorPath[0] - point;
		}
		float num = float.PositiveInfinity;
		int num2 = 0;
		for (int i = 0; i < vectorPath.Count - 1; i++)
		{
			Vector3 val = VectorMath.ClosestPointOnSegment(vectorPath[i], vectorPath[i + 1], point);
			Vector3 val2 = val - point;
			float sqrMagnitude = val2.sqrMagnitude;
			if (sqrMagnitude < num)
			{
				num = sqrMagnitude;
				num2 = i;
			}
		}
		return vectorPath[num2 + 1] - point;
	}
}
