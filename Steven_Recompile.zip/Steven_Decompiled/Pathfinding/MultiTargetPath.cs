using System;
using System.Collections.Generic;
using System.Text;
using Pathfinding.Util;
using UnityEngine;

namespace Pathfinding;

public class MultiTargetPath : ABPath
{
	public enum HeuristicMode
	{
		None,
		Average,
		MovingAverage,
		Midpoint,
		MovingMidpoint,
		Sequential
	}

	public OnPathDelegate[] callbacks;

	public GraphNode[] targetNodes;

	protected int targetNodeCount;

	public bool[] targetsFound;

	public Vector3[] targetPoints;

	public Vector3[] originalTargetPoints;

	public List<Vector3>[] vectorPaths;

	public List<GraphNode>[] nodePaths;

	public bool pathsForAll = true;

	public int chosenTarget = -1;

	private int sequentialTarget;

	public HeuristicMode heuristicMode = HeuristicMode.Sequential;

	public bool inverted = true;

	public static MultiTargetPath Construct(Vector3[] startPoints, Vector3 target, OnPathDelegate[] callbackDelegates, OnPathDelegate callback = null)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		MultiTargetPath multiTargetPath = Construct(target, startPoints, callbackDelegates, callback);
		multiTargetPath.inverted = true;
		return multiTargetPath;
	}

	public static MultiTargetPath Construct(Vector3 start, Vector3[] targets, OnPathDelegate[] callbackDelegates, OnPathDelegate callback = null)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		MultiTargetPath multiTargetPath = PathPool.GetPath<MultiTargetPath>();
		multiTargetPath.Setup(start, targets, callbackDelegates, callback);
		return multiTargetPath;
	}

	protected void Setup(Vector3 start, Vector3[] targets, OnPathDelegate[] callbackDelegates, OnPathDelegate callback)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		inverted = false;
		base.callback = callback;
		callbacks = callbackDelegates;
		targetPoints = targets;
		originalStartPoint = start;
		startPoint = start;
		startIntPoint = (Int3)start;
		if (targets.Length == 0)
		{
			Error();
			LogError("No targets were assigned to the MultiTargetPath");
			return;
		}
		endPoint = targets[0];
		originalTargetPoints = new Vector3[targetPoints.Length];
		for (int i = 0; i < targetPoints.Length; i++)
		{
			ref Vector3 reference = ref originalTargetPoints[i];
			reference = targetPoints[i];
		}
	}

	public override void OnEnterPool()
	{
		if (vectorPaths != null)
		{
			for (int i = 0; i < vectorPaths.Length; i++)
			{
				if (vectorPaths[i] != null)
				{
					ListPool<Vector3>.Release(vectorPaths[i]);
				}
			}
		}
		vectorPaths = null;
		vectorPath = null;
		if (nodePaths != null)
		{
			for (int j = 0; j < nodePaths.Length; j++)
			{
				if (nodePaths[j] != null)
				{
					ListPool<GraphNode>.Release(nodePaths[j]);
				}
			}
		}
		nodePaths = null;
		path = null;
		base.OnEnterPool();
	}

	private void ChooseShortestPath()
	{
		chosenTarget = -1;
		if (nodePaths == null)
		{
			return;
		}
		uint num = 2147483647u;
		for (int i = 0; i < nodePaths.Length; i++)
		{
			List<GraphNode> list = nodePaths[i];
			if (list != null)
			{
				uint g = pathHandler.GetPathNode(list[(!inverted) ? (list.Count - 1) : 0]).G;
				if (chosenTarget == -1 || g < num)
				{
					chosenTarget = i;
					num = g;
				}
			}
		}
	}

	private void SetPathParametersForReturn(int target)
	{
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		path = nodePaths[target];
		vectorPath = vectorPaths[target];
		if (inverted)
		{
			startNode = targetNodes[target];
			startPoint = targetPoints[target];
			originalStartPoint = originalTargetPoints[target];
		}
		else
		{
			endNode = targetNodes[target];
			endPoint = targetPoints[target];
			originalEndPoint = originalTargetPoints[target];
		}
	}

	public override void ReturnPath()
	{
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		if (error)
		{
			if (callbacks != null)
			{
				for (int i = 0; i < callbacks.Length; i++)
				{
					if (callbacks[i] != null)
					{
						callbacks[i](this);
					}
				}
			}
			if (callback != null)
			{
				callback(this);
			}
			return;
		}
		bool flag = false;
		if (inverted)
		{
			endPoint = startPoint;
			endNode = startNode;
			originalEndPoint = originalStartPoint;
		}
		for (int j = 0; j < nodePaths.Length; j++)
		{
			if (nodePaths[j] != null)
			{
				CompleteState = PathCompleteState.Complete;
				flag = true;
			}
			else
			{
				CompleteState = PathCompleteState.Error;
			}
			if (callbacks != null && callbacks[j] != null)
			{
				SetPathParametersForReturn(j);
				callbacks[j](this);
				vectorPaths[j] = vectorPath;
			}
		}
		if (flag)
		{
			CompleteState = PathCompleteState.Complete;
			SetPathParametersForReturn(chosenTarget);
		}
		else
		{
			CompleteState = PathCompleteState.Error;
		}
		if (callback != null)
		{
			callback(this);
		}
	}

	protected void FoundTarget(PathNode nodeR, int i)
	{
		nodeR.flag1 = false;
		Trace(nodeR);
		vectorPaths[i] = vectorPath;
		nodePaths[i] = path;
		vectorPath = ListPool<Vector3>.Claim();
		path = ListPool<GraphNode>.Claim();
		targetsFound[i] = true;
		targetNodeCount--;
		if (!pathsForAll)
		{
			CompleteState = PathCompleteState.Complete;
			targetNodeCount = 0;
		}
		else if (targetNodeCount <= 0)
		{
			CompleteState = PathCompleteState.Complete;
		}
		else
		{
			RecalculateHTarget(firstTime: false);
		}
	}

	protected void RebuildOpenList()
	{
		BinaryHeapM heap = pathHandler.GetHeap();
		for (int i = 0; i < heap.numberOfItems; i++)
		{
			PathNode node = heap.GetNode(i);
			node.H = CalculateHScore(node.node);
			heap.SetF(i, node.F);
		}
		pathHandler.RebuildHeap();
	}

	public override void Prepare()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		nnConstraint.tags = enabledTags;
		NNInfo nearest = AstarPath.active.GetNearest(startPoint, nnConstraint, startHint);
		startNode = nearest.node;
		if (startNode == null)
		{
			LogError("Could not find start node for multi target path");
			Error();
			return;
		}
		if (!startNode.Walkable)
		{
			LogError("Nearest node to the start point is not walkable");
			Error();
			return;
		}
		if (nnConstraint is PathNNConstraint pathNNConstraint)
		{
			pathNNConstraint.SetStart(nearest.node);
		}
		vectorPaths = new List<Vector3>[targetPoints.Length];
		nodePaths = new List<GraphNode>[targetPoints.Length];
		targetNodes = new GraphNode[targetPoints.Length];
		targetsFound = new bool[targetPoints.Length];
		targetNodeCount = targetPoints.Length;
		bool flag = false;
		bool flag2 = false;
		bool flag3 = false;
		for (int i = 0; i < targetPoints.Length; i++)
		{
			NNInfo nearest2 = AstarPath.active.GetNearest(targetPoints[i], nnConstraint);
			targetNodes[i] = nearest2.node;
			ref Vector3 reference = ref targetPoints[i];
			reference = nearest2.clampedPosition;
			if (targetNodes[i] != null)
			{
				flag3 = true;
				endNode = targetNodes[i];
			}
			bool flag4 = false;
			if (nearest2.node != null && nearest2.node.Walkable)
			{
				flag = true;
			}
			else
			{
				flag4 = true;
			}
			if (nearest2.node != null && nearest2.node.Area == startNode.Area)
			{
				flag2 = true;
			}
			else
			{
				flag4 = true;
			}
			if (flag4)
			{
				targetsFound[i] = true;
				targetNodeCount--;
			}
		}
		startPoint = nearest.clampedPosition;
		startIntPoint = (Int3)startPoint;
		if (startNode == null || !flag3)
		{
			LogError("Couldn't find close nodes to either the start or the end (start = " + ((startNode == null) ? "not found" : "found") + " end = " + ((!flag3) ? "none found" : "at least one found") + ")");
			Error();
		}
		else if (!startNode.Walkable)
		{
			LogError("The node closest to the start point is not walkable");
			Error();
		}
		else if (!flag)
		{
			LogError("No target nodes were walkable");
			Error();
		}
		else if (!flag2)
		{
			LogError("There are no valid paths to the targets");
			Error();
		}
		else
		{
			RecalculateHTarget(firstTime: true);
		}
	}

	private void RecalculateHTarget(bool firstTime)
	{
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		if (!pathsForAll)
		{
			heuristic = Heuristic.None;
			heuristicScale = 0f;
			return;
		}
		switch (heuristicMode)
		{
		case HeuristicMode.None:
			heuristic = Heuristic.None;
			heuristicScale = 0f;
			break;
		case HeuristicMode.Average:
			if (!firstTime)
			{
				return;
			}
			goto case HeuristicMode.MovingAverage;
		case HeuristicMode.MovingAverage:
		{
			Vector3 val = Vector3.zero;
			int num2 = 0;
			for (int j = 0; j < targetPoints.Length; j++)
			{
				if (!targetsFound[j])
				{
					val += (Vector3)targetNodes[j].position;
					num2++;
				}
			}
			if (num2 == 0)
			{
				throw new Exception("Should not happen");
			}
			val /= (float)num2;
			hTarget = (Int3)val;
			break;
		}
		case HeuristicMode.Midpoint:
			if (!firstTime)
			{
				return;
			}
			goto case HeuristicMode.MovingMidpoint;
		case HeuristicMode.MovingMidpoint:
		{
			Vector3 val2 = Vector3.zero;
			Vector3 val3 = Vector3.zero;
			bool flag = false;
			for (int k = 0; k < targetPoints.Length; k++)
			{
				if (!targetsFound[k])
				{
					if (!flag)
					{
						val2 = (Vector3)targetNodes[k].position;
						val3 = (Vector3)targetNodes[k].position;
						flag = true;
					}
					else
					{
						val2 = Vector3.Min((Vector3)targetNodes[k].position, val2);
						val3 = Vector3.Max((Vector3)targetNodes[k].position, val3);
					}
				}
			}
			Int3 @int = (Int3)((val2 + val3) * 0.5f);
			hTarget = @int;
			break;
		}
		case HeuristicMode.Sequential:
		{
			if (!firstTime && !targetsFound[sequentialTarget])
			{
				return;
			}
			float num = 0f;
			for (int i = 0; i < targetPoints.Length; i++)
			{
				if (!targetsFound[i])
				{
					float sqrMagnitude = (targetNodes[i].position - startNode.position).sqrMagnitude;
					if (sqrMagnitude > num)
					{
						num = sqrMagnitude;
						hTarget = (Int3)targetPoints[i];
						sequentialTarget = i;
					}
				}
			}
			break;
		}
		}
		if (!firstTime)
		{
			RebuildOpenList();
		}
	}

	public override void Initialize()
	{
		PathNode pathNode = pathHandler.GetPathNode(startNode);
		pathNode.node = startNode;
		pathNode.pathID = pathID;
		pathNode.parent = null;
		pathNode.cost = 0u;
		pathNode.G = GetTraversalCost(startNode);
		pathNode.H = CalculateHScore(startNode);
		for (int i = 0; i < targetNodes.Length; i++)
		{
			if (startNode == targetNodes[i])
			{
				FoundTarget(pathNode, i);
			}
			else if (targetNodes[i] != null)
			{
				pathHandler.GetPathNode(targetNodes[i]).flag1 = true;
			}
		}
		if (targetNodeCount <= 0)
		{
			CompleteState = PathCompleteState.Complete;
			return;
		}
		startNode.Open(this, pathNode, pathHandler);
		searchedNodes++;
		if (pathHandler.HeapEmpty())
		{
			LogError("No open points, the start node didn't open any nodes");
			Error();
		}
		else
		{
			currentR = pathHandler.PopNode();
		}
	}

	public override void Cleanup()
	{
		ChooseShortestPath();
		ResetFlags();
	}

	private void ResetFlags()
	{
		if (targetNodes == null)
		{
			return;
		}
		for (int i = 0; i < targetNodes.Length; i++)
		{
			if (targetNodes[i] != null)
			{
				pathHandler.GetPathNode(targetNodes[i]).flag1 = false;
			}
		}
	}

	public override void CalculateStep(long targetTick)
	{
		int num = 0;
		while (CompleteState == PathCompleteState.NotCalculated)
		{
			searchedNodes++;
			if (currentR.flag1)
			{
				for (int i = 0; i < targetNodes.Length; i++)
				{
					if (!targetsFound[i] && currentR.node == targetNodes[i])
					{
						FoundTarget(currentR, i);
						if (CompleteState != PathCompleteState.NotCalculated)
						{
							break;
						}
					}
				}
				if (targetNodeCount <= 0)
				{
					CompleteState = PathCompleteState.Complete;
					break;
				}
			}
			currentR.node.Open(this, currentR, pathHandler);
			if (pathHandler.HeapEmpty())
			{
				CompleteState = PathCompleteState.Complete;
				break;
			}
			currentR = pathHandler.PopNode();
			if (num > 500)
			{
				if (DateTime.UtcNow.Ticks >= targetTick)
				{
					break;
				}
				num = 0;
			}
			num++;
		}
	}

	protected override void Trace(PathNode node)
	{
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		base.Trace(node);
		if (inverted)
		{
			int num = path.Count / 2;
			for (int i = 0; i < num; i++)
			{
				GraphNode value = path[i];
				path[i] = path[path.Count - i - 1];
				path[path.Count - i - 1] = value;
			}
			for (int j = 0; j < num; j++)
			{
				Vector3 value2 = vectorPath[j];
				vectorPath[j] = vectorPath[vectorPath.Count - j - 1];
				vectorPath[vectorPath.Count - j - 1] = value2;
			}
		}
	}

	public override string DebugString(PathLog logMode)
	{
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		if (logMode == PathLog.None || (!error && logMode == PathLog.OnlyErrors))
		{
			return string.Empty;
		}
		StringBuilder debugStringBuilder = pathHandler.DebugStringBuilder;
		debugStringBuilder.Length = 0;
		DebugStringPrefix(logMode, debugStringBuilder);
		if (!error)
		{
			debugStringBuilder.Append("\nShortest path was ");
			debugStringBuilder.Append((chosenTarget != -1) ? nodePaths[chosenTarget].Count.ToString() : "undefined");
			debugStringBuilder.Append(" nodes long");
			if (logMode == PathLog.Heavy)
			{
				debugStringBuilder.Append("\nPaths (").Append(targetsFound.Length).Append("):");
				for (int i = 0; i < targetsFound.Length; i++)
				{
					debugStringBuilder.Append("\n\n\tPath ").Append(i).Append(" Found: ")
						.Append(targetsFound[i]);
					if (nodePaths[i] == null)
					{
						continue;
					}
					debugStringBuilder.Append("\n\t\tLength: ");
					debugStringBuilder.Append(nodePaths[i].Count);
					GraphNode graphNode = nodePaths[i][nodePaths[i].Count - 1];
					if (graphNode != null)
					{
						PathNode pathNode = pathHandler.GetPathNode(endNode);
						if (pathNode != null)
						{
							debugStringBuilder.Append("\n\t\tEnd Node");
							debugStringBuilder.Append("\n\t\t\tG: ");
							debugStringBuilder.Append(pathNode.G);
							debugStringBuilder.Append("\n\t\t\tH: ");
							debugStringBuilder.Append(pathNode.H);
							debugStringBuilder.Append("\n\t\t\tF: ");
							debugStringBuilder.Append(pathNode.F);
							debugStringBuilder.Append("\n\t\t\tPoint: ");
							Vector3 val = endPoint;
							debugStringBuilder.Append(((object)val/*cast due to constrained. prefix*/).ToString());
							debugStringBuilder.Append("\n\t\t\tGraph: ");
							debugStringBuilder.Append(endNode.GraphIndex);
						}
						else
						{
							debugStringBuilder.Append("\n\t\tEnd Node: Null");
						}
					}
				}
				debugStringBuilder.Append("\nStart Node");
				debugStringBuilder.Append("\n\tPoint: ");
				Vector3 val2 = endPoint;
				debugStringBuilder.Append(((object)val2/*cast due to constrained. prefix*/).ToString());
				debugStringBuilder.Append("\n\tGraph: ");
				debugStringBuilder.Append(startNode.GraphIndex);
				debugStringBuilder.Append("\nBinary Heap size at completion: ");
				debugStringBuilder.AppendLine((pathHandler.GetHeap() != null) ? (pathHandler.GetHeap().numberOfItems - 2).ToString() : "Null");
			}
		}
		DebugStringSuffix(logMode, debugStringBuilder);
		return debugStringBuilder.ToString();
	}
}
