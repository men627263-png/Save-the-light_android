using System;
using UnityEngine;

namespace Pathfinding;

[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_debug_utility.php")]
public class DebugUtility : MonoBehaviour
{
	public Material defaultMaterial;

	public static DebugUtility active;

	public float offset = 0.2f;

	public bool optimizeMeshes;

	public void Awake()
	{
		active = this;
	}

	public static void DrawCubes(Vector3[] topVerts, Vector3[] bottomVerts, Color[] vertexColors, float width)
	{
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0270: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0697: Unknown result type (might be due to invalid IL or missing references)
		//IL_069e: Expected Obj, but got Unknown
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ee: Expected Obj, but got Unknown
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		//IL_0352: Unknown result type (might be due to invalid IL or missing references)
		//IL_0354: Unknown result type (might be due to invalid IL or missing references)
		//IL_0364: Unknown result type (might be due to invalid IL or missing references)
		//IL_0366: Unknown result type (might be due to invalid IL or missing references)
		//IL_0376: Unknown result type (might be due to invalid IL or missing references)
		//IL_0378: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_0408: Unknown result type (might be due to invalid IL or missing references)
		//IL_045e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0460: Unknown result type (might be due to invalid IL or missing references)
		//IL_0470: Unknown result type (might be due to invalid IL or missing references)
		//IL_0472: Unknown result type (might be due to invalid IL or missing references)
		//IL_0482: Unknown result type (might be due to invalid IL or missing references)
		//IL_0484: Unknown result type (might be due to invalid IL or missing references)
		//IL_0494: Unknown result type (might be due to invalid IL or missing references)
		//IL_0496: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0500: Unknown result type (might be due to invalid IL or missing references)
		//IL_0502: Unknown result type (might be due to invalid IL or missing references)
		//IL_0512: Unknown result type (might be due to invalid IL or missing references)
		//IL_0514: Unknown result type (might be due to invalid IL or missing references)
		//IL_0522: Unknown result type (might be due to invalid IL or missing references)
		//IL_0524: Unknown result type (might be due to invalid IL or missing references)
		//IL_057c: Unknown result type (might be due to invalid IL or missing references)
		//IL_057e: Unknown result type (might be due to invalid IL or missing references)
		//IL_058e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0590: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0608: Unknown result type (might be due to invalid IL or missing references)
		//IL_060a: Unknown result type (might be due to invalid IL or missing references)
		//IL_061a: Unknown result type (might be due to invalid IL or missing references)
		//IL_061c: Unknown result type (might be due to invalid IL or missing references)
		//IL_062c: Unknown result type (might be due to invalid IL or missing references)
		//IL_062e: Unknown result type (might be due to invalid IL or missing references)
		//IL_063e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0640: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)active == (Object)null)
		{
			active = Object.FindObjectOfType(typeof(DebugUtility)) as DebugUtility;
		}
		if ((Object)(object)active == (Object)null)
		{
			throw new NullReferenceException();
		}
		if (topVerts.Length != bottomVerts.Length || topVerts.Length != vertexColors.Length)
		{
			Debug.LogError((object)"Array Lengths are not the same");
			return;
		}
		if (topVerts.Length > 2708)
		{
			Vector3[] array = new Vector3[topVerts.Length - 2708];
			Vector3[] array2 = new Vector3[topVerts.Length - 2708];
			Color[] array3 = new Color[topVerts.Length - 2708];
			for (int i = 2708; i < topVerts.Length; i++)
			{
				ref Vector3 reference = ref array[i - 2708];
				reference = topVerts[i];
				ref Vector3 reference2 = ref array2[i - 2708];
				reference2 = bottomVerts[i];
				ref Color reference3 = ref array3[i - 2708];
				reference3 = vertexColors[i];
			}
			Vector3[] array4 = new Vector3[2708];
			Vector3[] array5 = new Vector3[2708];
			Color[] array6 = new Color[2708];
			for (int j = 0; j < 2708; j++)
			{
				ref Vector3 reference4 = ref array4[j];
				reference4 = topVerts[j];
				ref Vector3 reference5 = ref array5[j];
				reference5 = bottomVerts[j];
				ref Color reference6 = ref array6[j];
				reference6 = vertexColors[j];
			}
			DrawCubes(array, array2, array3, width);
			topVerts = array4;
			bottomVerts = array5;
			vertexColors = array6;
		}
		width /= 2f;
		Vector3[] array7 = new Vector3[topVerts.Length * 4 * 6];
		int[] array8 = new int[topVerts.Length * 6 * 6];
		Color[] array9 = new Color[topVerts.Length * 4 * 6];
		for (int k = 0; k < topVerts.Length; k++)
		{
			Vector3 val = topVerts[k] + new Vector3(0f, active.offset, 0f);
			Vector3 val2 = bottomVerts[k] - new Vector3(0f, active.offset, 0f);
			Vector3 val3 = val + new Vector3(0f - width, 0f, 0f - width);
			Vector3 val4 = val + new Vector3(width, 0f, 0f - width);
			Vector3 val5 = val + new Vector3(width, 0f, width);
			Vector3 val6 = val + new Vector3(0f - width, 0f, width);
			Vector3 val7 = val2 + new Vector3(0f - width, 0f, 0f - width);
			Vector3 val8 = val2 + new Vector3(width, 0f, 0f - width);
			Vector3 val9 = val2 + new Vector3(width, 0f, width);
			Vector3 val10 = val2 + new Vector3(0f - width, 0f, width);
			int num = k * 4 * 6;
			Color val11 = vertexColors[k];
			for (int l = num; l < num + 24; l++)
			{
				array9[l] = val11;
			}
			array7[num] = val3;
			array7[num + 1] = val6;
			array7[num + 2] = val5;
			array7[num + 3] = val4;
			int num2 = k * 6 * 6;
			array8[num2] = num;
			array8[num2 + 1] = num + 1;
			array8[num2 + 2] = num + 2;
			array8[num2 + 3] = num;
			array8[num2 + 4] = num + 2;
			array8[num2 + 5] = num + 3;
			num += 4;
			array7[num + 3] = val7;
			array7[num + 2] = val10;
			array7[num + 1] = val9;
			array7[num] = val8;
			num2 += 6;
			array8[num2] = num;
			array8[num2 + 1] = num + 1;
			array8[num2 + 2] = num + 2;
			array8[num2 + 3] = num;
			array8[num2 + 4] = num + 2;
			array8[num2 + 5] = num + 3;
			num += 4;
			array7[num] = val8;
			array7[num + 1] = val4;
			array7[num + 2] = val5;
			array7[num + 3] = val9;
			num2 += 6;
			array8[num2] = num;
			array8[num2 + 1] = num + 1;
			array8[num2 + 2] = num + 2;
			array8[num2 + 3] = num;
			array8[num2 + 4] = num + 2;
			array8[num2 + 5] = num + 3;
			num += 4;
			array7[num + 3] = val7;
			array7[num + 2] = val3;
			array7[num + 1] = val6;
			array7[num] = val10;
			num2 += 6;
			array8[num2] = num;
			array8[num2 + 1] = num + 1;
			array8[num2 + 2] = num + 2;
			array8[num2 + 3] = num;
			array8[num2 + 4] = num + 2;
			array8[num2 + 5] = num + 3;
			num += 4;
			array7[num + 3] = val9;
			array7[num + 2] = val10;
			array7[num + 1] = val6;
			array7[num] = val5;
			num2 += 6;
			array8[num2] = num;
			array8[num2 + 1] = num + 1;
			array8[num2 + 2] = num + 2;
			array8[num2 + 3] = num;
			array8[num2 + 4] = num + 2;
			array8[num2 + 5] = num + 3;
			num += 4;
			array7[num] = val8;
			array7[num + 1] = val7;
			array7[num + 2] = val3;
			array7[num + 3] = val4;
			num2 += 6;
			array8[num2] = num;
			array8[num2 + 1] = num + 1;
			array8[num2 + 2] = num + 2;
			array8[num2 + 3] = num;
			array8[num2 + 4] = num + 2;
			array8[num2 + 5] = num + 3;
		}
		Mesh val12 = new Mesh();
		val12.vertices = array7;
		val12.triangles = array8;
		val12.colors = array9;
		((Object)val12).name = "VoxelMesh";
		val12.RecalculateNormals();
		val12.RecalculateBounds();
		if (active.optimizeMeshes)
		{
		}
		GameObject val13 = new GameObject("DebugMesh");
		Component val14 = val13.AddComponent(typeof(MeshRenderer));
		MeshRenderer val15 = (MeshRenderer)(object)((val14 is MeshRenderer) ? val14 : null);
		((Renderer)val15).material = active.defaultMaterial;
		Component val16 = val13.AddComponent(typeof(MeshFilter));
		((MeshFilter)((val16 is MeshFilter) ? val16 : null)).mesh = val12;
	}

	public static void DrawQuads(Vector3[] verts, float width)
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Expected Obj, but got Unknown
		//IL_01df: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Expected Obj, but got Unknown
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		if (verts.Length >= 16250)
		{
			Vector3[] array = new Vector3[verts.Length - 16250];
			for (int i = 16250; i < verts.Length; i++)
			{
				ref Vector3 reference = ref array[i - 16250];
				reference = verts[i];
			}
			Vector3[] array2 = new Vector3[16250];
			for (int j = 0; j < 16250; j++)
			{
				ref Vector3 reference2 = ref array2[j];
				reference2 = verts[j];
			}
			DrawQuads(array, width);
			verts = array2;
		}
		width /= 2f;
		Vector3[] array3 = new Vector3[verts.Length * 4];
		int[] array4 = new int[verts.Length * 6];
		for (int k = 0; k < verts.Length; k++)
		{
			Vector3 val = verts[k];
			int num = k * 4;
			ref Vector3 reference3 = ref array3[num];
			reference3 = val + new Vector3(0f - width, 0f, 0f - width);
			ref Vector3 reference4 = ref array3[num + 1];
			reference4 = val + new Vector3(0f - width, 0f, width);
			ref Vector3 reference5 = ref array3[num + 2];
			reference5 = val + new Vector3(width, 0f, width);
			ref Vector3 reference6 = ref array3[num + 3];
			reference6 = val + new Vector3(width, 0f, 0f - width);
			int num2 = k * 6;
			array4[num2] = num;
			array4[num2 + 1] = num + 1;
			array4[num2 + 2] = num + 2;
			array4[num2 + 3] = num;
			array4[num2 + 4] = num + 2;
			array4[num2 + 5] = num + 3;
		}
		Mesh val2 = new Mesh();
		val2.vertices = array3;
		val2.triangles = array4;
		val2.RecalculateNormals();
		val2.RecalculateBounds();
		GameObject val3 = new GameObject("DebugMesh");
		Component val4 = val3.AddComponent(typeof(MeshRenderer));
		MeshRenderer val5 = (MeshRenderer)(object)((val4 is MeshRenderer) ? val4 : null);
		((Renderer)val5).material = active.defaultMaterial;
		Component val6 = val3.AddComponent(typeof(MeshFilter));
		((MeshFilter)((val6 is MeshFilter) ? val6 : null)).mesh = val2;
	}
}
