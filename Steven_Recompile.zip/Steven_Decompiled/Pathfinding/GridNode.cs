using System.Collections.Generic;
using Pathfinding.Serialization;
using UnityEngine;

namespace Pathfinding;

public class GridNode : GridNodeBase
{
	private static GridGraph[] _gridGraphs = new GridGraph[0];

	public GraphNode[] connections;

	public uint[] connectionCosts;

	protected ushort gridFlags;

	private const int GridFlagsConnectionOffset = 0;

	private const int GridFlagsConnectionBit0 = 1;

	private const int GridFlagsConnectionMask = 255;

	private const int GridFlagsWalkableErosionOffset = 8;

	private const int GridFlagsWalkableErosionMask = 256;

	private const int GridFlagsWalkableTmpOffset = 9;

	private const int GridFlagsWalkableTmpMask = 512;

	private const int GridFlagsEdgeNodeOffset = 10;

	private const int GridFlagsEdgeNodeMask = 1024;

	internal ushort InternalGridFlags
	{
		get
		{
			return gridFlags;
		}
		set
		{
			gridFlags = value;
		}
	}

	public bool EdgeNode
	{
		get
		{
			return (gridFlags & 0x400) != 0;
		}
		set
		{
			gridFlags = (ushort)((gridFlags & -1025) | (value ? 1024 : 0));
		}
	}

	public bool WalkableErosion
	{
		get
		{
			return (gridFlags & 0x100) != 0;
		}
		set
		{
			gridFlags = (ushort)((gridFlags & -257) | (value ? 256 : 0));
		}
	}

	public bool TmpWalkable
	{
		get
		{
			return (gridFlags & 0x200) != 0;
		}
		set
		{
			gridFlags = (ushort)((gridFlags & -513) | (value ? 512 : 0));
		}
	}

	public GridNode(AstarPath astar)
		: base(astar)
	{
	}

	public static GridGraph GetGridGraph(uint graphIndex)
	{
		return _gridGraphs[graphIndex];
	}

	public static void SetGridGraph(int graphIndex, GridGraph graph)
	{
		if (_gridGraphs.Length <= graphIndex)
		{
			GridGraph[] array = new GridGraph[graphIndex + 1];
			for (int i = 0; i < _gridGraphs.Length; i++)
			{
				array[i] = _gridGraphs[i];
			}
			_gridGraphs = array;
		}
		_gridGraphs[graphIndex] = graph;
	}

	public bool GetConnectionInternal(int dir)
	{
		return ((gridFlags >> dir) & 1) != 0;
	}

	public void SetConnectionInternal(int dir, bool value)
	{
		gridFlags = (ushort)((gridFlags & ~(1 << dir)) | ((value ? 1 : 0) << 0 << dir));
	}

	public void SetAllConnectionInternal(int connections)
	{
		gridFlags = (ushort)((gridFlags & -256) | (connections << 0));
	}

	public void ResetConnectionsInternal()
	{
		gridFlags = (ushort)(gridFlags & -256);
	}

	public override void ClearConnections(bool alsoReverse)
	{
		if (alsoReverse)
		{
			GridGraph gridGraph = GetGridGraph(GraphIndex);
			for (int i = 0; i < 8; i++)
			{
				gridGraph.GetNodeConnection(this, i)?.SetConnectionInternal((i >= 4) ? 7 : ((i + 2) % 4), value: false);
			}
		}
		ResetConnectionsInternal();
		if (alsoReverse && connections != null)
		{
			for (int j = 0; j < connections.Length; j++)
			{
				connections[j].RemoveConnection(this);
			}
		}
		connections = null;
		connectionCosts = null;
	}

	public override void GetConnections(GraphNodeDelegate del)
	{
		GridGraph gridGraph = GetGridGraph(GraphIndex);
		int[] neighbourOffsets = gridGraph.neighbourOffsets;
		GridNode[] nodes = gridGraph.nodes;
		for (int i = 0; i < 8; i++)
		{
			if (GetConnectionInternal(i))
			{
				GridNode gridNode = nodes[nodeInGridIndex + neighbourOffsets[i]];
				if (gridNode != null)
				{
					del(gridNode);
				}
			}
		}
		if (connections != null)
		{
			for (int j = 0; j < connections.Length; j++)
			{
				del(connections[j]);
			}
		}
	}

	public Vector3 ClosestPointOnNode(Vector3 p)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		GridGraph gridGraph = GetGridGraph(GraphIndex);
		p = gridGraph.inverseMatrix.MultiplyPoint3x4(p);
		float num = (float)position.x - 0.5f;
		float num2 = (float)position.z - 0.5f;
		int num3 = nodeInGridIndex % gridGraph.width;
		int num4 = nodeInGridIndex / gridGraph.width;
		float y = gridGraph.inverseMatrix.MultiplyPoint3x4(p).y;
		Vector3 val = new Vector3(Mathf.Clamp(num, (float)num3 - 0.5f, (float)num3 + 0.5f) + 0.5f, y, Mathf.Clamp(num2, (float)num4 - 0.5f, (float)num4 + 0.5f) + 0.5f);
		return gridGraph.matrix.MultiplyPoint3x4(val);
	}

	public override bool GetPortal(GraphNode other, List<Vector3> left, List<Vector3> right, bool backwards)
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		if (backwards)
		{
			return true;
		}
		GridGraph gridGraph = GetGridGraph(GraphIndex);
		int[] neighbourOffsets = gridGraph.neighbourOffsets;
		GridNode[] nodes = gridGraph.nodes;
		for (int i = 0; i < 4; i++)
		{
			if (GetConnectionInternal(i) && other == nodes[nodeInGridIndex + neighbourOffsets[i]])
			{
				Vector3 val = (Vector3)(position + other.position) * 0.5f;
				Vector3 val2 = Vector3.Cross(gridGraph.collision.up, (Vector3)(other.position - position));
				val2.Normalize();
				val2 *= gridGraph.nodeSize * 0.5f;
				left.Add(val - val2);
				right.Add(val + val2);
				return true;
			}
		}
		for (int j = 4; j < 8; j++)
		{
			if (!GetConnectionInternal(j) || other != nodes[nodeInGridIndex + neighbourOffsets[j]])
			{
				continue;
			}
			bool flag = false;
			bool flag2 = false;
			if (GetConnectionInternal(j - 4))
			{
				GridNode gridNode = nodes[nodeInGridIndex + neighbourOffsets[j - 4]];
				if (gridNode.Walkable && gridNode.GetConnectionInternal((j - 4 + 1) % 4))
				{
					flag = true;
				}
			}
			if (GetConnectionInternal((j - 4 + 1) % 4))
			{
				GridNode gridNode2 = nodes[nodeInGridIndex + neighbourOffsets[(j - 4 + 1) % 4]];
				if (gridNode2.Walkable && gridNode2.GetConnectionInternal(j - 4))
				{
					flag2 = true;
				}
			}
			Vector3 val3 = (Vector3)(position + other.position) * 0.5f;
			Vector3 val4 = Vector3.Cross(gridGraph.collision.up, (Vector3)(other.position - position));
			val4.Normalize();
			val4 *= gridGraph.nodeSize * 1.4142f;
			left.Add(val3 - ((!flag2) ? Vector3.zero : val4));
			right.Add(val3 + ((!flag) ? Vector3.zero : val4));
			return true;
		}
		return false;
	}

	public override void FloodFill(Stack<GraphNode> stack, uint region)
	{
		GridGraph gridGraph = GetGridGraph(GraphIndex);
		int[] neighbourOffsets = gridGraph.neighbourOffsets;
		GridNode[] nodes = gridGraph.nodes;
		for (int i = 0; i < 8; i++)
		{
			if (GetConnectionInternal(i))
			{
				GridNode gridNode = nodes[nodeInGridIndex + neighbourOffsets[i]];
				if (gridNode != null && gridNode.Area != region)
				{
					gridNode.Area = region;
					stack.Push(gridNode);
				}
			}
		}
		if (connections == null)
		{
			return;
		}
		for (int j = 0; j < connections.Length; j++)
		{
			GraphNode graphNode = connections[j];
			if (graphNode.Area != region)
			{
				graphNode.Area = region;
				stack.Push(graphNode);
			}
		}
	}

	public override void AddConnection(GraphNode node, uint cost)
	{
		if (connections != null)
		{
			for (int i = 0; i < connections.Length; i++)
			{
				if (connections[i] == node)
				{
					connectionCosts[i] = cost;
					return;
				}
			}
		}
		int num = ((connections != null) ? connections.Length : 0);
		GraphNode[] array = new GraphNode[num + 1];
		uint[] array2 = new uint[num + 1];
		for (int j = 0; j < num; j++)
		{
			array[j] = connections[j];
			array2[j] = connectionCosts[j];
		}
		array[num] = node;
		array2[num] = cost;
		connections = array;
		connectionCosts = array2;
	}

	public override void RemoveConnection(GraphNode node)
	{
		if (connections == null)
		{
			return;
		}
		for (int i = 0; i < connections.Length; i++)
		{
			if (connections[i] == node)
			{
				int num = connections.Length;
				GraphNode[] array = new GraphNode[num - 1];
				uint[] array2 = new uint[num - 1];
				for (int j = 0; j < i; j++)
				{
					array[j] = connections[j];
					array2[j] = connectionCosts[j];
				}
				for (int k = i + 1; k < num; k++)
				{
					array[k - 1] = connections[k];
					array2[k - 1] = connectionCosts[k];
				}
				connections = array;
				connectionCosts = array2;
				break;
			}
		}
	}

	public override void UpdateRecursiveG(Path path, PathNode pathNode, PathHandler handler)
	{
		GridGraph gridGraph = GetGridGraph(GraphIndex);
		int[] neighbourOffsets = gridGraph.neighbourOffsets;
		GridNode[] nodes = gridGraph.nodes;
		UpdateG(path, pathNode);
		handler.PushNode(pathNode);
		ushort pathID = handler.PathID;
		for (int i = 0; i < 8; i++)
		{
			if (GetConnectionInternal(i))
			{
				GridNode gridNode = nodes[nodeInGridIndex + neighbourOffsets[i]];
				PathNode pathNode2 = handler.GetPathNode(gridNode);
				if (pathNode2.parent == pathNode && pathNode2.pathID == pathID)
				{
					gridNode.UpdateRecursiveG(path, pathNode2, handler);
				}
			}
		}
		if (connections == null)
		{
			return;
		}
		for (int j = 0; j < connections.Length; j++)
		{
			GraphNode graphNode = connections[j];
			PathNode pathNode3 = handler.GetPathNode(graphNode);
			if (pathNode3.parent == pathNode && pathNode3.pathID == pathID)
			{
				graphNode.UpdateRecursiveG(path, pathNode3, handler);
			}
		}
	}

	public override void Open(Path path, PathNode pathNode, PathHandler handler)
	{
		GridGraph gridGraph = GetGridGraph(GraphIndex);
		ushort pathID = handler.PathID;
		int[] neighbourOffsets = gridGraph.neighbourOffsets;
		uint[] neighbourCosts = gridGraph.neighbourCosts;
		GridNode[] nodes = gridGraph.nodes;
		for (int i = 0; i < 8; i++)
		{
			if (!GetConnectionInternal(i))
			{
				continue;
			}
			GridNode gridNode = nodes[nodeInGridIndex + neighbourOffsets[i]];
			if (path.CanTraverse(gridNode))
			{
				PathNode pathNode2 = handler.GetPathNode(gridNode);
				uint num = neighbourCosts[i];
				if (pathNode2.pathID != pathID)
				{
					pathNode2.parent = pathNode;
					pathNode2.pathID = pathID;
					pathNode2.cost = num;
					pathNode2.H = path.CalculateHScore(gridNode);
					gridNode.UpdateG(path, pathNode2);
					handler.PushNode(pathNode2);
				}
				else if (pathNode.G + num + path.GetTraversalCost(gridNode) < pathNode2.G)
				{
					pathNode2.cost = num;
					pathNode2.parent = pathNode;
					gridNode.UpdateRecursiveG(path, pathNode2, handler);
				}
				else if (pathNode2.G + num + path.GetTraversalCost(this) < pathNode.G)
				{
					pathNode.parent = pathNode2;
					pathNode.cost = num;
					UpdateRecursiveG(path, pathNode, handler);
				}
			}
		}
		if (connections == null)
		{
			return;
		}
		for (int j = 0; j < connections.Length; j++)
		{
			GraphNode graphNode = connections[j];
			if (path.CanTraverse(graphNode))
			{
				PathNode pathNode3 = handler.GetPathNode(graphNode);
				uint num2 = connectionCosts[j];
				if (pathNode3.pathID != pathID)
				{
					pathNode3.parent = pathNode;
					pathNode3.pathID = pathID;
					pathNode3.cost = num2;
					pathNode3.H = path.CalculateHScore(graphNode);
					graphNode.UpdateG(path, pathNode3);
					handler.PushNode(pathNode3);
				}
				else if (pathNode.G + num2 + path.GetTraversalCost(graphNode) < pathNode3.G)
				{
					pathNode3.cost = num2;
					pathNode3.parent = pathNode;
					graphNode.UpdateRecursiveG(path, pathNode3, handler);
				}
				else if (pathNode3.G + num2 + path.GetTraversalCost(this) < pathNode.G && graphNode.ContainsConnection(this))
				{
					pathNode.parent = pathNode3;
					pathNode.cost = num2;
					UpdateRecursiveG(path, pathNode, handler);
				}
			}
		}
	}

	public override void SerializeNode(GraphSerializationContext ctx)
	{
		base.SerializeNode(ctx);
		ctx.writer.Write(position.x);
		ctx.writer.Write(position.y);
		ctx.writer.Write(position.z);
		ctx.writer.Write(gridFlags);
	}

	public override void DeserializeNode(GraphSerializationContext ctx)
	{
		base.DeserializeNode(ctx);
		position = new Int3(ctx.reader.ReadInt32(), ctx.reader.ReadInt32(), ctx.reader.ReadInt32());
		gridFlags = ctx.reader.ReadUInt16();
	}
}
