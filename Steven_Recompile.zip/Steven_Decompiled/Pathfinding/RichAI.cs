using System;
using System.Collections;
using System.Collections.Generic;
using Pathfinding.RVO;
using UnityEngine;

namespace Pathfinding;

[RequireComponent(typeof(Seeker))]
[AddComponentMenu("Pathfinding/AI/RichAI (3D, for navmesh)")]
[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_rich_a_i.php")]
public class RichAI : MonoBehaviour
{
	public Transform target;

	public bool drawGizmos = true;

	public bool repeatedlySearchPaths;

	public float repathRate = 0.5f;

	public float maxSpeed = 1f;

	public float acceleration = 5f;

	public float slowdownTime = 0.5f;

	public float rotationSpeed = 360f;

	public float endReachedDistance = 0.01f;

	public float wallForce = 3f;

	public float wallDist = 1f;

	public Vector3 gravity = new Vector3(0f, -9.82f, 0f);

	public bool raycastingForGroundPlacement = true;

	public LayerMask groundMask = LayerMask.op_Implicit(-1);

	public float centerOffset = 1f;

	public RichFunnel.FunnelSimplification funnelSimplification;

	public Animation anim;

	public bool preciseSlowdown = true;

	public bool slowWhenNotFacingTarget = true;

	private Vector3 velocity;

	protected RichPath rp;

	protected Seeker seeker;

	protected Transform tr;

	private CharacterController controller;

	private RVOController rvoController;

	private Vector3 lastTargetPoint;

	private Vector3 currentTargetDirection;

	protected bool waitingForPathCalc;

	protected bool canSearchPath;

	protected bool delayUpdatePath;

	protected bool traversingSpecialPath;

	protected bool lastCorner;

	private float distanceToWaypoint = 999f;

	protected List<Vector3> buffer = new List<Vector3>();

	protected List<Vector3> wallBuffer = new List<Vector3>();

	private bool startHasRun;

	protected float lastRepath = -9999f;

	private static float deltaTime;

	public static readonly Color GizmoColorRaycast = new Color(118f / 255f, 206f / 255f, 112f / 255f);

	public static readonly Color GizmoColorPath = new Color(8f / 255f, 78f / 255f, 194f / 255f);

	public Vector3 Velocity
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return velocity;
		}
	}

	public bool TraversingSpecial => traversingSpecialPath;

	public Vector3 TargetPoint
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return lastTargetPoint;
		}
	}

	public bool ApproachingPartEndpoint => lastCorner;

	public bool ApproachingPathEndpoint => rp != null && ApproachingPartEndpoint && !rp.PartsLeft();

	public float DistanceToNextWaypoint => distanceToWaypoint;

	public RichAI()
	{
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Awake()
	{
		seeker = ((Component)this).GetComponent<Seeker>();
		controller = ((Component)this).GetComponent<CharacterController>();
		rvoController = ((Component)this).GetComponent<RVOController>();
		if ((Object)(object)rvoController != (Object)null)
		{
			rvoController.enableRotation = false;
		}
		tr = ((Component)this).transform;
	}

	protected virtual void Start()
	{
		startHasRun = true;
		OnEnable();
	}

	protected virtual void OnEnable()
	{
		lastRepath = -9999f;
		waitingForPathCalc = false;
		canSearchPath = true;
		if (startHasRun)
		{
			Seeker seeker = this.seeker;
			seeker.pathCallback = (OnPathDelegate)Delegate.Combine(seeker.pathCallback, new OnPathDelegate(OnPathComplete));
			((MonoBehaviour)this).StartCoroutine(SearchPaths());
		}
	}

	public void OnDisable()
	{
		if ((Object)(object)this.seeker != (Object)null && !this.seeker.IsDone())
		{
			this.seeker.GetCurrentPath().Error();
		}
		Seeker seeker = this.seeker;
		seeker.pathCallback = (OnPathDelegate)Delegate.Remove(seeker.pathCallback, new OnPathDelegate(OnPathComplete));
	}

	public virtual void UpdatePath()
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		canSearchPath = true;
		waitingForPathCalc = false;
		Path currentPath = seeker.GetCurrentPath();
		if (currentPath != null && !seeker.IsDone())
		{
			currentPath.Error();
			currentPath.Claim(this);
			currentPath.Release(this);
		}
		waitingForPathCalc = true;
		lastRepath = Time.time;
		seeker.StartPath(tr.position, target.position);
	}

	private IEnumerator SearchPaths()
	{
		while (true)
		{
			if (!repeatedlySearchPaths || waitingForPathCalc || !canSearchPath || Time.time - lastRepath < repathRate)
			{
				yield return null;
				continue;
			}
			UpdatePath();
			yield return null;
		}
	}

	private void OnPathComplete(Path p)
	{
		waitingForPathCalc = false;
		p.Claim(this);
		if (p.error)
		{
			p.Release(this);
			return;
		}
		if (traversingSpecialPath)
		{
			delayUpdatePath = true;
		}
		else
		{
			if (rp == null)
			{
				rp = new RichPath();
			}
			rp.Initialize(seeker, p, mergePartEndpoints: true, funnelSimplification);
		}
		p.Release(this);
	}

	private void NextPart()
	{
		rp.NextPart();
		lastCorner = false;
		if (!rp.PartsLeft())
		{
			OnTargetReached();
		}
	}

	protected virtual void OnTargetReached()
	{
	}

	protected virtual Vector3 UpdateTarget(RichFunnel fn)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		buffer.Clear();
		Vector3 position = tr.position;
		position = fn.Update(position, buffer, 2, out lastCorner, out var requiresRepath);
		if (requiresRepath && !waitingForPathCalc)
		{
			UpdatePath();
		}
		return position;
	}

	protected virtual void Update()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_076f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0710: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0401: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_040a: Unknown result type (might be due to invalid IL or missing references)
		//IL_040f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0411: Unknown result type (might be due to invalid IL or missing references)
		//IL_0419: Unknown result type (might be due to invalid IL or missing references)
		//IL_041e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0428: Unknown result type (might be due to invalid IL or missing references)
		//IL_042d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0432: Unknown result type (might be due to invalid IL or missing references)
		//IL_031f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0321: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		//IL_0327: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0442: Unknown result type (might be due to invalid IL or missing references)
		//IL_044a: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04df: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0386: Unknown result type (might be due to invalid IL or missing references)
		//IL_038f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_0399: Unknown result type (might be due to invalid IL or missing references)
		//IL_039e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_0347: Unknown result type (might be due to invalid IL or missing references)
		//IL_0359: Unknown result type (might be due to invalid IL or missing references)
		//IL_035e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0363: Unknown result type (might be due to invalid IL or missing references)
		//IL_0375: Unknown result type (might be due to invalid IL or missing references)
		//IL_037a: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03da: Unknown result type (might be due to invalid IL or missing references)
		//IL_03df: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_05da: Unknown result type (might be due to invalid IL or missing references)
		//IL_05df: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_051e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0523: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0609: Unknown result type (might be due to invalid IL or missing references)
		//IL_060e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0613: Unknown result type (might be due to invalid IL or missing references)
		//IL_0618: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0644: Unknown result type (might be due to invalid IL or missing references)
		//IL_0651: Unknown result type (might be due to invalid IL or missing references)
		//IL_0687: Unknown result type (might be due to invalid IL or missing references)
		//IL_0694: Unknown result type (might be due to invalid IL or missing references)
		//IL_069e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a3: Unknown result type (might be due to invalid IL or missing references)
		deltaTime = Mathf.Min(Time.smoothDeltaTime * 2f, Time.deltaTime);
		if (rp != null)
		{
			RichPathPart currentPart = rp.GetCurrentPart();
			if (currentPart is RichFunnel richFunnel)
			{
				Vector3 val = UpdateTarget(richFunnel);
				if (Time.frameCount % 5 == 0 && wallForce > 0f && wallDist > 0f)
				{
					wallBuffer.Clear();
					richFunnel.FindWalls(wallBuffer, wallDist);
				}
				int num = 0;
				Vector3 val2 = buffer[num];
				Vector3 val3 = val2 - val;
				val3.y = 0f;
				if (Vector3.Dot(val3, currentTargetDirection) < 0f && buffer.Count - num > 1)
				{
					num++;
					val2 = buffer[num];
				}
				if (val2 != lastTargetPoint)
				{
					currentTargetDirection = val2 - val;
					currentTargetDirection.y = 0f;
					currentTargetDirection.Normalize();
					lastTargetPoint = val2;
				}
				val3 = val2 - val;
				val3.y = 0f;
				float num2 = (distanceToWaypoint = val3.magnitude);
				val3 = ((num2 != 0f) ? (val3 / num2) : Vector3.zero);
				Vector3 val4 = val3;
				Vector3 val5 = Vector3.zero;
				if (wallForce > 0f && wallDist > 0f)
				{
					float num3 = 0f;
					float num4 = 0f;
					for (int i = 0; i < wallBuffer.Count; i += 2)
					{
						Vector3 val6 = VectorMath.ClosestPointOnSegment(wallBuffer[i], wallBuffer[i + 1], tr.position);
						Vector3 val7 = val6 - val;
						float sqrMagnitude = val7.sqrMagnitude;
						if (!(sqrMagnitude > wallDist * wallDist))
						{
							Vector3 val8 = wallBuffer[i + 1] - wallBuffer[i];
							Vector3 normalized = val8.normalized;
							float num5 = Vector3.Dot(val3, normalized) * (1f - Math.Max(0f, 2f * (sqrMagnitude / (wallDist * wallDist)) - 1f));
							if (num5 > 0f)
							{
								num4 = Math.Max(num4, num5);
							}
							else
							{
								num3 = Math.Max(num3, 0f - num5);
							}
						}
					}
					Vector3 val9 = Vector3.Cross(Vector3.up, val3);
					val5 = val9 * (num4 - num3);
				}
				bool flag = lastCorner && buffer.Count - num == 1;
				if (flag)
				{
					if (slowdownTime < 0.001f)
					{
						slowdownTime = 0.001f;
					}
					Vector3 val10 = val2 - val;
					val10.y = 0f;
					val3 = ((!preciseSlowdown) ? (2f * (val10 - slowdownTime * velocity) / (slowdownTime * slowdownTime)) : ((6f * val10 - 4f * slowdownTime * velocity) / (slowdownTime * slowdownTime)));
					val3 = Vector3.ClampMagnitude(val3, acceleration);
					val5 *= Math.Min(num2 / 0.5f, 1f);
					if (num2 < endReachedDistance)
					{
						NextPart();
					}
				}
				else
				{
					val3 *= acceleration;
				}
				velocity += (val3 + val5 * wallForce) * deltaTime;
				if (slowWhenNotFacingTarget)
				{
					float num6 = (Vector3.Dot(val4, tr.forward) + 0.5f) * (2f / 3f);
					float num7 = Mathf.Sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
					float y = velocity.y;
					velocity.y = 0f;
					float num8 = Mathf.Min(num7, maxSpeed * Mathf.Max(num6, 0.2f));
					velocity = Vector3.Lerp(tr.forward * num8, velocity.normalized * num8, Mathf.Clamp((!flag) ? 0f : (num2 * 2f), 0.5f, 1f));
					velocity.y = y;
				}
				else
				{
					float num9 = Mathf.Sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
					num9 = maxSpeed / num9;
					if (num9 < 1f)
					{
						ref Vector3 reference = ref velocity;
						reference.x *= num9;
						ref Vector3 reference2 = ref velocity;
						reference2.z *= num9;
					}
				}
				if (flag)
				{
					Vector3 trotdir = Vector3.Lerp(velocity, currentTargetDirection, Math.Max(1f - num2 * 2f, 0f));
					RotateTowards(trotdir);
				}
				else
				{
					RotateTowards(velocity);
				}
				velocity += deltaTime * gravity;
				if ((Object)(object)rvoController != (Object)null && ((Behaviour)rvoController).enabled)
				{
					tr.position = val;
					rvoController.Move(velocity);
				}
				else if ((Object)(object)controller != (Object)null && ((Collider)controller).enabled)
				{
					tr.position = val;
					controller.Move(velocity * deltaTime);
				}
				else
				{
					float y2 = val.y;
					val += velocity * deltaTime;
					val = RaycastPosition(val, y2);
					tr.position = val;
				}
			}
			else if ((Object)(object)rvoController != (Object)null && ((Behaviour)rvoController).enabled)
			{
				rvoController.Move(Vector3.zero);
			}
			if (currentPart is RichSpecial && !traversingSpecialPath)
			{
				((MonoBehaviour)this).StartCoroutine(TraverseSpecial(currentPart as RichSpecial));
			}
		}
		else if ((Object)(object)rvoController != (Object)null && ((Behaviour)rvoController).enabled)
		{
			rvoController.Move(Vector3.zero);
		}
		else if (!((Object)(object)controller != (Object)null) || !((Collider)controller).enabled)
		{
			tr.position = RaycastPosition(tr.position, tr.position.y);
		}
	}

	private Vector3 RaycastPosition(Vector3 position, float lasty)
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		if (raycastingForGroundPlacement)
		{
			float num = Mathf.Max(centerOffset, lasty - position.y + centerOffset);
			RaycastHit val = default;
			if (Physics.Raycast(position + Vector3.up * num, Vector3.down, ref val, num, LayerMask.op_Implicit(groundMask)) && val.distance < num)
			{
				position = val.point;
				velocity.y = 0f;
			}
		}
		return position;
	}

	private bool RotateTowards(Vector3 trotdir)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		trotdir.y = 0f;
		if (trotdir != Vector3.zero)
		{
			Quaternion rotation = tr.rotation;
			Quaternion val = Quaternion.LookRotation(trotdir);
			Vector3 eulerAngles = val.eulerAngles;
			Vector3 eulerAngles2 = rotation.eulerAngles;
			eulerAngles2.y = Mathf.MoveTowardsAngle(eulerAngles2.y, eulerAngles.y, rotationSpeed * deltaTime);
			tr.rotation = Quaternion.Euler(eulerAngles2);
			return Mathf.Abs(eulerAngles2.y - eulerAngles.y) < 5f;
		}
		return false;
	}

	public void OnDrawGizmos()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		if (!drawGizmos)
		{
			return;
		}
		if (raycastingForGroundPlacement)
		{
			Gizmos.color = GizmoColorRaycast;
			Gizmos.DrawLine(((Component)this).transform.position, ((Component)this).transform.position + Vector3.up * centerOffset);
			Gizmos.DrawLine(((Component)this).transform.position + Vector3.left * 0.1f, ((Component)this).transform.position + Vector3.right * 0.1f);
			Gizmos.DrawLine(((Component)this).transform.position + Vector3.back * 0.1f, ((Component)this).transform.position + Vector3.forward * 0.1f);
		}
		if ((Object)(object)tr != (Object)null && buffer != null)
		{
			Gizmos.color = GizmoColorPath;
			Vector3 val = tr.position;
			for (int i = 0; i < buffer.Count; i++)
			{
				Gizmos.DrawLine(val, buffer[i]);
				val = buffer[i];
			}
		}
	}

	private IEnumerator TraverseSpecial(RichSpecial rs)
	{
		traversingSpecialPath = true;
		velocity = Vector3.zero;
		AnimationLink al = rs.nodeLink as AnimationLink;
		if ((Object)(object)al == (Object)null)
		{
			Debug.LogError((object)"Unhandled RichSpecial");
			yield break;
		}
		while (!RotateTowards(rs.first.forward))
		{
			yield return null;
		}
		tr.parent.position = tr.position;
		tr.parent.rotation = tr.rotation;
		tr.localPosition = Vector3.zero;
		tr.localRotation = Quaternion.identity;
		if (rs.reverse && al.reverseAnim)
		{
			anim[al.clip].speed = 0f - al.animSpeed;
			anim[al.clip].normalizedTime = 1f;
			anim.Play(al.clip);
			anim.Sample();
		}
		else
		{
			anim[al.clip].speed = al.animSpeed;
			anim.Rewind(al.clip);
			anim.Play(al.clip);
		}
		Transform parent = tr.parent;
		parent.position -= tr.position - tr.parent.position;
		yield return (object)new WaitForSeconds(Mathf.Abs(anim[al.clip].length / al.animSpeed));
		traversingSpecialPath = false;
		NextPart();
		if (delayUpdatePath)
		{
			delayUpdatePath = false;
			UpdatePath();
		}
	}

	static RichAI()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
	}
}
