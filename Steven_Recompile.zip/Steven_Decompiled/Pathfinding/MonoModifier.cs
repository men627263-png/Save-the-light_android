using System;
using UnityEngine;

namespace Pathfinding;

[Serializable]
public abstract class MonoModifier : MonoBehaviour, IPathModifier
{
	[NonSerialized]
	public Seeker seeker;

	public abstract int Order { get; }

	public void OnEnable()
	{
	}

	public void OnDisable()
	{
	}

	public void Awake()
	{
		seeker = ((Component)this).GetComponent<Seeker>();
		if ((Object)(object)seeker != (Object)null)
		{
			seeker.RegisterModifier(this);
		}
	}

	public void OnDestroy()
	{
		if ((Object)(object)seeker != (Object)null)
		{
			seeker.DeregisterModifier(this);
		}
	}

	public virtual void PreProcess(Path p)
	{
	}

	public abstract void Apply(Path p);
}
