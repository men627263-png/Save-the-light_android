using System;
using System.Collections.Generic;
using UnityEngine;

namespace Pathfinding;

[AddComponentMenu("Pathfinding/Link2")]
[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_node_link2.php")]
public class NodeLink2 : GraphModifier
{
	protected static Dictionary<GraphNode, NodeLink2> reference = new Dictionary<GraphNode, NodeLink2>();

	public static bool graphManuallyUpdated = false;

	protected static List<NodeLink2> linksManuallyUpdating;

	public Transform end;

	public float costFactor = 1f;

	public bool oneWay;

	protected PointNode startNode;

	protected PointNode endNode;

	protected MeshNode connectedNode1;

	protected MeshNode connectedNode2;

	protected Vector3 clamped1;

	protected Vector3 clamped2;

	private bool postScanCalled;

	protected static readonly Color GizmosColor = new Color(206f / 255f, 8f / 15f, 48f / 255f, 0.5f);

	protected static readonly Color GizmosColorSelected = new Color(235f / 255f, 123f / 255f, 32f / 255f, 1f);

	public Transform StartTransform => ((Component)this).transform;

	public Transform EndTransform => end;

	public GraphNode StartNode => startNode;

	public GraphNode EndNode => endNode;

	public static NodeLink2 GetNodeLink(GraphNode node)
	{
		reference.TryGetValue(node, out var value);
		return value;
	}

	public override void OnPostScan()
	{
		if (!((Component)this).gameObject.activeInHierarchy)
		{
			return;
		}
		if (AstarPath.active.isScanning)
		{
			InternalOnPostScan();
			return;
		}
		AstarPath.active.AddWorkItem(new AstarPath.AstarWorkItem((bool force) =>
		{
			InternalOnPostScan();
			return true;
		}));
	}

	private void EvaluateLife(Path path)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = path.vectorPath[path.vectorPath.Count - 1];
		if (Vector3.Distance(val, EndTransform.position) < 0.1f)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	public void InternalOnPostScan(bool findNearestNode = false)
	{
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)EndTransform == (Object)null) && !((Object)(object)StartTransform == (Object)null) && ((Component)this).gameObject.activeInHierarchy)
		{
			if (AstarPath.active.astarData.pointGraph == null)
			{
				AstarPath.active.astarData.AddGraph(new PointGraph());
			}
			if (startNode != null && reference.TryGetValue(startNode, out var value) && (Object)(object)value == (Object)(object)this)
			{
				reference.Remove(startNode);
			}
			if (endNode != null && reference.TryGetValue(endNode, out var value2) && (Object)(object)value2 == (Object)(object)this)
			{
				reference.Remove(endNode);
			}
			if (!findNearestNode)
			{
				startNode = AstarPath.active.astarData.pointGraph.AddNode((Int3)StartTransform.position);
				endNode = AstarPath.active.astarData.pointGraph.AddNode((Int3)EndTransform.position);
			}
			else
			{
				startNode = AstarPath.active.astarData.pointGraph.GetNearest(StartTransform.position).node as PointNode;
				endNode = AstarPath.active.astarData.pointGraph.GetNearest(EndTransform.position).node as PointNode;
			}
			connectedNode1 = null;
			connectedNode2 = null;
			if (startNode == null || endNode == null)
			{
				startNode = null;
				endNode = null;
				return;
			}
			postScanCalled = true;
			reference[startNode] = this;
			reference[endNode] = this;
			Apply(forceNewCheck: true);
		}
	}

	public override void OnGraphsPreUpdate()
	{
		if (!AstarPath.active.isScanning && postScanCalled && graphManuallyUpdated)
		{
			if (linksManuallyUpdating == null)
			{
				linksManuallyUpdating = new List<NodeLink2>();
			}
			linksManuallyUpdating.Add(this);
		}
	}

	public override void OnGraphsPostUpdate()
	{
		if (AstarPath.active.isScanning)
		{
			return;
		}
		if (connectedNode1 != null && connectedNode1.Destroyed)
		{
			connectedNode1 = null;
		}
		if (connectedNode2 != null && connectedNode2.Destroyed)
		{
			connectedNode2 = null;
		}
		if (!postScanCalled)
		{
			OnPostScan();
			return;
		}
		if (!graphManuallyUpdated)
		{
			Apply(forceNewCheck: false);
			return;
		}
		Apply(forceNewCheck: true);
		linksManuallyUpdating.RemoveAll((NodeLink2 x) => ((object)x).Equals((object?)this));
		if (linksManuallyUpdating.Count <= 0)
		{
			graphManuallyUpdated = false;
			AstarPath.active.FloodFill();
		}
	}

	protected override void OnEnable()
	{
		base.OnEnable();
		if ((Object)(object)AstarPath.active != (Object)null && AstarPath.active.astarData != null && AstarPath.active.astarData.pointGraph != null)
		{
			OnGraphsPostUpdate();
		}
	}

	protected override void OnDisable()
	{
		base.OnDisable();
		postScanCalled = false;
		if (startNode != null && reference.TryGetValue(startNode, out var value) && (Object)(object)value == (Object)(object)this)
		{
			reference.Remove(startNode);
		}
		if (endNode != null && reference.TryGetValue(endNode, out var value2) && (Object)(object)value2 == (Object)(object)this)
		{
			reference.Remove(endNode);
		}
		if (startNode != null && endNode != null)
		{
			startNode.RemoveConnection(endNode);
			endNode.RemoveConnection(startNode);
			if (connectedNode1 != null && connectedNode2 != null)
			{
				startNode.RemoveConnection(connectedNode1);
				connectedNode1.RemoveConnection(startNode);
				endNode.RemoveConnection(connectedNode2);
				connectedNode2.RemoveConnection(endNode);
			}
		}
	}

	protected void RemoveConnections(GraphNode node)
	{
		node.ClearConnections(alsoReverse: true);
	}

	[ContextMenu("Recalculate neighbours")]
	protected virtual void ContextApplyForce()
	{
		if (Application.isPlaying)
		{
			Apply(forceNewCheck: true);
			if ((Object)(object)AstarPath.active != (Object)null)
			{
				AstarPath.active.FloodFill();
			}
		}
	}

	public virtual void Apply(bool forceNewCheck)
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		NNConstraint none = NNConstraint.None;
		int graphIndex = (int)startNode.GraphIndex;
		none.graphMask = ~(1 << graphIndex);
		startNode.SetPosition((Int3)StartTransform.position);
		endNode.SetPosition((Int3)EndTransform.position);
		RemoveConnections(startNode);
		RemoveConnections(endNode);
		uint cost = (uint)Mathf.RoundToInt((float)((Int3)(StartTransform.position - EndTransform.position)).costMagnitude * costFactor);
		startNode.AddConnection(endNode, cost);
		endNode.AddConnection(startNode, cost);
		if (connectedNode1 == null || forceNewCheck)
		{
			NNInfo nearest = AstarPath.active.GetNearest(StartTransform.position, none);
			connectedNode1 = nearest.node as MeshNode;
			clamped1 = nearest.clampedPosition;
		}
		if (connectedNode2 == null || forceNewCheck)
		{
			NNInfo nearest2 = AstarPath.active.GetNearest(EndTransform.position, none);
			connectedNode2 = nearest2.node as MeshNode;
			clamped2 = nearest2.clampedPosition;
		}
		if (connectedNode2 != null && connectedNode1 != null)
		{
			connectedNode1.AddConnection(startNode, (uint)Mathf.RoundToInt((float)((Int3)(clamped1 - StartTransform.position)).costMagnitude * costFactor));
			if (!oneWay)
			{
				connectedNode2.AddConnection(endNode, (uint)Mathf.RoundToInt((float)((Int3)(clamped2 - EndTransform.position)).costMagnitude * costFactor));
			}
			if (!oneWay)
			{
				startNode.AddConnection(connectedNode1, (uint)Mathf.RoundToInt((float)((Int3)(clamped1 - StartTransform.position)).costMagnitude * costFactor));
			}
			endNode.AddConnection(connectedNode2, (uint)Mathf.RoundToInt((float)((Int3)(clamped2 - EndTransform.position)).costMagnitude * costFactor));
		}
	}

	protected void DrawCircle(Vector3 o, float r, int detail, Color col)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = new Vector3(Mathf.Cos(0f) * r, 0f, Mathf.Sin(0f) * r) + o;
		Gizmos.color = col;
		for (int i = 0; i <= detail; i++)
		{
			float num = (float)i * (float)Math.PI * 2f / (float)detail;
			Vector3 val2 = new Vector3(Mathf.Cos(num) * r, 0f, Mathf.Sin(num) * r) + o;
			Gizmos.DrawLine(val, val2);
			val = val2;
		}
	}

	protected void DrawGizmoBezier(Vector3 p1, Vector3 p2)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = p2 - p1;
		if (!(val == Vector3.zero))
		{
			Vector3 val2 = Vector3.Cross(Vector3.up, val);
			Vector3 val3 = Vector3.Cross(val, val2);
			val3 = val3.normalized;
			val3 *= val.magnitude * 0.1f;
			Vector3 p3 = p1 + val3;
			Vector3 p4 = p2 + val3;
			Vector3 val4 = p1;
			for (int i = 1; i <= 20; i++)
			{
				float t = (float)i / 20f;
				Vector3 val5 = AstarSplines.CubicBezier(p1, p3, p4, p2, t);
				Gizmos.DrawLine(val4, val5);
				val4 = val5;
			}
		}
	}

	public virtual void OnDrawGizmosSelected()
	{
		OnDrawGizmos(selected: true);
	}

	public virtual void OnDrawGizmos()
	{
		OnDrawGizmos(selected: false);
	}

	public virtual void OnDrawGizmos(bool selected)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		Color val = ((!selected) ? GizmosColor : GizmosColorSelected);
		if ((Object)(object)StartTransform != (Object)null)
		{
			DrawCircle(StartTransform.position, 0.4f, 10, val);
		}
		if ((Object)(object)EndTransform != (Object)null)
		{
			DrawCircle(EndTransform.position, 0.4f, 10, val);
		}
		if ((Object)(object)StartTransform != (Object)null && (Object)(object)EndTransform != (Object)null)
		{
			Gizmos.color = val;
			DrawGizmoBezier(StartTransform.position, EndTransform.position);
			if (selected)
			{
				Vector3 val2 = Vector3.Cross(Vector3.up, EndTransform.position - StartTransform.position);
				Vector3 normalized = val2.normalized;
				DrawGizmoBezier(StartTransform.position + normalized * 0.1f, EndTransform.position + normalized * 0.1f);
				DrawGizmoBezier(StartTransform.position - normalized * 0.1f, EndTransform.position - normalized * 0.1f);
			}
		}
	}

	static NodeLink2()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
	}
}
