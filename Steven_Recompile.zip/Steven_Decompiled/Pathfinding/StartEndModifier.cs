using System;
using System.Collections.Generic;
using UnityEngine;

namespace Pathfinding;

[Serializable]
public class StartEndModifier : PathModifier
{
	public enum Exactness
	{
		SnapToNode,
		Original,
		Interpolate,
		ClosestOnNode,
		NodeConnection
	}

	public bool addPoints;

	public Exactness exactStartPoint = Exactness.ClosestOnNode;

	public Exactness exactEndPoint = Exactness.ClosestOnNode;

	public Func<Vector3> adjustStartPoint;

	public bool useRaycasting;

	public LayerMask mask = LayerMask.op_Implicit(-1);

	public bool useGraphRaycasting;

	private List<GraphNode> connectionBuffer;

	private GraphNodeDelegate connectionBufferAddDelegate;

	public override int Order => 0;

	public StartEndModifier()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
	}

	public override void Apply(Path _p)
	{
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		if (_p is ABPath aBPath && aBPath.vectorPath.Count != 0)
		{
			if (aBPath.vectorPath.Count == 1 && !addPoints)
			{
				aBPath.vectorPath.Add(aBPath.vectorPath[0]);
			}
			Vector3 val = Snap(aBPath, exactStartPoint, start: true, out var forceAddPoint);
			Vector3 val2 = Snap(aBPath, exactEndPoint, start: false, out var forceAddPoint2);
			if ((forceAddPoint || addPoints) && exactStartPoint != Exactness.SnapToNode)
			{
				aBPath.vectorPath.Insert(0, val);
			}
			else
			{
				aBPath.vectorPath[0] = val;
			}
			if ((forceAddPoint2 || addPoints) && exactEndPoint != Exactness.SnapToNode)
			{
				aBPath.vectorPath.Add(val2);
			}
			else
			{
				aBPath.vectorPath[aBPath.vectorPath.Count - 1] = val2;
			}
		}
	}

	private Vector3 Snap(ABPath path, Exactness mode, bool start, out bool forceAddPoint)
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		int num = ((!start) ? (path.path.Count - 1) : 0);
		GraphNode graphNode = path.path[num];
		Vector3 val = (Vector3)graphNode.position;
		forceAddPoint = false;
		switch (mode)
		{
		case Exactness.ClosestOnNode:
			return GetClampedPoint(val, (!start) ? path.endPoint : path.startPoint, graphNode);
		case Exactness.SnapToNode:
			return val;
		case Exactness.Original:
		case Exactness.Interpolate:
		case Exactness.NodeConnection:
		{
			Vector3 val2;
			if (start)
			{
				val2 = ((adjustStartPoint == null) ? path.originalStartPoint : adjustStartPoint());
			}
			else
			{
				val2 = path.originalEndPoint;
			}
			switch (mode)
			{
			case Exactness.Original:
				return GetClampedPoint(val, val2, graphNode);
			case Exactness.Interpolate:
			{
				Vector3 clampedPoint = GetClampedPoint(val, val2, graphNode);
				GraphNode graphNode2 = path.path[Mathf.Clamp(num + (start ? 1 : (-1)), 0, path.path.Count - 1)];
				return VectorMath.ClosestPointOnSegment(val, (Vector3)graphNode2.position, clampedPoint);
			}
			case Exactness.NodeConnection:
			{
				connectionBuffer = connectionBuffer ?? new List<GraphNode>();
				connectionBufferAddDelegate = connectionBufferAddDelegate ?? new GraphNodeDelegate(connectionBuffer.Add);
				GraphNode graphNode2 = path.path[Mathf.Clamp(num + (start ? 1 : (-1)), 0, path.path.Count - 1)];
				graphNode.GetConnections(connectionBufferAddDelegate);
				Vector3 result = val;
				float num2 = float.PositiveInfinity;
				for (int num3 = connectionBuffer.Count - 1; num3 >= 0; num3--)
				{
					GraphNode graphNode3 = connectionBuffer[num3];
					Vector3 val3 = VectorMath.ClosestPointOnSegment(val, (Vector3)graphNode3.position, val2);
					Vector3 val4 = val3 - val2;
					float sqrMagnitude = val4.sqrMagnitude;
					if (sqrMagnitude < num2)
					{
						result = val3;
						num2 = sqrMagnitude;
						forceAddPoint = graphNode3 != graphNode2;
					}
				}
				connectionBuffer.Clear();
				return result;
			}
			default:
				throw new ArgumentException("Cannot reach this point, but the compiler is not smart enough to realize that.");
			}
		}
		default:
			throw new ArgumentException("Invalid mode");
		}
	}

	public Vector3 GetClampedPoint(Vector3 from, Vector3 to, GraphNode hint)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = to;
		RaycastHit val2 = default;
		if (useRaycasting && Physics.Linecast(from, to, ref val2, LayerMask.op_Implicit(mask)))
		{
			val = val2.point;
		}
		if (useGraphRaycasting && hint != null && AstarData.GetGraph(hint) is IRaycastableGraph raycastableGraph && raycastableGraph.Linecast(from, val, hint, out var hit))
		{
			val = hit.point;
		}
		return val;
	}
}
