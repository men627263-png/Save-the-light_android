using System;
using System.Collections.Generic;
using Pathfinding.Util;
using UnityEngine;

namespace Pathfinding;

[Serializable]
[AddComponentMenu("Pathfinding/Modifiers/Funnel")]
[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_funnel_modifier.php")]
public class FunnelModifier : MonoModifier
{
	public override int Order => 10;

	public override void Apply(Path p)
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		List<GraphNode> path = p.path;
		List<Vector3> vectorPath = p.vectorPath;
		if (path == null || path.Count == 0 || vectorPath == null || vectorPath.Count != path.Count)
		{
			return;
		}
		List<Vector3> list = ListPool<Vector3>.Claim();
		List<Vector3> list2 = ListPool<Vector3>.Claim(path.Count + 1);
		List<Vector3> list3 = ListPool<Vector3>.Claim(path.Count + 1);
		list2.Add(vectorPath[0]);
		list3.Add(vectorPath[0]);
		for (int i = 0; i < path.Count - 1; i++)
		{
			if (!path[i].GetPortal(path[i + 1], list2, list3, backwards: false))
			{
				list2.Add((Vector3)path[i].position);
				list3.Add((Vector3)path[i].position);
				list2.Add((Vector3)path[i + 1].position);
				list3.Add((Vector3)path[i + 1].position);
			}
		}
		list2.Add(vectorPath[vectorPath.Count - 1]);
		list3.Add(vectorPath[vectorPath.Count - 1]);
		if (!RunFunnel(list2, list3, list))
		{
			list.Add(vectorPath[0]);
			list.Add(vectorPath[vectorPath.Count - 1]);
		}
		ListPool<Vector3>.Release(p.vectorPath);
		p.vectorPath = list;
		ListPool<Vector3>.Release(list2);
		ListPool<Vector3>.Release(list3);
	}

	public static bool RunFunnel(List<Vector3> left, List<Vector3> right, List<Vector3> funnelPath)
	{
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_027a: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_028c: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_025e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_0265: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ca: Unknown result type (might be due to invalid IL or missing references)
		if (left == null)
		{
			throw new ArgumentNullException("left");
		}
		if (right == null)
		{
			throw new ArgumentNullException("right");
		}
		if (funnelPath == null)
		{
			throw new ArgumentNullException("funnelPath");
		}
		if (left.Count != right.Count)
		{
			throw new ArgumentException("left and right lists must have equal length");
		}
		if (left.Count <= 3)
		{
			return false;
		}
		while (left[1] == left[2] && right[1] == right[2])
		{
			left.RemoveAt(1);
			right.RemoveAt(1);
			if (left.Count <= 3)
			{
				return false;
			}
		}
		Vector3 val = left[2];
		if (val == left[1])
		{
			val = right[2];
		}
		while (VectorMath.IsColinearXZ(left[0], left[1], right[1]) || VectorMath.RightOrColinearXZ(left[1], right[1], val) == VectorMath.RightOrColinearXZ(left[1], right[1], left[0]))
		{
			left.RemoveAt(1);
			right.RemoveAt(1);
			if (left.Count <= 3)
			{
				return false;
			}
			val = left[2];
			if (val == left[1])
			{
				val = right[2];
			}
		}
		if (!VectorMath.IsClockwiseXZ(left[0], left[1], right[1]) && !VectorMath.IsColinearXZ(left[0], left[1], right[1]))
		{
			List<Vector3> list = left;
			left = right;
			right = list;
		}
		funnelPath.Add(left[0]);
		Vector3 val2 = left[0];
		Vector3 val3 = left[1];
		Vector3 val4 = right[1];
		int num = 0;
		int num2 = 1;
		int num3 = 1;
		for (int i = 2; i < left.Count; i++)
		{
			if (funnelPath.Count > 2000)
			{
				Debug.LogWarning((object)"Avoiding infinite loop. Remove this check if you have this long paths.");
				break;
			}
			Vector3 val5 = left[i];
			Vector3 val6 = right[i];
			if (VectorMath.SignedTriangleAreaTimes2XZ(val2, val4, val6) >= 0f)
			{
				if (!(val2 == val4) && !(VectorMath.SignedTriangleAreaTimes2XZ(val2, val3, val6) <= 0f))
				{
					funnelPath.Add(val3);
					val2 = val3;
					num = num3;
					val3 = val2;
					val4 = val2;
					num3 = num;
					num2 = num;
					i = num;
					continue;
				}
				val4 = val6;
				num2 = i;
			}
			if (VectorMath.SignedTriangleAreaTimes2XZ(val2, val3, val5) <= 0f)
			{
				if (val2 == val3 || VectorMath.SignedTriangleAreaTimes2XZ(val2, val4, val5) >= 0f)
				{
					val3 = val5;
					num3 = i;
					continue;
				}
				funnelPath.Add(val4);
				val2 = val4;
				num = num2;
				val3 = val2;
				val4 = val2;
				num3 = num;
				num2 = num;
				i = num;
			}
		}
		funnelPath.Add(left[left.Count - 1]);
		return true;
	}
}
