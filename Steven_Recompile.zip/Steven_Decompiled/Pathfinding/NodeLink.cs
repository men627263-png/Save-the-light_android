using System;
using UnityEngine;

namespace Pathfinding;

[AddComponentMenu("Pathfinding/Link")]
[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_node_link.php")]
public class NodeLink : GraphModifier
{
	public Transform end;

	public float costFactor = 1f;

	public bool oneWay;

	public bool deleteConnection;

	public Transform Start => ((Component)this).transform;

	public Transform End => end;

	public override void OnPostScan()
	{
		if (AstarPath.active.isScanning)
		{
			InternalOnPostScan();
			return;
		}
		AstarPath.active.AddWorkItem(new AstarPath.AstarWorkItem((bool force) =>
		{
			InternalOnPostScan();
			return true;
		}));
	}

	public void InternalOnPostScan()
	{
		Apply();
	}

	public override void OnGraphsPostUpdate()
	{
		if (!AstarPath.active.isScanning)
		{
			AstarPath.active.AddWorkItem(new AstarPath.AstarWorkItem((bool force) =>
			{
				InternalOnPostScan();
				return true;
			}));
		}
	}

	public virtual void Apply()
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)Start == (Object)null || (Object)(object)End == (Object)null || (Object)(object)AstarPath.active == (Object)null)
		{
			return;
		}
		GraphNode node = AstarPath.active.GetNearest(Start.position).node;
		GraphNode node2 = AstarPath.active.GetNearest(End.position).node;
		if (node == null || node2 == null)
		{
			return;
		}
		if (deleteConnection)
		{
			node.RemoveConnection(node2);
			if (!oneWay)
			{
				node2.RemoveConnection(node);
			}
			return;
		}
		uint cost = (uint)Math.Round((float)(node.position - node2.position).costMagnitude * costFactor);
		node.AddConnection(node2, cost);
		if (!oneWay)
		{
			node2.AddConnection(node, cost);
		}
	}

	public void OnDrawGizmos()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)Start == (Object)null) && !((Object)(object)End == (Object)null))
		{
			Vector3 position = Start.position;
			Vector3 position2 = End.position;
			Gizmos.color = ((!deleteConnection) ? Color.green : Color.red);
			DrawGizmoBezier(position, position2);
		}
	}

	private void DrawGizmoBezier(Vector3 p1, Vector3 p2)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = p2 - p1;
		if (!(val == Vector3.zero))
		{
			Vector3 val2 = Vector3.Cross(Vector3.up, val);
			Vector3 val3 = Vector3.Cross(val, val2);
			val3 = val3.normalized;
			val3 *= val.magnitude * 0.1f;
			Vector3 p3 = p1 + val3;
			Vector3 p4 = p2 + val3;
			Vector3 val4 = p1;
			for (int i = 1; i <= 20; i++)
			{
				float t = (float)i / 20f;
				Vector3 val5 = AstarSplines.CubicBezier(p1, p3, p4, p2, t);
				Gizmos.DrawLine(val4, val5);
				val4 = val5;
			}
		}
	}
}
