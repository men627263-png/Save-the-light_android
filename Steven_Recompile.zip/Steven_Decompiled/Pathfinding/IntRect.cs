using System;
using UnityEngine;

namespace Pathfinding;

public struct IntRect(int xmin, int ymin, int xmax, int ymax)
{
	public int xmin = xmin;

	public int ymin = ymin;

	public int xmax = xmax;

	public int ymax = ymax;

	private static readonly int[] Rotations = new int[16]
	{
		1, 0, 0, 1, 0, 1, -1, 0, -1, 0,
		0, -1, 0, -1, 1, 0
	};

	public int Width => xmax - xmin + 1;

	public int Height => ymax - ymin + 1;

	public bool Contains(int x, int y)
	{
		return x >= xmin && y >= ymin && x <= xmax && y <= ymax;
	}

	public bool IsValid()
	{
		return xmin <= xmax && ymin <= ymax;
	}

	public static bool operator ==(IntRect a, IntRect b)
	{
		return a.xmin == b.xmin && a.xmax == b.xmax && a.ymin == b.ymin && a.ymax == b.ymax;
	}

	public static bool operator !=(IntRect a, IntRect b)
	{
		return a.xmin != b.xmin || a.xmax != b.xmax || a.ymin != b.ymin || a.ymax != b.ymax;
	}

	public override bool Equals(object _b)
	{
		IntRect intRect = (IntRect)_b;
		return xmin == intRect.xmin && xmax == intRect.xmax && ymin == intRect.ymin && ymax == intRect.ymax;
	}

	public override int GetHashCode()
	{
		return (xmin * 131071) ^ (xmax * 3571) ^ (ymin * 3109) ^ (ymax * 7);
	}

	public static IntRect Intersection(IntRect a, IntRect b)
	{
		return new IntRect(Math.Max(a.xmin, b.xmin), Math.Max(a.ymin, b.ymin), Math.Min(a.xmax, b.xmax), Math.Min(a.ymax, b.ymax));
	}

	public static bool Intersects(IntRect a, IntRect b)
	{
		return a.xmin <= b.xmax && a.ymin <= b.ymax && a.xmax >= b.xmin && a.ymax >= b.ymin;
	}

	public static IntRect Union(IntRect a, IntRect b)
	{
		return new IntRect(Math.Min(a.xmin, b.xmin), Math.Min(a.ymin, b.ymin), Math.Max(a.xmax, b.xmax), Math.Max(a.ymax, b.ymax));
	}

	public IntRect ExpandToContain(int x, int y)
	{
		return new IntRect(Math.Min(xmin, x), Math.Min(ymin, y), Math.Max(xmax, x), Math.Max(ymax, y));
	}

	public IntRect Expand(int range)
	{
		return new IntRect(xmin - range, ymin - range, xmax + range, ymax + range);
	}

	public IntRect Rotate(int r)
	{
		int num = Rotations[r * 4];
		int num2 = Rotations[r * 4 + 1];
		int num3 = Rotations[r * 4 + 2];
		int num4 = Rotations[r * 4 + 3];
		int val = num * xmin + num2 * ymin;
		int val2 = num3 * xmin + num4 * ymin;
		int val3 = num * xmax + num2 * ymax;
		int val4 = num3 * xmax + num4 * ymax;
		return new IntRect(Math.Min(val, val3), Math.Min(val2, val4), Math.Max(val, val3), Math.Max(val2, val4));
	}

	public IntRect Offset(Int2 offset)
	{
		return new IntRect(xmin + offset.x, ymin + offset.y, xmax + offset.x, ymax + offset.y);
	}

	public IntRect Offset(int x, int y)
	{
		return new IntRect(xmin + x, ymin + y, xmax + x, ymax + y);
	}

	public override string ToString()
	{
		return "[x: " + xmin + "..." + xmax + ", y: " + ymin + "..." + ymax + "]";
	}

	public void DebugDraw(Matrix4x4 matrix, Color col)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = matrix.MultiplyPoint3x4(new Vector3((float)xmin, 0f, (float)ymin));
		Vector3 val2 = matrix.MultiplyPoint3x4(new Vector3((float)xmin, 0f, (float)ymax));
		Vector3 val3 = matrix.MultiplyPoint3x4(new Vector3((float)xmax, 0f, (float)ymax));
		Vector3 val4 = matrix.MultiplyPoint3x4(new Vector3((float)xmax, 0f, (float)ymin));
		Debug.DrawLine(val, val2, col);
		Debug.DrawLine(val2, val3, col);
		Debug.DrawLine(val3, val4, col);
		Debug.DrawLine(val4, val, col);
	}
}
