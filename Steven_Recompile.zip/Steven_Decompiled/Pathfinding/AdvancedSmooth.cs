using System;
using System.Collections.Generic;
using UnityEngine;

namespace Pathfinding;

[Serializable]
[AddComponentMenu("Pathfinding/Modifiers/Advanced Smooth")]
[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_advanced_smooth.php")]
public class AdvancedSmooth : MonoModifier
{
	[Serializable]
	public class MaxTurn : TurnConstructor
	{
		private Vector3 preRightCircleCenter = Vector3.zero;

		private Vector3 preLeftCircleCenter = Vector3.zero;

		private Vector3 rightCircleCenter;

		private Vector3 leftCircleCenter;

		private double vaRight;

		private double vaLeft;

		private double preVaLeft;

		private double preVaRight;

		private double gammaLeft;

		private double gammaRight;

		private double betaRightRight;

		private double betaRightLeft;

		private double betaLeftRight;

		private double betaLeftLeft;

		private double deltaRightLeft;

		private double deltaLeftRight;

		private double alfaRightRight;

		private double alfaLeftLeft;

		private double alfaRightLeft;

		private double alfaLeftRight;

		public MaxTurn()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		}

		public override void OnTangentUpdate()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			//IL_0039: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Unknown result type (might be due to invalid IL or missing references)
			//IL_0046: Unknown result type (might be due to invalid IL or missing references)
			//IL_004b: Unknown result type (might be due to invalid IL or missing references)
			rightCircleCenter = TurnConstructor.current + TurnConstructor.normal * TurnConstructor.turningRadius;
			leftCircleCenter = TurnConstructor.current - TurnConstructor.normal * TurnConstructor.turningRadius;
			vaRight = Atan2(TurnConstructor.current - rightCircleCenter);
			vaLeft = vaRight + Math.PI;
		}

		public override void Prepare(int i, Vector3[] vectorPath)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0013: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0038: Unknown result type (might be due to invalid IL or missing references)
			//IL_003d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_004c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Unknown result type (might be due to invalid IL or missing references)
			//IL_0070: Unknown result type (might be due to invalid IL or missing references)
			//IL_0076: Unknown result type (might be due to invalid IL or missing references)
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			preRightCircleCenter = rightCircleCenter;
			preLeftCircleCenter = leftCircleCenter;
			rightCircleCenter = TurnConstructor.current + TurnConstructor.normal * TurnConstructor.turningRadius;
			leftCircleCenter = TurnConstructor.current - TurnConstructor.normal * TurnConstructor.turningRadius;
			preVaRight = vaRight;
			preVaLeft = vaLeft;
			vaRight = Atan2(TurnConstructor.current - rightCircleCenter);
			vaLeft = vaRight + Math.PI;
		}

		public override void TangentToTangent(List<Turn> turnList)
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_003d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_005a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0060: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_0075: Unknown result type (might be due to invalid IL or missing references)
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_0085: Unknown result type (might be due to invalid IL or missing references)
			//IL_0090: Unknown result type (might be due to invalid IL or missing references)
			//IL_0096: Unknown result type (might be due to invalid IL or missing references)
			//IL_009b: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_02f5: Unknown result type (might be due to invalid IL or missing references)
			//IL_02ff: Unknown result type (might be due to invalid IL or missing references)
			//IL_0305: Unknown result type (might be due to invalid IL or missing references)
			//IL_030a: Unknown result type (might be due to invalid IL or missing references)
			//IL_030f: Unknown result type (might be due to invalid IL or missing references)
			//IL_031f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0329: Unknown result type (might be due to invalid IL or missing references)
			//IL_032f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0334: Unknown result type (might be due to invalid IL or missing references)
			//IL_0339: Unknown result type (might be due to invalid IL or missing references)
			//IL_0349: Unknown result type (might be due to invalid IL or missing references)
			//IL_0353: Unknown result type (might be due to invalid IL or missing references)
			//IL_0359: Unknown result type (might be due to invalid IL or missing references)
			//IL_035e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0363: Unknown result type (might be due to invalid IL or missing references)
			//IL_0376: Unknown result type (might be due to invalid IL or missing references)
			//IL_0380: Unknown result type (might be due to invalid IL or missing references)
			//IL_0386: Unknown result type (might be due to invalid IL or missing references)
			//IL_038b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0390: Unknown result type (might be due to invalid IL or missing references)
			//IL_03a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_03ad: Unknown result type (might be due to invalid IL or missing references)
			//IL_03b3: Unknown result type (might be due to invalid IL or missing references)
			//IL_03b8: Unknown result type (might be due to invalid IL or missing references)
			//IL_03bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_03d7: Unknown result type (might be due to invalid IL or missing references)
			//IL_03e1: Unknown result type (might be due to invalid IL or missing references)
			//IL_03e7: Unknown result type (might be due to invalid IL or missing references)
			//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
			//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
			//IL_040b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0415: Unknown result type (might be due to invalid IL or missing references)
			//IL_041b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0420: Unknown result type (might be due to invalid IL or missing references)
			//IL_0425: Unknown result type (might be due to invalid IL or missing references)
			//IL_0438: Unknown result type (might be due to invalid IL or missing references)
			//IL_0442: Unknown result type (might be due to invalid IL or missing references)
			//IL_0448: Unknown result type (might be due to invalid IL or missing references)
			//IL_044d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0452: Unknown result type (might be due to invalid IL or missing references)
			//IL_045b: Unknown result type (might be due to invalid IL or missing references)
			//IL_045d: Unknown result type (might be due to invalid IL or missing references)
			//IL_045f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0464: Unknown result type (might be due to invalid IL or missing references)
			//IL_047b: Unknown result type (might be due to invalid IL or missing references)
			//IL_047d: Unknown result type (might be due to invalid IL or missing references)
			//IL_047f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0484: Unknown result type (might be due to invalid IL or missing references)
			//IL_049b: Unknown result type (might be due to invalid IL or missing references)
			//IL_049d: Unknown result type (might be due to invalid IL or missing references)
			//IL_049f: Unknown result type (might be due to invalid IL or missing references)
			//IL_04a4: Unknown result type (might be due to invalid IL or missing references)
			//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
			//IL_04bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_04bf: Unknown result type (might be due to invalid IL or missing references)
			//IL_04c4: Unknown result type (might be due to invalid IL or missing references)
			alfaRightRight = Atan2(rightCircleCenter - preRightCircleCenter);
			alfaLeftLeft = Atan2(leftCircleCenter - preLeftCircleCenter);
			alfaRightLeft = Atan2(leftCircleCenter - preRightCircleCenter);
			alfaLeftRight = Atan2(rightCircleCenter - preLeftCircleCenter);
			Vector3 val = leftCircleCenter - preRightCircleCenter;
			double num = val.magnitude;
			Vector3 val2 = rightCircleCenter - preLeftCircleCenter;
			double num2 = val2.magnitude;
			bool flag = false;
			bool flag2 = false;
			if (num < (double)(TurnConstructor.turningRadius * 2f))
			{
				num = TurnConstructor.turningRadius * 2f;
				flag = true;
			}
			if (num2 < (double)(TurnConstructor.turningRadius * 2f))
			{
				num2 = TurnConstructor.turningRadius * 2f;
				flag2 = true;
			}
			deltaRightLeft = ((!flag) ? (Math.PI / 2.0 - Math.Asin((double)(TurnConstructor.turningRadius * 2f) / num)) : 0.0);
			deltaLeftRight = ((!flag2) ? (Math.PI / 2.0 - Math.Asin((double)(TurnConstructor.turningRadius * 2f) / num2)) : 0.0);
			betaRightRight = ClockwiseAngle(preVaRight, alfaRightRight - Math.PI / 2.0);
			betaRightLeft = ClockwiseAngle(preVaRight, alfaRightLeft - deltaRightLeft);
			betaLeftRight = CounterClockwiseAngle(preVaLeft, alfaLeftRight + deltaLeftRight);
			betaLeftLeft = CounterClockwiseAngle(preVaLeft, alfaLeftLeft + Math.PI / 2.0);
			betaRightRight += ClockwiseAngle(alfaRightRight - Math.PI / 2.0, vaRight);
			betaRightLeft += CounterClockwiseAngle(alfaRightLeft + deltaRightLeft, vaLeft);
			betaLeftRight += ClockwiseAngle(alfaLeftRight - deltaLeftRight, vaRight);
			betaLeftLeft += CounterClockwiseAngle(alfaLeftLeft + Math.PI / 2.0, vaLeft);
			betaRightRight = GetLengthFromAngle(betaRightRight, TurnConstructor.turningRadius);
			betaRightLeft = GetLengthFromAngle(betaRightLeft, TurnConstructor.turningRadius);
			betaLeftRight = GetLengthFromAngle(betaLeftRight, TurnConstructor.turningRadius);
			betaLeftLeft = GetLengthFromAngle(betaLeftLeft, TurnConstructor.turningRadius);
			Vector3 val3 = AngleToVector(alfaRightRight - Math.PI / 2.0) * TurnConstructor.turningRadius + preRightCircleCenter;
			Vector3 val4 = AngleToVector(alfaRightLeft - deltaRightLeft) * TurnConstructor.turningRadius + preRightCircleCenter;
			Vector3 val5 = AngleToVector(alfaLeftRight + deltaLeftRight) * TurnConstructor.turningRadius + preLeftCircleCenter;
			Vector3 val6 = AngleToVector(alfaLeftLeft + Math.PI / 2.0) * TurnConstructor.turningRadius + preLeftCircleCenter;
			Vector3 val7 = AngleToVector(alfaRightRight - Math.PI / 2.0) * TurnConstructor.turningRadius + rightCircleCenter;
			Vector3 val8 = AngleToVector(alfaRightLeft - deltaRightLeft + Math.PI) * TurnConstructor.turningRadius + leftCircleCenter;
			Vector3 val9 = AngleToVector(alfaLeftRight + deltaLeftRight + Math.PI) * TurnConstructor.turningRadius + rightCircleCenter;
			Vector3 val10 = AngleToVector(alfaLeftLeft + Math.PI / 2.0) * TurnConstructor.turningRadius + leftCircleCenter;
			double num3 = betaRightRight;
			Vector3 val11 = val3 - val7;
			betaRightRight = num3 + (double)val11.magnitude;
			double num4 = betaRightLeft;
			Vector3 val12 = val4 - val8;
			betaRightLeft = num4 + (double)val12.magnitude;
			double num5 = betaLeftRight;
			Vector3 val13 = val5 - val9;
			betaLeftRight = num5 + (double)val13.magnitude;
			double num6 = betaLeftLeft;
			Vector3 val14 = val6 - val10;
			betaLeftLeft = num6 + (double)val14.magnitude;
			if (flag)
			{
				betaRightLeft += 10000000.0;
			}
			if (flag2)
			{
				betaLeftRight += 10000000.0;
			}
			turnList.Add(new Turn((float)betaRightRight, this, 2));
			turnList.Add(new Turn((float)betaRightLeft, this, 3));
			turnList.Add(new Turn((float)betaLeftRight, this, 4));
			turnList.Add(new Turn((float)betaLeftLeft, this, 5));
		}

		public override void PointToTangent(List<Turn> turnList)
		{
			//IL_0004: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0068: Unknown result type (might be due to invalid IL or missing references)
			//IL_006e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0073: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
			//IL_010c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0112: Unknown result type (might be due to invalid IL or missing references)
			//IL_0117: Unknown result type (might be due to invalid IL or missing references)
			//IL_0145: Unknown result type (might be due to invalid IL or missing references)
			//IL_014b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0150: Unknown result type (might be due to invalid IL or missing references)
			//IL_0155: Unknown result type (might be due to invalid IL or missing references)
			bool flag = false;
			bool flag2 = false;
			Vector3 val = TurnConstructor.prev - rightCircleCenter;
			float magnitude = val.magnitude;
			Vector3 val2 = TurnConstructor.prev - leftCircleCenter;
			float magnitude2 = val2.magnitude;
			if (magnitude < TurnConstructor.turningRadius)
			{
				flag = true;
			}
			if (magnitude2 < TurnConstructor.turningRadius)
			{
				flag2 = true;
			}
			double num = ((!flag) ? Atan2(TurnConstructor.prev - rightCircleCenter) : 0.0);
			double num2;
			if (flag)
			{
				num2 = 0.0;
			}
			else
			{
				float num3 = TurnConstructor.turningRadius;
				Vector3 val3 = TurnConstructor.prev - rightCircleCenter;
				num2 = Math.PI / 2.0 - Math.Asin(num3 / val3.magnitude);
			}
			double num4 = num2;
			gammaRight = num + num4;
			double num5 = ((!flag) ? ClockwiseAngle(gammaRight, vaRight) : 0.0);
			double num6 = ((!flag2) ? Atan2(TurnConstructor.prev - leftCircleCenter) : 0.0);
			double num7;
			if (flag2)
			{
				num7 = 0.0;
			}
			else
			{
				float num8 = TurnConstructor.turningRadius;
				Vector3 val4 = TurnConstructor.prev - leftCircleCenter;
				num7 = Math.PI / 2.0 - Math.Asin(num8 / val4.magnitude);
			}
			double num9 = num7;
			gammaLeft = num6 - num9;
			double num10 = ((!flag2) ? CounterClockwiseAngle(gammaLeft, vaLeft) : 0.0);
			if (!flag)
			{
				turnList.Add(new Turn((float)num5, this));
			}
			if (!flag2)
			{
				turnList.Add(new Turn((float)num10, this, 1));
			}
		}

		public override void TangentToPoint(List<Turn> turnList)
		{
			//IL_0004: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_005a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0060: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
			bool flag = false;
			bool flag2 = false;
			Vector3 val = TurnConstructor.next - rightCircleCenter;
			float magnitude = val.magnitude;
			Vector3 val2 = TurnConstructor.next - leftCircleCenter;
			float magnitude2 = val2.magnitude;
			if (magnitude < TurnConstructor.turningRadius)
			{
				flag = true;
			}
			if (magnitude2 < TurnConstructor.turningRadius)
			{
				flag2 = true;
			}
			if (!flag)
			{
				double num = Atan2(TurnConstructor.next - rightCircleCenter);
				double num2 = Math.PI / 2.0 - Math.Asin(TurnConstructor.turningRadius / magnitude);
				gammaRight = num - num2;
				double num3 = ClockwiseAngle(vaRight, gammaRight);
				turnList.Add(new Turn((float)num3, this, 6));
			}
			if (!flag2)
			{
				double num4 = Atan2(TurnConstructor.next - leftCircleCenter);
				double num5 = Math.PI / 2.0 - Math.Asin(TurnConstructor.turningRadius / magnitude2);
				gammaLeft = num4 + num5;
				double num6 = CounterClockwiseAngle(vaLeft, gammaLeft);
				turnList.Add(new Turn((float)num6, this, 7));
			}
		}

		public override void GetPath(Turn turn, List<Vector3> output)
		{
			//IL_0042: Unknown result type (might be due to invalid IL or missing references)
			//IL_0066: Unknown result type (might be due to invalid IL or missing references)
			//IL_0094: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0118: Unknown result type (might be due to invalid IL or missing references)
			//IL_0143: Unknown result type (might be due to invalid IL or missing references)
			//IL_0173: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
			//IL_0212: Unknown result type (might be due to invalid IL or missing references)
			switch (turn.id)
			{
			case 0:
				AddCircleSegment(gammaRight, vaRight, clockwise: true, rightCircleCenter, output, TurnConstructor.turningRadius);
				break;
			case 1:
				AddCircleSegment(gammaLeft, vaLeft, clockwise: false, leftCircleCenter, output, TurnConstructor.turningRadius);
				break;
			case 2:
				AddCircleSegment(preVaRight, alfaRightRight - Math.PI / 2.0, clockwise: true, preRightCircleCenter, output, TurnConstructor.turningRadius);
				AddCircleSegment(alfaRightRight - Math.PI / 2.0, vaRight, clockwise: true, rightCircleCenter, output, TurnConstructor.turningRadius);
				break;
			case 3:
				AddCircleSegment(preVaRight, alfaRightLeft - deltaRightLeft, clockwise: true, preRightCircleCenter, output, TurnConstructor.turningRadius);
				AddCircleSegment(alfaRightLeft - deltaRightLeft + Math.PI, vaLeft, clockwise: false, leftCircleCenter, output, TurnConstructor.turningRadius);
				break;
			case 4:
				AddCircleSegment(preVaLeft, alfaLeftRight + deltaLeftRight, clockwise: false, preLeftCircleCenter, output, TurnConstructor.turningRadius);
				AddCircleSegment(alfaLeftRight + deltaLeftRight + Math.PI, vaRight, clockwise: true, rightCircleCenter, output, TurnConstructor.turningRadius);
				break;
			case 5:
				AddCircleSegment(preVaLeft, alfaLeftLeft + Math.PI / 2.0, clockwise: false, preLeftCircleCenter, output, TurnConstructor.turningRadius);
				AddCircleSegment(alfaLeftLeft + Math.PI / 2.0, vaLeft, clockwise: false, leftCircleCenter, output, TurnConstructor.turningRadius);
				break;
			case 6:
				AddCircleSegment(vaRight, gammaRight, clockwise: true, rightCircleCenter, output, TurnConstructor.turningRadius);
				break;
			case 7:
				AddCircleSegment(vaLeft, gammaLeft, clockwise: false, leftCircleCenter, output, TurnConstructor.turningRadius);
				break;
			}
		}
	}

	[Serializable]
	public class ConstantTurn : TurnConstructor
	{
		private Vector3 circleCenter;

		private double gamma1;

		private double gamma2;

		private bool clockwise;

		public override void Prepare(int i, Vector3[] vectorPath)
		{
		}

		public override void TangentToTangent(List<Turn> turnList)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0030: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0049: Unknown result type (might be due to invalid IL or missing references)
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Unknown result type (might be due to invalid IL or missing references)
			//IL_0060: Unknown result type (might be due to invalid IL or missing references)
			//IL_0066: Unknown result type (might be due to invalid IL or missing references)
			//IL_006b: Unknown result type (might be due to invalid IL or missing references)
			//IL_007c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_0087: Unknown result type (might be due to invalid IL or missing references)
			//IL_0098: Unknown result type (might be due to invalid IL or missing references)
			//IL_009d: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
			//IL_0102: Unknown result type (might be due to invalid IL or missing references)
			//IL_0107: Unknown result type (might be due to invalid IL or missing references)
			Vector3 dir = Vector3.Cross(TurnConstructor.t1, Vector3.up);
			Vector3 val = TurnConstructor.current - TurnConstructor.prev;
			Vector3 start = val * 0.5f + TurnConstructor.prev;
			val = Vector3.Cross(val, Vector3.up);
			circleCenter = VectorMath.LineDirIntersectionPointXZ(TurnConstructor.prev, dir, start, val, out var intersects);
			if (intersects)
			{
				gamma1 = Atan2(TurnConstructor.prev - circleCenter);
				gamma2 = Atan2(TurnConstructor.current - circleCenter);
				clockwise = !VectorMath.RightOrColinearXZ(circleCenter, TurnConstructor.prev, TurnConstructor.prev + TurnConstructor.t1);
				double num = ((!clockwise) ? CounterClockwiseAngle(gamma1, gamma2) : ClockwiseAngle(gamma1, gamma2));
				double angle = num;
				Vector3 val2 = circleCenter - TurnConstructor.current;
				num = GetLengthFromAngle(angle, val2.magnitude);
				turnList.Add(new Turn((float)num, this));
			}
		}

		public override void GetPath(Turn turn, List<Vector3> output)
		{
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			//IL_001b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Unknown result type (might be due to invalid IL or missing references)
			//IL_003d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0042: Unknown result type (might be due to invalid IL or missing references)
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_004f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Unknown result type (might be due to invalid IL or missing references)
			//IL_0066: Unknown result type (might be due to invalid IL or missing references)
			//IL_006b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0070: Unknown result type (might be due to invalid IL or missing references)
			//IL_0075: Unknown result type (might be due to invalid IL or missing references)
			//IL_007a: Unknown result type (might be due to invalid IL or missing references)
			//IL_008a: Unknown result type (might be due to invalid IL or missing references)
			//IL_008f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0094: Unknown result type (might be due to invalid IL or missing references)
			//IL_0099: Unknown result type (might be due to invalid IL or missing references)
			//IL_009e: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
			double startAngle = gamma1;
			double endAngle = gamma2;
			bool flag = clockwise;
			Vector3 center = circleCenter;
			Vector3 val = circleCenter - TurnConstructor.current;
			AddCircleSegment(startAngle, endAngle, flag, center, output, val.magnitude);
			Vector3 val2 = TurnConstructor.current - circleCenter;
			TurnConstructor.normal = val2.normalized;
			Vector3 val3 = Vector3.Cross(TurnConstructor.normal, Vector3.up);
			TurnConstructor.t2 = val3.normalized;
			TurnConstructor.normal = -TurnConstructor.normal;
			if (!clockwise)
			{
				TurnConstructor.t2 = -TurnConstructor.t2;
				TurnConstructor.normal = -TurnConstructor.normal;
			}
			TurnConstructor.changedPreviousTangent = true;
		}
	}

	public abstract class TurnConstructor
	{
		public float constantBias;

		public float factorBias = 1f;

		public static float turningRadius = 1f;

		public const double ThreeSixtyRadians = Math.PI * 2.0;

		public static Vector3 prev;

		public static Vector3 current;

		public static Vector3 next;

		public static Vector3 t1;

		public static Vector3 t2;

		public static Vector3 normal;

		public static Vector3 prevNormal;

		public static bool changedPreviousTangent;

		public abstract void Prepare(int i, Vector3[] vectorPath);

		public virtual void OnTangentUpdate()
		{
		}

		public virtual void PointToTangent(List<Turn> turnList)
		{
		}

		public virtual void TangentToPoint(List<Turn> turnList)
		{
		}

		public virtual void TangentToTangent(List<Turn> turnList)
		{
		}

		public abstract void GetPath(Turn turn, List<Vector3> output);

		public static void Setup(int i, Vector3[] vectorPath)
		{
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_005f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_006e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0073: Unknown result type (might be due to invalid IL or missing references)
			//IL_0078: Unknown result type (might be due to invalid IL or missing references)
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_0085: Unknown result type (might be due to invalid IL or missing references)
			//IL_008a: Unknown result type (might be due to invalid IL or missing references)
			//IL_008f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0092: Unknown result type (might be due to invalid IL or missing references)
			//IL_0097: Unknown result type (might be due to invalid IL or missing references)
			//IL_009c: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
			current = vectorPath[i];
			prev = vectorPath[i - 1];
			next = vectorPath[i + 1];
			prev.y = current.y;
			next.y = current.y;
			t1 = t2;
			Vector3 val = next - current;
			Vector3 normalized = val.normalized;
			Vector3 val2 = prev - current;
			t2 = normalized - val2.normalized;
			t2 = t2.normalized;
			prevNormal = normal;
			normal = Vector3.Cross(t2, Vector3.up);
			normal = normal.normalized;
		}

		public static void PostPrepare()
		{
			changedPreviousTangent = false;
		}

		public void AddCircleSegment(double startAngle, double endAngle, bool clockwise, Vector3 center, List<Vector3> output, float radius)
		{
			//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00df: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
			//IL_0104: Unknown result type (might be due to invalid IL or missing references)
			//IL_0106: Unknown result type (might be due to invalid IL or missing references)
			//IL_009e: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
			double num = Math.PI / 50.0;
			if (clockwise)
			{
				while (endAngle > startAngle + Math.PI * 2.0)
				{
					endAngle -= Math.PI * 2.0;
				}
				while (endAngle < startAngle)
				{
					endAngle += Math.PI * 2.0;
				}
			}
			else
			{
				while (endAngle < startAngle - Math.PI * 2.0)
				{
					endAngle += Math.PI * 2.0;
				}
				while (endAngle > startAngle)
				{
					endAngle -= Math.PI * 2.0;
				}
			}
			if (clockwise)
			{
				for (double num2 = startAngle; num2 < endAngle; num2 += num)
				{
					output.Add(AngleToVector(num2) * radius + center);
				}
			}
			else
			{
				for (double num3 = startAngle; num3 > endAngle; num3 -= num)
				{
					output.Add(AngleToVector(num3) * radius + center);
				}
			}
			output.Add(AngleToVector(endAngle) * radius + center);
		}

		public void DebugCircleSegment(Vector3 center, double startAngle, double endAngle, double radius, Color color)
		{
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			//IL_0038: Unknown result type (might be due to invalid IL or missing references)
			//IL_0042: Unknown result type (might be due to invalid IL or missing references)
			//IL_0045: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Unknown result type (might be due to invalid IL or missing references)
			//IL_0053: Unknown result type (might be due to invalid IL or missing references)
			//IL_0068: Unknown result type (might be due to invalid IL or missing references)
			//IL_006b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0073: Unknown result type (might be due to invalid IL or missing references)
			//IL_0078: Unknown result type (might be due to invalid IL or missing references)
			//IL_0079: Unknown result type (might be due to invalid IL or missing references)
			double num = Math.PI / 50.0;
			while (endAngle < startAngle)
			{
				endAngle += Math.PI * 2.0;
			}
			Vector3 val = AngleToVector(startAngle) * (float)radius + center;
			for (double num2 = startAngle + num; num2 < endAngle; num2 += num)
			{
				Debug.DrawLine(val, AngleToVector(num2) * (float)radius + center);
			}
			Debug.DrawLine(val, AngleToVector(endAngle) * (float)radius + center);
		}

		public void DebugCircle(Vector3 center, double radius, Color color)
		{
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0031: Unknown result type (might be due to invalid IL or missing references)
			//IL_0038: Unknown result type (might be due to invalid IL or missing references)
			//IL_003d: Unknown result type (might be due to invalid IL or missing references)
			//IL_003e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			//IL_0045: Unknown result type (might be due to invalid IL or missing references)
			//IL_0046: Unknown result type (might be due to invalid IL or missing references)
			//IL_004c: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Unknown result type (might be due to invalid IL or missing references)
			double num = Math.PI / 50.0;
			Vector3 val = AngleToVector(0.0 - num) * (float)radius + center;
			for (double num2 = 0.0; num2 < Math.PI * 2.0; num2 += num)
			{
				Vector3 val2 = AngleToVector(num2) * (float)radius + center;
				Debug.DrawLine(val, val2, color);
				val = val2;
			}
		}

		public double GetLengthFromAngle(double angle, double radius)
		{
			return radius * angle;
		}

		public double ClockwiseAngle(double from, double to)
		{
			return ClampAngle(to - from);
		}

		public double CounterClockwiseAngle(double from, double to)
		{
			return ClampAngle(from - to);
		}

		public Vector3 AngleToVector(double a)
		{
			//IL_0013: Unknown result type (might be due to invalid IL or missing references)
			return new Vector3((float)Math.Cos(a), 0f, (float)Math.Sin(a));
		}

		public double ToDegrees(double rad)
		{
			return rad * 57.295780181884766;
		}

		public double ClampAngle(double a)
		{
			while (a < 0.0)
			{
				a += Math.PI * 2.0;
			}
			while (a > Math.PI * 2.0)
			{
				a -= Math.PI * 2.0;
			}
			return a;
		}

		public double Atan2(Vector3 v)
		{
			return Math.Atan2(v.z, v.x);
		}
	}

	public struct Turn(float length, TurnConstructor constructor, int id = 0) : IComparable<Turn>
	{
		public float length = length;

		public int id = id;

		public TurnConstructor constructor = constructor;

		public float score => length * constructor.factorBias + constructor.constantBias;

		public void GetPath(List<Vector3> output)
		{
			constructor.GetPath(this, output);
		}

		public int CompareTo(Turn t)
		{
			return (t.score > score) ? (-1) : ((t.score < score) ? 1 : 0);
		}

		public static bool operator <(Turn lhs, Turn rhs)
		{
			return lhs.score < rhs.score;
		}

		public static bool operator >(Turn lhs, Turn rhs)
		{
			return lhs.score > rhs.score;
		}
	}

	public float turningRadius = 1f;

	public MaxTurn turnConstruct1 = new MaxTurn();

	public ConstantTurn turnConstruct2 = new ConstantTurn();

	public override int Order => 40;

	public override void Apply(Path p)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		Vector3[] array = p.vectorPath.ToArray();
		if (array == null || array.Length <= 2)
		{
			return;
		}
		List<Vector3> list = new List<Vector3>();
		list.Add(array[0]);
		TurnConstructor.turningRadius = turningRadius;
		for (int i = 1; i < array.Length - 1; i++)
		{
			List<Turn> turnList = new List<Turn>();
			TurnConstructor.Setup(i, array);
			turnConstruct1.Prepare(i, array);
			turnConstruct2.Prepare(i, array);
			TurnConstructor.PostPrepare();
			if (i == 1)
			{
				turnConstruct1.PointToTangent(turnList);
				turnConstruct2.PointToTangent(turnList);
			}
			else
			{
				turnConstruct1.TangentToTangent(turnList);
				turnConstruct2.TangentToTangent(turnList);
			}
			EvaluatePaths(turnList, list);
			if (i == array.Length - 2)
			{
				turnConstruct1.TangentToPoint(turnList);
				turnConstruct2.TangentToPoint(turnList);
			}
			EvaluatePaths(turnList, list);
		}
		list.Add(array[^1]);
		p.vectorPath = list;
	}

	private void EvaluatePaths(List<Turn> turnList, List<Vector3> output)
	{
		turnList.Sort();
		for (int i = 0; i < turnList.Count; i++)
		{
			if (i == 0)
			{
				turnList[i].GetPath(output);
			}
		}
		turnList.Clear();
		if (TurnConstructor.changedPreviousTangent)
		{
			turnConstruct1.OnTangentUpdate();
			turnConstruct2.OnTangentUpdate();
		}
	}
}
