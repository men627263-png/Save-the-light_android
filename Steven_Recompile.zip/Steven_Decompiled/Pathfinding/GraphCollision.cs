using System;
using System.Collections.Generic;
using Pathfinding.Serialization;
using UnityEngine;

namespace Pathfinding;

[Serializable]
public class GraphCollision
{
	public ColliderType type = ColliderType.Capsule;

	public float diameter = 1f;

	public float height = 2f;

	public float collisionOffset;

	public RayDirection rayDirection = RayDirection.Both;

	public LayerMask mask;

	public LayerMask heightMask = LayerMask.op_Implicit(-1);

	public float fromHeight = 100f;

	public bool thickRaycast;

	public float thickRaycastDiameter = 1f;

	public bool unwalkableWhenNoGround = true;

	public bool use2D;

	public bool collisionCheck = true;

	public bool heightCheck = true;

	public Vector3 up;

	private Vector3 upheight;

	private float finalRadius;

	private float finalRaycastRadius;

	public const float RaycastErrorMargin = 0.005f;

	public GraphCollision()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
	}

	public void Initialize(Matrix4x4 matrix, float scale)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		up = matrix.MultiplyVector(Vector3.up);
		upheight = up * height;
		finalRadius = diameter * scale * 0.5f;
		finalRaycastRadius = thickRaycastDiameter * scale * 0.5f;
	}

	public bool Check(Vector3 position)
	{
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		if (!collisionCheck)
		{
			return true;
		}
		if (use2D)
		{
			return type switch
			{
				ColliderType.Capsule => throw new Exception("Capsule mode cannot be used with 2D since capsules don't exist in 2D. Please change the Physics Testing -> Collider Type setting."), 
				ColliderType.Sphere => (Object)(object)Physics2D.OverlapCircle(Vector2.op_Implicit(position), finalRadius, LayerMask.op_Implicit(mask)) == (Object)null, 
				_ => (Object)(object)Physics2D.OverlapPoint(Vector2.op_Implicit(position), LayerMask.op_Implicit(mask)) == (Object)null, 
			};
		}
		position += up * collisionOffset;
		return type switch
		{
			ColliderType.Capsule => !Physics.CheckCapsule(position, position + upheight, finalRadius, LayerMask.op_Implicit(mask)), 
			ColliderType.Sphere => !Physics.CheckSphere(position, finalRadius, LayerMask.op_Implicit(mask)), 
			_ => rayDirection switch
			{
				RayDirection.Both => !Physics.Raycast(position, up, height, LayerMask.op_Implicit(mask)) && !Physics.Raycast(position + upheight, -up, height, LayerMask.op_Implicit(mask)), 
				RayDirection.Up => !Physics.Raycast(position, up, height, LayerMask.op_Implicit(mask)), 
				_ => !Physics.Raycast(position + upheight, -up, height, LayerMask.op_Implicit(mask)), 
			}, 
		};
	}

	public Vector3 CheckHeight(Vector3 position)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit hit;
		bool walkable;
		return CheckHeight(position, out hit, out walkable);
	}

	public Vector3 CheckHeight(Vector3 position, out RaycastHit hit, out bool walkable)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		walkable = true;
		if (!heightCheck || use2D)
		{
			hit = default;
			return position;
		}
		if (thickRaycast)
		{
			Ray val = new Ray(position + up * fromHeight, -up);
			if (Physics.SphereCast(val, finalRaycastRadius, ref hit, fromHeight + 0.005f, LayerMask.op_Implicit(heightMask)))
			{
				return VectorMath.ClosestPointOnLine(val.origin, val.origin + val.direction, hit.point);
			}
			walkable &= !unwalkableWhenNoGround;
		}
		else
		{
			if (Physics.Raycast(position + up * fromHeight, -up, ref hit, fromHeight + 0.005f, LayerMask.op_Implicit(heightMask)))
			{
				return hit.point;
			}
			walkable &= !unwalkableWhenNoGround;
		}
		return position;
	}

	public Vector3 Raycast(Vector3 origin, out RaycastHit hit, out bool walkable)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		walkable = true;
		if (!heightCheck || use2D)
		{
			hit = default;
			return origin - up * fromHeight;
		}
		if (thickRaycast)
		{
			Ray val = new Ray(origin, -up);
			if (Physics.SphereCast(val, finalRaycastRadius, ref hit, fromHeight + 0.005f, LayerMask.op_Implicit(heightMask)))
			{
				return VectorMath.ClosestPointOnLine(val.origin, val.origin + val.direction, hit.point);
			}
			walkable &= !unwalkableWhenNoGround;
		}
		else
		{
			if (Physics.Raycast(origin, -up, ref hit, fromHeight + 0.005f, LayerMask.op_Implicit(heightMask)))
			{
				return hit.point;
			}
			walkable &= !unwalkableWhenNoGround;
		}
		return origin - up * fromHeight;
	}

	public RaycastHit[] CheckHeightAll(Vector3 position)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		if (!heightCheck || use2D)
		{
			RaycastHit val = default;
			val.point = position;
			val.distance = 0f;
			return new RaycastHit[1] { val };
		}
		if (thickRaycast)
		{
			return new RaycastHit[0];
		}
		List<RaycastHit> list = new List<RaycastHit>();
		Vector3 val2 = position + up * fromHeight;
		Vector3 val3 = Vector3.zero;
		int num = 0;
		while (true)
		{
			Raycast(val2, out var hit, out var _);
			if ((Object)(object)hit.transform == (Object)null)
			{
				break;
			}
			if (hit.point != val3 || list.Count == 0)
			{
				val2 = hit.point - up * 0.005f;
				val3 = hit.point;
				num = 0;
				list.Add(hit);
				continue;
			}
			val2 -= up * 0.001f;
			num++;
			if (num <= 10)
			{
				continue;
			}
			Debug.LogError((object)string.Concat(new object[4] { "Infinite Loop when raycasting. Please report this error (arongranberg.com)\n", val2, " : ", val3 }));
			break;
		}
		return list.ToArray();
	}

	public void SerializeSettings(GraphSerializationContext ctx)
	{
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		ctx.writer.Write((int)type);
		ctx.writer.Write(diameter);
		ctx.writer.Write(height);
		ctx.writer.Write(collisionOffset);
		ctx.writer.Write((int)rayDirection);
		ctx.writer.Write(LayerMask.op_Implicit(mask));
		ctx.writer.Write(LayerMask.op_Implicit(heightMask));
		ctx.writer.Write(fromHeight);
		ctx.writer.Write(thickRaycast);
		ctx.writer.Write(thickRaycastDiameter);
		ctx.writer.Write(unwalkableWhenNoGround);
		ctx.writer.Write(use2D);
		ctx.writer.Write(collisionCheck);
		ctx.writer.Write(heightCheck);
	}

	public void DeserializeSettings(GraphSerializationContext ctx)
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		type = (ColliderType)ctx.reader.ReadInt32();
		diameter = ctx.reader.ReadSingle();
		height = ctx.reader.ReadSingle();
		collisionOffset = ctx.reader.ReadSingle();
		rayDirection = (RayDirection)ctx.reader.ReadInt32();
		mask = LayerMask.op_Implicit(ctx.reader.ReadInt32());
		heightMask = LayerMask.op_Implicit(ctx.reader.ReadInt32());
		fromHeight = ctx.reader.ReadSingle();
		thickRaycast = ctx.reader.ReadBoolean();
		thickRaycastDiameter = ctx.reader.ReadSingle();
		unwalkableWhenNoGround = ctx.reader.ReadBoolean();
		use2D = ctx.reader.ReadBoolean();
		collisionCheck = ctx.reader.ReadBoolean();
		heightCheck = ctx.reader.ReadBoolean();
	}
}
