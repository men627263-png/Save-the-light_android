using System;
using System.Collections.Generic;
using UnityEngine;

namespace Pathfinding;

[AddComponentMenu("Pathfinding/Navmesh/RecastMeshObj")]
[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_recast_mesh_obj.php")]
public class RecastMeshObj : MonoBehaviour
{
	protected static RecastBBTree tree = new RecastBBTree();

	protected static List<RecastMeshObj> dynamicMeshObjs = new List<RecastMeshObj>();

	[HideInInspector]
	public Bounds bounds;

	public bool dynamic = true;

	public int area;

	private bool _dynamic;

	private bool registered;

	public static void GetAllInBounds(List<RecastMeshObj> buffer, Bounds bounds)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		if (!Application.isPlaying)
		{
			RecastMeshObj[] array = Object.FindObjectsOfType(typeof(RecastMeshObj)) as RecastMeshObj[];
			for (int i = 0; i < array.Length; i++)
			{
				array[i].RecalculateBounds();
				Bounds val = array[i].GetBounds();
				if (val.Intersects(bounds))
				{
					buffer.Add(array[i]);
				}
			}
			return;
		}
		if (Time.timeSinceLevelLoad == 0f)
		{
			RecastMeshObj[] array2 = Object.FindObjectsOfType(typeof(RecastMeshObj)) as RecastMeshObj[];
			for (int j = 0; j < array2.Length; j++)
			{
				array2[j].Register();
			}
		}
		for (int k = 0; k < dynamicMeshObjs.Count; k++)
		{
			Bounds val2 = dynamicMeshObjs[k].GetBounds();
			if (val2.Intersects(bounds))
			{
				buffer.Add(dynamicMeshObjs[k]);
			}
		}
		Rect val3 = Rect.MinMaxRect(bounds.min.x, bounds.min.z, bounds.max.x, bounds.max.z);
		tree.QueryInBounds(val3, buffer);
	}

	private void OnEnable()
	{
		Register();
	}

	private void Register()
	{
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		if (!registered)
		{
			registered = true;
			area = Mathf.Clamp(area, -1, 33554432);
			Renderer component = ((Component)this).GetComponent<Renderer>();
			Collider component2 = ((Component)this).GetComponent<Collider>();
			if ((Object)(object)component == (Object)null && (Object)(object)component2 == (Object)null)
			{
				throw new Exception("A renderer or a collider should be attached to the GameObject");
			}
			MeshFilter component3 = ((Component)this).GetComponent<MeshFilter>();
			if ((Object)(object)component != (Object)null && (Object)(object)component3 == (Object)null)
			{
				throw new Exception("A renderer was attached but no mesh filter");
			}
			bounds = ((!((Object)(object)component != (Object)null)) ? component2.bounds : component.bounds);
			_dynamic = dynamic;
			if (_dynamic)
			{
				dynamicMeshObjs.Add(this);
			}
			else
			{
				tree.Insert(this);
			}
		}
	}

	private void RecalculateBounds()
	{
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		Renderer component = ((Component)this).GetComponent<Renderer>();
		Collider collider = GetCollider();
		if ((Object)(object)component == (Object)null && (Object)(object)collider == (Object)null)
		{
			throw new Exception("A renderer or a collider should be attached to the GameObject");
		}
		MeshFilter component2 = ((Component)this).GetComponent<MeshFilter>();
		if ((Object)(object)component != (Object)null && (Object)(object)component2 == (Object)null)
		{
			throw new Exception("A renderer was attached but no mesh filter");
		}
		bounds = ((!((Object)(object)component != (Object)null)) ? collider.bounds : component.bounds);
	}

	public Bounds GetBounds()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		if (_dynamic)
		{
			RecalculateBounds();
		}
		return bounds;
	}

	public MeshFilter GetMeshFilter()
	{
		return ((Component)this).GetComponent<MeshFilter>();
	}

	public Collider GetCollider()
	{
		return ((Component)this).GetComponent<Collider>();
	}

	private void OnDisable()
	{
		registered = false;
		if (_dynamic)
		{
			dynamicMeshObjs.Remove(this);
		}
		else if (!tree.Remove(this))
		{
			throw new Exception("Could not remove RecastMeshObj from tree even though it should exist in it. Has the object moved without being marked as dynamic?");
		}
		_dynamic = dynamic;
	}
}
