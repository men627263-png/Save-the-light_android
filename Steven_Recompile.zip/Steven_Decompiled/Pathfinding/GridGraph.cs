using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Pathfinding.Serialization;
using Pathfinding.Serialization.JsonFx;
using Pathfinding.Util;
using UnityEngine;

namespace Pathfinding;

[JsonOptIn]
public class GridGraph : NavGraph, IUpdatableGraph, IRaycastableGraph
{
	public class TextureData
	{
		public enum ChannelUse
		{
			None,
			Penalty,
			Position,
			WalkablePenalty
		}

		public bool enabled;

		public Texture2D source;

		public float[] factors = new float[3];

		public ChannelUse[] channels = new ChannelUse[3];

		private Color32[] data;

		public void Initialize()
		{
			//IL_0047: Expected Obj, but got Unknown
			if (!enabled || !((Object)(object)source != (Object)null))
			{
				return;
			}
			for (int i = 0; i < channels.Length; i++)
			{
				if (channels[i] != ChannelUse.None)
				{
					try
					{
						data = source.GetPixels32();
						break;
					}
					catch (UnityException ex)
					{
						UnityException ex2 = ex;
						Debug.LogWarning((object)((object)ex2).ToString());
						data = null;
						break;
					}
				}
			}
		}

		public void Apply(GridNode node, int x, int z)
		{
			//IL_0052: Unknown result type (might be due to invalid IL or missing references)
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			if (enabled && data != null && x < ((Texture)source).width && z < ((Texture)source).height)
			{
				Color32 val = data[z * ((Texture)source).width + x];
				if (channels[0] != ChannelUse.None)
				{
					ApplyChannel(node, x, z, val.r, channels[0], factors[0]);
				}
				if (channels[1] != ChannelUse.None)
				{
					ApplyChannel(node, x, z, val.g, channels[1], factors[1]);
				}
				if (channels[2] != ChannelUse.None)
				{
					ApplyChannel(node, x, z, val.b, channels[2], factors[2]);
				}
			}
		}

		private void ApplyChannel(GridNode node, int x, int z, int value, ChannelUse channelUse, float factor)
		{
			switch (channelUse)
			{
			case ChannelUse.Penalty:
				node.Penalty += (uint)Mathf.RoundToInt((float)value * factor);
				break;
			case ChannelUse.Position:
				node.position = GridNode.GetGridGraph(node.GraphIndex).GraphPointToWorld(x, z, value);
				break;
			case ChannelUse.WalkablePenalty:
				if (value == 0)
				{
					node.Walkable = false;
				}
				else
				{
					node.Penalty += (uint)Mathf.RoundToInt((float)(value - 1) * factor);
				}
				break;
			}
		}
	}

	public int width;

	public int depth;

	[JsonMember]
	public float aspectRatio = 1f;

	[JsonMember]
	public float isometricAngle;

	[JsonMember]
	public bool uniformEdgeCosts;

	[JsonMember]
	public Vector3 rotation;

	public Bounds bounds;

	[JsonMember]
	public Vector3 center;

	[JsonMember]
	public Vector2 unclampedSize;

	[JsonMember]
	public float nodeSize = 1f;

	[JsonMember]
	public GraphCollision collision;

	[JsonMember]
	public float maxClimb = 0.4f;

	[JsonMember]
	public int maxClimbAxis = 1;

	[JsonMember]
	public float maxSlope = 90f;

	[JsonMember]
	public int erodeIterations;

	[JsonMember]
	public bool erosionUseTags;

	[JsonMember]
	public int erosionFirstTag = 1;

	[JsonMember]
	public bool autoLinkGrids;

	[JsonMember]
	public float autoLinkDistLimit = 10f;

	[JsonMember]
	public NumNeighbours neighbours = NumNeighbours.Eight;

	[JsonMember]
	public bool cutCorners = true;

	[JsonMember]
	public float penaltyPositionOffset;

	[JsonMember]
	public bool penaltyPosition;

	[JsonMember]
	public float penaltyPositionFactor = 1f;

	[JsonMember]
	public bool penaltyAngle;

	[JsonMember]
	public float penaltyAngleFactor = 100f;

	[JsonMember]
	public float penaltyAnglePower = 1f;

	[JsonMember]
	public bool useJumpPointSearch;

	[JsonMember]
	public TextureData textureData = new TextureData();

	[NonSerialized]
	public readonly int[] neighbourOffsets = new int[8];

	[NonSerialized]
	public readonly uint[] neighbourCosts = new uint[8];

	[NonSerialized]
	public readonly int[] neighbourXOffsets = new int[8];

	[NonSerialized]
	public readonly int[] neighbourZOffsets = new int[8];

	internal static readonly int[] hexagonNeighbourIndices = new int[6] { 0, 1, 2, 3, 5, 7 };

	public const int getNearestForceOverlap = 2;

	public GridNode[] nodes;

	public virtual bool uniformWidthDepthGrid => true;

	public bool useRaycastNormal => Math.Abs(90f - maxSlope) > float.Epsilon;

	public Vector2 size
	{
		[CompilerGenerated]
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return field;
		}
		[CompilerGenerated]
		protected set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			field = value;
		}
	}

	public Matrix4x4 boundsMatrix
	{
		[CompilerGenerated]
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return field;
		}
		[CompilerGenerated]
		protected set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			field = value;
		}
	}

	public int Width
	{
		get
		{
			return width;
		}
		set
		{
			width = value;
		}
	}

	public int Depth
	{
		get
		{
			return depth;
		}
		set
		{
			depth = value;
		}
	}

	public GridGraph()
	{
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		unclampedSize = new Vector2(10f, 10f);
		nodeSize = 1f;
		collision = new GraphCollision();
	}

	public override void OnDestroy()
	{
		base.OnDestroy();
		RemoveGridGraphFromStatic();
	}

	private void RemoveGridGraphFromStatic()
	{
		GridNode.SetGridGraph(AstarPath.active.astarData.GetGraphIndex(this), null);
	}

	public override int CountNodes()
	{
		return nodes.Length;
	}

	public override void GetNodes(GraphNodeDelegateCancelable del)
	{
		if (nodes != null)
		{
			for (int i = 0; i < nodes.Length && del(nodes[i]); i++)
			{
			}
		}
	}

	public void RelocateNodes(Vector3 center, Quaternion rotation, float nodeSize, float aspectRatio = 1f, float isometricAngle = 0f)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		Matrix4x4 oldMatrix = matrix;
		this.center = center;
		this.rotation = rotation.eulerAngles;
		this.nodeSize = nodeSize;
		this.aspectRatio = aspectRatio;
		this.isometricAngle = isometricAngle;
		UpdateSizeFromWidthDepth();
		RelocateNodes(oldMatrix, matrix);
	}

	public Int3 GraphPointToWorld(int x, int z, float height)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		return (Int3)matrix.MultiplyPoint3x4(new Vector3((float)x + 0.5f, height, (float)z + 0.5f));
	}

	public uint GetConnectionCost(int dir)
	{
		return neighbourCosts[dir];
	}

	public GridNode GetNodeConnection(GridNode node, int dir)
	{
		if (!node.GetConnectionInternal(dir))
		{
			return null;
		}
		if (!node.EdgeNode)
		{
			return nodes[node.NodeInGridIndex + neighbourOffsets[dir]];
		}
		int nodeInGridIndex = node.NodeInGridIndex;
		int num = nodeInGridIndex / Width;
		int x = nodeInGridIndex - num * Width;
		return GetNodeConnection(nodeInGridIndex, x, num, dir);
	}

	public bool HasNodeConnection(GridNode node, int dir)
	{
		if (!node.GetConnectionInternal(dir))
		{
			return false;
		}
		if (!node.EdgeNode)
		{
			return true;
		}
		int nodeInGridIndex = node.NodeInGridIndex;
		int num = nodeInGridIndex / Width;
		int x = nodeInGridIndex - num * Width;
		return HasNodeConnection(nodeInGridIndex, x, num, dir);
	}

	public void SetNodeConnection(GridNode node, int dir, bool value)
	{
		int nodeInGridIndex = node.NodeInGridIndex;
		int num = nodeInGridIndex / Width;
		int x = nodeInGridIndex - num * Width;
		SetNodeConnection(nodeInGridIndex, x, num, dir, value);
	}

	private GridNode GetNodeConnection(int index, int x, int z, int dir)
	{
		if (!nodes[index].GetConnectionInternal(dir))
		{
			return null;
		}
		int num = x + neighbourXOffsets[dir];
		if (num < 0 || num >= Width)
		{
			return null;
		}
		int num2 = z + neighbourZOffsets[dir];
		if (num2 < 0 || num2 >= Depth)
		{
			return null;
		}
		int num3 = index + neighbourOffsets[dir];
		return nodes[num3];
	}

	public void SetNodeConnection(int index, int x, int z, int dir, bool value)
	{
		nodes[index].SetConnectionInternal(dir, value);
	}

	public bool HasNodeConnection(int index, int x, int z, int dir)
	{
		if (!nodes[index].GetConnectionInternal(dir))
		{
			return false;
		}
		int num = x + neighbourXOffsets[dir];
		if (num < 0 || num >= Width)
		{
			return false;
		}
		int num2 = z + neighbourZOffsets[dir];
		if (num2 < 0 || num2 >= Depth)
		{
			return false;
		}
		return true;
	}

	public void UpdateSizeFromWidthDepth()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		unclampedSize = new Vector2((float)width, (float)depth) * nodeSize;
		GenerateMatrix();
	}

	public void GenerateMatrix()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = unclampedSize;
		val.x *= Mathf.Sign(val.x);
		val.y *= Mathf.Sign(val.y);
		nodeSize = Mathf.Clamp(nodeSize, val.x / 1024f, float.PositiveInfinity);
		nodeSize = Mathf.Clamp(nodeSize, val.y / 1024f, float.PositiveInfinity);
		val.x = ((!(val.x < nodeSize)) ? val.x : nodeSize);
		val.y = ((!(val.y < nodeSize)) ? val.y : nodeSize);
		size = val;
		Matrix4x4 val2 = Matrix4x4.TRS(Vector3.zero, Quaternion.Euler(0f, 45f, 0f), Vector3.one);
		val2 = Matrix4x4.Scale(new Vector3(Mathf.Cos((float)Math.PI / 180f * isometricAngle), 1f, 1f)) * val2;
		val2 = Matrix4x4.TRS(Vector3.zero, Quaternion.Euler(0f, -45f, 0f), Vector3.one) * val2;
		boundsMatrix = Matrix4x4.TRS(center, Quaternion.Euler(rotation), new Vector3(aspectRatio, 1f, 1f)) * val2;
		width = Mathf.FloorToInt(size.x / nodeSize);
		depth = Mathf.FloorToInt(size.y / nodeSize);
		if (Mathf.Approximately(size.x / nodeSize, (float)Mathf.CeilToInt(size.x / nodeSize)))
		{
			width = Mathf.CeilToInt(size.x / nodeSize);
		}
		if (Mathf.Approximately(size.y / nodeSize, (float)Mathf.CeilToInt(size.y / nodeSize)))
		{
			depth = Mathf.CeilToInt(size.y / nodeSize);
		}
		Matrix4x4 val3 = boundsMatrix;
		Matrix4x4 val4 = Matrix4x4.TRS(val3.MultiplyPoint3x4(-new Vector3(size.x, 0f, size.y) * 0.5f), Quaternion.Euler(rotation), new Vector3(nodeSize * aspectRatio, 1f, nodeSize)) * val2;
		SetMatrix(val4);
	}

	public override NNInfo GetNearest(Vector3 position, NNConstraint constraint, GraphNode hint)
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		if (nodes == null || depth * width != nodes.Length)
		{
			return default;
		}
		position = inverseMatrix.MultiplyPoint3x4(position);
		float num = position.x - 0.5f;
		float num2 = position.z - 0.5f;
		int num3 = Mathf.Clamp(Mathf.RoundToInt(num), 0, width - 1);
		int num4 = Mathf.Clamp(Mathf.RoundToInt(num2), 0, depth - 1);
		NNInfo result = new NNInfo(nodes[num4 * width + num3]);
		float y = inverseMatrix.MultiplyPoint3x4((Vector3)nodes[num4 * width + num3].position).y;
		result.clampedPosition = matrix.MultiplyPoint3x4(new Vector3(Mathf.Clamp(num, (float)num3 - 0.5f, (float)num3 + 0.5f) + 0.5f, y, Mathf.Clamp(num2, (float)num4 - 0.5f, (float)num4 + 0.5f) + 0.5f));
		return result;
	}

	public override NNInfo GetNearestForce(Vector3 position, NNConstraint constraint)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0384: Unknown result type (might be due to invalid IL or missing references)
		//IL_0389: Unknown result type (might be due to invalid IL or missing references)
		//IL_038a: Unknown result type (might be due to invalid IL or missing references)
		//IL_038f: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0420: Unknown result type (might be due to invalid IL or missing references)
		//IL_0425: Unknown result type (might be due to invalid IL or missing references)
		//IL_042a: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_052d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0532: Unknown result type (might be due to invalid IL or missing references)
		//IL_0537: Unknown result type (might be due to invalid IL or missing references)
		//IL_055e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0563: Unknown result type (might be due to invalid IL or missing references)
		//IL_0568: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0600: Unknown result type (might be due to invalid IL or missing references)
		//IL_0601: Unknown result type (might be due to invalid IL or missing references)
		//IL_0606: Unknown result type (might be due to invalid IL or missing references)
		//IL_066d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0672: Unknown result type (might be due to invalid IL or missing references)
		//IL_0677: Unknown result type (might be due to invalid IL or missing references)
		//IL_069e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a8: Unknown result type (might be due to invalid IL or missing references)
		if (nodes == null || depth * width != nodes.Length)
		{
			return default;
		}
		Vector3 val = position;
		position = inverseMatrix.MultiplyPoint3x4(position);
		float num = position.x - 0.5f;
		float num2 = position.z - 0.5f;
		int num3 = Mathf.Clamp(Mathf.RoundToInt(num), 0, width - 1);
		int num4 = Mathf.Clamp(Mathf.RoundToInt(num2), 0, depth - 1);
		GridNode gridNode = nodes[num3 + num4 * width];
		GridNode gridNode2 = null;
		float num5 = float.PositiveInfinity;
		int num6 = 2;
		Vector3 clampedPosition = Vector3.zero;
		NNInfo result = new NNInfo(null);
		if (constraint.Suitable(gridNode))
		{
			gridNode2 = gridNode;
			Vector3 val2 = (Vector3)gridNode2.position - val;
			num5 = val2.sqrMagnitude;
			float y = inverseMatrix.MultiplyPoint3x4((Vector3)gridNode.position).y;
			clampedPosition = matrix.MultiplyPoint3x4(new Vector3(Mathf.Clamp(num, (float)num3 - 0.5f, (float)num3 + 0.5f) + 0.5f, y, Mathf.Clamp(num2, (float)num4 - 0.5f, (float)num4 + 0.5f) + 0.5f));
		}
		if (gridNode2 != null)
		{
			result.node = gridNode2;
			result.clampedPosition = clampedPosition;
			if (num6 == 0)
			{
				return result;
			}
			num6--;
		}
		float num7 = ((!constraint.constrainDistance) ? float.PositiveInfinity : AstarPath.active.maxNearestNodeDistance);
		float num8 = num7 * num7;
		int num9 = 1;
		while (true)
		{
			if (nodeSize * (float)num9 > num7)
			{
				result.node = gridNode2;
				result.clampedPosition = clampedPosition;
				return result;
			}
			bool flag = false;
			int num10 = num4 + num9;
			int num11 = num10 * width;
			int i;
			for (i = num3 - num9; i <= num3 + num9; i++)
			{
				if (i < 0 || num10 < 0 || i >= width || num10 >= depth)
				{
					continue;
				}
				flag = true;
				if (constraint.Suitable(nodes[i + num11]))
				{
					Vector3 val3 = (Vector3)nodes[i + num11].position - val;
					float sqrMagnitude = val3.sqrMagnitude;
					if (sqrMagnitude < num5 && sqrMagnitude < num8)
					{
						num5 = sqrMagnitude;
						gridNode2 = nodes[i + num11];
						clampedPosition = matrix.MultiplyPoint3x4(new Vector3(Mathf.Clamp(num, (float)i - 0.5f, (float)i + 0.5f) + 0.5f, inverseMatrix.MultiplyPoint3x4((Vector3)gridNode2.position).y, Mathf.Clamp(num2, (float)num10 - 0.5f, (float)num10 + 0.5f) + 0.5f));
					}
				}
			}
			num10 = num4 - num9;
			num11 = num10 * width;
			for (i = num3 - num9; i <= num3 + num9; i++)
			{
				if (i < 0 || num10 < 0 || i >= width || num10 >= depth)
				{
					continue;
				}
				flag = true;
				if (constraint.Suitable(nodes[i + num11]))
				{
					Vector3 val4 = (Vector3)nodes[i + num11].position - val;
					float sqrMagnitude2 = val4.sqrMagnitude;
					if (sqrMagnitude2 < num5 && sqrMagnitude2 < num8)
					{
						num5 = sqrMagnitude2;
						gridNode2 = nodes[i + num11];
						clampedPosition = matrix.MultiplyPoint3x4(new Vector3(Mathf.Clamp(num, (float)i - 0.5f, (float)i + 0.5f) + 0.5f, inverseMatrix.MultiplyPoint3x4((Vector3)gridNode2.position).y, Mathf.Clamp(num2, (float)num10 - 0.5f, (float)num10 + 0.5f) + 0.5f));
					}
				}
			}
			i = num3 - num9;
			for (num10 = num4 - num9 + 1; num10 <= num4 + num9 - 1; num10++)
			{
				if (i < 0 || num10 < 0 || i >= width || num10 >= depth)
				{
					continue;
				}
				flag = true;
				if (constraint.Suitable(nodes[i + num10 * width]))
				{
					Vector3 val5 = (Vector3)nodes[i + num10 * width].position - val;
					float sqrMagnitude3 = val5.sqrMagnitude;
					if (sqrMagnitude3 < num5 && sqrMagnitude3 < num8)
					{
						num5 = sqrMagnitude3;
						gridNode2 = nodes[i + num10 * width];
						clampedPosition = matrix.MultiplyPoint3x4(new Vector3(Mathf.Clamp(num, (float)i - 0.5f, (float)i + 0.5f) + 0.5f, inverseMatrix.MultiplyPoint3x4((Vector3)gridNode2.position).y, Mathf.Clamp(num2, (float)num10 - 0.5f, (float)num10 + 0.5f) + 0.5f));
					}
				}
			}
			i = num3 + num9;
			for (num10 = num4 - num9 + 1; num10 <= num4 + num9 - 1; num10++)
			{
				if (i < 0 || num10 < 0 || i >= width || num10 >= depth)
				{
					continue;
				}
				flag = true;
				if (constraint.Suitable(nodes[i + num10 * width]))
				{
					Vector3 val6 = (Vector3)nodes[i + num10 * width].position - val;
					float sqrMagnitude4 = val6.sqrMagnitude;
					if (sqrMagnitude4 < num5 && sqrMagnitude4 < num8)
					{
						num5 = sqrMagnitude4;
						gridNode2 = nodes[i + num10 * width];
						clampedPosition = matrix.MultiplyPoint3x4(new Vector3(Mathf.Clamp(num, (float)i - 0.5f, (float)i + 0.5f) + 0.5f, inverseMatrix.MultiplyPoint3x4((Vector3)gridNode2.position).y, Mathf.Clamp(num2, (float)num10 - 0.5f, (float)num10 + 0.5f) + 0.5f));
					}
				}
			}
			if (gridNode2 != null)
			{
				if (num6 == 0)
				{
					result.node = gridNode2;
					result.clampedPosition = clampedPosition;
					return result;
				}
				num6--;
			}
			if (!flag)
			{
				break;
			}
			num9++;
		}
		result.node = gridNode2;
		result.clampedPosition = clampedPosition;
		return result;
	}

	public virtual void SetUpOffsetsAndCosts()
	{
		neighbourOffsets[0] = -width;
		neighbourOffsets[1] = 1;
		neighbourOffsets[2] = width;
		neighbourOffsets[3] = -1;
		neighbourOffsets[4] = -width + 1;
		neighbourOffsets[5] = width + 1;
		neighbourOffsets[6] = width - 1;
		neighbourOffsets[7] = -width - 1;
		uint num = (uint)Mathf.RoundToInt(nodeSize * 1000f);
		uint num2 = ((!uniformEdgeCosts) ? ((uint)Mathf.RoundToInt(nodeSize * Mathf.Sqrt(2f) * 1000f)) : num);
		neighbourCosts[0] = num;
		neighbourCosts[1] = num;
		neighbourCosts[2] = num;
		neighbourCosts[3] = num;
		neighbourCosts[4] = num2;
		neighbourCosts[5] = num2;
		neighbourCosts[6] = num2;
		neighbourCosts[7] = num2;
		neighbourXOffsets[0] = 0;
		neighbourXOffsets[1] = 1;
		neighbourXOffsets[2] = 0;
		neighbourXOffsets[3] = -1;
		neighbourXOffsets[4] = 1;
		neighbourXOffsets[5] = 1;
		neighbourXOffsets[6] = -1;
		neighbourXOffsets[7] = -1;
		neighbourZOffsets[0] = -1;
		neighbourZOffsets[1] = 0;
		neighbourZOffsets[2] = 1;
		neighbourZOffsets[3] = 0;
		neighbourZOffsets[4] = -1;
		neighbourZOffsets[5] = 1;
		neighbourZOffsets[6] = 1;
		neighbourZOffsets[7] = -1;
	}

	public override void ScanInternal(OnScanStatus statusCallback)
	{
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		AstarPath.OnPostScan = (OnScanDelegate)Delegate.Combine(AstarPath.OnPostScan, new OnScanDelegate(OnPostScan));
		if (nodeSize <= 0f)
		{
			return;
		}
		GenerateMatrix();
		if (width > 1024 || depth > 1024)
		{
			Debug.LogError((object)"One of the grid's sides is longer than 1024 nodes");
			return;
		}
		if (useJumpPointSearch)
		{
			Debug.LogError((object)"Trying to use Jump Point Search, but support for it is not enabled. Please enable it in the inspector (Grid Graph settings).");
		}
		SetUpOffsetsAndCosts();
		int num = AstarPath.active.astarData.GetGraphIndex(this);
		GridNode.SetGridGraph(num, this);
		nodes = new GridNode[width * depth];
		for (int i = 0; i < nodes.Length; i++)
		{
			nodes[i] = new GridNode(active);
			nodes[i].GraphIndex = (uint)num;
		}
		if (collision == null)
		{
			collision = new GraphCollision();
		}
		collision.Initialize(matrix, nodeSize);
		textureData.Initialize();
		for (int j = 0; j < depth; j++)
		{
			for (int k = 0; k < width; k++)
			{
				GridNode gridNode = nodes[j * width + k];
				gridNode.NodeInGridIndex = j * width + k;
				UpdateNodePositionCollision(gridNode, k, j);
				textureData.Apply(gridNode, k, j);
			}
		}
		for (int l = 0; l < depth; l++)
		{
			for (int m = 0; m < width; m++)
			{
				GridNode node = nodes[l * width + m];
				CalculateConnections(m, l, node);
			}
		}
		ErodeWalkableArea();
	}

	public virtual void UpdateNodePositionCollision(GridNode node, int x, int z, bool resetPenalty = true)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		node.position = GraphPointToWorld(x, z, 0f);
		Vector3 val = collision.CheckHeight((Vector3)node.position, out var hit, out var walkable);
		node.position = (Int3)val;
		if (resetPenalty)
		{
			node.Penalty = initialPenalty;
			if (penaltyPosition)
			{
				node.Penalty += (uint)Mathf.RoundToInt(((float)node.position.y - penaltyPositionOffset) * penaltyPositionFactor);
			}
		}
		if (walkable && useRaycastNormal && collision.heightCheck && hit.normal != Vector3.zero)
		{
			Vector3 normal = hit.normal;
			float num = Vector3.Dot(normal.normalized, collision.up);
			if (penaltyAngle && resetPenalty)
			{
				node.Penalty += (uint)Mathf.RoundToInt((1f - Mathf.Pow(num, penaltyAnglePower)) * penaltyAngleFactor);
			}
			float num2 = Mathf.Cos(maxSlope * ((float)Math.PI / 180f));
			if (num < num2)
			{
				walkable = false;
			}
		}
		node.Walkable = walkable && collision.Check((Vector3)node.position);
		node.WalkableErosion = node.Walkable;
	}

	public virtual void ErodeWalkableArea()
	{
		ErodeWalkableArea(0, 0, Width, Depth);
	}

	private bool ErosionAnyFalseConnections(GridNode node)
	{
		if (neighbours == NumNeighbours.Six)
		{
			for (int i = 0; i < 6; i++)
			{
				if (!HasNodeConnection(node, hexagonNeighbourIndices[i]))
				{
					return true;
				}
			}
		}
		else
		{
			for (int j = 0; j < 4; j++)
			{
				if (!HasNodeConnection(node, j))
				{
					return true;
				}
			}
		}
		return false;
	}

	public virtual void ErodeWalkableArea(int xmin, int zmin, int xmax, int zmax)
	{
		xmin = Mathf.Clamp(xmin, 0, Width);
		xmax = Mathf.Clamp(xmax, 0, Width);
		zmin = Mathf.Clamp(zmin, 0, Depth);
		zmax = Mathf.Clamp(zmax, 0, Depth);
		if (!erosionUseTags)
		{
			for (int i = 0; i < erodeIterations; i++)
			{
				for (int j = zmin; j < zmax; j++)
				{
					for (int k = xmin; k < xmax; k++)
					{
						GridNode gridNode = nodes[j * Width + k];
						if (gridNode.Walkable && ErosionAnyFalseConnections(gridNode))
						{
							gridNode.Walkable = false;
						}
					}
				}
				for (int l = zmin; l < zmax; l++)
				{
					for (int m = xmin; m < xmax; m++)
					{
						GridNode node = nodes[l * Width + m];
						CalculateConnections(m, l, node);
					}
				}
			}
			return;
		}
		if (erodeIterations + erosionFirstTag > 31)
		{
			Debug.LogError((object)("Too few tags available for " + erodeIterations + " erode iterations and starting with tag " + erosionFirstTag + " (erodeIterations+erosionFirstTag > 31)"));
			return;
		}
		if (erosionFirstTag <= 0)
		{
			Debug.LogError((object)"First erosion tag must be greater or equal to 1");
			return;
		}
		for (int n = 0; n < erodeIterations; n++)
		{
			for (int num = zmin; num < zmax; num++)
			{
				for (int num2 = xmin; num2 < xmax; num2++)
				{
					GridNode gridNode2 = nodes[num * width + num2];
					if (gridNode2.Walkable && gridNode2.Tag >= erosionFirstTag && gridNode2.Tag < erosionFirstTag + n)
					{
						if (neighbours == NumNeighbours.Six)
						{
							for (int num3 = 0; num3 < 6; num3++)
							{
								GridNode nodeConnection = GetNodeConnection(gridNode2, hexagonNeighbourIndices[num3]);
								if (nodeConnection != null)
								{
									uint tag = nodeConnection.Tag;
									if (tag > erosionFirstTag + n || tag < erosionFirstTag)
									{
										nodeConnection.Tag = (uint)(erosionFirstTag + n);
									}
								}
							}
							continue;
						}
						for (int num4 = 0; num4 < 4; num4++)
						{
							GridNode nodeConnection2 = GetNodeConnection(gridNode2, num4);
							if (nodeConnection2 != null)
							{
								uint tag2 = nodeConnection2.Tag;
								if (tag2 > erosionFirstTag + n || tag2 < erosionFirstTag)
								{
									nodeConnection2.Tag = (uint)(erosionFirstTag + n);
								}
							}
						}
					}
					else if (gridNode2.Walkable && n == 0 && ErosionAnyFalseConnections(gridNode2))
					{
						gridNode2.Tag = (uint)(erosionFirstTag + n);
					}
				}
			}
		}
	}

	public virtual bool IsValidConnection(GridNode n1, GridNode n2)
	{
		if (!n1.Walkable || !n2.Walkable)
		{
			return false;
		}
		return maxClimb <= 0f || (float)Math.Abs(n1.position[maxClimbAxis] - n2.position[maxClimbAxis]) <= maxClimb * 1000f;
	}

	public static void CalculateConnections(GridNode node)
	{
		if (AstarData.GetGraph(node) is GridGraph gridGraph)
		{
			int nodeInGridIndex = node.NodeInGridIndex;
			int x = nodeInGridIndex % gridGraph.width;
			int z = nodeInGridIndex / gridGraph.width;
			gridGraph.CalculateConnections(x, z, node);
		}
	}

	[Obsolete("CalculateConnections no longer takes a node array, it just uses the one on the graph")]
	public virtual void CalculateConnections(GridNode[] nodes, int x, int z, GridNode node)
	{
		CalculateConnections(x, z, node);
	}

	public virtual void CalculateConnections(int x, int z, GridNode node)
	{
		if (!node.Walkable)
		{
			node.ResetConnectionsInternal();
			return;
		}
		int nodeInGridIndex = node.NodeInGridIndex;
		if (neighbours == NumNeighbours.Four || neighbours == NumNeighbours.Eight)
		{
			int num = 0;
			for (int i = 0; i < 4; i++)
			{
				int num2 = x + neighbourXOffsets[i];
				int num3 = z + neighbourZOffsets[i];
				if ((num2 >= 0) & (num3 >= 0) & (num2 < width) & (num3 < depth))
				{
					GridNode n = nodes[nodeInGridIndex + neighbourOffsets[i]];
					if (IsValidConnection(node, n))
					{
						num |= 1 << i;
					}
				}
			}
			int num4 = 0;
			if (neighbours == NumNeighbours.Eight)
			{
				if (cutCorners)
				{
					for (int j = 0; j < 4; j++)
					{
						if ((((num >> j) | (num >> j + 1) | (num >> j + 1 - 4)) & 1) == 0)
						{
							continue;
						}
						int num5 = j + 4;
						int num6 = x + neighbourXOffsets[num5];
						int num7 = z + neighbourZOffsets[num5];
						if ((num6 >= 0) & (num7 >= 0) & (num6 < width) & (num7 < depth))
						{
							GridNode n2 = nodes[nodeInGridIndex + neighbourOffsets[num5]];
							if (IsValidConnection(node, n2))
							{
								num4 |= 1 << num5;
							}
						}
					}
				}
				else
				{
					for (int k = 0; k < 4; k++)
					{
						if (((num >> k) & 1) != 0 && (((num >> k + 1) | (num >> k + 1 - 4)) & 1) != 0)
						{
							GridNode n3 = nodes[nodeInGridIndex + neighbourOffsets[k + 4]];
							if (IsValidConnection(node, n3))
							{
								num4 |= 1 << k + 4;
							}
						}
					}
				}
			}
			node.SetAllConnectionInternal(num | num4);
			return;
		}
		node.ResetConnectionsInternal();
		for (int l = 0; l < hexagonNeighbourIndices.Length; l++)
		{
			int num8 = hexagonNeighbourIndices[l];
			int num9 = x + neighbourXOffsets[num8];
			int num10 = z + neighbourZOffsets[num8];
			if ((num9 >= 0) & (num10 >= 0) & (num9 < width) & (num10 < depth))
			{
				GridNode n4 = nodes[nodeInGridIndex + neighbourOffsets[num8]];
				node.SetConnectionInternal(num8, IsValidConnection(node, n4));
			}
		}
	}

	public void OnPostScan(AstarPath script)
	{
		AstarPath.OnPostScan = (OnScanDelegate)Delegate.Remove(AstarPath.OnPostScan, new OnScanDelegate(OnPostScan));
		if (!autoLinkGrids || autoLinkDistLimit <= 0f)
		{
			return;
		}
		throw new NotSupportedException();
	}

	public override void OnDrawGizmos(bool drawNodes)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		Gizmos.matrix = boundsMatrix;
		Gizmos.color = Color.white;
		Gizmos.DrawWireCube(Vector3.zero, new Vector3(size.x, 0f, size.y));
		Gizmos.matrix = Matrix4x4.identity;
		if (!drawNodes || nodes == null || nodes.Length != width * depth)
		{
			return;
		}
		PathHandler debugPathData = AstarPath.active.debugPathData;
		bool flag = AstarPath.active.showSearchTree && debugPathData != null;
		for (int i = 0; i < depth; i++)
		{
			for (int j = 0; j < width; j++)
			{
				GridNode gridNode = nodes[i * width + j];
				if (!gridNode.Walkable)
				{
					continue;
				}
				Gizmos.color = NodeColor(gridNode, debugPathData);
				Vector3 val = (Vector3)gridNode.position;
				if (flag)
				{
					if (NavGraph.InSearchTree(gridNode, AstarPath.active.debugPath))
					{
						PathNode pathNode = debugPathData.GetPathNode(gridNode);
						if (pathNode != null && pathNode.parent != null)
						{
							Gizmos.DrawLine(val, (Vector3)pathNode.parent.node.position);
						}
					}
					continue;
				}
				for (int k = 0; k < 8; k++)
				{
					if (gridNode.GetConnectionInternal(k))
					{
						GridNode gridNode2 = nodes[gridNode.NodeInGridIndex + neighbourOffsets[k]];
						Gizmos.DrawLine(val, (Vector3)gridNode2.position);
					}
				}
				if (gridNode.connections != null)
				{
					for (int l = 0; l < gridNode.connections.Length; l++)
					{
						GraphNode graphNode = gridNode.connections[l];
						Gizmos.DrawLine(val, (Vector3)graphNode.position);
					}
				}
			}
		}
	}

	protected static void GetBoundsMinMax(Bounds b, Matrix4x4 matrix, out Vector3 min, out Vector3 max)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0270: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0309: Unknown result type (might be due to invalid IL or missing references)
		//IL_030e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0313: Unknown result type (might be due to invalid IL or missing references)
		Vector3[] array = new Vector3[8]
		{
			matrix.MultiplyPoint3x4(b.center + new Vector3(b.extents.x, b.extents.y, b.extents.z)),
			matrix.MultiplyPoint3x4(b.center + new Vector3(b.extents.x, b.extents.y, 0f - b.extents.z)),
			matrix.MultiplyPoint3x4(b.center + new Vector3(b.extents.x, 0f - b.extents.y, b.extents.z)),
			matrix.MultiplyPoint3x4(b.center + new Vector3(b.extents.x, 0f - b.extents.y, 0f - b.extents.z)),
			matrix.MultiplyPoint3x4(b.center + new Vector3(0f - b.extents.x, b.extents.y, b.extents.z)),
			matrix.MultiplyPoint3x4(b.center + new Vector3(0f - b.extents.x, b.extents.y, 0f - b.extents.z)),
			matrix.MultiplyPoint3x4(b.center + new Vector3(0f - b.extents.x, 0f - b.extents.y, b.extents.z)),
			matrix.MultiplyPoint3x4(b.center + new Vector3(0f - b.extents.x, 0f - b.extents.y, 0f - b.extents.z))
		};
		min = array[0];
		max = array[0];
		for (int i = 1; i < 8; i++)
		{
			min = Vector3.Min(min, array[i]);
			max = Vector3.Max(max, array[i]);
		}
	}

	public List<GraphNode> GetNodesInArea(Bounds b)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return GetNodesInArea(b, null);
	}

	public List<GraphNode> GetNodesInArea(GraphUpdateShape shape)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		return GetNodesInArea(shape.GetBounds(), shape);
	}

	private List<GraphNode> GetNodesInArea(Bounds b, GraphUpdateShape shape)
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		if (nodes == null || width * depth != nodes.Length)
		{
			return null;
		}
		List<GraphNode> list = ListPool<GraphNode>.Claim();
		GetBoundsMinMax(b, inverseMatrix, out var min, out var max);
		int xmin = Mathf.RoundToInt(min.x - 0.5f);
		int xmax = Mathf.RoundToInt(max.x - 0.5f);
		int ymin = Mathf.RoundToInt(min.z - 0.5f);
		int ymax = Mathf.RoundToInt(max.z - 0.5f);
		IntRect a = new IntRect(xmin, ymin, xmax, ymax);
		IntRect b2 = new IntRect(0, 0, width - 1, depth - 1);
		IntRect intRect = IntRect.Intersection(a, b2);
		for (int i = intRect.xmin; i <= intRect.xmax; i++)
		{
			for (int j = intRect.ymin; j <= intRect.ymax; j++)
			{
				int num = j * width + i;
				GraphNode graphNode = nodes[num];
				if (b.Contains((Vector3)graphNode.position) && (shape == null || shape.Contains((Vector3)graphNode.position)))
				{
					list.Add(graphNode);
				}
			}
		}
		return list;
	}

	public GraphUpdateThreading CanUpdateAsync(GraphUpdateObject o)
	{
		return GraphUpdateThreading.UnityThread;
	}

	public void UpdateAreaInit(GraphUpdateObject o)
	{
	}

	public void UpdateArea(GraphUpdateObject o)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_038a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0353: Unknown result type (might be due to invalid IL or missing references)
		if (nodes == null || nodes.Length != width * depth)
		{
			Debug.LogWarning((object)"The Grid Graph is not scanned, cannot update area ");
			return;
		}
		Bounds b = o.bounds;
		GetBoundsMinMax(b, inverseMatrix, out var min, out var max);
		int xmin = Mathf.RoundToInt(min.x - 0.5f);
		int xmax = Mathf.RoundToInt(max.x - 0.5f);
		int ymin = Mathf.RoundToInt(min.z - 0.5f);
		int ymax = Mathf.RoundToInt(max.z - 0.5f);
		IntRect intRect = new IntRect(xmin, ymin, xmax, ymax);
		IntRect intRect2 = intRect;
		IntRect b2 = new IntRect(0, 0, width - 1, depth - 1);
		IntRect intRect3 = intRect;
		int num = (o.updateErosion ? erodeIterations : 0);
		bool flag = o.updatePhysics || o.modifyWalkability;
		if (o.updatePhysics && !o.modifyWalkability && collision.collisionCheck)
		{
			Vector3 val = new Vector3(collision.diameter, 0f, collision.diameter) * 0.5f;
			min -= val * 1.02f;
			max += val * 1.02f;
			intRect3 = new IntRect(Mathf.RoundToInt(min.x - 0.5f), Mathf.RoundToInt(min.z - 0.5f), Mathf.RoundToInt(max.x - 0.5f), Mathf.RoundToInt(max.z - 0.5f));
			intRect2 = IntRect.Union(intRect3, intRect2);
		}
		if (flag || num > 0)
		{
			intRect2 = intRect2.Expand(num + 1);
		}
		IntRect intRect4 = IntRect.Intersection(intRect2, b2);
		for (int i = intRect4.xmin; i <= intRect4.xmax; i++)
		{
			for (int j = intRect4.ymin; j <= intRect4.ymax; j++)
			{
				o.WillUpdateNode(nodes[j * width + i]);
			}
		}
		if (o.updatePhysics && !o.modifyWalkability)
		{
			collision.Initialize(matrix, nodeSize);
			intRect4 = IntRect.Intersection(intRect3, b2);
			for (int k = intRect4.xmin; k <= intRect4.xmax; k++)
			{
				for (int l = intRect4.ymin; l <= intRect4.ymax; l++)
				{
					int num2 = l * width + k;
					GridNode node = nodes[num2];
					UpdateNodePositionCollision(node, k, l, o.resetPenaltyOnPhysics);
				}
			}
		}
		intRect4 = IntRect.Intersection(intRect, b2);
		for (int m = intRect4.xmin; m <= intRect4.xmax; m++)
		{
			for (int n = intRect4.ymin; n <= intRect4.ymax; n++)
			{
				int num3 = n * width + m;
				GridNode gridNode = nodes[num3];
				if (flag)
				{
					gridNode.Walkable = gridNode.WalkableErosion;
					if (o.bounds.Contains((Vector3)gridNode.position))
					{
						o.Apply(gridNode);
					}
					gridNode.WalkableErosion = gridNode.Walkable;
				}
				else if (o.bounds.Contains((Vector3)gridNode.position))
				{
					o.Apply(gridNode);
				}
			}
		}
		if (flag && num == 0)
		{
			intRect4 = IntRect.Intersection(intRect2, b2);
			for (int num4 = intRect4.xmin; num4 <= intRect4.xmax; num4++)
			{
				for (int num5 = intRect4.ymin; num5 <= intRect4.ymax; num5++)
				{
					int num6 = num5 * width + num4;
					GridNode node2 = nodes[num6];
					CalculateConnections(num4, num5, node2);
				}
			}
		}
		else
		{
			if (!flag || num <= 0)
			{
				return;
			}
			IntRect a = IntRect.Union(intRect, intRect3).Expand(num);
			IntRect a2 = a.Expand(num);
			a = IntRect.Intersection(a, b2);
			a2 = IntRect.Intersection(a2, b2);
			for (int num7 = a2.xmin; num7 <= a2.xmax; num7++)
			{
				for (int num8 = a2.ymin; num8 <= a2.ymax; num8++)
				{
					int num9 = num8 * width + num7;
					GridNode gridNode2 = nodes[num9];
					bool walkable = gridNode2.Walkable;
					gridNode2.Walkable = gridNode2.WalkableErosion;
					if (!a.Contains(num7, num8))
					{
						gridNode2.TmpWalkable = walkable;
					}
				}
			}
			for (int num10 = a2.xmin; num10 <= a2.xmax; num10++)
			{
				for (int num11 = a2.ymin; num11 <= a2.ymax; num11++)
				{
					int num12 = num11 * width + num10;
					GridNode node3 = nodes[num12];
					CalculateConnections(num10, num11, node3);
				}
			}
			ErodeWalkableArea(a2.xmin, a2.ymin, a2.xmax + 1, a2.ymax + 1);
			for (int num13 = a2.xmin; num13 <= a2.xmax; num13++)
			{
				for (int num14 = a2.ymin; num14 <= a2.ymax; num14++)
				{
					if (!a.Contains(num13, num14))
					{
						int num15 = num14 * width + num13;
						GridNode gridNode3 = nodes[num15];
						gridNode3.Walkable = gridNode3.TmpWalkable;
					}
				}
			}
			for (int num16 = a2.xmin; num16 <= a2.xmax; num16++)
			{
				for (int num17 = a2.ymin; num17 <= a2.ymax; num17++)
				{
					int num18 = num17 * width + num16;
					GridNode node4 = nodes[num18];
					CalculateConnections(num16, num17, node4);
				}
			}
		}
	}

	public bool Linecast(Vector3 _a, Vector3 _b)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		GraphHitInfo hit;
		return Linecast(_a, _b, null, out hit);
	}

	public bool Linecast(Vector3 _a, Vector3 _b, GraphNode hint)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		GraphHitInfo hit;
		return Linecast(_a, _b, hint, out hit);
	}

	public bool Linecast(Vector3 _a, Vector3 _b, GraphNode hint, out GraphHitInfo hit)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		return Linecast(_a, _b, hint, out hit, null);
	}

	protected static float CrossMagnitude(Vector2 a, Vector2 b)
	{
		return a.x * b.y - b.x * a.y;
	}

	protected virtual GridNodeBase GetNeighbourAlongDirection(GridNodeBase node, int direction)
	{
		GridNode gridNode = node as GridNode;
		if (gridNode.GetConnectionInternal(direction))
		{
			return nodes[gridNode.NodeInGridIndex + neighbourOffsets[direction]];
		}
		return null;
	}

	protected bool ClipLineSegmentToBounds(Vector3 a, Vector3 b, out Vector3 outA, out Vector3 outB)
	{
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		if (a.x < 0f || a.z < 0f || a.x > (float)width || a.z > (float)depth || b.x < 0f || b.z < 0f || b.x > (float)width || b.z > (float)depth)
		{
			Vector3 val = new Vector3(0f, 0f, 0f);
			Vector3 val2 = new Vector3(0f, 0f, (float)depth);
			Vector3 val3 = new Vector3((float)width, 0f, (float)depth);
			Vector3 val4 = new Vector3((float)width, 0f, 0f);
			int num = 0;
			Vector3 val5 = VectorMath.SegmentIntersectionPointXZ(a, b, val, val2, out var intersects);
			if (intersects)
			{
				num++;
				if (!VectorMath.RightOrColinearXZ(val, val2, a))
				{
					a = val5;
				}
				else
				{
					b = val5;
				}
			}
			val5 = VectorMath.SegmentIntersectionPointXZ(a, b, val2, val3, out intersects);
			if (intersects)
			{
				num++;
				if (!VectorMath.RightOrColinearXZ(val2, val3, a))
				{
					a = val5;
				}
				else
				{
					b = val5;
				}
			}
			val5 = VectorMath.SegmentIntersectionPointXZ(a, b, val3, val4, out intersects);
			if (intersects)
			{
				num++;
				if (!VectorMath.RightOrColinearXZ(val3, val4, a))
				{
					a = val5;
				}
				else
				{
					b = val5;
				}
			}
			val5 = VectorMath.SegmentIntersectionPointXZ(a, b, val4, val, out intersects);
			if (intersects)
			{
				num++;
				if (!VectorMath.RightOrColinearXZ(val4, val, a))
				{
					a = val5;
				}
				else
				{
					b = val5;
				}
			}
			if (num == 0)
			{
				outA = Vector3.zero;
				outB = Vector3.zero;
				return false;
			}
		}
		outA = a;
		outB = b;
		return true;
	}

	public bool Linecast(Vector3 _a, Vector3 _b, GraphNode hint, out GraphHitInfo hit, List<GraphNode> trace)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_03df: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_028b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0346: Unknown result type (might be due to invalid IL or missing references)
		//IL_0353: Unknown result type (might be due to invalid IL or missing references)
		//IL_0355: Unknown result type (might be due to invalid IL or missing references)
		//IL_035a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0367: Unknown result type (might be due to invalid IL or missing references)
		//IL_0369: Unknown result type (might be due to invalid IL or missing references)
		//IL_036e: Unknown result type (might be due to invalid IL or missing references)
		//IL_038e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0393: Unknown result type (might be due to invalid IL or missing references)
		//IL_0398: Unknown result type (might be due to invalid IL or missing references)
		hit = default;
		hit.origin = _a;
		Vector3 outA = inverseMatrix.MultiplyPoint3x4(_a);
		Vector3 outB = inverseMatrix.MultiplyPoint3x4(_b);
		if (!ClipLineSegmentToBounds(outA, outB, out outA, out outB))
		{
			return false;
		}
		GridNodeBase gridNodeBase = GetNearest(matrix.MultiplyPoint3x4(outA), NNConstraint.None).node as GridNodeBase;
		GridNodeBase gridNodeBase2 = GetNearest(matrix.MultiplyPoint3x4(outB), NNConstraint.None).node as GridNodeBase;
		if (!gridNodeBase.Walkable)
		{
			hit.node = gridNodeBase;
			hit.point = matrix.MultiplyPoint3x4(outA);
			hit.tangentOrigin = hit.point;
			return true;
		}
		Vector2 val = new Vector2(outA.x, outA.z);
		Vector2 val2 = new Vector2(outB.x, outB.z);
		val -= Vector2.one * 0.5f;
		val2 -= Vector2.one * 0.5f;
		if (gridNodeBase == null || gridNodeBase2 == null)
		{
			hit.node = null;
			hit.point = _a;
			return true;
		}
		Vector2 a = val2 - val;
		Int2 @int = new Int2((int)Mathf.Sign(a.x), (int)Mathf.Sign(a.y));
		float num = CrossMagnitude(a, new Vector2((float)@int.x, (float)@int.y)) * 0.5f;
		int num2;
		int num3;
		if (a.y >= 0f)
		{
			if (a.x >= 0f)
			{
				num2 = 1;
				num3 = 2;
			}
			else
			{
				num2 = 2;
				num3 = 3;
			}
		}
		else if (a.x < 0f)
		{
			num2 = 3;
			num3 = 0;
		}
		else
		{
			num2 = 0;
			num3 = 1;
		}
		GridNodeBase gridNodeBase3 = gridNodeBase;
		while (gridNodeBase3.NodeInGridIndex != gridNodeBase2.NodeInGridIndex)
		{
			trace?.Add(gridNodeBase3);
			Vector2 val3 = new Vector2((float)(gridNodeBase3.NodeInGridIndex % width), (float)(gridNodeBase3.NodeInGridIndex / width));
			float num4 = CrossMagnitude(a, val3 - val);
			float num5 = num4 + num;
			int num6 = ((!(num5 < 0f)) ? num2 : num3);
			GridNodeBase neighbourAlongDirection = GetNeighbourAlongDirection(gridNodeBase3, num6);
			if (neighbourAlongDirection != null)
			{
				gridNodeBase3 = neighbourAlongDirection;
				continue;
			}
			Vector2 val4 = val3 + new Vector2((float)neighbourXOffsets[num6], (float)neighbourZOffsets[num6]) * 0.5f;
			Vector2 val5 = ((neighbourXOffsets[num6] != 0) ? new Vector2(0f, 1f) : new Vector2(1f, 0f));
			Vector2 val6 = VectorMath.LineIntersectionPoint(val4, val4 + val5, val, val2);
			Vector3 val7 = inverseMatrix.MultiplyPoint3x4((Vector3)gridNodeBase3.position);
			Vector3 val8 = new Vector3(val6.x + 0.5f, val7.y, val6.y + 0.5f);
			Vector3 val9 = new Vector3(val4.x + 0.5f, val7.y, val4.y + 0.5f);
			hit.point = matrix.MultiplyPoint3x4(val8);
			hit.tangentOrigin = matrix.MultiplyPoint3x4(val9);
			hit.tangent = matrix.MultiplyVector(new Vector3(val5.x, 0f, val5.y));
			hit.node = gridNodeBase3;
			return true;
		}
		trace?.Add(gridNodeBase3);
		if (gridNodeBase3 == gridNodeBase2)
		{
			return false;
		}
		hit.point = (Vector3)gridNodeBase3.position;
		hit.tangentOrigin = hit.point;
		return true;
	}

	public bool SnappedLinecast(Vector3 a, Vector3 b, GraphNode hint, out GraphHitInfo hit)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		return Linecast((Vector3)GetNearest(a, NNConstraint.None).node.position, (Vector3)GetNearest(b, NNConstraint.None).node.position, hint, out hit);
	}

	public bool CheckConnection(GridNode node, int dir)
	{
		if (neighbours == NumNeighbours.Eight || neighbours == NumNeighbours.Six || dir < 4)
		{
			return HasNodeConnection(node, dir);
		}
		int num = (dir - 4 - 1) & 3;
		int num2 = (dir - 4 + 1) & 3;
		if (!HasNodeConnection(node, num) || !HasNodeConnection(node, num2))
		{
			return false;
		}
		GridNode gridNode = nodes[node.NodeInGridIndex + neighbourOffsets[num]];
		GridNode gridNode2 = nodes[node.NodeInGridIndex + neighbourOffsets[num2]];
		if (!gridNode.Walkable || !gridNode2.Walkable)
		{
			return false;
		}
		if (!HasNodeConnection(gridNode2, num) || !HasNodeConnection(gridNode, num2))
		{
			return false;
		}
		return true;
	}

	public override void SerializeExtraInfo(GraphSerializationContext ctx)
	{
		if (nodes == null)
		{
			ctx.writer.Write(-1);
			return;
		}
		ctx.writer.Write(nodes.Length);
		for (int i = 0; i < nodes.Length; i++)
		{
			nodes[i].SerializeNode(ctx);
		}
	}

	public override void DeserializeExtraInfo(GraphSerializationContext ctx)
	{
		int num = ctx.reader.ReadInt32();
		if (num == -1)
		{
			nodes = null;
			return;
		}
		nodes = new GridNode[num];
		for (int i = 0; i < nodes.Length; i++)
		{
			nodes[i] = new GridNode(active);
			nodes[i].DeserializeNode(ctx);
		}
	}

	public override void PostDeserialization()
	{
		GenerateMatrix();
		SetUpOffsetsAndCosts();
		if (nodes == null || nodes.Length == 0)
		{
			return;
		}
		if (width * depth != nodes.Length)
		{
			Debug.LogError((object)"Node data did not match with bounds data. Probably a change to the bounds/width/depth data was made after scanning the graph just prior to saving it. Nodes will be discarded");
			nodes = new GridNode[0];
			return;
		}
		GridNode.SetGridGraph(AstarPath.active.astarData.GetGraphIndex(this), this);
		for (int i = 0; i < depth; i++)
		{
			for (int j = 0; j < width; j++)
			{
				GridNode gridNode = nodes[i * width + j];
				if (gridNode == null)
				{
					Debug.LogError((object)"Deserialization Error : Couldn't cast the node to the appropriate type - GridGenerator");
					return;
				}
				gridNode.NodeInGridIndex = i * width + j;
			}
		}
	}
}
