using UnityEngine;

namespace Pathfinding;

[AddComponentMenu("Pathfinding/GraphUpdateScene")]
[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_graph_update_scene.php")]
public class GraphUpdateScene : GraphModifier
{
	public Vector3[] points;

	private Vector3[] convexPoints;

	[HideInInspector]
	public bool convex = true;

	[HideInInspector]
	public float minBoundsHeight = 1f;

	[HideInInspector]
	public int penaltyDelta;

	[HideInInspector]
	public bool modifyWalkability;

	[HideInInspector]
	public bool setWalkability;

	[HideInInspector]
	public bool applyOnStart = true;

	[HideInInspector]
	public bool applyOnScan = true;

	[HideInInspector]
	public bool useWorldSpace;

	[HideInInspector]
	public bool updatePhysics;

	[HideInInspector]
	public bool resetPenaltyOnPhysics = true;

	[HideInInspector]
	public bool updateErosion = true;

	[HideInInspector]
	public bool lockToY;

	[HideInInspector]
	public float lockToYValue;

	[HideInInspector]
	public bool modifyTag;

	[HideInInspector]
	public int setTag;

	private int setTagInvert;

	private bool firstApplied;

	public void Start()
	{
		if (!firstApplied && applyOnStart)
		{
			Apply();
		}
	}

	public override void OnPostScan()
	{
		if (applyOnScan)
		{
			Apply();
		}
	}

	public virtual void InvertSettings()
	{
		setWalkability = !setWalkability;
		penaltyDelta = -penaltyDelta;
		if (setTagInvert == 0)
		{
			setTagInvert = setTag;
			setTag = 0;
		}
		else
		{
			setTag = setTagInvert;
			setTagInvert = 0;
		}
	}

	public void RecalcConvex()
	{
		convexPoints = ((!convex) ? null : Polygon.ConvexHullXZ(points));
	}

	public void ToggleUseWorldSpace()
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		useWorldSpace = !useWorldSpace;
		if (points != null)
		{
			convexPoints = null;
			Matrix4x4 val = ((!useWorldSpace) ? ((Component)this).transform.worldToLocalMatrix : ((Component)this).transform.localToWorldMatrix);
			for (int i = 0; i < points.Length; i++)
			{
				ref Vector3 reference = ref points[i];
				reference = val.MultiplyPoint3x4(points[i]);
			}
		}
	}

	public void LockToY()
	{
		if (points != null)
		{
			for (int i = 0; i < points.Length; i++)
			{
				points[i].y = lockToYValue;
			}
		}
	}

	public void Apply(AstarPath active)
	{
		if (applyOnScan)
		{
			Apply();
		}
	}

	public Bounds GetBounds()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		Bounds result;
		if (points == null || points.Length == 0)
		{
			Collider component = ((Component)this).GetComponent<Collider>();
			Renderer component2 = ((Component)this).GetComponent<Renderer>();
			if ((Object)(object)component != (Object)null)
			{
				result = component.bounds;
			}
			else
			{
				if (!((Object)(object)component2 != (Object)null))
				{
					return new Bounds(Vector3.zero, Vector3.zero);
				}
				result = component2.bounds;
			}
		}
		else
		{
			Matrix4x4 val = Matrix4x4.identity;
			if (!useWorldSpace)
			{
				val = ((Component)this).transform.localToWorldMatrix;
			}
			Vector3 val2 = val.MultiplyPoint3x4(points[0]);
			Vector3 val3 = val.MultiplyPoint3x4(points[0]);
			for (int i = 0; i < points.Length; i++)
			{
				Vector3 val4 = val.MultiplyPoint3x4(points[i]);
				val2 = Vector3.Min(val2, val4);
				val3 = Vector3.Max(val3, val4);
			}
			result = new Bounds((val2 + val3) * 0.5f, val3 - val2);
		}
		if (result.size.y < minBoundsHeight)
		{
			result.size = new Vector3(result.size.x, minBoundsHeight, result.size.z);
		}
		return result;
	}

	public void Apply()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)AstarPath.active == (Object)null)
		{
			Debug.LogError((object)"There is no AstarPath object in the scene");
			return;
		}
		GraphUpdateObject graphUpdateObject;
		if (points == null || points.Length == 0)
		{
			Collider component = ((Component)this).GetComponent<Collider>();
			Renderer component2 = ((Component)this).GetComponent<Renderer>();
			Bounds bounds;
			if ((Object)(object)component != (Object)null)
			{
				bounds = component.bounds;
			}
			else
			{
				if (!((Object)(object)component2 != (Object)null))
				{
					Debug.LogWarning((object)"Cannot apply GraphUpdateScene, no points defined and no renderer or collider attached");
					return;
				}
				bounds = component2.bounds;
			}
			if (bounds.size.y < minBoundsHeight)
			{
				bounds.size = new Vector3(bounds.size.x, minBoundsHeight, bounds.size.z);
			}
			graphUpdateObject = new GraphUpdateObject(bounds);
		}
		else
		{
			GraphUpdateShape graphUpdateShape = new GraphUpdateShape();
			graphUpdateShape.convex = convex;
			Vector3[] array = points;
			if (!useWorldSpace)
			{
				array = new Vector3[points.Length];
				Matrix4x4 localToWorldMatrix = ((Component)this).transform.localToWorldMatrix;
				for (int i = 0; i < array.Length; i++)
				{
					ref Vector3 reference = ref array[i];
					reference = localToWorldMatrix.MultiplyPoint3x4(points[i]);
				}
			}
			graphUpdateShape.points = array;
			Bounds bounds2 = graphUpdateShape.GetBounds();
			if (bounds2.size.y < minBoundsHeight)
			{
				bounds2.size = new Vector3(bounds2.size.x, minBoundsHeight, bounds2.size.z);
			}
			graphUpdateObject = new GraphUpdateObject(bounds2);
			graphUpdateObject.shape = graphUpdateShape;
		}
		firstApplied = true;
		graphUpdateObject.modifyWalkability = modifyWalkability;
		graphUpdateObject.setWalkability = setWalkability;
		graphUpdateObject.addPenalty = penaltyDelta;
		graphUpdateObject.updatePhysics = updatePhysics;
		graphUpdateObject.updateErosion = updateErosion;
		graphUpdateObject.resetPenaltyOnPhysics = resetPenaltyOnPhysics;
		graphUpdateObject.modifyTag = modifyTag;
		graphUpdateObject.setTag = setTag;
		AstarPath.active.UpdateGraphs(graphUpdateObject);
	}

	public void OnDrawGizmos()
	{
		OnDrawGizmos(selected: false);
	}

	public void OnDrawGizmosSelected()
	{
		OnDrawGizmos(selected: true);
	}

	public void OnDrawGizmos(bool selected)
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_023d: Unknown result type (might be due to invalid IL or missing references)
		Color val = ((!selected) ? new Color(227f / 255f, 61f / 255f, 22f / 255f, 0.9f) : new Color(227f / 255f, 61f / 255f, 22f / 255f, 1f));
		if (selected)
		{
			Gizmos.color = Color.Lerp(val, new Color(1f, 1f, 1f, 0.2f), 0.9f);
			Bounds bounds = GetBounds();
			Gizmos.DrawCube(bounds.center, bounds.size);
			Gizmos.DrawWireCube(bounds.center, bounds.size);
		}
		if (points == null)
		{
			return;
		}
		if (convex)
		{
			val.a *= 0.5f;
		}
		Gizmos.color = val;
		Matrix4x4 val2 = ((!useWorldSpace) ? ((Component)this).transform.localToWorldMatrix : Matrix4x4.identity);
		if (convex)
		{
			val.r -= 0.1f;
			val.g -= 0.2f;
			val.b -= 0.1f;
			Gizmos.color = val;
		}
		if (selected || !convex)
		{
			for (int i = 0; i < points.Length; i++)
			{
				Gizmos.DrawLine(val2.MultiplyPoint3x4(points[i]), val2.MultiplyPoint3x4(points[(i + 1) % points.Length]));
			}
		}
		if (convex)
		{
			if (convexPoints == null)
			{
				RecalcConvex();
			}
			Gizmos.color = ((!selected) ? new Color(227f / 255f, 61f / 255f, 22f / 255f, 0.9f) : new Color(227f / 255f, 61f / 255f, 22f / 255f, 1f));
			for (int j = 0; j < convexPoints.Length; j++)
			{
				Gizmos.DrawLine(val2.MultiplyPoint3x4(convexPoints[j]), val2.MultiplyPoint3x4(convexPoints[(j + 1) % convexPoints.Length]));
			}
		}
	}
}
