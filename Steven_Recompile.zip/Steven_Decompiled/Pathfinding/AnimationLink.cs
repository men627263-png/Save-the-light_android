using System;
using System.Collections.Generic;
using Pathfinding.Util;
using UnityEngine;

namespace Pathfinding;

[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_animation_link.php")]
public class AnimationLink : NodeLink2
{
	[Serializable]
	public class LinkClip
	{
		public AnimationClip clip;

		public Vector3 velocity;

		public int loopCount = 1;

		public string name => (!((Object)(object)clip != (Object)null)) ? string.Empty : ((Object)clip).name;
	}

	public string clip;

	public float animSpeed = 1f;

	public bool reverseAnim = true;

	public GameObject referenceMesh;

	public LinkClip[] sequence;

	public string boneRoot = "bn_COG_Root";

	private static Transform SearchRec(Transform tr, string name)
	{
		int childCount = tr.childCount;
		for (int i = 0; i < childCount; i++)
		{
			Transform child = tr.GetChild(i);
			if (((Object)child).name == name)
			{
				return child;
			}
			Transform val = SearchRec(child, name);
			if ((Object)(object)val != (Object)null)
			{
				return val;
			}
		}
		return null;
	}

	public void CalculateOffsets(List<Vector3> trace, out Vector3 endPosition)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_0310: Unknown result type (might be due to invalid IL or missing references)
		//IL_0312: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		endPosition = ((Component)this).transform.position;
		if ((Object)(object)referenceMesh == (Object)null)
		{
			return;
		}
		GameObject val = Object.Instantiate<GameObject>(referenceMesh, ((Component)this).transform.position, ((Component)this).transform.rotation);
		((Object)val).hideFlags = (HideFlags)61;
		Transform val2 = SearchRec(val.transform, boneRoot);
		if ((Object)(object)val2 == (Object)null)
		{
			throw new Exception("Could not find root transform");
		}
		Animation val3 = val.GetComponent<Animation>();
		if ((Object)(object)val3 == (Object)null)
		{
			val3 = val.AddComponent<Animation>();
		}
		for (int i = 0; i < sequence.Length; i++)
		{
			val3.AddClip(sequence[i].clip, ((Object)sequence[i].clip).name);
		}
		Vector3 val4 = Vector3.zero;
		Vector3 val5 = ((Component)this).transform.position;
		Vector3 val6 = Vector3.zero;
		for (int j = 0; j < sequence.Length; j++)
		{
			LinkClip linkClip = sequence[j];
			if (linkClip == null)
			{
				endPosition = val5;
				return;
			}
			val3[((Object)linkClip.clip).name].enabled = true;
			val3[((Object)linkClip.clip).name].weight = 1f;
			for (int k = 0; k < linkClip.loopCount; k++)
			{
				val3[((Object)linkClip.clip).name].normalizedTime = 0f;
				val3.Sample();
				Vector3 val7 = val2.position - ((Component)this).transform.position;
				if (j > 0)
				{
					val5 += val4 - val7;
				}
				else
				{
					val6 = val7;
				}
				for (int l = 0; l <= 20; l++)
				{
					float num = (float)l / 20f;
					val3[((Object)linkClip.clip).name].normalizedTime = num;
					val3.Sample();
					Vector3 item = val5 + (val2.position - ((Component)this).transform.position) + linkClip.velocity * num * linkClip.clip.length;
					trace.Add(item);
				}
				val5 += linkClip.velocity * 1f * linkClip.clip.length;
				val3[((Object)linkClip.clip).name].normalizedTime = 1f;
				val3.Sample();
				Vector3 val8 = val2.position - ((Component)this).transform.position;
				val4 = val8;
			}
			val3[((Object)linkClip.clip).name].enabled = false;
			val3[((Object)linkClip.clip).name].weight = 0f;
		}
		val5 += val4 - val6;
		Object.DestroyImmediate((Object)(object)val);
		endPosition = val5;
	}

	public override void OnDrawGizmosSelected()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		base.OnDrawGizmosSelected();
		List<Vector3> list = ListPool<Vector3>.Claim();
		Vector3 endPosition = Vector3.zero;
		CalculateOffsets(list, out endPosition);
		Gizmos.color = Color.blue;
		for (int i = 0; i < list.Count - 1; i++)
		{
			Gizmos.DrawLine(list[i], list[i + 1]);
		}
	}
}
