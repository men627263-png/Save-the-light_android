using UnityEngine;

namespace Pathfinding;

[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_target_mover.php")]
public class TargetMover : MonoBehaviour
{
	public LayerMask mask;

	public Transform target;

	private RichAI[] ais;

	private AIPath[] ais2;

	private AILerp[] ais3;

	public bool onlyOnDoubleClick;

	public bool use2D;

	private Camera cam;

	public void Start()
	{
		cam = Camera.main;
		ais = Object.FindObjectsOfType<RichAI>();
		ais2 = Object.FindObjectsOfType<AIPath>();
		ais3 = Object.FindObjectsOfType<AILerp>();
		((MonoBehaviour)this).useGUILayout = false;
	}

	public void OnGUI()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		if (onlyOnDoubleClick && (Object)(object)cam != (Object)null && (int)Event.current.type == 0 && Event.current.clickCount == 2)
		{
			UpdateTargetPosition();
		}
	}

	private void Update()
	{
		if (!onlyOnDoubleClick && (Object)(object)cam != (Object)null)
		{
			UpdateTargetPosition();
		}
	}

	public void UpdateTargetPosition()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.zero;
		bool flag = false;
		RaycastHit val2 = default;
		if (use2D)
		{
			val = cam.ScreenToWorldPoint(Input.mousePosition);
			val.z = 0f;
			flag = true;
		}
		else if (Physics.Raycast(cam.ScreenPointToRay(Input.mousePosition), ref val2, float.PositiveInfinity, LayerMask.op_Implicit(mask)))
		{
			val = val2.point;
			flag = true;
		}
		if (!flag || !(val != target.position))
		{
			return;
		}
		target.position = val;
		if (!onlyOnDoubleClick)
		{
			return;
		}
		if (ais != null)
		{
			for (int i = 0; i < ais.Length; i++)
			{
				if ((Object)(object)ais[i] != (Object)null)
				{
					ais[i].UpdatePath();
				}
			}
		}
		if (ais2 != null)
		{
			for (int j = 0; j < ais2.Length; j++)
			{
				if ((Object)(object)ais2[j] != (Object)null)
				{
					ais2[j].SearchPath();
				}
			}
		}
		if (ais3 == null)
		{
			return;
		}
		for (int k = 0; k < ais3.Length; k++)
		{
			if ((Object)(object)ais3[k] != (Object)null)
			{
				ais3[k].SearchPath();
			}
		}
	}
}
