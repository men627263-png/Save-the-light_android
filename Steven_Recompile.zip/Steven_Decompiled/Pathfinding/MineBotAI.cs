using UnityEngine;

namespace Pathfinding;

[RequireComponent(typeof(Seeker))]
[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_mine_bot_a_i.php")]
public class MineBotAI : AIPath
{
	public Animation anim;

	public float sleepVelocity = 0.4f;

	public float animationSpeed = 0.2f;

	public GameObject endOfPathEffect;

	protected Vector3 lastTarget;

	public new void Start()
	{
		anim["forward"].layer = 10;
		anim.Play("awake");
		anim.Play("forward");
		anim["awake"].wrapMode = (WrapMode)1;
		anim["awake"].speed = 0f;
		anim["awake"].normalizedTime = 1f;
		base.Start();
	}

	public override void OnTargetReached()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)endOfPathEffect != (Object)null && Vector3.Distance(tr.position, lastTarget) > 1f)
		{
			Object.Instantiate<GameObject>(endOfPathEffect, tr.position, tr.rotation);
			lastTarget = tr.position;
		}
	}

	public override Vector3 GetFeetPosition()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		return tr.position;
	}

	protected new void Update()
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val2;
		if (canMove)
		{
			Vector3 val = CalculateVelocity(GetFeetPosition());
			RotateTowards(targetDirection);
			val.y = 0f;
			if (!(val.sqrMagnitude > sleepVelocity * sleepVelocity))
			{
				val = Vector3.zero;
			}
			if ((Object)(object)rvoController != (Object)null)
			{
				rvoController.Move(val);
				val2 = rvoController.velocity;
			}
			else if ((Object)(object)controller != (Object)null)
			{
				controller.SimpleMove(val);
				val2 = controller.velocity;
			}
			else
			{
				Debug.LogWarning((object)"No NavmeshController or CharacterController attached to GameObject");
				val2 = Vector3.zero;
			}
		}
		else
		{
			val2 = Vector3.zero;
		}
		Vector3 val3 = tr.InverseTransformDirection(val2);
		val3.y = 0f;
		if (val2.sqrMagnitude <= sleepVelocity * sleepVelocity)
		{
			anim.Blend("forward", 0f, 0.2f);
			return;
		}
		anim.Blend("forward", 1f, 0.2f);
		AnimationState val4 = anim["forward"];
		float z = val3.z;
		val4.speed = z * animationSpeed;
	}
}
