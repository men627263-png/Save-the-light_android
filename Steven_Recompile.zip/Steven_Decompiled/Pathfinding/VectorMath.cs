using System;
using UnityEngine;

namespace Pathfinding;

public static class VectorMath
{
	public static Vector3 ClosestPointOnLine(Vector3 lineStart, Vector3 lineEnd, Vector3 point)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.Normalize(lineEnd - lineStart);
		float num = Vector3.Dot(point - lineStart, val);
		return lineStart + num * val;
	}

	public static float ClosestPointOnLineFactor(Vector3 lineStart, Vector3 lineEnd, Vector3 point)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = lineEnd - lineStart;
		float sqrMagnitude = val.sqrMagnitude;
		if ((double)sqrMagnitude <= 1E-06)
		{
			return 0f;
		}
		return Vector3.Dot(point - lineStart, val) / sqrMagnitude;
	}

	public static float ClosestPointOnLineFactor(Int3 lineStart, Int3 lineEnd, Int3 point)
	{
		Int3 rhs = lineEnd - lineStart;
		float sqrMagnitude = rhs.sqrMagnitude;
		float num = Int3.Dot(point - lineStart, rhs);
		if (sqrMagnitude != 0f)
		{
			num /= sqrMagnitude;
		}
		return num;
	}

	public static float ClosestPointOnLineFactor(Int2 lineStart, Int2 lineEnd, Int2 point)
	{
		Int2 b = lineEnd - lineStart;
		double num = b.sqrMagnitudeLong;
		double num2 = Int2.DotLong(point - lineStart, b);
		if (num != 0.0)
		{
			num2 /= num;
		}
		return (float)num2;
	}

	public static Vector3 ClosestPointOnSegment(Vector3 lineStart, Vector3 lineEnd, Vector3 point)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = lineEnd - lineStart;
		float sqrMagnitude = val.sqrMagnitude;
		if ((double)sqrMagnitude <= 1E-06)
		{
			return lineStart;
		}
		float num = Vector3.Dot(point - lineStart, val) / sqrMagnitude;
		return lineStart + Mathf.Clamp01(num) * val;
	}

	public static Vector3 ClosestPointOnSegmentXZ(Vector3 lineStart, Vector3 lineEnd, Vector3 point)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		lineStart.y = point.y;
		lineEnd.y = point.y;
		Vector3 val = lineEnd - lineStart;
		Vector3 val2 = val;
		val2.y = 0f;
		float magnitude = val2.magnitude;
		Vector3 val3 = ((!(magnitude > float.Epsilon)) ? Vector3.zero : (val2 / magnitude));
		float num = Vector3.Dot(point - lineStart, val3);
		return lineStart + Mathf.Clamp(num, 0f, val2.magnitude) * val3;
	}

	public static float SqrDistancePointSegmentApproximate(int x, int z, int px, int pz, int qx, int qz)
	{
		float num = qx - px;
		float num2 = qz - pz;
		float num3 = x - px;
		float num4 = z - pz;
		float num5 = num * num + num2 * num2;
		float num6 = num * num3 + num2 * num4;
		if (num5 > 0f)
		{
			num6 /= num5;
		}
		if (num6 < 0f)
		{
			num6 = 0f;
		}
		else if (num6 > 1f)
		{
			num6 = 1f;
		}
		num3 = (float)px + num6 * num - (float)x;
		num4 = (float)pz + num6 * num2 - (float)z;
		return num3 * num3 + num4 * num4;
	}

	public static float SqrDistancePointSegmentApproximate(Int3 a, Int3 b, Int3 p)
	{
		float num = b.x - a.x;
		float num2 = b.z - a.z;
		float num3 = p.x - a.x;
		float num4 = p.z - a.z;
		float num5 = num * num + num2 * num2;
		float num6 = num * num3 + num2 * num4;
		if (num5 > 0f)
		{
			num6 /= num5;
		}
		if (num6 < 0f)
		{
			num6 = 0f;
		}
		else if (num6 > 1f)
		{
			num6 = 1f;
		}
		num3 = (float)a.x + num6 * num - (float)p.x;
		num4 = (float)a.z + num6 * num2 - (float)p.z;
		return num3 * num3 + num4 * num4;
	}

	public static float SqrDistancePointSegment(Vector3 a, Vector3 b, Vector3 p)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = ClosestPointOnSegment(a, b, p);
		Vector3 val2 = val - p;
		return val2.sqrMagnitude;
	}

	public static float SqrDistanceSegmentSegment(Vector3 s1, Vector3 e1, Vector3 s2, Vector3 e2)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = e1 - s1;
		Vector3 val2 = e2 - s2;
		Vector3 val3 = s1 - s2;
		float num = Vector3.Dot(val, val);
		float num2 = Vector3.Dot(val, val2);
		float num3 = Vector3.Dot(val2, val2);
		float num4 = Vector3.Dot(val, val3);
		float num5 = Vector3.Dot(val2, val3);
		float num6 = num * num3 - num2 * num2;
		float num7 = num6;
		float num8 = num6;
		float num9;
		float num10;
		if (num6 < 1E-06f)
		{
			num9 = 0f;
			num7 = 1f;
			num10 = num5;
			num8 = num3;
		}
		else
		{
			num9 = num2 * num5 - num3 * num4;
			num10 = num * num5 - num2 * num4;
			if (num9 < 0f)
			{
				num9 = 0f;
				num10 = num5;
				num8 = num3;
			}
			else if (num9 > num7)
			{
				num9 = num7;
				num10 = num5 + num2;
				num8 = num3;
			}
		}
		if (num10 < 0f)
		{
			num10 = 0f;
			if (0f - num4 < 0f)
			{
				num9 = 0f;
			}
			else if (0f - num4 > num)
			{
				num9 = num7;
			}
			else
			{
				num9 = 0f - num4;
				num7 = num;
			}
		}
		else if (num10 > num8)
		{
			num10 = num8;
			if (0f - num4 + num2 < 0f)
			{
				num9 = 0f;
			}
			else if (0f - num4 + num2 > num)
			{
				num9 = num7;
			}
			else
			{
				num9 = 0f - num4 + num2;
				num7 = num;
			}
		}
		float num11 = ((!(Math.Abs(num9) < 1E-06f)) ? (num9 / num7) : 0f);
		float num12 = ((!(Math.Abs(num10) < 1E-06f)) ? (num10 / num8) : 0f);
		Vector3 val4 = val3 + num11 * val - num12 * val2;
		return val4.sqrMagnitude;
	}

	public static float SqrDistanceXZ(Vector3 a, Vector3 b)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = a - b;
		return val.x * val.x + val.z * val.z;
	}

	public static long SignedTriangleAreaTimes2XZ(Int3 a, Int3 b, Int3 c)
	{
		return (long)(b.x - a.x) * (long)(c.z - a.z) - (long)(c.x - a.x) * (long)(b.z - a.z);
	}

	public static float SignedTriangleAreaTimes2XZ(Vector3 a, Vector3 b, Vector3 c)
	{
		return (b.x - a.x) * (c.z - a.z) - (c.x - a.x) * (b.z - a.z);
	}

	public static bool RightXZ(Vector3 a, Vector3 b, Vector3 p)
	{
		return (b.x - a.x) * (p.z - a.z) - (p.x - a.x) * (b.z - a.z) < -float.Epsilon;
	}

	public static bool RightXZ(Int3 a, Int3 b, Int3 p)
	{
		return (long)(b.x - a.x) * (long)(p.z - a.z) - (long)(p.x - a.x) * (long)(b.z - a.z) < 0;
	}

	public static bool RightOrColinear(Vector2 a, Vector2 b, Vector2 p)
	{
		return (b.x - a.x) * (p.y - a.y) - (p.x - a.x) * (b.y - a.y) <= 0f;
	}

	public static bool RightOrColinear(Int2 a, Int2 b, Int2 p)
	{
		return (long)(b.x - a.x) * (long)(p.y - a.y) - (long)(p.x - a.x) * (long)(b.y - a.y) <= 0;
	}

	public static bool RightOrColinearXZ(Vector3 a, Vector3 b, Vector3 p)
	{
		return (b.x - a.x) * (p.z - a.z) - (p.x - a.x) * (b.z - a.z) <= 0f;
	}

	public static bool RightOrColinearXZ(Int3 a, Int3 b, Int3 p)
	{
		return (long)(b.x - a.x) * (long)(p.z - a.z) - (long)(p.x - a.x) * (long)(b.z - a.z) <= 0;
	}

	public static bool IsClockwiseMarginXZ(Vector3 a, Vector3 b, Vector3 c)
	{
		return (b.x - a.x) * (c.z - a.z) - (c.x - a.x) * (b.z - a.z) <= float.Epsilon;
	}

	public static bool IsClockwiseXZ(Vector3 a, Vector3 b, Vector3 c)
	{
		return (b.x - a.x) * (c.z - a.z) - (c.x - a.x) * (b.z - a.z) < 0f;
	}

	public static bool IsClockwiseXZ(Int3 a, Int3 b, Int3 c)
	{
		return RightXZ(a, b, c);
	}

	public static bool IsClockwiseOrColinearXZ(Int3 a, Int3 b, Int3 c)
	{
		return RightOrColinearXZ(a, b, c);
	}

	public static bool IsClockwiseOrColinear(Int2 a, Int2 b, Int2 c)
	{
		return RightOrColinear(a, b, c);
	}

	public static bool IsColinearXZ(Int3 a, Int3 b, Int3 c)
	{
		return (long)(b.x - a.x) * (long)(c.z - a.z) - (long)(c.x - a.x) * (long)(b.z - a.z) == 0;
	}

	public static bool IsColinearXZ(Vector3 a, Vector3 b, Vector3 c)
	{
		float num = (b.x - a.x) * (c.z - a.z) - (c.x - a.x) * (b.z - a.z);
		return num <= 1E-07f && num >= -1E-07f;
	}

	public static bool IsColinearAlmostXZ(Int3 a, Int3 b, Int3 c)
	{
		long num = (long)(b.x - a.x) * (long)(c.z - a.z) - (long)(c.x - a.x) * (long)(b.z - a.z);
		return num > -1 && num < 1;
	}

	public static bool SegmentsIntersect(Int2 start1, Int2 end1, Int2 start2, Int2 end2)
	{
		return RightOrColinear(start1, end1, start2) != RightOrColinear(start1, end1, end2) && RightOrColinear(start2, end2, start1) != RightOrColinear(start2, end2, end1);
	}

	public static bool SegmentsIntersectXZ(Int3 start1, Int3 end1, Int3 start2, Int3 end2)
	{
		return RightOrColinearXZ(start1, end1, start2) != RightOrColinearXZ(start1, end1, end2) && RightOrColinearXZ(start2, end2, start1) != RightOrColinearXZ(start2, end2, end1);
	}

	public static bool SegmentsIntersectXZ(Vector3 start1, Vector3 end1, Vector3 start2, Vector3 end2)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = end1 - start1;
		Vector3 val2 = end2 - start2;
		float num = val2.z * val.x - val2.x * val.z;
		if (num == 0f)
		{
			return false;
		}
		float num2 = val2.x * (start1.z - start2.z) - val2.z * (start1.x - start2.x);
		float num3 = val.x * (start1.z - start2.z) - val.z * (start1.x - start2.x);
		float num4 = num2 / num;
		float num5 = num3 / num;
		if (num4 < 0f || num4 > 1f || num5 < 0f || num5 > 1f)
		{
			return false;
		}
		return true;
	}

	public static Vector3 LineDirIntersectionPointXZ(Vector3 start1, Vector3 dir1, Vector3 start2, Vector3 dir2)
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		float num = dir2.z * dir1.x - dir2.x * dir1.z;
		if (num == 0f)
		{
			return start1;
		}
		float num2 = dir2.x * (start1.z - start2.z) - dir2.z * (start1.x - start2.x);
		float num3 = num2 / num;
		return start1 + dir1 * num3;
	}

	public static Vector3 LineDirIntersectionPointXZ(Vector3 start1, Vector3 dir1, Vector3 start2, Vector3 dir2, out bool intersects)
	{
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		float num = dir2.z * dir1.x - dir2.x * dir1.z;
		if (num == 0f)
		{
			intersects = false;
			return start1;
		}
		float num2 = dir2.x * (start1.z - start2.z) - dir2.z * (start1.x - start2.x);
		float num3 = num2 / num;
		intersects = true;
		return start1 + dir1 * num3;
	}

	public static bool RaySegmentIntersectXZ(Int3 start1, Int3 end1, Int3 start2, Int3 end2)
	{
		Int3 @int = end1 - start1;
		Int3 int2 = end2 - start2;
		long num = int2.z * @int.x - int2.x * @int.z;
		if (num == 0)
		{
			return false;
		}
		long num2 = int2.x * (start1.z - start2.z) - int2.z * (start1.x - start2.x);
		long num3 = @int.x * (start1.z - start2.z) - @int.z * (start1.x - start2.x);
		if (!((num2 < 0) ^ (num < 0)))
		{
			return false;
		}
		if (!((num3 < 0) ^ (num < 0)))
		{
			return false;
		}
		if ((num >= 0 && num3 > num) || (num < 0 && num3 <= num))
		{
			return false;
		}
		return true;
	}

	public static bool LineIntersectionFactorXZ(Int3 start1, Int3 end1, Int3 start2, Int3 end2, out float factor1, out float factor2)
	{
		Int3 @int = end1 - start1;
		Int3 int2 = end2 - start2;
		long num = int2.z * @int.x - int2.x * @int.z;
		if (num == 0)
		{
			factor1 = 0f;
			factor2 = 0f;
			return false;
		}
		long num2 = int2.x * (start1.z - start2.z) - int2.z * (start1.x - start2.x);
		long num3 = @int.x * (start1.z - start2.z) - @int.z * (start1.x - start2.x);
		factor1 = (float)num2 / (float)num;
		factor2 = (float)num3 / (float)num;
		return true;
	}

	public static bool LineIntersectionFactorXZ(Vector3 start1, Vector3 end1, Vector3 start2, Vector3 end2, out float factor1, out float factor2)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = end1 - start1;
		Vector3 val2 = end2 - start2;
		float num = val2.z * val.x - val2.x * val.z;
		if (num <= 1E-05f && num >= -1E-05f)
		{
			factor1 = 0f;
			factor2 = 0f;
			return false;
		}
		float num2 = val2.x * (start1.z - start2.z) - val2.z * (start1.x - start2.x);
		float num3 = val.x * (start1.z - start2.z) - val.z * (start1.x - start2.x);
		float num4 = num2 / num;
		float num5 = num3 / num;
		factor1 = num4;
		factor2 = num5;
		return true;
	}

	public static float LineRayIntersectionFactorXZ(Int3 start1, Int3 end1, Int3 start2, Int3 end2)
	{
		Int3 @int = end1 - start1;
		Int3 int2 = end2 - start2;
		int num = int2.z * @int.x - int2.x * @int.z;
		if (num == 0)
		{
			return float.NaN;
		}
		int num2 = int2.x * (start1.z - start2.z) - int2.z * (start1.x - start2.x);
		int num3 = @int.x * (start1.z - start2.z) - @int.z * (start1.x - start2.x);
		if ((float)num3 / (float)num < 0f)
		{
			return float.NaN;
		}
		return (float)num2 / (float)num;
	}

	public static float LineIntersectionFactorXZ(Vector3 start1, Vector3 end1, Vector3 start2, Vector3 end2)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = end1 - start1;
		Vector3 val2 = end2 - start2;
		float num = val2.z * val.x - val2.x * val.z;
		if (num == 0f)
		{
			return -1f;
		}
		float num2 = val2.x * (start1.z - start2.z) - val2.z * (start1.x - start2.x);
		return num2 / num;
	}

	public static Vector3 LineIntersectionPointXZ(Vector3 start1, Vector3 end1, Vector3 start2, Vector3 end2)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		bool intersects;
		return LineIntersectionPointXZ(start1, end1, start2, end2, out intersects);
	}

	public static Vector3 LineIntersectionPointXZ(Vector3 start1, Vector3 end1, Vector3 start2, Vector3 end2, out bool intersects)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = end1 - start1;
		Vector3 val2 = end2 - start2;
		float num = val2.z * val.x - val2.x * val.z;
		if (num == 0f)
		{
			intersects = false;
			return start1;
		}
		float num2 = val2.x * (start1.z - start2.z) - val2.z * (start1.x - start2.x);
		float num3 = num2 / num;
		intersects = true;
		return start1 + val * num3;
	}

	public static Vector2 LineIntersectionPoint(Vector2 start1, Vector2 end1, Vector2 start2, Vector2 end2)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		bool intersects;
		return LineIntersectionPoint(start1, end1, start2, end2, out intersects);
	}

	public static Vector2 LineIntersectionPoint(Vector2 start1, Vector2 end1, Vector2 start2, Vector2 end2, out bool intersects)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = end1 - start1;
		Vector2 val2 = end2 - start2;
		float num = val2.y * val.x - val2.x * val.y;
		if (num == 0f)
		{
			intersects = false;
			return start1;
		}
		float num2 = val2.x * (start1.y - start2.y) - val2.y * (start1.x - start2.x);
		float num3 = num2 / num;
		intersects = true;
		return start1 + val * num3;
	}

	public static Vector3 SegmentIntersectionPointXZ(Vector3 start1, Vector3 end1, Vector3 start2, Vector3 end2, out bool intersects)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = end1 - start1;
		Vector3 val2 = end2 - start2;
		float num = val2.z * val.x - val2.x * val.z;
		if (num == 0f)
		{
			intersects = false;
			return start1;
		}
		float num2 = val2.x * (start1.z - start2.z) - val2.z * (start1.x - start2.x);
		float num3 = val.x * (start1.z - start2.z) - val.z * (start1.x - start2.x);
		float num4 = num2 / num;
		float num5 = num3 / num;
		if (num4 < 0f || num4 > 1f || num5 < 0f || num5 > 1f)
		{
			intersects = false;
			return start1;
		}
		intersects = true;
		return start1 + val * num4;
	}

	public static bool SegmentIntersectsBounds(Bounds bounds, Vector3 a, Vector3 b)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		a -= bounds.center;
		b -= bounds.center;
		Vector3 val = (a + b) * 0.5f;
		Vector3 val2 = a - val;
		Vector3 val3 = new Vector3(Math.Abs(val2.x), Math.Abs(val2.y), Math.Abs(val2.z));
		Vector3 extents = bounds.extents;
		if (Math.Abs(val.x) > extents.x + val3.x)
		{
			return false;
		}
		if (Math.Abs(val.y) > extents.y + val3.y)
		{
			return false;
		}
		if (Math.Abs(val.z) > extents.z + val3.z)
		{
			return false;
		}
		if (Math.Abs(val.y * val2.z - val.z * val2.y) > extents.y * val3.z + extents.z * val3.y)
		{
			return false;
		}
		if (Math.Abs(val.x * val2.z - val.z * val2.x) > extents.x * val3.z + extents.z * val3.x)
		{
			return false;
		}
		if (Math.Abs(val.x * val2.y - val.y * val2.x) > extents.x * val3.y + extents.y * val3.x)
		{
			return false;
		}
		return true;
	}

	public static bool ReversesFaceOrientations(Matrix4x4 matrix)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = matrix.MultiplyVector(new Vector3(1f, 0f, 0f));
		Vector3 val2 = matrix.MultiplyVector(new Vector3(0f, 1f, 0f));
		Vector3 val3 = matrix.MultiplyVector(new Vector3(0f, 0f, 1f));
		float num = Vector3.Dot(Vector3.Cross(val, val2), val3);
		return num < 0f;
	}
}
