using UnityEngine;

namespace Pathfinding;

public struct GraphHitInfo(Vector3 point)
{
	public Vector3 origin = Vector3.zero;

	public Vector3 point = point;

	public GraphNode node = null;

	public Vector3 tangentOrigin = Vector3.zero;

	public Vector3 tangent = Vector3.zero;

	public float distance
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			Vector3 val = point - origin;
			return val.magnitude;
		}
	}
}
