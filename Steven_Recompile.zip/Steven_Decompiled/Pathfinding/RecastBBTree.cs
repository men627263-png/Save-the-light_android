using System;
using System.Collections.Generic;
using UnityEngine;

namespace Pathfinding;

public class RecastBBTree
{
	public RecastBBTreeBox root;

	public void QueryInBounds(Rect bounds, List<RecastMeshObj> buffer)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		RecastBBTreeBox recastBBTreeBox = root;
		if (recastBBTreeBox != null)
		{
			QueryBoxInBounds(recastBBTreeBox, bounds, buffer);
		}
	}

	private void QueryBoxInBounds(RecastBBTreeBox box, Rect bounds, List<RecastMeshObj> boxes)
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)box.mesh != (Object)null)
		{
			if (RectIntersectsRect(box.rect, bounds))
			{
				boxes.Add(box.mesh);
			}
			return;
		}
		if (RectIntersectsRect(box.c1.rect, bounds))
		{
			QueryBoxInBounds(box.c1, bounds, boxes);
		}
		if (RectIntersectsRect(box.c2.rect, bounds))
		{
			QueryBoxInBounds(box.c2, bounds, boxes);
		}
	}

	public bool Remove(RecastMeshObj mesh)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)mesh == (Object)null)
		{
			throw new ArgumentNullException("mesh");
		}
		if (root == null)
		{
			return false;
		}
		bool found = false;
		Bounds bounds = mesh.GetBounds();
		Rect bounds2 = Rect.MinMaxRect(bounds.min.x, bounds.min.z, bounds.max.x, bounds.max.z);
		root = RemoveBox(root, mesh, bounds2, ref found);
		return found;
	}

	private RecastBBTreeBox RemoveBox(RecastBBTreeBox c, RecastMeshObj mesh, Rect bounds, ref bool found)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		if (!RectIntersectsRect(c.rect, bounds))
		{
			return c;
		}
		if ((Object)(object)c.mesh == (Object)(object)mesh)
		{
			found = true;
			return null;
		}
		if ((Object)(object)c.mesh == (Object)null && !found)
		{
			c.c1 = RemoveBox(c.c1, mesh, bounds, ref found);
			if (c.c1 == null)
			{
				return c.c2;
			}
			if (!found)
			{
				c.c2 = RemoveBox(c.c2, mesh, bounds, ref found);
				if (c.c2 == null)
				{
					return c.c1;
				}
			}
			if (found)
			{
				c.rect = ExpandToContain(c.c1.rect, c.c2.rect);
			}
		}
		return c;
	}

	public void Insert(RecastMeshObj mesh)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		RecastBBTreeBox recastBBTreeBox = new RecastBBTreeBox(mesh);
		if (root == null)
		{
			root = recastBBTreeBox;
			return;
		}
		RecastBBTreeBox recastBBTreeBox2 = root;
		while (true)
		{
			recastBBTreeBox2.rect = ExpandToContain(recastBBTreeBox2.rect, recastBBTreeBox.rect);
			if ((Object)(object)recastBBTreeBox2.mesh != (Object)null)
			{
				break;
			}
			float num = ExpansionRequired(recastBBTreeBox2.c1.rect, recastBBTreeBox.rect);
			float num2 = ExpansionRequired(recastBBTreeBox2.c2.rect, recastBBTreeBox.rect);
			if (num < num2)
			{
				recastBBTreeBox2 = recastBBTreeBox2.c1;
			}
			else if (num2 < num)
			{
				recastBBTreeBox2 = recastBBTreeBox2.c2;
			}
			else
			{
				recastBBTreeBox2 = ((!(RectArea(recastBBTreeBox2.c1.rect) < RectArea(recastBBTreeBox2.c2.rect))) ? recastBBTreeBox2.c2 : recastBBTreeBox2.c1);
			}
		}
		recastBBTreeBox2.c1 = recastBBTreeBox;
		RecastBBTreeBox c = new RecastBBTreeBox(recastBBTreeBox2.mesh);
		recastBBTreeBox2.c2 = c;
		recastBBTreeBox2.mesh = null;
	}

	public void OnDrawGizmos()
	{
	}

	public void OnDrawGizmos(RecastBBTreeBox box)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		if (box != null)
		{
			Vector3 val = new Vector3(box.rect.xMin, 0f, box.rect.yMin);
			Vector3 val2 = new Vector3(box.rect.xMax, 0f, box.rect.yMax);
			Vector3 val3 = (val + val2) * 0.5f;
			Vector3 val4 = (val2 - val3) * 2f;
			Gizmos.DrawCube(val3, val4);
			OnDrawGizmos(box.c1);
			OnDrawGizmos(box.c2);
		}
	}

	private static bool RectIntersectsRect(Rect r, Rect r2)
	{
		return r.xMax > r2.xMin && r.yMax > r2.yMin && r2.xMax > r.xMin && r2.yMax > r.yMin;
	}

	private static bool RectIntersectsCircle(Rect r, Vector3 p, float radius)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		if (float.IsPositiveInfinity(radius))
		{
			return true;
		}
		if (RectContains(r, p))
		{
			return true;
		}
		return XIntersectsCircle(r.xMin, r.xMax, r.yMin, p, radius) || XIntersectsCircle(r.xMin, r.xMax, r.yMax, p, radius) || ZIntersectsCircle(r.yMin, r.yMax, r.xMin, p, radius) || ZIntersectsCircle(r.yMin, r.yMax, r.xMax, p, radius);
	}

	private static bool RectContains(Rect r, Vector3 p)
	{
		return p.x >= r.xMin && p.x <= r.xMax && p.z >= r.yMin && p.z <= r.yMax;
	}

	private static bool ZIntersectsCircle(float z1, float z2, float xpos, Vector3 circle, float radius)
	{
		double num = Math.Abs(xpos - circle.x) / radius;
		if (num > 1.0 || num < -1.0)
		{
			return false;
		}
		float num2 = (float)Math.Sqrt(1.0 - num * num) * radius;
		float val = circle.z - num2;
		num2 += circle.z;
		float num3 = Math.Min(num2, val);
		float num4 = Math.Max(num2, val);
		num3 = Mathf.Max(z1, num3);
		num4 = Mathf.Min(z2, num4);
		return num4 > num3;
	}

	private static bool XIntersectsCircle(float x1, float x2, float zpos, Vector3 circle, float radius)
	{
		double num = Math.Abs(zpos - circle.z) / radius;
		if (num > 1.0 || num < -1.0)
		{
			return false;
		}
		float num2 = (float)Math.Sqrt(1.0 - num * num) * radius;
		float val = circle.x - num2;
		num2 += circle.x;
		float num3 = Math.Min(num2, val);
		float num4 = Math.Max(num2, val);
		num3 = Mathf.Max(x1, num3);
		num4 = Mathf.Min(x2, num4);
		return num4 > num3;
	}

	private static float ExpansionRequired(Rect r, Rect r2)
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		float num = Mathf.Min(r.xMin, r2.xMin);
		float num2 = Mathf.Max(r.xMax, r2.xMax);
		float num3 = Mathf.Min(r.yMin, r2.yMin);
		float num4 = Mathf.Max(r.yMax, r2.yMax);
		return (num2 - num) * (num4 - num3) - RectArea(r);
	}

	private static Rect ExpandToContain(Rect r, Rect r2)
	{
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		float num = Mathf.Min(r.xMin, r2.xMin);
		float num2 = Mathf.Max(r.xMax, r2.xMax);
		float num3 = Mathf.Min(r.yMin, r2.yMin);
		float num4 = Mathf.Max(r.yMax, r2.yMax);
		return Rect.MinMaxRect(num, num3, num2, num4);
	}

	private static float RectArea(Rect r)
	{
		return r.width * r.height;
	}

	public new void ToString()
	{
		RecastBBTreeBox recastBBTreeBox = root;
		Stack<RecastBBTreeBox> stack = new Stack<RecastBBTreeBox>();
		stack.Push(recastBBTreeBox);
		recastBBTreeBox.WriteChildren(0);
	}
}
