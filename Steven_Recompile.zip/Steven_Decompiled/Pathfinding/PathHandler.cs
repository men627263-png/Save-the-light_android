using System;
using System.Collections.Generic;
using System.Text;

namespace Pathfinding;

public class PathHandler
{
	private ushort pathID;

	public readonly int threadID;

	public readonly int totalThreadCount;

	private BinaryHeapM heap = new BinaryHeapM(128);

	private const int BucketSizeLog2 = 10;

	private const int BucketSize = 1024;

	private const int BucketIndexMask = 1023;

	public List<PathNode[]> nodes = new List<PathNode[]>();

	private bool[] bucketNew = new bool[0];

	private bool[] bucketCreated = new bool[0];

	private Stack<PathNode[]> bucketCache = new Stack<PathNode[]>();

	private int filledBuckets;

	public readonly StringBuilder DebugStringBuilder = new StringBuilder();

	public ushort PathID => pathID;

	public PathHandler(int threadID, int totalThreadCount)
	{
		this.threadID = threadID;
		this.totalThreadCount = totalThreadCount;
	}

	public void PushNode(PathNode node)
	{
		heap.Add(node);
	}

	public PathNode PopNode()
	{
		return heap.Remove();
	}

	public BinaryHeapM GetHeap()
	{
		return heap;
	}

	public void RebuildHeap()
	{
		heap.Rebuild();
	}

	public bool HeapEmpty()
	{
		return heap.numberOfItems <= 0;
	}

	public void InitializeForPath(Path p)
	{
		pathID = p.pathID;
		heap.Clear();
	}

	public void DestroyNode(GraphNode node)
	{
		PathNode pathNode = GetPathNode(node);
		pathNode.node = null;
		pathNode.parent = null;
	}

	public void InitializeNode(GraphNode node)
	{
		int nodeIndex = node.NodeIndex;
		int num = nodeIndex >> 10;
		int num2 = nodeIndex & 0x3FF;
		if (num >= nodes.Count)
		{
			List<PathNode[]> list = new List<PathNode[]>();
			int num3 = Math.Max(Math.Max(nodes.Count * 3 / 2, num + 1), nodes.Count + 2);
			for (int i = 0; i < num3; i++)
			{
				list.Add(null);
			}
			for (int j = 0; j < nodes.Count; j++)
			{
				list[j] = nodes[j];
			}
			bool[] array = new bool[list.Count];
			for (int k = 0; k < nodes.Count; k++)
			{
				array[k] = bucketNew[k];
			}
			bool[] array2 = new bool[list.Count];
			for (int l = 0; l < nodes.Count; l++)
			{
				array2[l] = bucketCreated[l];
			}
			nodes = list;
			bucketNew = array;
			bucketCreated = array2;
		}
		if (nodes[num] == null)
		{
			PathNode[] array3;
			if (bucketCache.Count > 0)
			{
				array3 = bucketCache.Pop();
			}
			else
			{
				array3 = new PathNode[1024];
				for (int m = 0; m < 1024; m++)
				{
					array3[m] = new PathNode();
				}
			}
			nodes[num] = array3;
			if (!bucketCreated[num])
			{
				bucketNew[num] = true;
				bucketCreated[num] = true;
			}
			filledBuckets++;
		}
		PathNode pathNode = nodes[num][num2];
		pathNode.node = node;
	}

	public PathNode GetPathNode(int nodeIndex)
	{
		return nodes[nodeIndex >> 10][nodeIndex & 0x3FF];
	}

	public PathNode GetPathNode(GraphNode node)
	{
		int nodeIndex = node.NodeIndex;
		return nodes[nodeIndex >> 10][nodeIndex & 0x3FF];
	}

	public void ClearPathIDs()
	{
		for (int i = 0; i < nodes.Count; i++)
		{
			PathNode[] array = nodes[i];
			if (array != null)
			{
				for (int j = 0; j < 1024; j++)
				{
					array[j].pathID = 0;
				}
			}
		}
	}
}
