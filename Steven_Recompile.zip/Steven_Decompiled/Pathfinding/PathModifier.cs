using System;
using UnityEngine;

namespace Pathfinding;

[Serializable]
public abstract class PathModifier : IPathModifier
{
	[NonSerialized]
	public Seeker seeker;

	public abstract int Order { get; }

	public void Awake(Seeker s)
	{
		seeker = s;
		if ((Object)(object)s != (Object)null)
		{
			s.RegisterModifier(this);
		}
	}

	public void OnDestroy(Seeker s)
	{
		if ((Object)(object)s != (Object)null)
		{
			s.DeregisterModifier(this);
		}
	}

	public virtual void PreProcess(Path p)
	{
	}

	public abstract void Apply(Path p);
}
