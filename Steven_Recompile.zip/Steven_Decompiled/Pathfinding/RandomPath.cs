using System;
using UnityEngine;

namespace Pathfinding;

public class RandomPath : ABPath
{
	public int searchLength;

	public int spread;

	public bool uniform;

	public float aimStrength;

	private PathNode chosenNodeR;

	private PathNode maxGScoreNodeR;

	private int maxGScore;

	public Vector3 aim;

	private int nodesEvaluatedRep;

	private readonly Random rnd = new Random();

	public override bool FloodingPath => true;

	protected override bool hasEndPoint => false;

	public RandomPath()
	{
	}

	[Obsolete("This constructor is obsolete. Please use the pooling API and the Construct methods")]
	public RandomPath(Vector3 start, int length, OnPathDelegate callback = null)
	{
		throw new Exception("This constructor is obsolete. Please use the pooling API and the Setup methods");
	}

	public override void Reset()
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		base.Reset();
		searchLength = 5000;
		spread = 5000;
		uniform = true;
		aimStrength = 0f;
		chosenNodeR = null;
		maxGScoreNodeR = null;
		maxGScore = 0;
		aim = Vector3.zero;
		nodesEvaluatedRep = 0;
	}

	public static RandomPath Construct(Vector3 start, int length, OnPathDelegate callback = null)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		RandomPath randomPath = PathPool.GetPath<RandomPath>();
		randomPath.Setup(start, length, callback);
		return randomPath;
	}

	protected RandomPath Setup(Vector3 start, int length, OnPathDelegate callback)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		base.callback = callback;
		searchLength = length;
		originalStartPoint = start;
		originalEndPoint = Vector3.zero;
		startPoint = start;
		endPoint = Vector3.zero;
		startIntPoint = (Int3)start;
		return this;
	}

	public override void ReturnPath()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		if (path != null && path.Count > 0)
		{
			endNode = path[path.Count - 1];
			endPoint = (Vector3)endNode.position;
			originalEndPoint = endPoint;
			hTarget = endNode.position;
		}
		if (callback != null)
		{
			callback(this);
		}
	}

	public override void Prepare()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		nnConstraint.tags = enabledTags;
		NNInfo nearest = AstarPath.active.GetNearest(startPoint, nnConstraint, startHint);
		startPoint = nearest.clampedPosition;
		endPoint = startPoint;
		startIntPoint = (Int3)startPoint;
		hTarget = (Int3)aim;
		startNode = nearest.node;
		endNode = startNode;
		if (startNode == null || endNode == null)
		{
			LogError("Couldn't find close nodes to the start point");
			Error();
		}
		else if (!startNode.Walkable)
		{
			LogError("The node closest to the start point is not walkable");
			Error();
		}
		else
		{
			heuristicScale = aimStrength;
		}
	}

	public override void Initialize()
	{
		PathNode pathNode = pathHandler.GetPathNode(startNode);
		pathNode.node = startNode;
		if (searchLength + spread <= 0)
		{
			CompleteState = PathCompleteState.Complete;
			Trace(pathNode);
			return;
		}
		pathNode.pathID = pathID;
		pathNode.parent = null;
		pathNode.cost = 0u;
		pathNode.G = GetTraversalCost(startNode);
		pathNode.H = CalculateHScore(startNode);
		startNode.Open(this, pathNode, pathHandler);
		searchedNodes++;
		if (pathHandler.HeapEmpty())
		{
			LogError("No open points, the start node didn't open any nodes");
			Error();
		}
		else
		{
			currentR = pathHandler.PopNode();
		}
	}

	public override void CalculateStep(long targetTick)
	{
		int num = 0;
		while (CompleteState == PathCompleteState.NotCalculated)
		{
			searchedNodes++;
			if (currentR.G >= searchLength)
			{
				nodesEvaluatedRep++;
				if (chosenNodeR == null || rnd.NextDouble() <= (double)(1f / (float)nodesEvaluatedRep))
				{
					chosenNodeR = currentR;
				}
				if (currentR.G >= searchLength + spread)
				{
					CompleteState = PathCompleteState.Complete;
					break;
				}
			}
			else if (currentR.G > maxGScore)
			{
				maxGScore = (int)currentR.G;
				maxGScoreNodeR = currentR;
			}
			currentR.node.Open(this, currentR, pathHandler);
			if (pathHandler.HeapEmpty())
			{
				if (chosenNodeR != null)
				{
					CompleteState = PathCompleteState.Complete;
				}
				else if (maxGScoreNodeR != null)
				{
					chosenNodeR = maxGScoreNodeR;
					CompleteState = PathCompleteState.Complete;
				}
				else
				{
					LogError("Not a single node found to search");
					Error();
				}
				break;
			}
			currentR = pathHandler.PopNode();
			if (num > 500)
			{
				if (DateTime.UtcNow.Ticks >= targetTick)
				{
					return;
				}
				num = 0;
				if (searchedNodes > 1000000)
				{
					throw new Exception("Probable infinite loop. Over 1,000,000 nodes searched");
				}
			}
			num++;
		}
		if (CompleteState == PathCompleteState.Complete)
		{
			Trace(chosenNodeR);
		}
	}
}
