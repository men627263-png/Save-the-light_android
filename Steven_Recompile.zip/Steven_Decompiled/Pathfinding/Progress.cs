namespace Pathfinding;

public struct Progress(float p, string d)
{
	public float progress = p;

	public string description = d;
}
