using UnityEngine;

namespace Pathfinding;

public class GraphUpdateShape
{
	private Vector3[] _points;

	private Vector3[] _convexPoints;

	private bool _convex;

	public Vector3[] points
	{
		get
		{
			return _points;
		}
		set
		{
			_points = value;
			if (convex)
			{
				CalculateConvexHull();
			}
		}
	}

	public bool convex
	{
		get
		{
			return _convex;
		}
		set
		{
			if (_convex != value && value)
			{
				_convex = value;
				CalculateConvexHull();
			}
			else
			{
				_convex = value;
			}
		}
	}

	private void CalculateConvexHull()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		if (points == null)
		{
			_convexPoints = null;
			return;
		}
		_convexPoints = Polygon.ConvexHullXZ(points);
		for (int i = 0; i < _convexPoints.Length; i++)
		{
			Debug.DrawLine(_convexPoints[i], _convexPoints[(i + 1) % _convexPoints.Length], Color.green);
		}
	}

	public Bounds GetBounds()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		if (points == null || points.Length == 0)
		{
			return default;
		}
		Vector3 val = points[0];
		Vector3 val2 = points[0];
		for (int i = 0; i < points.Length; i++)
		{
			val = Vector3.Min(val, points[i]);
			val2 = Vector3.Max(val2, points[i]);
		}
		return new Bounds((val + val2) * 0.5f, val2 - val);
	}

	public bool Contains(GraphNode node)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		return Contains((Vector3)node.position);
	}

	public bool Contains(Vector3 point)
	{
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		if (convex)
		{
			if (_convexPoints == null)
			{
				return false;
			}
			int i = 0;
			int num = _convexPoints.Length - 1;
			for (; i < _convexPoints.Length; i++)
			{
				if (VectorMath.RightOrColinearXZ(_convexPoints[i], _convexPoints[num], point))
				{
					return false;
				}
				num = i;
			}
			return true;
		}
		return _points != null && Polygon.ContainsPointXZ(_points, point);
	}
}
