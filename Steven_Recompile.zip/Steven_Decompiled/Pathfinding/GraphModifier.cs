using UnityEngine;

namespace Pathfinding;

public abstract class GraphModifier : MonoBehaviour
{
	public enum EventType
	{
		PostScan = 1,
		PreScan = 2,
		LatePostScan = 4,
		PreUpdate = 8,
		PostUpdate = 0x10,
		PostCacheLoad = 0x20,
		PostUpdatePreFloodFill = 0x40,
		PostFloodFill = 0x80
	}

	private static GraphModifier root;

	private GraphModifier prev;

	private GraphModifier next;

	public static void FindAllModifiers()
	{
		GraphModifier[] array = Object.FindObjectsOfType(typeof(GraphModifier)) as GraphModifier[];
		for (int i = 0; i < array.Length; i++)
		{
			array[i].OnEnable();
		}
	}

	public static void TriggerEvent(EventType type)
	{
		if (!Application.isPlaying)
		{
			FindAllModifiers();
		}
		GraphModifier graphModifier = root;
		switch (type)
		{
		default:
			return;
		case EventType.PreScan:
			while ((Object)(object)graphModifier != (Object)null)
			{
				graphModifier.OnPreScan();
				graphModifier = graphModifier.next;
			}
			return;
		case EventType.PostScan:
			while ((Object)(object)graphModifier != (Object)null)
			{
				graphModifier.OnPostScan();
				graphModifier = graphModifier.next;
			}
			return;
		case EventType.LatePostScan:
			while ((Object)(object)graphModifier != (Object)null)
			{
				graphModifier.OnLatePostScan();
				graphModifier = graphModifier.next;
			}
			return;
		case EventType.PreUpdate:
			while ((Object)(object)graphModifier != (Object)null)
			{
				graphModifier.OnGraphsPreUpdate();
				graphModifier = graphModifier.next;
			}
			return;
		case EventType.PostUpdate:
			while ((Object)(object)graphModifier != (Object)null)
			{
				graphModifier.OnGraphsPostUpdate();
				graphModifier = graphModifier.next;
			}
			return;
		case EventType.PostCacheLoad:
			while ((Object)(object)graphModifier != (Object)null)
			{
				graphModifier.OnPostCacheLoad();
				graphModifier = graphModifier.next;
			}
			return;
		case EventType.PostFloodFill:
			break;
		}
		while ((Object)(object)graphModifier != (Object)null)
		{
			graphModifier.OnPostFloodFill();
			graphModifier = graphModifier.next;
		}
	}

	protected virtual void OnEnable()
	{
		OnDisable();
		if ((Object)(object)root == (Object)null)
		{
			root = this;
			return;
		}
		next = root;
		root.prev = this;
		root = this;
	}

	protected virtual void OnDisable()
	{
		if ((Object)(object)root == (Object)(object)this)
		{
			root = next;
			if ((Object)(object)root != (Object)null)
			{
				root.prev = null;
			}
		}
		else
		{
			if ((Object)(object)prev != (Object)null)
			{
				prev.next = next;
			}
			if ((Object)(object)next != (Object)null)
			{
				next.prev = prev;
			}
		}
		prev = null;
		next = null;
	}

	public virtual void OnPostScan()
	{
	}

	public virtual void OnPreScan()
	{
	}

	public virtual void OnLatePostScan()
	{
	}

	public virtual void OnPostCacheLoad()
	{
	}

	public virtual void OnGraphsPreUpdate()
	{
	}

	public virtual void OnGraphsPostUpdate()
	{
	}

	public virtual void OnGraphsPostUpdatePreFloodFill()
	{
	}

	public virtual void OnPostFloodFill()
	{
	}
}
