using System;
using System.Collections.Generic;
using Pathfinding.Util;
using UnityEngine;

namespace Pathfinding;

public static class PathUtilities
{
	private static Queue<GraphNode> BFSQueue;

	private static Dictionary<GraphNode, int> BFSMap;

	public static bool IsPathPossible(GraphNode n1, GraphNode n2)
	{
		return n1.Walkable && n2.Walkable && n1.Area == n2.Area;
	}

	public static bool IsPathPossible(List<GraphNode> nodes)
	{
		if (nodes.Count == 0)
		{
			return true;
		}
		uint area = nodes[0].Area;
		for (int i = 0; i < nodes.Count; i++)
		{
			if (!nodes[i].Walkable || nodes[i].Area != area)
			{
				return false;
			}
		}
		return true;
	}

	public static bool IsPathPossible(List<GraphNode> nodes, int tagMask)
	{
		if (nodes.Count == 0)
		{
			return true;
		}
		if (((tagMask >> (int)nodes[0].Tag) & 1) == 0)
		{
			return false;
		}
		if (!IsPathPossible(nodes))
		{
			return false;
		}
		List<GraphNode> reachableNodes = GetReachableNodes(nodes[0], tagMask);
		bool result = true;
		for (int i = 1; i < nodes.Count; i++)
		{
			if (!reachableNodes.Contains(nodes[i]))
			{
				result = false;
				break;
			}
		}
		ListPool<GraphNode>.Release(reachableNodes);
		return result;
	}

	public static List<GraphNode> GetReachableNodes(GraphNode seed, int tagMask = -1)
	{
		Stack<GraphNode> stack = StackPool<GraphNode>.Claim();
		List<GraphNode> list = ListPool<GraphNode>.Claim();
		HashSet<GraphNode> map = new HashSet<GraphNode>();
		GraphNodeDelegate graphNodeDelegate = ((tagMask != -1) ? ((GraphNodeDelegate)((GraphNode node) =>
		{
			if (node.Walkable && ((tagMask >> (int)node.Tag) & 1) != 0 && map.Add(node))
			{
				list.Add(node);
				stack.Push(node);
			}
		})) : ((GraphNodeDelegate)((GraphNode node) =>
		{
			if (node.Walkable && map.Add(node))
			{
				list.Add(node);
				stack.Push(node);
			}
		})));
		graphNodeDelegate(seed);
		while (stack.Count > 0)
		{
			stack.Pop().GetConnections(graphNodeDelegate);
		}
		StackPool<GraphNode>.Release(stack);
		return list;
	}

	public static List<GraphNode> BFS(GraphNode seed, int depth, int tagMask = -1)
	{
		BFSQueue = BFSQueue ?? new Queue<GraphNode>();
		Queue<GraphNode> que = BFSQueue;
		BFSMap = BFSMap ?? new Dictionary<GraphNode, int>();
		Dictionary<GraphNode, int> map = BFSMap;
		que.Clear();
		map.Clear();
		List<GraphNode> result = ListPool<GraphNode>.Claim();
		int currentDist = -1;
		GraphNodeDelegate graphNodeDelegate = ((tagMask != -1) ? ((GraphNodeDelegate)((GraphNode node) =>
		{
			if (node.Walkable && ((tagMask >> (int)node.Tag) & 1) != 0 && !map.ContainsKey(node))
			{
				map.Add(node, currentDist + 1);
				result.Add(node);
				que.Enqueue(node);
			}
		})) : ((GraphNodeDelegate)((GraphNode node) =>
		{
			if (node.Walkable && !map.ContainsKey(node))
			{
				map.Add(node, currentDist + 1);
				result.Add(node);
				que.Enqueue(node);
			}
		})));
		graphNodeDelegate(seed);
		while (que.Count > 0)
		{
			GraphNode graphNode = que.Dequeue();
			currentDist = map[graphNode];
			if (currentDist >= depth)
			{
				break;
			}
			graphNode.GetConnections(graphNodeDelegate);
		}
		que.Clear();
		map.Clear();
		return result;
	}

	public static List<Vector3> GetSpiralPoints(int count, float clearance)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		List<Vector3> list = ListPool<Vector3>.Claim(count);
		float num = clearance / ((float)Math.PI * 2f);
		float num2 = 0f;
		list.Add(InvoluteOfCircle(num, num2));
		for (int i = 0; i < count; i++)
		{
			Vector3 val = list[list.Count - 1];
			float num3 = (0f - num2) / 2f + Mathf.Sqrt(num2 * num2 / 4f + 2f * clearance / num);
			float num4 = num2 + num3;
			float num5 = num2 + 2f * num3;
			while (num5 - num4 > 0.01f)
			{
				float num6 = (num4 + num5) / 2f;
				Vector3 val2 = InvoluteOfCircle(num, num6);
				Vector3 val3 = val2 - val;
				if (val3.sqrMagnitude < clearance * clearance)
				{
					num4 = num6;
				}
				else
				{
					num5 = num6;
				}
			}
			list.Add(InvoluteOfCircle(num, num5));
			num2 = num5;
		}
		return list;
	}

	private static Vector3 InvoluteOfCircle(float a, float t)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		return new Vector3(a * (Mathf.Cos(t) + t * Mathf.Sin(t)), 0f, a * (Mathf.Sin(t) - t * Mathf.Cos(t)));
	}

	public static void GetPointsAroundPointWorld(Vector3 p, IRaycastableGraph g, List<Vector3> previousPoints, float radius, float clearanceRadius)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		if (previousPoints.Count != 0)
		{
			Vector3 val = Vector3.zero;
			for (int i = 0; i < previousPoints.Count; i++)
			{
				val += previousPoints[i];
			}
			val /= (float)previousPoints.Count;
			for (int j = 0; j < previousPoints.Count; j++)
			{
				List<Vector3> list;
				int index;
				(list = previousPoints)[index = j] = list[index] - val;
			}
			GetPointsAroundPoint(p, g, previousPoints, radius, clearanceRadius);
		}
	}

	public static void GetPointsAroundPoint(Vector3 p, IRaycastableGraph g, List<Vector3> previousPoints, float radius, float clearanceRadius)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		if (g == null)
		{
			throw new ArgumentNullException("g");
		}
		if (!(g is NavGraph navGraph))
		{
			throw new ArgumentException("g is not a NavGraph");
		}
		NNInfo nearestForce = navGraph.GetNearestForce(p, NNConstraint.Default);
		p = nearestForce.clampedPosition;
		if (nearestForce.node == null)
		{
			return;
		}
		radius = Mathf.Max(radius, 1.4142f * clearanceRadius * Mathf.Sqrt((float)previousPoints.Count));
		clearanceRadius *= clearanceRadius;
		for (int i = 0; i < previousPoints.Count; i++)
		{
			Vector3 val = previousPoints[i];
			float magnitude = val.magnitude;
			if (magnitude > 0f)
			{
				val /= magnitude;
			}
			float num = radius;
			val *= num;
			bool flag = false;
			int num2 = 0;
			do
			{
				Vector3 val2 = p + val;
				if (g.Linecast(p, val2, nearestForce.node, out var hit))
				{
					val2 = hit.point;
				}
				for (float num3 = 0.1f; num3 <= 1f; num3 += 0.05f)
				{
					Vector3 val3 = (val2 - p) * num3 + p;
					flag = true;
					for (int j = 0; j < i; j++)
					{
						Vector3 val4 = previousPoints[j] - val3;
						if (val4.sqrMagnitude < clearanceRadius)
						{
							flag = false;
							break;
						}
					}
					if (flag)
					{
						previousPoints[i] = val3;
						break;
					}
				}
				if (!flag)
				{
					if (num2 > 8)
					{
						flag = true;
						continue;
					}
					clearanceRadius *= 0.9f;
					val = Random.onUnitSphere * Mathf.Lerp(num, radius, (float)(num2 / 5));
					val.y = 0f;
					num2++;
				}
			}
			while (!flag);
		}
	}

	public static List<Vector3> GetPointsOnNodes(List<GraphNode> nodes, int count, float clearanceRadius = 0f)
	{
		//IL_0369: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_029a: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0317: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		if (nodes == null)
		{
			throw new ArgumentNullException("nodes");
		}
		if (nodes.Count == 0)
		{
			throw new ArgumentException("no nodes passed");
		}
		Random random = new Random();
		List<Vector3> list = ListPool<Vector3>.Claim(count);
		clearanceRadius *= clearanceRadius;
		if (nodes[0] is TriangleMeshNode || nodes[0] is GridNode)
		{
			List<float> list2 = ListPool<float>.Claim(nodes.Count);
			float num = 0f;
			for (int i = 0; i < nodes.Count; i++)
			{
				if (nodes[i] is TriangleMeshNode triangleMeshNode)
				{
					float num2 = Math.Abs(VectorMath.SignedTriangleAreaTimes2XZ(triangleMeshNode.GetVertex(0), triangleMeshNode.GetVertex(1), triangleMeshNode.GetVertex(2)));
					num += num2;
					list2.Add(num);
				}
				else if (nodes[i] is GridNode gridNode)
				{
					GridGraph gridGraph = GridNode.GetGridGraph(gridNode.GraphIndex);
					float num3 = gridGraph.nodeSize * gridGraph.nodeSize;
					num += num3;
					list2.Add(num);
				}
				else
				{
					list2.Add(num);
				}
			}
			for (int j = 0; j < count; j++)
			{
				int num4 = 0;
				int num5 = 10;
				bool flag = false;
				while (!flag)
				{
					flag = true;
					if (num4 >= num5)
					{
						clearanceRadius *= 0.8f;
						num5 += 10;
						if (num5 > 100)
						{
							clearanceRadius = 0f;
						}
					}
					float item = (float)random.NextDouble() * num;
					int num6 = list2.BinarySearch(item);
					if (num6 < 0)
					{
						num6 = ~num6;
					}
					if (num6 >= nodes.Count)
					{
						flag = false;
						continue;
					}
					Vector3 val;
					if (nodes[num6] is TriangleMeshNode triangleMeshNode2)
					{
						float num7;
						float num8;
						do
						{
							num7 = (float)random.NextDouble();
							num8 = (float)random.NextDouble();
						}
						while (num7 + num8 > 1f);
						val = (Vector3)(triangleMeshNode2.GetVertex(1) - triangleMeshNode2.GetVertex(0)) * num7 + (Vector3)(triangleMeshNode2.GetVertex(2) - triangleMeshNode2.GetVertex(0)) * num8 + (Vector3)triangleMeshNode2.GetVertex(0);
					}
					else
					{
						if (!(nodes[num6] is GridNode gridNode2))
						{
							list.Add((Vector3)nodes[num6].position);
							break;
						}
						GridGraph gridGraph2 = GridNode.GetGridGraph(gridNode2.GraphIndex);
						float num9 = (float)random.NextDouble();
						float num10 = (float)random.NextDouble();
						val = (Vector3)gridNode2.position + new Vector3(num9 - 0.5f, 0f, num10 - 0.5f) * gridGraph2.nodeSize;
					}
					if (clearanceRadius > 0f)
					{
						for (int k = 0; k < list.Count; k++)
						{
							Vector3 val2 = list[k] - val;
							if (val2.sqrMagnitude < clearanceRadius)
							{
								flag = false;
								break;
							}
						}
					}
					if (flag)
					{
						list.Add(val);
						break;
					}
					num4++;
				}
			}
			ListPool<float>.Release(list2);
		}
		else
		{
			for (int l = 0; l < count; l++)
			{
				list.Add((Vector3)nodes[random.Next(nodes.Count)].position);
			}
		}
		return list;
	}
}
