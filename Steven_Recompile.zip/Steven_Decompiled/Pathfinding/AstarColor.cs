using System;
using UnityEngine;

namespace Pathfinding;

[Serializable]
public class AstarColor
{
	public Color _NodeConnection;

	public Color _UnwalkableNode;

	public Color _BoundsHandles;

	public Color _ConnectionLowLerp;

	public Color _ConnectionHighLerp;

	public Color _MeshEdgeColor;

	public Color _MeshColor;

	public Color[] _AreaColors;

	public static Color NodeConnection = new Color(1f, 1f, 1f, 0.9f);

	public static Color UnwalkableNode = new Color(1f, 0f, 0f, 0.5f);

	public static Color BoundsHandles = new Color(0.29f, 0.454f, 0.741f, 0.9f);

	public static Color ConnectionLowLerp = new Color(0f, 1f, 0f, 0.5f);

	public static Color ConnectionHighLerp = new Color(1f, 0f, 0f, 0.5f);

	public static Color MeshEdgeColor = new Color(0f, 0f, 0f, 0.5f);

	public static Color MeshColor = new Color(0f, 0f, 0f, 0.5f);

	private static Color[] AreaColors;

	public AstarColor()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		_NodeConnection = new Color(1f, 1f, 1f, 0.9f);
		_UnwalkableNode = new Color(1f, 0f, 0f, 0.5f);
		_BoundsHandles = new Color(0.29f, 0.454f, 0.741f, 0.9f);
		_ConnectionLowLerp = new Color(0f, 1f, 0f, 0.5f);
		_ConnectionHighLerp = new Color(1f, 0f, 0f, 0.5f);
		_MeshEdgeColor = new Color(0f, 0f, 0f, 0.5f);
		_MeshColor = new Color(0.125f, 0.686f, 0f, 0.19f);
	}

	public static Color GetAreaColor(uint area)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		if (AreaColors == null || area >= AreaColors.Length)
		{
			return AstarMath.IntToColor((int)area, 1f);
		}
		return AreaColors[area];
	}

	public void OnEnable()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		NodeConnection = _NodeConnection;
		UnwalkableNode = _UnwalkableNode;
		BoundsHandles = _BoundsHandles;
		ConnectionLowLerp = _ConnectionLowLerp;
		ConnectionHighLerp = _ConnectionHighLerp;
		MeshEdgeColor = _MeshEdgeColor;
		MeshColor = _MeshColor;
		AreaColors = _AreaColors;
	}

	static AstarColor()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
	}
}
