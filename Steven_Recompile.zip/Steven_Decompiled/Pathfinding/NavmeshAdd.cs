using System.Collections.Generic;
using Pathfinding.Util;
using UnityEngine;

namespace Pathfinding;

[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_navmesh_add.php")]
public class NavmeshAdd : MonoBehaviour
{
	public enum MeshType
	{
		Rectangle,
		CustomMesh
	}

	private static List<NavmeshAdd> allCuts = new List<NavmeshAdd>();

	public MeshType type;

	public Mesh mesh;

	private Vector3[] verts;

	private int[] tris;

	public Vector2 rectangleSize = new Vector2(1f, 1f);

	public float meshScale = 1f;

	public Vector3 center;

	private Bounds bounds;

	public bool useRotation;

	protected Transform tr;

	public static readonly Color GizmoColor = new Color(94f / 255f, 239f / 255f, 37f / 255f);

	public Vector3 Center
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			return tr.position + ((!useRotation) ? center : tr.TransformPoint(center));
		}
	}

	public NavmeshAdd()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
	}

	private static void Add(NavmeshAdd obj)
	{
		allCuts.Add(obj);
	}

	private static void Remove(NavmeshAdd obj)
	{
		allCuts.Remove(obj);
	}

	public static List<NavmeshAdd> GetAllInRange(Bounds b)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		List<NavmeshAdd> list = ListPool<NavmeshAdd>.Claim();
		for (int i = 0; i < allCuts.Count; i++)
		{
			if (((Behaviour)allCuts[i]).enabled && Intersects(b, allCuts[i].GetBounds()))
			{
				list.Add(allCuts[i]);
			}
		}
		return list;
	}

	private static bool Intersects(Bounds b1, Bounds b2)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		Vector3 min = b1.min;
		Vector3 max = b1.max;
		Vector3 min2 = b2.min;
		Vector3 max2 = b2.max;
		return min.x <= max2.x && max.x >= min2.x && min.z <= max2.z && max.z >= min2.z;
	}

	public static List<NavmeshAdd> GetAll()
	{
		return allCuts;
	}

	public void Awake()
	{
		Add(this);
	}

	public void OnEnable()
	{
		tr = ((Component)this).transform;
	}

	public void OnDestroy()
	{
		Remove(this);
	}

	[ContextMenu("Rebuild Mesh")]
	public void RebuildMesh()
	{
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		if (type == MeshType.CustomMesh)
		{
			if ((Object)(object)mesh == (Object)null)
			{
				verts = null;
				tris = null;
			}
			else
			{
				verts = mesh.vertices;
				tris = mesh.triangles;
			}
			return;
		}
		if (verts == null || verts.Length != 4 || tris == null || tris.Length != 6)
		{
			verts = new Vector3[4];
			tris = new int[6];
		}
		tris[0] = 0;
		tris[1] = 1;
		tris[2] = 2;
		tris[3] = 0;
		tris[4] = 2;
		tris[5] = 3;
		ref Vector3 reference = ref verts[0];
		reference = new Vector3((0f - rectangleSize.x) * 0.5f, 0f, (0f - rectangleSize.y) * 0.5f);
		ref Vector3 reference2 = ref verts[1];
		reference2 = new Vector3(rectangleSize.x * 0.5f, 0f, (0f - rectangleSize.y) * 0.5f);
		ref Vector3 reference3 = ref verts[2];
		reference3 = new Vector3(rectangleSize.x * 0.5f, 0f, rectangleSize.y * 0.5f);
		ref Vector3 reference4 = ref verts[3];
		reference4 = new Vector3((0f - rectangleSize.x) * 0.5f, 0f, rectangleSize.y * 0.5f);
	}

	public Bounds GetBounds()
	{
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_037e: Unknown result type (might be due to invalid IL or missing references)
		//IL_032c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_034b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		//IL_0357: Unknown result type (might be due to invalid IL or missing references)
		//IL_0362: Unknown result type (might be due to invalid IL or missing references)
		//IL_0367: Unknown result type (might be due to invalid IL or missing references)
		//IL_036c: Unknown result type (might be due to invalid IL or missing references)
		//IL_036e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0373: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		switch (type)
		{
		case MeshType.Rectangle:
			if (useRotation)
			{
				Matrix4x4 val4 = Matrix4x4.TRS(tr.position, tr.rotation, Vector3.one);
				bounds = new Bounds(val4.MultiplyPoint3x4(center + new Vector3(0f - rectangleSize.x, 0f, 0f - rectangleSize.y) * 0.5f), Vector3.zero);
				bounds.Encapsulate(val4.MultiplyPoint3x4(center + new Vector3(rectangleSize.x, 0f, 0f - rectangleSize.y) * 0.5f));
				bounds.Encapsulate(val4.MultiplyPoint3x4(center + new Vector3(rectangleSize.x, 0f, rectangleSize.y) * 0.5f));
				bounds.Encapsulate(val4.MultiplyPoint3x4(center + new Vector3(0f - rectangleSize.x, 0f, rectangleSize.y) * 0.5f));
			}
			else
			{
				bounds = new Bounds(tr.position + center, new Vector3(rectangleSize.x, 0f, rectangleSize.y));
			}
			break;
		case MeshType.CustomMesh:
			if (!((Object)(object)mesh == (Object)null))
			{
				Bounds val = mesh.bounds;
				if (useRotation)
				{
					Matrix4x4 val2 = Matrix4x4.TRS(tr.position, tr.rotation, Vector3.one * meshScale);
					bounds = new Bounds(val2.MultiplyPoint3x4(center + val.center), Vector3.zero);
					Vector3 max = val.max;
					Vector3 min = val.min;
					bounds.Encapsulate(val2.MultiplyPoint3x4(center + new Vector3(max.x, min.y, max.z)));
					bounds.Encapsulate(val2.MultiplyPoint3x4(center + new Vector3(min.x, min.y, max.z)));
					bounds.Encapsulate(val2.MultiplyPoint3x4(center + new Vector3(min.x, max.y, min.z)));
					bounds.Encapsulate(val2.MultiplyPoint3x4(center + new Vector3(max.x, max.y, min.z)));
				}
				else
				{
					Vector3 val3 = val.size * meshScale;
					bounds = new Bounds(((Component)this).transform.position + center + val.center * meshScale, val3);
				}
			}
			break;
		}
		return bounds;
	}

	public void GetMesh(Int3 offset, ref Int3[] vbuffer, out int[] tbuffer)
	{
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		if (verts == null)
		{
			RebuildMesh();
		}
		if (verts == null)
		{
			tbuffer = new int[0];
			return;
		}
		if (vbuffer == null || vbuffer.Length < verts.Length)
		{
			vbuffer = new Int3[verts.Length];
		}
		tbuffer = tris;
		if (useRotation)
		{
			Matrix4x4 val = Matrix4x4.TRS(tr.position + center, tr.rotation, tr.localScale * meshScale);
			for (int i = 0; i < verts.Length; i++)
			{
				ref Int3 reference = ref vbuffer[i];
				reference = offset + (Int3)val.MultiplyPoint3x4(verts[i]);
			}
		}
		else
		{
			Vector3 val2 = tr.position + center;
			for (int j = 0; j < verts.Length; j++)
			{
				ref Int3 reference2 = ref vbuffer[j];
				reference2 = offset + (Int3)(val2 + verts[j] * meshScale);
			}
		}
	}

	static NavmeshAdd()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
	}
}
