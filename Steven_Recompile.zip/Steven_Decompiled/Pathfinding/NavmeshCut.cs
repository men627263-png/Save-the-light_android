using System;
using System.Collections.Generic;
using Pathfinding.ClipperLib;
using Pathfinding.Util;
using UnityEngine;

namespace Pathfinding;

[AddComponentMenu("Pathfinding/Navmesh/Navmesh Cut")]
[HelpURL("http://arongranberg.com/astar/docs/class_pathfinding_1_1_navmesh_cut.php")]
public class NavmeshCut : MonoBehaviour
{
	public enum MeshType
	{
		Rectangle,
		Circle,
		CustomMesh
	}

	private static List<NavmeshCut> allCuts = new List<NavmeshCut>();

	public MeshType type;

	public Mesh mesh;

	public Vector2 rectangleSize = new Vector2(1f, 1f);

	public float circleRadius = 1f;

	public int circleResolution = 6;

	public float height = 1f;

	public float meshScale = 1f;

	public Vector3 center;

	public float updateDistance = 0.4f;

	public bool isDual;

	public bool cutsAddedGeom = true;

	public float updateRotationDistance = 10f;

	public bool useRotation;

	private List<Vector3[]> contours;

	protected Transform tr;

	private Mesh lastMesh;

	private Vector3 lastPosition;

	private Quaternion lastRotation;

	private bool wasEnabled;

	private Bounds lastBounds;

	private static readonly Dictionary<Int2, int> edges = new Dictionary<Int2, int>();

	private static readonly Dictionary<int, int> pointers = new Dictionary<int, int>();

	public static readonly Color GizmoColor = new Color(37f / 255f, 184f / 255f, 239f / 255f);

	public Bounds LastBounds
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return lastBounds;
		}
	}

	public static event Action<NavmeshCut> OnDestroyCallback;

	public NavmeshCut()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
	}

	private static void AddCut(NavmeshCut obj)
	{
		allCuts.Add(obj);
	}

	private static void RemoveCut(NavmeshCut obj)
	{
		allCuts.Remove(obj);
	}

	public static List<NavmeshCut> GetAllInRange(Bounds b)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		List<NavmeshCut> list = ListPool<NavmeshCut>.Claim();
		for (int i = 0; i < allCuts.Count; i++)
		{
			if (((Behaviour)allCuts[i]).enabled && ((Component)allCuts[i]).gameObject.activeInHierarchy && Intersects(b, allCuts[i].GetBounds()))
			{
				list.Add(allCuts[i]);
			}
		}
		return list;
	}

	private static bool Intersects(Bounds b1, Bounds b2)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		Vector3 min = b1.min;
		Vector3 max = b1.max;
		Vector3 min2 = b2.min;
		Vector3 max2 = b2.max;
		return min.x <= max2.x && max.x >= min2.x && min.y <= max2.y && max.y >= min2.y && min.z <= max2.z && max.z >= min2.z;
	}

	public static List<NavmeshCut> GetAll()
	{
		return allCuts;
	}

	public void Awake()
	{
		AddCut(this);
	}

	public void OnEnable()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		tr = ((Component)this).transform;
		lastPosition = new Vector3(float.PositiveInfinity, float.PositiveInfinity, float.PositiveInfinity);
		lastRotation = tr.rotation;
	}

	public void OnDestroy()
	{
		if (OnDestroyCallback != null)
		{
			OnDestroyCallback(this);
		}
		RemoveCut(this);
	}

	public void ForceUpdate()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		lastPosition = new Vector3(float.PositiveInfinity, float.PositiveInfinity, float.PositiveInfinity);
	}

	public bool RequiresUpdate()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		int result;
		if (wasEnabled == (((Behaviour)this).enabled && ((Component)this).gameObject.activeInHierarchy))
		{
			if (wasEnabled)
			{
				Vector3 val = tr.position - lastPosition;
				result = ((val.sqrMagnitude > updateDistance * updateDistance || (useRotation && Quaternion.Angle(lastRotation, tr.rotation) > updateRotationDistance)) ? 1 : 0);
			}
			else
			{
				result = 0;
			}
		}
		else
		{
			result = 1;
		}
		return (byte)result != 0;
	}

	public virtual void UsedForCut()
	{
	}

	public void NotifyUpdated()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		wasEnabled = ((Behaviour)this).enabled && ((Component)this).gameObject.activeInHierarchy;
		if (wasEnabled)
		{
			lastPosition = tr.position;
			lastBounds = GetBounds();
			if (useRotation)
			{
				lastRotation = tr.rotation;
			}
		}
	}

	private void CalculateMeshContour()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)mesh == (Object)null)
		{
			return;
		}
		edges.Clear();
		pointers.Clear();
		Vector3[] vertices = mesh.vertices;
		int[] triangles = mesh.triangles;
		for (int i = 0; i < triangles.Length; i += 3)
		{
			if (VectorMath.IsClockwiseXZ(vertices[triangles[i]], vertices[triangles[i + 1]], vertices[triangles[i + 2]]))
			{
				int num = triangles[i];
				triangles[i] = triangles[i + 2];
				triangles[i + 2] = num;
			}
			edges[new Int2(triangles[i], triangles[i + 1])] = i;
			edges[new Int2(triangles[i + 1], triangles[i + 2])] = i;
			edges[new Int2(triangles[i + 2], triangles[i])] = i;
		}
		for (int j = 0; j < triangles.Length; j += 3)
		{
			for (int k = 0; k < 3; k++)
			{
				if (!edges.ContainsKey(new Int2(triangles[j + (k + 1) % 3], triangles[j + k % 3])))
				{
					pointers[triangles[j + k % 3]] = triangles[j + (k + 1) % 3];
				}
			}
		}
		List<Vector3[]> list = new List<Vector3[]>();
		List<Vector3> list2 = ListPool<Vector3>.Claim();
		for (int l = 0; l < vertices.Length; l++)
		{
			if (!pointers.ContainsKey(l))
			{
				continue;
			}
			list2.Clear();
			int num2 = l;
			do
			{
				int num3 = pointers[num2];
				if (num3 == -1)
				{
					break;
				}
				pointers[num2] = -1;
				list2.Add(vertices[num2]);
				num2 = num3;
				if (num2 == -1)
				{
					Debug.LogError((object)("Invalid Mesh '" + ((Object)mesh).name + " in " + ((Object)((Component)this).gameObject).name));
					break;
				}
			}
			while (num2 != l);
			if (list2.Count > 0)
			{
				list.Add(list2.ToArray());
			}
		}
		ListPool<Vector3>.Release(list2);
		contours = new List<Vector3[]>(list);
	}

	public Bounds GetBounds()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		//IL_029e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_032e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0334: Unknown result type (might be due to invalid IL or missing references)
		//IL_0339: Unknown result type (might be due to invalid IL or missing references)
		//IL_035c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0361: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0317: Unknown result type (might be due to invalid IL or missing references)
		//IL_031c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0387: Unknown result type (might be due to invalid IL or missing references)
		//IL_038c: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_061f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0625: Unknown result type (might be due to invalid IL or missing references)
		//IL_062a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0631: Unknown result type (might be due to invalid IL or missing references)
		//IL_063c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0641: Unknown result type (might be due to invalid IL or missing references)
		//IL_0646: Unknown result type (might be due to invalid IL or missing references)
		//IL_0648: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03db: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_040b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0412: Unknown result type (might be due to invalid IL or missing references)
		//IL_042c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0431: Unknown result type (might be due to invalid IL or missing references)
		//IL_0436: Unknown result type (might be due to invalid IL or missing references)
		//IL_0445: Unknown result type (might be due to invalid IL or missing references)
		//IL_045f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0464: Unknown result type (might be due to invalid IL or missing references)
		//IL_0469: Unknown result type (might be due to invalid IL or missing references)
		//IL_0478: Unknown result type (might be due to invalid IL or missing references)
		//IL_0492: Unknown result type (might be due to invalid IL or missing references)
		//IL_0497: Unknown result type (might be due to invalid IL or missing references)
		//IL_049c: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_04de: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0502: Unknown result type (might be due to invalid IL or missing references)
		//IL_0511: Unknown result type (might be due to invalid IL or missing references)
		//IL_052b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0530: Unknown result type (might be due to invalid IL or missing references)
		//IL_0535: Unknown result type (might be due to invalid IL or missing references)
		//IL_0544: Unknown result type (might be due to invalid IL or missing references)
		//IL_055e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0563: Unknown result type (might be due to invalid IL or missing references)
		//IL_0568: Unknown result type (might be due to invalid IL or missing references)
		//IL_0577: Unknown result type (might be due to invalid IL or missing references)
		//IL_0591: Unknown result type (might be due to invalid IL or missing references)
		//IL_0596: Unknown result type (might be due to invalid IL or missing references)
		//IL_059b: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05de: Unknown result type (might be due to invalid IL or missing references)
		//IL_065d: Unknown result type (might be due to invalid IL or missing references)
		Bounds result = default;
		if ((Object)(object)tr == (Object)null)
		{
			tr = ((Component)this).transform;
		}
		switch (type)
		{
		case MeshType.Rectangle:
			if (useRotation)
			{
				Matrix4x4 localToWorldMatrix2 = tr.localToWorldMatrix;
				result = new Bounds(localToWorldMatrix2.MultiplyPoint3x4(center + new Vector3(0f - rectangleSize.x, 0f - height, 0f - rectangleSize.y) * 0.5f), Vector3.zero);
				result.Encapsulate(localToWorldMatrix2.MultiplyPoint3x4(center + new Vector3(rectangleSize.x, 0f - height, 0f - rectangleSize.y) * 0.5f));
				result.Encapsulate(localToWorldMatrix2.MultiplyPoint3x4(center + new Vector3(rectangleSize.x, 0f - height, rectangleSize.y) * 0.5f));
				result.Encapsulate(localToWorldMatrix2.MultiplyPoint3x4(center + new Vector3(0f - rectangleSize.x, 0f - height, rectangleSize.y) * 0.5f));
				result.Encapsulate(localToWorldMatrix2.MultiplyPoint3x4(center + new Vector3(0f - rectangleSize.x, height, 0f - rectangleSize.y) * 0.5f));
				result.Encapsulate(localToWorldMatrix2.MultiplyPoint3x4(center + new Vector3(rectangleSize.x, height, 0f - rectangleSize.y) * 0.5f));
				result.Encapsulate(localToWorldMatrix2.MultiplyPoint3x4(center + new Vector3(rectangleSize.x, height, rectangleSize.y) * 0.5f));
				result.Encapsulate(localToWorldMatrix2.MultiplyPoint3x4(center + new Vector3(0f - rectangleSize.x, height, rectangleSize.y) * 0.5f));
			}
			else
			{
				result = new Bounds(tr.position + center, new Vector3(rectangleSize.x, height, rectangleSize.y));
			}
			break;
		case MeshType.Circle:
			if (useRotation)
			{
				Matrix4x4 localToWorldMatrix3 = tr.localToWorldMatrix;
				result = new Bounds(localToWorldMatrix3.MultiplyPoint3x4(center), new Vector3(circleRadius * 2f, height, circleRadius * 2f));
			}
			else
			{
				result = new Bounds(((Component)this).transform.position + center, new Vector3(circleRadius * 2f, height, circleRadius * 2f));
			}
			break;
		case MeshType.CustomMesh:
			if (!((Object)(object)mesh == (Object)null))
			{
				Bounds bounds = mesh.bounds;
				if (useRotation)
				{
					Matrix4x4 localToWorldMatrix = tr.localToWorldMatrix;
					bounds.center *= meshScale;
					bounds.size *= meshScale;
					result = new Bounds(localToWorldMatrix.MultiplyPoint3x4(center + bounds.center), Vector3.zero);
					Vector3 max = bounds.max;
					Vector3 min = bounds.min;
					result.Encapsulate(localToWorldMatrix.MultiplyPoint3x4(center + new Vector3(max.x, max.y, max.z)));
					result.Encapsulate(localToWorldMatrix.MultiplyPoint3x4(center + new Vector3(min.x, max.y, max.z)));
					result.Encapsulate(localToWorldMatrix.MultiplyPoint3x4(center + new Vector3(min.x, max.y, min.z)));
					result.Encapsulate(localToWorldMatrix.MultiplyPoint3x4(center + new Vector3(max.x, max.y, min.z)));
					result.Encapsulate(localToWorldMatrix.MultiplyPoint3x4(center + new Vector3(max.x, min.y, max.z)));
					result.Encapsulate(localToWorldMatrix.MultiplyPoint3x4(center + new Vector3(min.x, min.y, max.z)));
					result.Encapsulate(localToWorldMatrix.MultiplyPoint3x4(center + new Vector3(min.x, min.y, min.z)));
					result.Encapsulate(localToWorldMatrix.MultiplyPoint3x4(center + new Vector3(max.x, min.y, min.z)));
					Vector3 size = result.size;
					size.y = Mathf.Max(size.y, height * tr.lossyScale.y);
					result.size = size;
				}
				else
				{
					Vector3 val = bounds.size * meshScale;
					val.y = Mathf.Max(val.y, height);
					result = new Bounds(((Component)this).transform.position + center + bounds.center * meshScale, val);
				}
			}
			break;
		default:
			throw new Exception("Invalid mesh type");
		}
		return result;
	}

	public void GetContour(List<List<IntPoint>> buffer)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_022e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0233: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0274: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0330: Unknown result type (might be due to invalid IL or missing references)
		//IL_0332: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0346: Unknown result type (might be due to invalid IL or missing references)
		//IL_037c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0387: Unknown result type (might be due to invalid IL or missing references)
		//IL_038c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0391: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0304: Unknown result type (might be due to invalid IL or missing references)
		//IL_0309: Unknown result type (might be due to invalid IL or missing references)
		//IL_030e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0404: Unknown result type (might be due to invalid IL or missing references)
		//IL_040b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0410: Unknown result type (might be due to invalid IL or missing references)
		//IL_0455: Unknown result type (might be due to invalid IL or missing references)
		//IL_045a: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0468: Unknown result type (might be due to invalid IL or missing references)
		//IL_0476: Unknown result type (might be due to invalid IL or missing references)
		//IL_0481: Unknown result type (might be due to invalid IL or missing references)
		//IL_0486: Unknown result type (might be due to invalid IL or missing references)
		//IL_048b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0490: Unknown result type (might be due to invalid IL or missing references)
		if (circleResolution < 3)
		{
			circleResolution = 3;
		}
		Vector3 position = tr.position;
		switch (type)
		{
		case MeshType.Rectangle:
		{
			List<IntPoint> list = ListPool<IntPoint>.Claim();
			if (useRotation)
			{
				Matrix4x4 localToWorldMatrix2 = tr.localToWorldMatrix;
				list.Add(V3ToIntPoint(localToWorldMatrix2.MultiplyPoint3x4(center + new Vector3(0f - rectangleSize.x, 0f, 0f - rectangleSize.y) * 0.5f)));
				list.Add(V3ToIntPoint(localToWorldMatrix2.MultiplyPoint3x4(center + new Vector3(rectangleSize.x, 0f, 0f - rectangleSize.y) * 0.5f)));
				list.Add(V3ToIntPoint(localToWorldMatrix2.MultiplyPoint3x4(center + new Vector3(rectangleSize.x, 0f, rectangleSize.y) * 0.5f)));
				list.Add(V3ToIntPoint(localToWorldMatrix2.MultiplyPoint3x4(center + new Vector3(0f - rectangleSize.x, 0f, rectangleSize.y) * 0.5f)));
			}
			else
			{
				position += center;
				list.Add(V3ToIntPoint(position + new Vector3(0f - rectangleSize.x, 0f, 0f - rectangleSize.y) * 0.5f));
				list.Add(V3ToIntPoint(position + new Vector3(rectangleSize.x, 0f, 0f - rectangleSize.y) * 0.5f));
				list.Add(V3ToIntPoint(position + new Vector3(rectangleSize.x, 0f, rectangleSize.y) * 0.5f));
				list.Add(V3ToIntPoint(position + new Vector3(0f - rectangleSize.x, 0f, rectangleSize.y) * 0.5f));
			}
			buffer.Add(list);
			break;
		}
		case MeshType.Circle:
		{
			List<IntPoint> list = ListPool<IntPoint>.Claim(circleResolution);
			if (useRotation)
			{
				Matrix4x4 localToWorldMatrix3 = tr.localToWorldMatrix;
				for (int l = 0; l < circleResolution; l++)
				{
					list.Add(V3ToIntPoint(localToWorldMatrix3.MultiplyPoint3x4(center + new Vector3(Mathf.Cos((float)(l * 2) * (float)Math.PI / (float)circleResolution), 0f, Mathf.Sin((float)(l * 2) * (float)Math.PI / (float)circleResolution)) * circleRadius)));
				}
			}
			else
			{
				position += center;
				for (int m = 0; m < circleResolution; m++)
				{
					list.Add(V3ToIntPoint(position + new Vector3(Mathf.Cos((float)(m * 2) * (float)Math.PI / (float)circleResolution), 0f, Mathf.Sin((float)(m * 2) * (float)Math.PI / (float)circleResolution)) * circleRadius));
				}
			}
			buffer.Add(list);
			break;
		}
		case MeshType.CustomMesh:
		{
			if ((Object)(object)mesh != (Object)(object)lastMesh || contours == null)
			{
				CalculateMeshContour();
				lastMesh = mesh;
			}
			if (contours == null)
			{
				break;
			}
			position += center;
			bool flag = Vector3.Dot(tr.up, Vector3.up) < 0f;
			for (int i = 0; i < contours.Count; i++)
			{
				Vector3[] array = contours[i];
				List<IntPoint> list = ListPool<IntPoint>.Claim(array.Length);
				if (useRotation)
				{
					Matrix4x4 localToWorldMatrix = tr.localToWorldMatrix;
					for (int j = 0; j < array.Length; j++)
					{
						list.Add(V3ToIntPoint(localToWorldMatrix.MultiplyPoint3x4(center + array[j] * meshScale)));
					}
				}
				else
				{
					for (int k = 0; k < array.Length; k++)
					{
						list.Add(V3ToIntPoint(position + array[k] * meshScale));
					}
				}
				if (flag)
				{
					list.Reverse();
				}
				buffer.Add(list);
			}
			break;
		}
		}
	}

	public bool ContainsPointOBB(Vector3 point)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = ((Component)this).transform.InverseTransformPoint(point);
		Vector3 zero = Vector3.zero;
		zero.y = height;
		switch (type)
		{
		case MeshType.Rectangle:
			zero.x = rectangleSize.x;
			zero.z = rectangleSize.y;
			break;
		case MeshType.Circle:
			zero.x = (zero.z = circleRadius * 2f);
			break;
		case MeshType.CustomMesh:
			return false;
		}
		float num = zero.x * 0.5f;
		float num2 = zero.y * 0.5f;
		float num3 = zero.z * 0.5f;
		return val.x < num && val.x > 0f - num && val.y < num2 && val.y > 0f - num2 && val.z < num3 && val.z > 0f - num3;
	}

	public static IntPoint V3ToIntPoint(Vector3 p)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		Int3 @int = (Int3)p;
		return new IntPoint((long)@int.x, (long)@int.z);
	}

	public static Vector3 IntPointToV3(IntPoint p)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		Int3 @int = new Int3((int)p.X, 0, (int)p.Y);
		return (Vector3)@int;
	}

	public void OnDrawGizmos()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)tr == (Object)null)
		{
			tr = ((Component)this).transform;
		}
		List<List<IntPoint>> list = ListPool<List<IntPoint>>.Claim();
		GetContour(list);
		Gizmos.color = GizmoColor;
		Bounds bounds = GetBounds();
		float y = bounds.min.y;
		Vector3 val = Vector3.up * (bounds.max.y - y);
		for (int i = 0; i < list.Count; i++)
		{
			List<IntPoint> list2 = list[i];
			for (int j = 0; j < list2.Count; j++)
			{
				Vector3 val2 = IntPointToV3(list2[j]);
				val2.y = y;
				Vector3 val3 = IntPointToV3(list2[(j + 1) % list2.Count]);
				val3.y = y;
				Gizmos.DrawLine(val2, val3);
				Gizmos.DrawLine(val2 + val, val3 + val);
				Gizmos.DrawLine(val2, val2 + val);
				Gizmos.DrawLine(val3, val3 + val);
			}
		}
		ListPool<List<IntPoint>>.Release(list);
	}

	public void OnDrawGizmosSelected()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		Gizmos.color = Color.Lerp(GizmoColor, new Color(1f, 1f, 1f, 0.2f), 0.9f);
		Bounds bounds = GetBounds();
		Gizmos.DrawCube(bounds.center, bounds.size);
		Gizmos.DrawWireCube(bounds.center, bounds.size);
	}

	static NavmeshCut()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
	}
}
