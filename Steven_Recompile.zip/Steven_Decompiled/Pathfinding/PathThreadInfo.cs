namespace Pathfinding;

public struct PathThreadInfo(int index, AstarPath astar, PathHandler runData)
{
	public int threadIndex = index;

	public AstarPath astar = astar;

	public PathHandler runData = runData;

	public readonly object lockObject = new object();
}
