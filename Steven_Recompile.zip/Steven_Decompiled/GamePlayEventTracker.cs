using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GamePlayEventTracker : MonoBehaviour
{
	public List<GamePlayEventTrackerState> trackerStates = new List<GamePlayEventTrackerState>();

	public bool checkOnlyOnStart;

	public Component componentToModify;

	private Coroutine delayDisableRoutine;

	private IEnumerator Start()
	{
		yield return (object)new WaitForEndOfFrame();
		if (!checkOnlyOnStart)
		{
			PlayerGameState.Instance.GamePlayEventCompleted += HandleGamePlayEventComplete;
			PlayerGameState.Instance.GamePlayEventTriggered += HandleGamePlayEventTriggered;
		}
		PlayerGameState.Instance.PlayerDataChanged += HandlePlayerDataChanged;
		HandlePlayerDataChanged();
	}

	private void OnDestroy()
	{
		if (!checkOnlyOnStart)
		{
			PlayerGameState.Instance.GamePlayEventCompleted -= HandleGamePlayEventComplete;
			PlayerGameState.Instance.GamePlayEventTriggered -= HandleGamePlayEventTriggered;
		}
		PlayerGameState.Instance.PlayerDataChanged -= HandlePlayerDataChanged;
	}

	private void HandlePlayerDataChanged()
	{
		CheckShouldEnable();
	}

	public void CheckShouldEnable(bool disableImmediately = false)
	{
		bool flag = false;
		bool flag2 = false;
		for (int i = 0; i < trackerStates.Count; i++)
		{
			GamePlayEventTrackerState gamePlayEventTrackerState = trackerStates[i];
			if (gamePlayEventTrackerState.eventState == GamePlayEventState.Active && PlayerGameState.Instance.IsGamePlayEventIDActive(gamePlayEventTrackerState.eventUID))
			{
				if (gamePlayEventTrackerState.eventResult == GamePlayEventTrackerResult.Enable)
				{
					flag = true;
					flag2 = false;
				}
				if (gamePlayEventTrackerState.eventResult == GamePlayEventTrackerResult.Disable)
				{
					flag = false;
					flag2 = true;
				}
			}
			if (gamePlayEventTrackerState.eventState == GamePlayEventState.Complete && PlayerGameState.Instance.HasCompletedGamePlayEventID(gamePlayEventTrackerState.eventUID))
			{
				if (gamePlayEventTrackerState.eventResult == GamePlayEventTrackerResult.Enable)
				{
					flag = true;
					flag2 = false;
				}
				if (gamePlayEventTrackerState.eventResult == GamePlayEventTrackerResult.Disable)
				{
					flag = false;
					flag2 = true;
				}
			}
			if (gamePlayEventTrackerState.eventState == GamePlayEventState.Unassigned && !PlayerGameState.Instance.HasCompletedGamePlayEventID(gamePlayEventTrackerState.eventUID) && !PlayerGameState.Instance.IsGamePlayEventIDActive(gamePlayEventTrackerState.eventUID))
			{
				if (gamePlayEventTrackerState.eventResult == GamePlayEventTrackerResult.Enable)
				{
					flag = true;
					flag2 = false;
				}
				if (gamePlayEventTrackerState.eventResult == GamePlayEventTrackerResult.Disable)
				{
					flag = false;
					flag2 = true;
				}
			}
			if (gamePlayEventTrackerState.eventState != GamePlayEventState.ActiveCount || !PlayerGameState.Instance.IsGamePlayEventIDActive(gamePlayEventTrackerState.eventUID))
			{
				continue;
			}
			GamePlayEventData gamePlayEventData = PlayerGameState.Instance.GetGamePlayEventData(gamePlayEventTrackerState.eventUID);
			if (gamePlayEventTrackerState.eventCondition == GamePlayEventTrackerCondition.On && gamePlayEventTrackerState.activeCount == gamePlayEventData.currentCount)
			{
				if (gamePlayEventTrackerState.eventResult == GamePlayEventTrackerResult.Enable)
				{
					flag = true;
					flag2 = false;
				}
				if (gamePlayEventTrackerState.eventResult == GamePlayEventTrackerResult.Disable)
				{
					flag = false;
					flag2 = true;
				}
			}
			if (gamePlayEventTrackerState.eventCondition == GamePlayEventTrackerCondition.GreaterThan && gamePlayEventData.currentCount > gamePlayEventTrackerState.activeCount)
			{
				if (gamePlayEventTrackerState.eventResult == GamePlayEventTrackerResult.Enable)
				{
					flag = true;
					flag2 = false;
				}
				if (gamePlayEventTrackerState.eventResult == GamePlayEventTrackerResult.Disable)
				{
					flag = false;
					flag2 = true;
				}
			}
			if (gamePlayEventTrackerState.eventCondition == GamePlayEventTrackerCondition.LessThan && gamePlayEventData.currentCount < gamePlayEventTrackerState.activeCount)
			{
				if (gamePlayEventTrackerState.eventResult == GamePlayEventTrackerResult.Enable)
				{
					flag = true;
					flag2 = false;
				}
				if (gamePlayEventTrackerState.eventResult == GamePlayEventTrackerResult.Disable)
				{
					flag = false;
					flag2 = true;
				}
			}
		}
		if (flag)
		{
			ShouldEnable();
		}
		else
		{
			if (!flag2)
			{
				return;
			}
			if (disableImmediately)
			{
				if ((Object)(object)componentToModify != (Object)null)
				{
					SetComponentState(componentToModify, enabled: false);
				}
				else
				{
					((Component)this).gameObject.SetActive(false);
				}
			}
			else
			{
				ShouldDisable();
			}
		}
	}

	protected virtual void ShouldEnable()
	{
		if (delayDisableRoutine != null)
		{
			((MonoBehaviour)GameController.Instance).StopCoroutine(delayDisableRoutine);
		}
		if ((Object)(object)componentToModify != (Object)null)
		{
			SetComponentState(componentToModify, enabled: true);
		}
		else
		{
			((Component)this).gameObject.SetActive(true);
		}
	}

	protected virtual void ShouldDisable()
	{
		if (delayDisableRoutine != null)
		{
			((MonoBehaviour)GameController.Instance).StopCoroutine(delayDisableRoutine);
		}
		delayDisableRoutine = ((MonoBehaviour)GameController.Instance).StartCoroutine(DelayDisable());
	}

	private void SetComponentState(Component component, bool enabled)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (component is MonoBehaviour)
		{
			((Behaviour)(MonoBehaviour)component).enabled = enabled;
		}
		else if (component is Collider)
		{
			((Collider)component).enabled = enabled;
		}
	}

	private IEnumerator DelayDisable()
	{
		yield return (object)new WaitForEndOfFrame();
		if ((Object)(object)componentToModify != (Object)null)
		{
			SetComponentState(componentToModify, enabled: false);
		}
		else if ((Object)(object)((Component)this).gameObject != (Object)null)
		{
			((Component)this).gameObject.SetActive(false);
		}
	}

	private void HandleGamePlayEventComplete(int guid)
	{
		HandlePlayerDataChanged();
	}

	private void HandleGamePlayEventTriggered(int guid)
	{
		HandlePlayerDataChanged();
	}
}
