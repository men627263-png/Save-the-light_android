using UnityEngine;

public class FlipPosition : MonoBehaviour
{
	[SerializeField]
	private Transform otherTransform;

	[SerializeField]
	private float normalX;

	[SerializeField]
	private float flippedX;

	private void Awake()
	{
		if ((Object)(object)otherTransform == (Object)null)
		{
			Object.Destroy((Object)(object)this);
		}
	}

	private void LateUpdate()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)otherTransform != (Object)null)
		{
			Vector3 localPosition = ((Component)this).transform.localPosition;
			localPosition.x = ((!(otherTransform.localScale.x < 0f)) ? normalX : flippedX);
			((Component)this).transform.localPosition = localPosition;
		}
	}
}
