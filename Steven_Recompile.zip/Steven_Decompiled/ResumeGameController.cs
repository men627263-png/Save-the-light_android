using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResumeGameController : MonoBehaviour
{
	public static ResumeGameController instance;

	public PlayMakerFSM resumeGameFSM;

	public Transform characterStartPosition;

	public Transform moveToWarppadPosition;

	public float moveSpeed = 5f;

	public float timeBetweenFollowersMovingToWarp = 0.7f;

	public bool resuming;

	public bool resumingInOtherScene;

	private PlayerCharacter partyLeader;

	private void Awake()
	{
		instance = this;
	}

	private void OnDestroy()
	{
		instance = null;
	}

	public void ResumeGame()
	{
		((MonoBehaviour)this).StartCoroutine(ResumeGameRoutine());
	}

	private IEnumerator ResumeGameRoutine()
	{
		resuming = true;
		if (PlayerGameState.Instance.HasUnlockedLevel(8))
		{
			PlayerGameState.Instance.AddCharacterToParty(1, addToActiveParty: false);
			PlayerGameState.Instance.AddCharacterToParty(0, addToActiveParty: false);
			PlayerGameState.Instance.AddCharacterToParty(6, addToActiveParty: false);
			PlayerGameState.Instance.AddCharacterToParty(4, addToActiveParty: false);
			PlayerGameState.Instance.AddCharacterToParty(22, addToActiveParty: false);
			PlayerGameState.Instance.AddCharacterToParty(7, addToActiveParty: false);
			if (PlayerGameState.Instance.HasCompletedGamePlayEventID(33))
			{
				PlayerGameState.Instance.AddCharacterToParty(18, addToActiveParty: false);
			}
		}
		if (!PlayerGameState.Instance.HasCompletedGamePlayEventID(72) && PlayerGameState.Instance.HasCharacterInParty(4) && PlayerGameState.Instance.HasCharacterInParty(22))
		{
			if (PlayerGameState.Instance.HasCharacterInActiveParty(22))
			{
				List<int> charactersNotInActiveParty = PlayerGameState.Instance.CharactersNotInActiveParty;
				if (charactersNotInActiveParty.Count > 0)
				{
					PlayerGameState.Instance.ReplaceCharactersInActiveParty(charactersNotInActiveParty[0], 22);
				}
			}
			PlayerGameState.Instance.RemoveCharacterFromParty(22);
		}
		GamePlayEventData gameplayEventData_17 = PlayerGameState.Instance.GetGamePlayEventData(17);
		if (gameplayEventData_17 != null && !gameplayEventData_17.currentState.Equals(GamePlayEventState.Complete))
		{
			int itemCount = PlayerGameState.Instance.GetItemCount(62);
			if (itemCount != gameplayEventData_17.currentCount)
			{
				gameplayEventData_17.currentCount = itemCount;
				Debug.Log((object)"Number of Glow Sticks in inventory and number tracked in event data don't match. Setting the event data's value to match that of the player's inventory");
			}
			if (!PlayerGameState.Instance.HasConversationPlayed(85))
			{
				PlayerGameState.Instance.SetGamePlayEventState(17, GamePlayEventState.Unassigned);
			}
		}
		GamePlayEventData gameplayEventData_35 = PlayerGameState.Instance.GetGamePlayEventData(35);
		if (gameplayEventData_35 != null && gameplayEventData_35.currentState.Equals(GamePlayEventState.Complete))
		{
			GamePlayEventData gamePlayEventData = PlayerGameState.Instance.GetGamePlayEventData(50);
			if (gamePlayEventData == null || gamePlayEventData.currentState.Equals(GamePlayEventState.Unassigned))
			{
				PlayerGameState.Instance.TriggerGamePlayEvent(50);
				Debug.Log((object)"Setting the 'Travel to Sky Arena' mission as Active");
			}
			if (!PlayerGameState.Instance.HasUnlockedLevel(22))
			{
				PlayerGameState.Instance.AddToLevelsVisited(22);
				Debug.Log((object)"Added the Ancient Sky Arena to the list of levels visited");
			}
		}
		if (PlayerGameState.Instance.HasCompletedGamePlayEventID(3) && !PlayerGameState.Instance.HasCompletedGamePlayEventID(20))
		{
			PlayerGameState.Instance.TriggerGamePlayEvent(20, GamePlayEventState.Complete);
		}
		if (PlayerGameState.Instance.HasCompletedGamePlayEventID(113) && !PlayerGameState.Instance.HasWeaponUpgrade(CharacterName.Steven, 2) && !PlayerGameState.Instance.OwnsWeaponSchematicID(69))
		{
			PlayerGameState.Instance.CollectItem(69);
		}
		GamePlayEventData gameplayEventData_5_2 = PlayerGameState.Instance.GetGamePlayEventData(82);
		GamePlayEventData gameplayEventData_5_3 = PlayerGameState.Instance.GetGamePlayEventData(83);
		GamePlayEventData gameplayEventData_5_4_Reunion = PlayerGameState.Instance.GetGamePlayEventData(102);
		if (gameplayEventData_5_2 != null && gameplayEventData_5_2.currentState == GamePlayEventState.Complete && (gameplayEventData_5_3 == null || gameplayEventData_5_3.currentState == GamePlayEventState.Unassigned))
		{
			PlayerGameState.Instance.TriggerGamePlayEvent(83);
			gameplayEventData_5_3 = PlayerGameState.Instance.GetGamePlayEventData(83);
		}
		if (gameplayEventData_5_3 != null && gameplayEventData_5_3.currentState == GamePlayEventState.Complete && (gameplayEventData_5_4_Reunion == null || gameplayEventData_5_4_Reunion.currentState == GamePlayEventState.Unassigned))
		{
			PlayerGameState.Instance.TriggerGamePlayEvent(102);
			gameplayEventData_5_4_Reunion = PlayerGameState.Instance.GetGamePlayEventData(102);
		}
		if (gameplayEventData_5_2 != null && gameplayEventData_5_2.currentState == GamePlayEventState.Active)
		{
			GamePlayLevelDefinition level = GameController.Instance.gameplayDatabase.GetLevel(12);
			if ((Object)(object)level != (Object)null)
			{
				if ((Object)(object)GameController.Instance.musicExplorationSource != (Object)null)
				{
					AudioEventManager.Instance.FadeTo(GameController.Instance.musicExplorationSource, 0f, 2f, stopSound: true, isIndependentUpdate: true);
				}
				if ((Object)(object)GameController.Instance.musicBattleSource != (Object)null)
				{
					AudioEventManager.Instance.FadeTo(GameController.Instance.musicBattleSource, 0f, 2f, stopSound: true, isIndependentUpdate: true);
				}
				resumingInOtherScene = true;
				UILoadingScreen.Instance.LoadScene(level.sceneName, 1f, 0.1f, fromWarpPad: true);
				yield break;
			}
		}
		if (gameplayEventData_5_3 != null && gameplayEventData_5_3.currentState == GamePlayEventState.Active)
		{
			GamePlayLevelDefinition level2 = GameController.Instance.gameplayDatabase.GetLevel(16);
			if ((Object)(object)level2 != (Object)null)
			{
				if ((Object)(object)GameController.Instance.musicExplorationSource != (Object)null)
				{
					AudioEventManager.Instance.FadeTo(GameController.Instance.musicExplorationSource, 0f, 2f, stopSound: true, isIndependentUpdate: true);
				}
				if ((Object)(object)GameController.Instance.musicBattleSource != (Object)null)
				{
					AudioEventManager.Instance.FadeTo(GameController.Instance.musicBattleSource, 0f, 2f, stopSound: true, isIndependentUpdate: true);
				}
				resumingInOtherScene = true;
				UILoadingScreen.Instance.LoadScene(level2.sceneName, 1f, 0.1f, fromWarpPad: true);
				yield break;
			}
		}
		if (gameplayEventData_5_4_Reunion != null && gameplayEventData_5_4_Reunion.currentState == GamePlayEventState.Active)
		{
			GamePlayLevelDefinition level3 = GameController.Instance.gameplayDatabase.GetLevel(13);
			if ((Object)(object)level3 != (Object)null)
			{
				if ((Object)(object)GameController.Instance.musicExplorationSource != (Object)null)
				{
					AudioEventManager.Instance.FadeTo(GameController.Instance.musicExplorationSource, 0f, 2f, stopSound: true, isIndependentUpdate: true);
				}
				if ((Object)(object)GameController.Instance.musicBattleSource != (Object)null)
				{
					AudioEventManager.Instance.FadeTo(GameController.Instance.musicBattleSource, 0f, 2f, stopSound: true, isIndependentUpdate: true);
				}
				resumingInOtherScene = true;
				UILoadingScreen.Instance.LoadScene(level3.sceneName, 1f, 0.1f, fromWarpPad: true);
				yield break;
			}
		}
		GameController.Instance.preventCharacterSwitch = true;
		GameController.Instance.preventBackpackUse = true;
		GameController.Instance.preventCharacterScreenUse = true;
		resumeGameFSM.SendEvent("StartResumeGame");
		while ((Object)(object)GameController.Instance.partyLeader == (Object)null)
		{
			yield return null;
		}
		partyLeader = GameController.Instance.partyLeader;
		partyLeader.disableAction = true;
		partyLeader.disableMovement = true;
		partyLeader.disableJump = true;
		partyLeader.RichAI2D.MoveToPosition(moveToWarppadPosition.position, moveSpeed);
		for (int i = 0; i < GameController.Instance.party.Count; i++)
		{
			PlayerCharacter playerCharacter = GameController.Instance.party[i];
			if ((Object)(object)playerCharacter != (Object)(object)partyLeader)
			{
				playerCharacter.StopFollowPartyLeader();
			}
		}
		yield return (object)new WaitWhile((Func<bool>)(() => !GameController.Instance.isInitialized));
		if ((Object)(object)GameController.Instance.cheeseburgerBackpack != (Object)null)
		{
			((Component)GameController.Instance.cheeseburgerBackpack).gameObject.SetActive(false);
		}
		for (int i2 = 0; i2 < GameController.Instance.party.Count; i2++)
		{
			PlayerCharacter playerCharacter2 = GameController.Instance.party[i2];
			if ((Object)(object)playerCharacter2 != (Object)(object)partyLeader)
			{
				playerCharacter2.StartFollowPartyLeader();
				yield return (object)new WaitForSeconds(timeBetweenFollowersMovingToWarp);
			}
		}
		yield return (object)new WaitForEndOfFrame();
		yield return (object)new WaitForEndOfFrame();
		yield return (object)new WaitForEndOfFrame();
		for (int num = 0; num < TitleScreenController.Instance.titleScreenCharacters.Length; num++)
		{
			TitleScreenController.Instance.titleScreenCharacters[num].gameObject.SetActive(false);
		}
		bool anyMoving;
		do
		{
			yield return (object)new WaitForEndOfFrame();
			anyMoving = false;
			for (int num2 = 0; num2 < GameController.Instance.party.Count; num2++)
			{
				if (GameController.Instance.party[num2].RichAI2D.IsMovingAlongPath)
				{
					anyMoving = true;
				}
			}
		}
		while (anyMoving);
		List<GameObject> charactersToHide = new List<GameObject>();
		for (int num3 = 0; num3 < GameController.Instance.DialogueCharacters.Count; num3++)
		{
			if (GameController.Instance.DialogueCharacters[num3] is PlayerCharacter)
			{
				PlayerCharacter playerCharacter3 = (PlayerCharacter)GameController.Instance.DialogueCharacters[num3];
				if (!GameController.Instance.party.Contains(playerCharacter3))
				{
					charactersToHide.Add(((Component)playerCharacter3).gameObject);
				}
			}
		}
		foreach (GameObject item in charactersToHide)
		{
			item.SetActive(false);
		}
		if (!UIGameMap.Instance.showingCharacterSelect && !UIGameMap.Instance.showingMap && !UIGameMap.Instance.showingCharacterSelect)
		{
			UIGameMap.Instance.DisplayMap();
		}
		partyLeader.disableAction = false;
		partyLeader.disableMovement = false;
		partyLeader.disableJump = false;
		GameController.Instance.preventCharacterSwitch = false;
		GameController.Instance.preventBackpackUse = false;
		while (UIGameMap.Instance.showingMap)
		{
			yield return null;
		}
		resuming = false;
		resumeGameFSM.SendEvent("FinishResumeGame");
	}

	public void AdjustCharacterPositions()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < GameController.Instance.party.Count; i++)
		{
			((Component)GameController.Instance.party[i]).transform.position = characterStartPosition.position;
		}
	}
}
