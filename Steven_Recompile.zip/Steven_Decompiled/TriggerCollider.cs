using System;
using UnityEngine;

[RequireComponent(typeof(Collider))]
public class TriggerCollider : MonoBehaviour
{
	private Collider _collider;

	public Collider collider
	{
		get
		{
			if ((Object)(object)_collider == (Object)null)
			{
				_collider = ((Component)this).GetComponent<Collider>();
			}
			return _collider;
		}
	}

	public event Action<Collider> Entered;

	public event Action<Collider> Exited;

	private void OnTriggerEnter(Collider other)
	{
		OnEntered(other);
	}

	private void OnTriggerExit(Collider other)
	{
		OnExited(other);
	}

	protected virtual void OnEntered(Collider collider)
	{
		if (Entered != null)
		{
			Entered(collider);
		}
	}

	protected virtual void OnExited(Collider collider)
	{
		if (Exited != null)
		{
			Exited(collider);
		}
	}
}
