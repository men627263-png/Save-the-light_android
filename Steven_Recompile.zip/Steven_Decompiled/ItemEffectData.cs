using System;
using UnityEngine;

[Serializable]
public class ItemEffectData
{
	[SerializeField]
	private ItemEffect _effectType;

	[SerializeField]
	private int _intValue1;

	[SerializeField]
	private float _floatValue1;

	[SerializeField]
	private HealInfo _healInfo;

	[SerializeField]
	private StatusEffectName _statusEffect;

	[SerializeField]
	private StatusEffectType _statusEffectType;

	[SerializeField]
	private StatusEffectData _statusEffectData;

	public ItemEffect effectType => _effectType;

	public int intValue1 => _intValue1;

	public float floatValue1 => _floatValue1;

	public HealInfo healInfo => _healInfo;

	public StatusEffectName statusEffect => _statusEffect;

	public StatusEffectType statusEffectType => _statusEffectType;

	public StatusEffectData statusEffectData => _statusEffectData;
}
