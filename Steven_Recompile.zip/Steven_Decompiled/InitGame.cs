using System;
using System.Collections;
using UnityEngine;

public class InitGame : MonoBehaviour
{
	public MovieTexture CN_movieTexture;

	public MovieTexture Grumpyface_movieTexture;

	public MovieTexture frLogo;

	public Renderer movieRenderer;

	[SerializeField]
	private UIAutoSaveScreen autoSaveScreen;

	private AudioSource _audioSource;

	private AudioSource audioSource
	{
		get
		{
			if ((Object)(object)_audioSource == (Object)null)
			{
				_audioSource = ((Component)this).GetComponent<AudioSource>();
			}
			return _audioSource;
		}
	}

	private IEnumerator Start()
	{
		Cursor.visible = false;
		if ((Object)(object)autoSaveScreen != (Object)null && ((Component)autoSaveScreen).gameObject.activeSelf)
		{
			((Component)autoSaveScreen).gameObject.SetActive(false);
		}
		yield return new WaitForSecondsIndependent(0.5f);
		bool isPlaying = true;
		if ((Object)(object)CN_movieTexture != (Object)null)
		{
			movieRenderer.material.mainTexture = (Texture)(object)CN_movieTexture;
			audioSource.clip = CN_movieTexture.audioClip;
			CN_movieTexture.Play();
			audioSource.Play();
			while (isPlaying)
			{
				isPlaying = CN_movieTexture.isPlaying;
				if (Input.anyKeyDown)
				{
					isPlaying = false;
					if ((Object)(object)CN_movieTexture != (Object)null)
					{
						CN_movieTexture.Stop();
					}
				}
				yield return null;
			}
		}
		if ((Object)(object)Grumpyface_movieTexture != (Object)null)
		{
			isPlaying = true;
			UIScreenCover.Instance.FadeIn(0.3f, 0f);
			yield return (object)new WaitForSeconds(0.3f);
			movieRenderer.material.mainTexture = (Texture)(object)Grumpyface_movieTexture;
			audioSource.clip = Grumpyface_movieTexture.audioClip;
			UIScreenCover.Instance.FadeOut(0.3f, 0f);
			yield return (object)new WaitForSeconds(0.3f);
			Grumpyface_movieTexture.Play();
			audioSource.Play();
			while (isPlaying)
			{
				isPlaying = Grumpyface_movieTexture.isPlaying;
				if (Input.anyKeyDown)
				{
					isPlaying = false;
					if ((Object)(object)Grumpyface_movieTexture != (Object)null)
					{
						Grumpyface_movieTexture.Stop();
					}
				}
				yield return null;
			}
		}
		if ((Object)(object)frLogo != (Object)null)
		{
			isPlaying = true;
			UIScreenCover.Instance.FadeIn(0.3f, 0f);
			yield return (object)new WaitForSeconds(0.3f);
			movieRenderer.material.mainTexture = (Texture)(object)frLogo;
			audioSource.clip = frLogo.audioClip;
			UIScreenCover.Instance.FadeOut(0.3f, 0f);
			yield return (object)new WaitForSeconds(0.3f);
			frLogo.Play();
			audioSource.Play();
			while (isPlaying)
			{
				isPlaying = frLogo.isPlaying;
				if (Input.anyKeyDown)
				{
					isPlaying = false;
					if ((Object)(object)frLogo != (Object)null)
					{
						frLogo.Stop();
					}
				}
				yield return null;
			}
		}
		Application.backgroundLoadingPriority = (ThreadPriority)0;
		STLAchievementsManager.instance.Initialize();
		PlayerControllerManager.instance.Initialize();
		yield return ((MonoBehaviour)this).StartCoroutine(LoadGameData());
		if ((Object)(object)autoSaveScreen != (Object)null)
		{
			((Component)autoSaveScreen).gameObject.SetActive(true);
			yield return ((MonoBehaviour)this).StartCoroutine(autoSaveScreen.Show());
		}
		GameController.showTitleScreen = true;
		UILoadingScreen.Instance.LoadScene("HouseInterior", 1f, 0f);
	}

	private IEnumerator LoadGameData()
	{
		SaveDataManager.Instance.Init();
		if (SaveDataManager.Instance.HasSaveData())
		{
			SaveDataManager.Instance.GameDataLoaded += HandleGameDataLoaded;
			SaveDataManager.Instance.LoadGameData();
		}
		else
		{
			PlayerGameState.Instance.Init(new STLGameData());
			PlayerGameState.Save();
		}
		yield return (object)new WaitWhile((Func<bool>)(() => SaveDataManager.Instance.IsBusy));
	}

	private void HandleGameDataLoaded(STLGameData gameData)
	{
		SaveDataManager.Instance.GameDataLoaded -= HandleGameDataLoaded;
		PlayerGameState.Instance.Init(gameData);
	}
}
