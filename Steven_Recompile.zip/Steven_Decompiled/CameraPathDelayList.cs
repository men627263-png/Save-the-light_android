using System;
using UnityEngine;

[ExecuteInEditMode]
public class CameraPathDelayList : CameraPathPointList
{
	public delegate void CameraPathDelayEventHandler(float time);

	public float MINIMUM_EASE_VALUE = 0.01f;

	private float _lastPercentage;

	[SerializeField]
	private CameraPathDelay _introPoint;

	[SerializeField]
	private CameraPathDelay _outroPoint;

	[SerializeField]
	private bool delayInitialised;

	public new CameraPathDelay this[int index] => (CameraPathDelay)base[index];

	public CameraPathDelay introPoint => _introPoint;

	public CameraPathDelay outroPoint => _outroPoint;

	public event CameraPathDelayEventHandler CameraPathDelayEvent;

	private void OnEnable()
	{
		((Object)this).hideFlags = (HideFlags)2;
	}

	public override void Init(CameraPath _cameraPath)
	{
		if (!initialised)
		{
			pointTypeName = "Delay";
			base.Init(_cameraPath);
			if (!delayInitialised)
			{
				_introPoint = ((Component)this).gameObject.AddComponent<CameraPathDelay>();
				_introPoint.customName = "Start Point";
				((Object)_introPoint).hideFlags = (HideFlags)2;
				AddPoint(introPoint, 0f);
				_outroPoint = ((Component)this).gameObject.AddComponent<CameraPathDelay>();
				_outroPoint.customName = "End Point";
				((Object)_outroPoint).hideFlags = (HideFlags)2;
				AddPoint(outroPoint, 1f);
				RecalculatePoints();
				delayInitialised = true;
			}
		}
	}

	public void AddDelayPoint(CameraPathControlPoint atPoint)
	{
		CameraPathDelay cameraPathDelay = ((Component)this).gameObject.AddComponent<CameraPathDelay>();
		((Object)cameraPathDelay).hideFlags = (HideFlags)2;
		AddPoint(cameraPathDelay, atPoint);
		RecalculatePoints();
	}

	public CameraPathDelay AddDelayPoint(CameraPathControlPoint curvePointA, CameraPathControlPoint curvePointB, float curvePercetage)
	{
		CameraPathDelay cameraPathDelay = ((Component)this).gameObject.AddComponent<CameraPathDelay>();
		((Object)cameraPathDelay).hideFlags = (HideFlags)2;
		AddPoint(cameraPathDelay, curvePointA, curvePointB, curvePercetage);
		RecalculatePoints();
		return cameraPathDelay;
	}

	public void OnAnimationStart(float startPercentage)
	{
		_lastPercentage = startPercentage;
	}

	public void CheckEvents(float percentage)
	{
		if (Mathf.Abs(percentage - _lastPercentage) > 0.1f)
		{
			_lastPercentage = percentage;
		}
		else
		{
			if (_lastPercentage == percentage)
			{
				return;
			}
			for (int i = 0; i < realNumberOfPoints; i++)
			{
				CameraPathDelay cameraPathDelay = this[i];
				if ((Object)(object)cameraPathDelay == (Object)(object)outroPoint)
				{
					continue;
				}
				if (cameraPathDelay.percent >= _lastPercentage && cameraPathDelay.percent <= percentage)
				{
					if ((Object)(object)cameraPathDelay != (Object)(object)introPoint)
					{
						FireDelay(cameraPathDelay);
					}
					else if (cameraPathDelay.time > 0f)
					{
						FireDelay(cameraPathDelay);
					}
				}
				else if (cameraPathDelay.percent >= percentage && cameraPathDelay.percent <= _lastPercentage)
				{
					if ((Object)(object)cameraPathDelay != (Object)(object)introPoint)
					{
						FireDelay(cameraPathDelay);
					}
					else if (cameraPathDelay.time > 0f)
					{
						FireDelay(cameraPathDelay);
					}
				}
			}
			_lastPercentage = percentage;
		}
	}

	public float CheckEase(float percent)
	{
		float val = 1f;
		for (int i = 0; i < realNumberOfPoints; i++)
		{
			CameraPathDelay cameraPathDelay = this[i];
			if ((Object)(object)cameraPathDelay != (Object)(object)introPoint)
			{
				CameraPathDelay cameraPathDelay2 = (CameraPathDelay)GetPoint(i - 1);
				float pathPercentage = cameraPath.GetPathPercentage(cameraPathDelay2.percent, cameraPathDelay.percent, 1f - cameraPathDelay.introStartEasePercentage);
				if (pathPercentage < percent && cameraPathDelay.percent > percent)
				{
					float num = (percent - pathPercentage) / (cameraPathDelay.percent - pathPercentage);
					val = cameraPathDelay.introCurve.Evaluate(num);
				}
			}
			if ((Object)(object)cameraPathDelay != (Object)(object)outroPoint)
			{
				CameraPathDelay cameraPathDelay3 = (CameraPathDelay)GetPoint(i + 1);
				float pathPercentage2 = cameraPath.GetPathPercentage(cameraPathDelay.percent, cameraPathDelay3.percent, cameraPathDelay.outroEndEasePercentage);
				if (cameraPathDelay.percent < percent && pathPercentage2 > percent)
				{
					float num2 = (percent - cameraPathDelay.percent) / (pathPercentage2 - cameraPathDelay.percent);
					val = cameraPathDelay.outroCurve.Evaluate(num2);
				}
			}
		}
		return Math.Max(val, MINIMUM_EASE_VALUE);
	}

	public void FireDelay(CameraPathDelay eventPoint)
	{
		if (CameraPathDelayEvent != null)
		{
			CameraPathDelayEvent(eventPoint.time);
		}
	}
}
