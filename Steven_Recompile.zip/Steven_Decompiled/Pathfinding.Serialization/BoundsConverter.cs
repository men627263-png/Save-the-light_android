using System;
using System.Collections.Generic;
using Pathfinding.Serialization.JsonFx;
using UnityEngine;

namespace Pathfinding.Serialization;

public class BoundsConverter : JsonConverter
{
	public override bool CanConvert(Type type)
	{
		return object.Equals(type, typeof(Bounds));
	}

	public override object ReadJson(Type objectType, Dictionary<string, object> values)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		Bounds val = default;
		val.center = new Vector3(((JsonConverter)this).CastFloat(values["cx"]), ((JsonConverter)this).CastFloat(values["cy"]), ((JsonConverter)this).CastFloat(values["cz"]));
		val.extents = new Vector3(((JsonConverter)this).CastFloat(values["ex"]), ((JsonConverter)this).CastFloat(values["ey"]), ((JsonConverter)this).CastFloat(values["ez"]));
		return val;
	}

	public override Dictionary<string, object> WriteJson(Type type, object value)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		Bounds val = (Bounds)value;
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary.Add("cx", val.center.x);
		dictionary.Add("cy", val.center.y);
		dictionary.Add("cz", val.center.z);
		dictionary.Add("ex", val.extents.x);
		dictionary.Add("ey", val.extents.y);
		dictionary.Add("ez", val.extents.z);
		return dictionary;
	}
}
