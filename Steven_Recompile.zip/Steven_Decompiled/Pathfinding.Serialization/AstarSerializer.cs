using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Pathfinding.Ionic.Zip;
using Pathfinding.Serialization.JsonFx;
using Pathfinding.Util;
using UnityEngine;

namespace Pathfinding.Serialization;

public class AstarSerializer
{
	private AstarData data;

	public JsonWriterSettings writerSettings;

	public JsonReaderSettings readerSettings;

	private ZipFile zip;

	private MemoryStream zipStream;

	private GraphMeta meta;

	private SerializeSettings settings;

	private NavGraph[] graphs;

	private Dictionary<NavGraph, int> graphIndexInZip;

	private int graphIndexOffset;

	private const string binaryExt = ".binary";

	private const string jsonExt = ".json";

	private uint checksum = uint.MaxValue;

	private UTF8Encoding encoding = new UTF8Encoding();

	private static StringBuilder _stringBuilder = new StringBuilder();

	public AstarSerializer(AstarData data)
	{
		this.data = data;
		settings = SerializeSettings.Settings;
	}

	public AstarSerializer(AstarData data, SerializeSettings settings)
	{
		this.data = data;
		this.settings = settings;
	}

	private static StringBuilder GetStringBuilder()
	{
		_stringBuilder.Length = 0;
		return _stringBuilder;
	}

	public void SetGraphIndexOffset(int offset)
	{
		graphIndexOffset = offset;
	}

	private void AddChecksum(byte[] bytes)
	{
		checksum = Checksum.GetChecksum(bytes, checksum);
	}

	public uint GetChecksum()
	{
		return checksum;
	}

	public void OpenSerialize()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected Obj, but got Unknown
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Expected Obj, but got Unknown
		zip = new ZipFile();
		zip.AlternateEncoding = Encoding.UTF8;
		zip.AlternateEncodingUsage = (ZipOption)2;
		writerSettings = new JsonWriterSettings();
		writerSettings.AddTypeConverter((JsonConverter)(object)new VectorConverter());
		writerSettings.AddTypeConverter((JsonConverter)(object)new BoundsConverter());
		writerSettings.AddTypeConverter((JsonConverter)(object)new LayerMaskConverter());
		writerSettings.AddTypeConverter((JsonConverter)(object)new MatrixConverter());
		writerSettings.AddTypeConverter((JsonConverter)(object)new GuidConverter());
		writerSettings.AddTypeConverter((JsonConverter)(object)new UnityObjectConverter());
		writerSettings.PrettyPrint = settings.prettyPrint;
		meta = new GraphMeta();
	}

	public byte[] CloseSerialize()
	{
		byte[] array = SerializeMeta();
		AddChecksum(array);
		zip.AddEntry("meta.json", array);
		DateTime dateTime = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
		foreach (ZipEntry entry in zip.Entries)
		{
			entry.AccessedTime = dateTime;
			entry.CreationTime = dateTime;
			entry.LastModified = dateTime;
			entry.ModifiedTime = dateTime;
		}
		MemoryStream memoryStream = new MemoryStream();
		zip.Save((Stream)memoryStream);
		array = memoryStream.ToArray();
		memoryStream.Dispose();
		zip.Dispose();
		zip = null;
		return array;
	}

	public void SerializeGraphs(NavGraph[] _graphs)
	{
		if (graphs != null)
		{
			throw new InvalidOperationException("Cannot serialize graphs multiple times.");
		}
		graphs = _graphs;
		if (zip == null)
		{
			throw new NullReferenceException("You must not call CloseSerialize before a call to this function");
		}
		if (graphs == null)
		{
			graphs = new NavGraph[0];
		}
		for (int i = 0; i < graphs.Length; i++)
		{
			if (graphs[i] != null)
			{
				byte[] array = Serialize(graphs[i]);
				AddChecksum(array);
				zip.AddEntry("graph" + i + ".json", array);
			}
		}
	}

	private byte[] SerializeMeta()
	{
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Expected Obj, but got Unknown
		if (graphs == null)
		{
			throw new Exception("No call to SerializeGraphs has been done");
		}
		meta.version = AstarPath.Version;
		meta.graphs = graphs.Length;
		meta.guids = new string[graphs.Length];
		meta.typeNames = new string[graphs.Length];
		meta.nodeCounts = new int[graphs.Length];
		for (int i = 0; i < graphs.Length; i++)
		{
			if (graphs[i] != null)
			{
				meta.guids[i] = graphs[i].guid.ToString();
				meta.typeNames[i] = graphs[i].GetType().FullName;
			}
		}
		StringBuilder stringBuilder = GetStringBuilder();
		JsonWriter val = new JsonWriter(stringBuilder, writerSettings);
		val.Write((object)meta);
		return encoding.GetBytes(stringBuilder.ToString());
	}

	public byte[] Serialize(NavGraph graph)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Expected Obj, but got Unknown
		StringBuilder stringBuilder = GetStringBuilder();
		JsonWriter val = new JsonWriter(stringBuilder, writerSettings);
		val.Write((object)graph);
		return encoding.GetBytes(stringBuilder.ToString());
	}

	[Obsolete("Not used anymore. You can safely remove the call to this function.")]
	public void SerializeNodes()
	{
	}

	private static int GetMaxNodeIndexInAllGraphs(NavGraph[] graphs)
	{
		int maxIndex = 0;
		for (int i = 0; i < graphs.Length; i++)
		{
			if (graphs[i] == null)
			{
				continue;
			}
			graphs[i].GetNodes((GraphNode node) =>
			{
				maxIndex = Math.Max(node.NodeIndex, maxIndex);
				if (node.NodeIndex == -1)
				{
					Debug.LogError((object)"Graph contains destroyed nodes. This is a bug.");
				}
				return true;
			});
		}
		return maxIndex;
	}

	private static byte[] SerializeNodeIndices(NavGraph[] graphs)
	{
		MemoryStream memoryStream = new MemoryStream();
		BinaryWriter wr = new BinaryWriter(memoryStream);
		int maxNodeIndexInAllGraphs = GetMaxNodeIndexInAllGraphs(graphs);
		wr.Write(maxNodeIndexInAllGraphs);
		int maxNodeIndex2 = 0;
		for (int i = 0; i < graphs.Length; i++)
		{
			if (graphs[i] != null)
			{
				graphs[i].GetNodes((GraphNode node) =>
				{
					maxNodeIndex2 = Math.Max(node.NodeIndex, maxNodeIndex2);
					wr.Write(node.NodeIndex);
					return true;
				});
			}
		}
		if (maxNodeIndex2 != maxNodeIndexInAllGraphs)
		{
			throw new Exception("Some graphs are not consistent in their GetNodes calls, sequential calls give different results.");
		}
		byte[] result = memoryStream.ToArray();
		wr.Close();
		return result;
	}

	private static byte[] SerializeGraphExtraInfo(NavGraph graph)
	{
		MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		GraphSerializationContext ctx = new GraphSerializationContext(binaryWriter);
		graph.SerializeExtraInfo(ctx);
		byte[] result = memoryStream.ToArray();
		binaryWriter.Close();
		return result;
	}

	private static byte[] SerializeGraphNodeReferences(NavGraph graph)
	{
		MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		GraphSerializationContext ctx = new GraphSerializationContext(binaryWriter);
		graph.GetNodes((GraphNode node) =>
		{
			node.SerializeReferences(ctx);
			return true;
		});
		binaryWriter.Close();
		return memoryStream.ToArray();
	}

	public void SerializeExtraInfo()
	{
		if (!settings.nodes)
		{
			return;
		}
		if (graphs == null)
		{
			throw new InvalidOperationException("Cannot serialize extra info with no serialized graphs (call SerializeGraphs first)");
		}
		byte[] array = SerializeNodeIndices(graphs);
		AddChecksum(array);
		zip.AddEntry("graph_references.binary", array);
		for (int i = 0; i < graphs.Length; i++)
		{
			if (graphs[i] != null)
			{
				array = SerializeGraphExtraInfo(graphs[i]);
				AddChecksum(array);
				zip.AddEntry("graph" + i + "_extra.binary", array);
				array = SerializeGraphNodeReferences(graphs[i]);
				AddChecksum(array);
				zip.AddEntry("graph" + i + "_references.binary", array);
			}
		}
	}

	public void SerializeEditorSettings(GraphEditorBase[] editors)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Expected Obj, but got Unknown
		if (editors == null || !settings.editorSettings)
		{
			return;
		}
		for (int i = 0; i < editors.Length && editors[i] != null; i++)
		{
			StringBuilder stringBuilder = GetStringBuilder();
			JsonWriter val = new JsonWriter(stringBuilder, writerSettings);
			val.Write((object)editors[i]);
			byte[] bytes = encoding.GetBytes(stringBuilder.ToString());
			if (bytes.Length > 2)
			{
				AddChecksum(bytes);
				zip.AddEntry("graph" + i + "_editor.json", bytes);
			}
		}
	}

	public bool OpenDeserialize(byte[] bytes)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected Obj, but got Unknown
		readerSettings = new JsonReaderSettings();
		readerSettings.AddTypeConverter((JsonConverter)(object)new VectorConverter());
		readerSettings.AddTypeConverter((JsonConverter)(object)new BoundsConverter());
		readerSettings.AddTypeConverter((JsonConverter)(object)new LayerMaskConverter());
		readerSettings.AddTypeConverter((JsonConverter)(object)new MatrixConverter());
		readerSettings.AddTypeConverter((JsonConverter)(object)new GuidConverter());
		readerSettings.AddTypeConverter((JsonConverter)(object)new UnityObjectConverter());
		zipStream = new MemoryStream();
		zipStream.Write(bytes, 0, bytes.Length);
		zipStream.Position = 0L;
		try
		{
			zip = ZipFile.Read((Stream)zipStream);
		}
		catch (Exception ex)
		{
			Debug.LogError((object)("Caught exception when loading from zip\n" + ex));
			zipStream.Dispose();
			return false;
		}
		meta = DeserializeMeta(zip["meta.json"]);
		if (FullyDefinedVersion(meta.version) > FullyDefinedVersion(AstarPath.Version))
		{
			Debug.LogWarning((object)string.Concat(new object[5]
			{
				"Trying to load data from a newer version of the A* Pathfinding Project\nCurrent version: ",
				AstarPath.Version,
				" Data version: ",
				meta.version,
				"\nThis is usually fine as the stored data is usually backwards and forwards compatible.\nHowever node data (not settings) can get corrupted between versions (even though I try my best to keep compatibility), so it is recommended to recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n"
			}));
		}
		else if (FullyDefinedVersion(meta.version) < FullyDefinedVersion(AstarPath.Version))
		{
			Debug.LogWarning((object)string.Concat(new object[5]
			{
				"Trying to load data from an older version of the A* Pathfinding Project\nCurrent version: ",
				AstarPath.Version,
				" Data version: ",
				meta.version,
				"\nThis is usually fine, it just means you have upgraded to a new version.\nHowever node data (not settings) can get corrupted between versions (even though I try my best to keep compatibility), so it is recommended to recalculate any caches (those for faster startup) and resave any files. Even if it seems to load fine, it might cause subtle bugs.\n"
			}));
		}
		return true;
	}

	private static Version FullyDefinedVersion(Version v)
	{
		return new Version(Mathf.Max(v.Major, 0), Mathf.Max(v.Minor, 0), Mathf.Max(v.Build, 0), Mathf.Max(v.Revision, 0));
	}

	public void CloseDeserialize()
	{
		zipStream.Dispose();
		zip.Dispose();
		zip = null;
		zipStream = null;
	}

	private NavGraph DeserializeGraph(int zipIndex, int graphIndex)
	{
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Expected Obj, but got Unknown
		Type graphType = meta.GetGraphType(zipIndex);
		if (object.Equals(graphType, null))
		{
			return null;
		}
		ZipEntry val = zip["graph" + zipIndex + ".json"];
		if (val == null)
		{
			throw new FileNotFoundException("Could not find data for graph " + zipIndex + " in zip. Entry 'graph" + zipIndex + ".json' does not exist");
		}
		NavGraph navGraph = data.CreateGraph(graphType);
		navGraph.graphIndex = (uint)graphIndex;
		string text = GetString(val);
		JsonReader val2 = new JsonReader(text, readerSettings);
		val2.PopulateObject<NavGraph>(ref navGraph);
		if (navGraph.guid.ToString() != meta.guids[zipIndex])
		{
			throw new Exception(string.Concat(new object[4]
			{
				"Guid in graph file not equal to guid defined in meta file. Have you edited the data manually?\n",
				navGraph.guid,
				" != ",
				meta.guids[zipIndex]
			}));
		}
		return navGraph;
	}

	public NavGraph[] DeserializeGraphs()
	{
		List<NavGraph> list = new List<NavGraph>();
		graphIndexInZip = new Dictionary<NavGraph, int>();
		for (int i = 0; i < meta.graphs; i++)
		{
			int graphIndex = list.Count + graphIndexOffset;
			NavGraph navGraph = DeserializeGraph(i, graphIndex);
			if (navGraph != null)
			{
				list.Add(navGraph);
				graphIndexInZip[navGraph] = i;
			}
		}
		graphs = list.ToArray();
		return graphs;
	}

	private bool DeserializeExtraInfo(NavGraph graph)
	{
		int num = graphIndexInZip[graph];
		ZipEntry val = zip["graph" + num + "_extra.binary"];
		if (val == null)
		{
			return false;
		}
		BinaryReader binaryReader = GetBinaryReader(val);
		GraphSerializationContext ctx = new GraphSerializationContext(binaryReader, null, graph.graphIndex);
		graph.DeserializeExtraInfo(ctx);
		return true;
	}

	private bool AnyDestroyedNodesInGraphs()
	{
		bool result = false;
		for (int i = 0; i < graphs.Length; i++)
		{
			graphs[i].GetNodes((GraphNode node) =>
			{
				if (node.Destroyed)
				{
					result = true;
				}
				return true;
			});
		}
		return result;
	}

	private GraphNode[] DeserializeNodeReferenceMap()
	{
		ZipEntry val = zip["graph_references.binary"];
		if (val == null)
		{
			throw new Exception("Node references not found in the data. Was this loaded from an older version of the A* Pathfinding Project?");
		}
		BinaryReader reader = GetBinaryReader(val);
		int num = reader.ReadInt32();
		GraphNode[] int2Node = new GraphNode[num + 1];
		try
		{
			for (int i = 0; i < graphs.Length; i++)
			{
				graphs[i].GetNodes((GraphNode node) =>
				{
					int num2 = reader.ReadInt32();
					int2Node[num2] = node;
					return true;
				});
			}
		}
		catch (Exception innerException)
		{
			throw new Exception("Some graph(s) has thrown an exception during GetNodes, or some graph(s) have deserialized more or fewer nodes than were serialized", innerException);
		}
		if (reader.BaseStream.Position != reader.BaseStream.Length)
		{
			throw new Exception(reader.BaseStream.Length / 4 + " nodes were serialized, but only data for " + reader.BaseStream.Position / 4 + " nodes was found. The data looks corrupt.");
		}
		reader.Close();
		return int2Node;
	}

	private void DeserializeNodeReferences(NavGraph graph, GraphNode[] int2Node)
	{
		int num = graphIndexInZip[graph];
		ZipEntry val = zip["graph" + num + "_references.binary"];
		if (val == null)
		{
			throw new Exception("Node references for graph " + num + " not found in the data. Was this loaded from an older version of the A* Pathfinding Project?");
		}
		BinaryReader binaryReader = GetBinaryReader(val);
		GraphSerializationContext ctx = new GraphSerializationContext(binaryReader, int2Node, graph.graphIndex);
		graph.GetNodes((GraphNode node) =>
		{
			node.DeserializeReferences(ctx);
			return true;
		});
	}

	public void DeserializeExtraInfo()
	{
		bool flag = false;
		for (int i = 0; i < graphs.Length; i++)
		{
			flag |= DeserializeExtraInfo(graphs[i]);
		}
		if (flag)
		{
			if (AnyDestroyedNodesInGraphs())
			{
				Debug.LogError((object)"Graph contains destroyed nodes. This is a bug.");
			}
			GraphNode[] int2Node = DeserializeNodeReferenceMap();
			for (int j = 0; j < graphs.Length; j++)
			{
				DeserializeNodeReferences(graphs[j], int2Node);
			}
		}
	}

	public void PostDeserialization()
	{
		for (int i = 0; i < graphs.Length; i++)
		{
			graphs[i].PostDeserialization();
		}
	}

	public void DeserializeEditorSettings(GraphEditorBase[] graphEditors)
	{
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Expected Obj, but got Unknown
		if (graphEditors == null)
		{
			return;
		}
		for (int i = 0; i < graphEditors.Length; i++)
		{
			if (graphEditors[i] == null)
			{
				continue;
			}
			for (int j = 0; j < graphs.Length; j++)
			{
				if (graphEditors[i].target == graphs[j])
				{
					int num = graphIndexInZip[graphs[j]];
					ZipEntry val = zip["graph" + num + "_editor.json"];
					if (val != null)
					{
						string text = GetString(val);
						JsonReader val2 = new JsonReader(text, readerSettings);
						GraphEditorBase graphEditorBase = graphEditors[i];
						val2.PopulateObject<GraphEditorBase>(ref graphEditorBase);
						graphEditors[i] = graphEditorBase;
						break;
					}
				}
			}
		}
	}

	private static BinaryReader GetBinaryReader(ZipEntry entry)
	{
		MemoryStream memoryStream = new MemoryStream();
		entry.Extract((Stream)memoryStream);
		memoryStream.Position = 0L;
		return new BinaryReader(memoryStream);
	}

	private static string GetString(ZipEntry entry)
	{
		MemoryStream memoryStream = new MemoryStream();
		entry.Extract((Stream)memoryStream);
		memoryStream.Position = 0L;
		StreamReader streamReader = new StreamReader(memoryStream);
		string result = streamReader.ReadToEnd();
		memoryStream.Position = 0L;
		streamReader.Dispose();
		return result;
	}

	private GraphMeta DeserializeMeta(ZipEntry entry)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Expected Obj, but got Unknown
		if (entry == null)
		{
			throw new Exception("No metadata found in serialized data.");
		}
		string text = GetString(entry);
		JsonReader val = new JsonReader(text, readerSettings);
		return (GraphMeta)val.Deserialize(typeof(GraphMeta));
	}

	public static void SaveToFile(string path, byte[] data)
	{
		using FileStream fileStream = new FileStream(path, FileMode.Create);
		fileStream.Write(data, 0, data.Length);
	}

	public static byte[] LoadFromFile(string path)
	{
		using FileStream fileStream = new FileStream(path, FileMode.Open);
		byte[] array = new byte[(int)fileStream.Length];
		fileStream.Read(array, 0, (int)fileStream.Length);
		return array;
	}
}
