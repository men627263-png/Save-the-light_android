using System;
using System.Collections.Generic;
using Pathfinding.Serialization.JsonFx;
using UnityEngine;

namespace Pathfinding.Serialization;

public class LayerMaskConverter : JsonConverter
{
	public override bool CanConvert(Type type)
	{
		return object.Equals(type, typeof(LayerMask));
	}

	public override object ReadJson(Type type, Dictionary<string, object> values)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		return LayerMask.op_Implicit((int)values["value"]);
	}

	public override Dictionary<string, object> WriteJson(Type type, object value)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		LayerMask val = (LayerMask)value;
		dictionary.Add("value", val.value);
		return dictionary;
	}
}
