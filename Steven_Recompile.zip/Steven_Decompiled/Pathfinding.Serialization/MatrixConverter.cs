using System;
using System.Collections.Generic;
using Pathfinding.Serialization.JsonFx;
using UnityEngine;

namespace Pathfinding.Serialization;

public class MatrixConverter : JsonConverter
{
	private readonly float[] values = new float[16];

	public override bool CanConvert(Type type)
	{
		return object.Equals(type, typeof(Matrix4x4));
	}

	public override object ReadJson(Type objectType, Dictionary<string, object> values)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		Matrix4x4 val = default;
		Array array = (Array)values["values"];
		if (array.Length != 16)
		{
			Debug.LogError((object)("Number of elements in matrix was not 16 (got " + array.Length + ")"));
			return val;
		}
		for (int i = 0; i < 16; i++)
		{
			val[i] = Convert.ToSingle(array.GetValue(new int[1] { i }));
		}
		return val;
	}

	public override Dictionary<string, object> WriteJson(Type type, object value)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		Matrix4x4 val = (Matrix4x4)value;
		for (int i = 0; i < values.Length; i++)
		{
			values[i] = val[i];
		}
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary.Add("values", values);
		return dictionary;
	}
}
