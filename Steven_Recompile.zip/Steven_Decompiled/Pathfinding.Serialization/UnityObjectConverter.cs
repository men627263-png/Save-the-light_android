using System;
using System.Collections.Generic;
using Pathfinding.Serialization.JsonFx;
using UnityEngine;

namespace Pathfinding.Serialization;

public class UnityObjectConverter : JsonConverter
{
	public override bool CanConvert(Type type)
	{
		return typeof(Object).IsAssignableFrom(type);
	}

	public override object ReadJson(Type objectType, Dictionary<string, object> values)
	{
		if (values == null)
		{
			return null;
		}
		string text = (string)values["Name"];
		if (text == null)
		{
			return null;
		}
		string text2 = (string)values["Type"];
		Type type = Type.GetType(text2);
		if (object.Equals(type, null))
		{
			Debug.LogError((object)("Could not find type '" + text2 + "'. Cannot deserialize Unity reference"));
			return null;
		}
		if (values.ContainsKey("GUID"))
		{
			string text3 = (string)values["GUID"];
			UnityReferenceHelper[] array = Object.FindObjectsOfType(typeof(UnityReferenceHelper)) as UnityReferenceHelper[];
			for (int i = 0; i < array.Length; i++)
			{
				if (array[i].GetGUID() == text3)
				{
					if (object.Equals(type, typeof(GameObject)))
					{
						return ((Component)array[i]).gameObject;
					}
					return ((Component)array[i]).GetComponent(type);
				}
			}
		}
		Object[] array2 = Resources.LoadAll(text, type);
		for (int j = 0; j < array2.Length; j++)
		{
			if (array2[j].name == text || array2.Length == 1)
			{
				return array2[j];
			}
		}
		return null;
	}

	public override Dictionary<string, object> WriteJson(Type type, object value)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Expected Obj, but got Unknown
		Object val = (Object)value;
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		if (value == null)
		{
			dictionary.Add("Name", null);
			return dictionary;
		}
		dictionary.Add("Name", val.name);
		dictionary.Add("Type", ((object)val).GetType().AssemblyQualifiedName);
		Component val2 = (Component)((value is Component) ? value : null);
		GameObject val3 = (GameObject)((value is GameObject) ? value : null);
		if ((Object)(object)val2 != (Object)null || (Object)(object)val3 != (Object)null)
		{
			if ((Object)(object)val2 != (Object)null && (Object)(object)val3 == (Object)null)
			{
				val3 = val2.gameObject;
			}
			UnityReferenceHelper unityReferenceHelper = val3.GetComponent<UnityReferenceHelper>();
			if ((Object)(object)unityReferenceHelper == (Object)null)
			{
				Debug.Log((object)("Adding UnityReferenceHelper to Unity Reference '" + val.name + "'"));
				unityReferenceHelper = val3.AddComponent<UnityReferenceHelper>();
			}
			unityReferenceHelper.Reset();
			dictionary.Add("GUID", unityReferenceHelper.GetGUID());
		}
		return dictionary;
	}
}
