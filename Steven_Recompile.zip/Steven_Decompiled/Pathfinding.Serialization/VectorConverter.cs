using System;
using System.Collections.Generic;
using Pathfinding.Serialization.JsonFx;
using UnityEngine;

namespace Pathfinding.Serialization;

public class VectorConverter : JsonConverter
{
	public override bool CanConvert(Type type)
	{
		return object.Equals(type, typeof(Vector2)) || object.Equals(type, typeof(Vector3)) || object.Equals(type, typeof(Vector4));
	}

	public override object ReadJson(Type type, Dictionary<string, object> values)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		if (object.Equals(type, typeof(Vector2)))
		{
			return (object)new Vector2(((JsonConverter)this).CastFloat(values["x"]), ((JsonConverter)this).CastFloat(values["y"]));
		}
		if (object.Equals(type, typeof(Vector3)))
		{
			return (object)new Vector3(((JsonConverter)this).CastFloat(values["x"]), ((JsonConverter)this).CastFloat(values["y"]), ((JsonConverter)this).CastFloat(values["z"]));
		}
		if (object.Equals(type, typeof(Vector4)))
		{
			return (object)new Vector4(((JsonConverter)this).CastFloat(values["x"]), ((JsonConverter)this).CastFloat(values["y"]), ((JsonConverter)this).CastFloat(values["z"]), ((JsonConverter)this).CastFloat(values["w"]));
		}
		throw new NotImplementedException("Can only read Vector2,3,4. Not objects of type " + type);
	}

	public override Dictionary<string, object> WriteJson(Type type, object value)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		if (object.Equals(type, typeof(Vector2)))
		{
			Vector2 val = (Vector2)value;
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			dictionary.Add("x", val.x);
			dictionary.Add("y", val.y);
			return dictionary;
		}
		if (object.Equals(type, typeof(Vector3)))
		{
			Vector3 val2 = (Vector3)value;
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			dictionary.Add("x", val2.x);
			dictionary.Add("y", val2.y);
			dictionary.Add("z", val2.z);
			return dictionary;
		}
		if (object.Equals(type, typeof(Vector4)))
		{
			Vector4 val3 = (Vector4)value;
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			dictionary.Add("x", val3.x);
			dictionary.Add("y", val3.y);
			dictionary.Add("z", val3.z);
			dictionary.Add("w", val3.w);
			return dictionary;
		}
		throw new NotImplementedException("Can only write Vector2,3,4. Not objects of type " + type);
	}
}
