using System.Collections;
using UnityEngine;

[RequireComponent(typeof(tk2dSpriteAnimator))]
public class tk2dSpriteAnimatorRare : MonoBehaviour
{
	public string clipToWatch;

	public string[] clipsToPlay;

	public float probability = 0.25f;

	public int minLoops;

	public bool flipOnReturn;

	private tk2dSpriteAnimationClip _activeClip;

	private int _loopCounter;

	private tk2dSpriteAnimationClip prevCurrentClip;

	private int prevFrame;

	[SerializeField]
	private tk2dSpriteAnimator _animator;

	private bool clipToWatchActive => animator.CurrentClip != null && animator.CurrentClip.name == clipToWatch;

	public tk2dSpriteAnimator animator => _animator;

	private void Awake()
	{
		if ((Object)(object)_animator == (Object)null)
		{
			_animator = ((Component)this).GetComponent<tk2dSpriteAnimator>();
		}
	}

	private void Start()
	{
		prevCurrentClip = _animator.CurrentClip;
		HandleAnimationChanged(_animator);
	}

	private void Update()
	{
		if (clipToWatchActive)
		{
			if (_animator.CurrentFrame < prevFrame)
			{
				HandleLoopComplete(_animator.CurrentClip);
			}
			prevFrame = _animator.CurrentFrame;
		}
		if (_animator.CurrentClip != prevCurrentClip)
		{
			HandleAnimationChanged(_animator);
		}
		prevCurrentClip = _animator.CurrentClip;
	}

	private void HandleAnimationChanged(tk2dSpriteAnimator animator)
	{
		if (animator.CurrentClip != null)
		{
			_loopCounter = 0;
		}
	}

	private void HandleLoopComplete(tk2dSpriteAnimationClip clip)
	{
		if (clipsToPlay.Length > 0)
		{
			_loopCounter++;
			if (_loopCounter > minLoops && Random.value <= probability)
			{
				((MonoBehaviour)this).StartCoroutine(WaitForClip(clipsToPlay[Random.Range(0, clipsToPlay.Length)]));
			}
		}
	}

	private IEnumerator WaitForClip(string clipName)
	{
		_animator.Play(clipName);
		_activeClip = _animator.CurrentClip;
		while (_animator.CurrentClip == _activeClip)
		{
			if (!_animator.Playing)
			{
				_animator.Play(clipToWatch);
				_activeClip = null;
				if (flipOnReturn)
				{
					_animator.Sprite.FlipX = !_animator.Sprite.FlipX;
				}
				break;
			}
			yield return null;
		}
	}
}
