using UnityEngine;

public static class CameraPathExtensions
{
	public static Bounds GetBounds(this CameraPath cameraPath)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		Vector3 worldPosition = cameraPath.GetPoint(0).worldPosition;
		Vector3 val = worldPosition;
		for (int i = 1; i < cameraPath.realNumberOfPoints; i++)
		{
			Vector3 worldPosition2 = cameraPath.GetPoint(i).worldPosition;
			if (worldPosition2.x < worldPosition.x)
			{
				worldPosition.x = worldPosition2.x;
			}
			else if (worldPosition2.x > val.x)
			{
				val.x = worldPosition2.x;
			}
			if (worldPosition2.y < worldPosition.y)
			{
				worldPosition.y = worldPosition2.y;
			}
			else if (worldPosition2.y > val.y)
			{
				val.y = worldPosition2.y;
			}
			if (worldPosition2.z < worldPosition.z)
			{
				worldPosition.z = worldPosition2.z;
			}
			else if (worldPosition2.z > val.z)
			{
				val.z = worldPosition2.z;
			}
		}
		Vector3 val2 = (val + worldPosition) / 2f;
		Vector3 val3 = val - worldPosition;
		return new Bounds(val2, val3);
	}
}
