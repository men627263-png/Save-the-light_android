using HutongGames.PlayMaker;

[ActionCategory(/*Could not decode attribute arguments.*/)]
public class STLRemoveControllerVibration : FsmStateAction
{
	[Tooltip("The ID of the vibration instance you wish to remove")]
	public FsmString id;

	public override void Reset()
	{
		id = FsmString.op_Implicit(string.Empty);
	}

	public override void OnEnter()
	{
		EventMessenger.Instance.Raise(new RemoveVibrationEvent(id.Value));
		((FsmStateAction)this).Finish();
	}
}
