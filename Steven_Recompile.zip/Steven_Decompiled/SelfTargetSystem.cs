using System;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Target Systems/Self")]
public class SelfTargetSystem : BattleTargetSystem
{
	[NonSerialized]
	private BaseCharacter caster;

	public override bool canExit => false;

	public override ITargetable lastSelected => null;

	protected override void OnStartTargeting(BaseCharacter caster, AbilityTargetType targetType, bool canTargetNonCharacters, ITargetable initialTarget = null)
	{
		this.caster = caster;
	}

	protected override void OnUpdateTargeting()
	{
		OnTargetsSelected(new List<ITargetable> { caster });
	}

	protected override void OnEndTargeting()
	{
		caster = null;
	}

	public override void ResetForReUse()
	{
		caster = null;
		base.ResetForReUse();
	}
}
