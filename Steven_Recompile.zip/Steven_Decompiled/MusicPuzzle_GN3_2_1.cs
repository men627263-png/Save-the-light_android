using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicPuzzle_GN3_2_1 : MusicPuzzle
{
	[Serializable]
	public class PuzzleRockAnimator
	{
		public Animator animator;

		public RockColor targetColor;

		public RockColor currentColor { get; set; }

		public bool hasPlayed { get; set; }
	}

	public enum RockColor
	{
		None,
		Red,
		Green,
		Blue
	}

	public Animator redLight;

	public Animator greenLight;

	public Animator blueLight;

	public int redSolution;

	public int greenSolution;

	public int blueSolution;

	public List<PuzzleRockAnimator> rockAnimators;

	private bool checkingForLostView;

	private IEnumerator CheckLostView()
	{
		checkingForLostView = true;
		while (true)
		{
			if (!IsAnyRequiredViewpointInView())
			{
				int num = 0;
				foreach (PuzzleRockAnimator rockAnimator in rockAnimators)
				{
					if (rockAnimator.hasPlayed)
					{
						num++;
						break;
					}
				}
				if (num > 0)
				{
					ResetRockStates();
					break;
				}
			}
			if (solved)
			{
				break;
			}
			yield return null;
		}
		checkingForLostView = false;
	}

	protected override void Solve(MusicPuzzleSolution solution, int solutionIndex)
	{
		if (!checkingForLostView)
		{
			((MonoBehaviour)this).StartCoroutine(CheckLostView());
		}
		if (solutionIndex == redSolution)
		{
			redLight.Play("Greg_PuzzleColor_Activate", 0, 0f);
		}
		else if (solutionIndex == greenSolution)
		{
			greenLight.Play("Greg_PuzzleColor_Activate", 0, 0f);
		}
		else if (solutionIndex == blueSolution)
		{
			blueLight.Play("Greg_PuzzleColor_Activate", 0, 0f);
		}
		int num = 0;
		PuzzleRockAnimator puzzleRockAnimator = rockAnimators.Find((PuzzleRockAnimator x) => !x.hasPlayed);
		if (puzzleRockAnimator != null)
		{
			puzzleRockAnimator.hasPlayed = true;
			foreach (PuzzleRockAnimator rockAnimator in rockAnimators)
			{
				if (rockAnimator.hasPlayed)
				{
					num++;
				}
			}
			if (solutionIndex == redSolution)
			{
				puzzleRockAnimator.currentColor = RockColor.Red;
				puzzleRockAnimator.animator.Play("Greg_Puzzle_RockGlow_Red", 0, 0f);
			}
			else if (solutionIndex == greenSolution)
			{
				puzzleRockAnimator.currentColor = RockColor.Green;
				puzzleRockAnimator.animator.Play("Greg_Puzzle_RockGlow_Green", 0, 0f);
			}
			else if (solutionIndex == blueSolution)
			{
				puzzleRockAnimator.currentColor = RockColor.Blue;
				puzzleRockAnimator.animator.Play("Greg_Puzzle_RockGlow_Blue", 0, 0f);
			}
			greg.ClearNotesPlayed();
			if (num < rockAnimators.Count)
			{
				((MonoBehaviour)this).StartCoroutine(SolvedColorSequence(solutionIndex));
			}
		}
		if (num < rockAnimators.Count)
		{
			return;
		}
		bool flag = true;
		for (int num2 = 0; num2 < rockAnimators.Count; num2++)
		{
			PuzzleRockAnimator puzzleRockAnimator2 = rockAnimators[num2];
			if (puzzleRockAnimator2.currentColor != puzzleRockAnimator2.targetColor)
			{
				flag = false;
				break;
			}
		}
		if (flag)
		{
			if (PuzzleSolved != null)
			{
				PuzzleSolved(this, solutionIndex);
			}
			solved = true;
			greg.NotePlayed -= HandleNewNotePlayed;
			((MonoBehaviour)this).StartCoroutine(SolvedSequence());
		}
		else
		{
			ResetRockStates();
		}
	}

	private IEnumerator SolvedColorSequence(int solutionIndex)
	{
		isBusy = true;
		for (int i = 0; i < solutions.Length; i++)
		{
			MusicPuzzleSolution musicPuzzleSolution = solutions[i];
			if (i == solutionIndex)
			{
				int count = musicPuzzleSolution.requiredNotes.Count;
				for (int j = 0; j < count; j++)
				{
					MusicNote musicNote = musicPuzzleSolution.requiredNotes[j];
					((Component)musicNote.glowSprite).GetComponent<Animator>().SetTrigger("Pulse100");
				}
				break;
			}
		}
		yield return (object)new WaitForSeconds(1f);
		isBusy = false;
	}

	private IEnumerator SolvedSequence()
	{
		PlayerGameState.Instance.CompletePuzzle(guid);
		if (SuccessPlaybackStarted != null)
		{
			SuccessPlaybackStarted();
		}
		yield return (object)new WaitForSeconds(0.75f);
		AudioSource success = successMusic.Play();
		for (int i = 0; i < solutions.Length; i++)
		{
			MusicPuzzleSolution musicPuzzleSolution = solutions[i];
			int count = musicPuzzleSolution.requiredNotes.Count;
			for (int j = 0; j < count; j++)
			{
				MusicNote musicNote = musicPuzzleSolution.requiredNotes[j];
				if (musicNote.detached)
				{
					if ((Object)(object)musicNote.placedPuzzlePiece != (Object)null)
					{
						for (int k = 0; k < musicNote.placedPuzzlePiece.glowSprites.Length; k++)
						{
							tk2dBaseSprite tk2dBaseSprite2 = musicNote.placedPuzzlePiece.glowSprites[j];
							((Component)tk2dBaseSprite2).GetComponent<Animator>().SetTrigger("Pulse100");
						}
					}
				}
				else
				{
					((Component)musicNote.glowSprite).GetComponent<Animator>().SetTrigger("Pulse100");
				}
			}
		}
		while (success.isPlaying)
		{
			yield return null;
		}
		if ((Object)(object)base.chestSpawner != (Object)null)
		{
			base.chestSpawner.SpawnChest();
			bool continueSequence = false;
			WaitForChestSpawn = () =>
			{
				continueSequence = true;
			};
			ChestSpawner chestSpawner = base.chestSpawner;
			chestSpawner.FinishedSpawning = (Action)Delegate.Combine(chestSpawner.FinishedSpawning, WaitForChestSpawn);
			yield return (object)new WaitForSeconds(0.5f);
			GameCamera.instance.SetTarget(((Component)base.chestSpawner).transform);
			while (!continueSequence)
			{
				yield return null;
			}
			ChestSpawner chestSpawner2 = base.chestSpawner;
			chestSpawner2.FinishedSpawning = (Action)Delegate.Remove(chestSpawner2.FinishedSpawning, WaitForChestSpawn);
			GameCamera.instance.SetTarget(((Component)GameController.Instance.partyLeader).transform);
		}
		if (SuccessPlaybackEnded != null)
		{
			SuccessPlaybackEnded();
		}
		SuccessPlaybackStarted = null;
		SuccessPlaybackEnded = null;
		Animator[] array = startAnimators;
		foreach (Animator val in array)
		{
			val.Play("greg_puzzlewall_exit");
		}
		if (triggerEventOnSolved > -1)
		{
			PlayerGameState.Instance.TriggerGamePlayEvent(triggerEventOnSolved, GamePlayEventState.Complete, save: false);
		}
	}

	private void ResetRockStates()
	{
		foreach (PuzzleRockAnimator rockAnimator in rockAnimators)
		{
			rockAnimator.hasPlayed = false;
			rockAnimator.animator.Play("Greg_Puzzle_RockGlow_Hold", 0, 0f);
		}
	}
}
