using System.Collections.Generic;
using UnityEngine;

public class UIItemButtonGroup : MonoBehaviour
{
	public UIItemButton[] buttons;

	public RadialLayout radialLayout;

	private Canvas uiCanvas;

	private Collider characterCollider;

	public BaseCharacter character { get; private set; }

	private void Awake()
	{
		if ((Object)(object)radialLayout == (Object)null)
		{
			radialLayout = ((Component)this).GetComponent<RadialLayout>();
		}
	}

	public void SetItems(List<ItemData> itemList, BaseCharacter character, Canvas uiCanvas)
	{
		this.character = character;
		this.uiCanvas = uiCanvas;
		characterCollider = ((Component)character).GetComponent<Collider>();
		int num = buttons.Length;
		for (int i = 0; i < num; i++)
		{
			if (i < itemList.Count)
			{
				((Component)buttons[i]).gameObject.SetActive(true);
			}
			else
			{
				((Component)buttons[i]).gameObject.SetActive(false);
			}
		}
		radialLayout.MaxAngle = 360f / (float)itemList.Count;
	}

	private void LateUpdate()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)uiCanvas == (Object)null) && !((Object)(object)characterCollider == (Object)null))
		{
			Transform transform = ((Component)this).transform;
			Canvas canvas = uiCanvas;
			Bounds bounds = characterCollider.bounds;
			transform.localPosition = Vector2.op_Implicit(canvas.WorldToCanvas(bounds.center));
		}
	}
}
