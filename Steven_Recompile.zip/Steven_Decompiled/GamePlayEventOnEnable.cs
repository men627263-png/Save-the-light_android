using UnityEngine;

public class GamePlayEventOnEnable : MonoBehaviour
{
	public int gameEventUID;

	public GamePlayEventState activateState;

	public bool onlyOnce;

	private void Start()
	{
		PlayerGameState.Instance.PlayerDataChanged += HandlePlayerDataChanged;
		HandlePlayerDataChanged();
	}

	private void OnDestroy()
	{
		PlayerGameState.Instance.PlayerDataChanged -= HandlePlayerDataChanged;
	}

	private void HandlePlayerDataChanged()
	{
		if (!onlyOnce || !PlayerGameState.Instance.HasCompletedGamePlayEventID(gameEventUID))
		{
			PlayerGameState.Instance.TriggerGamePlayEvent(gameEventUID, activateState);
		}
	}
}
