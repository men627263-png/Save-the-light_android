public interface IBackpackItem
{
	BackpackItemType backpackItemType { get; set; }
}
