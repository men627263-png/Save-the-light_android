using System;
using System.Collections;
using UnityEngine;

public class StrawberryKnight_EyeHolder : MonoBehaviour, ITargetable, IDamageReceiver, ITinter
{
	[SerializeField]
	protected Animator animator;

	[SerializeField]
	protected CharacterAnimator characterAnimator;

	[SerializeField]
	protected MeshRenderer eyeRenderer;

	[SerializeField]
	protected HitBoxManager hitBoxManager;

	[SerializeField]
	protected TintAdapter[] tintAdapters;

	[SerializeField]
	protected Transform frontPosition;

	[SerializeField]
	protected Transform backPosition;

	[SerializeField]
	protected Transform centerTopPosition;

	[Header("Animations")]
	[SerializeField]
	private CharacterAnimationNamePair idleAnim;

	[SerializeField]
	private CharacterAnimationNamePair idleShatteredAnim;

	[SerializeField]
	private CharacterAnimationNamePair shatterAnim;

	[SerializeField]
	private CharacterAnimationNamePair regenerateAnim;

	[SerializeField]
	private CharacterAnimationNamePair hurtAnim;

	[SerializeField]
	private CharacterAnimationNamePair openCloseAnim;

	[Header("Tweakables")]
	[SerializeField]
	private int baseMaxHealth = 20;

	[SerializeField]
	private int baseDefense;

	[Header("Sounds")]
	[SerializeField]
	private DelayedAudioEvent openSound;

	[SerializeField]
	private DelayedAudioEvent closeSound;

	[SerializeField]
	private DelayedAudioEvent deathSound;

	protected Vector3 eyeRendererHomePos;

	protected StrawberryKnight _owner;

	private int currentHealth;

	private CharacterStats stats;

	protected StatusEffectManager statusEffectManager;

	protected TargetableTinter targetableTinter;

	private Color tintColor = new Color(1f, 1f, 1f, 0f);

	protected bool _isShattered;

	private bool _hasEye;

	public Animator Animator => animator;

	public int CurrentHealthValue => currentHealth;

	public int MaxHealthValue => Stats.MaxHealthStat.Value;

	public int DefenseValue => Stats.DefenseStat.Value;

	public Vector3 FrontPosition
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return frontPosition.position;
		}
	}

	public Vector3 BackPosition
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return backPosition.position;
		}
	}

	public Vector3 CenterPosition
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return ((Component)this).transform.position;
		}
	}

	public Vector3 CenterTopPosition
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return centerTopPosition.position;
		}
	}

	public bool IsTargetable => true;

	public virtual bool IsFlying => false;

	public bool IsAlive => !IsDead;

	public bool IsDead => _owner.isDead;

	public float EffectScale => 1f;

	public virtual bool CanBlock => false;

	public IDamageReceiver damageReceiver => this;

	public CharacterStats Stats
	{
		get
		{
			if (stats == null)
			{
				stats = new CharacterStats();
			}
			return stats;
		}
	}

	public HitBoxManager HitBoxManager => hitBoxManager;

	public StatusEffectManager StatusEffectManager
	{
		get
		{
			if ((Object)(object)statusEffectManager == (Object)null)
			{
				statusEffectManager = ((Component)this).GetComponent<StatusEffectManager>();
				if ((Object)(object)statusEffectManager == (Object)null)
				{
					statusEffectManager = ((Component)this).gameObject.AddComponent<StatusEffectManager>();
				}
				statusEffectManager.Init(this);
			}
			return statusEffectManager;
		}
	}

	public StatusEffectName[] InnateImmunities => new StatusEffectName[1] { StatusEffectName.Shock };

	public TargetableTinter TargetableTinter
	{
		get
		{
			if ((Object)(object)targetableTinter == (Object)null)
			{
				targetableTinter = ((Component)this).GetComponent<TargetableTinter>();
			}
			return targetableTinter;
		}
	}

	public Color TintColor
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return tintColor;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			tintColor = value;
			for (int i = 0; i < tintAdapters.Length; i++)
			{
				tintAdapters[i].tintColor = tintColor;
			}
		}
	}

	public Renderer[] AllRenderers => _owner.AllRenderers;

	public bool isShattered
	{
		get
		{
			return _isShattered;
		}
		set
		{
			_isShattered = value;
			RefreshEyeRenderer();
		}
	}

	public bool hasEye
	{
		get
		{
			return _hasEye;
		}
		set
		{
			_hasEye = value;
			RefreshEyeRenderer();
		}
	}

	public event Action<int> HealthUpdated;

	public event Action<DamageResult> IncomingDamage;

	public event Action<DamageResult> DamageReceived;

	public event Action<HealResult> IncomingHeal;

	public event Action<HealResult> HealReceived;

	public StrawberryKnight_EyeHolder()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
	}

	private void OnEnable()
	{
		characterAnimator.AnimationChanged += HandleAnimationChanged;
	}

	private void OnDisable()
	{
		characterAnimator.AnimationChanged -= HandleAnimationChanged;
	}

	protected virtual void Start()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		Stats.MaxHealthStat.BaseValue = (currentHealth = baseMaxHealth);
		Stats.DefenseStat.BaseValue = baseDefense;
		hasEye = false;
		eyeRendererHomePos = ((Component)eyeRenderer).transform.localPosition;
		_owner = ((Component)this).GetComponentInParent<StrawberryKnight>();
		characterAnimator.Play(GetIdleAnimation());
	}

	private void HandleAnimationChanged()
	{
		RefreshEyeRenderer();
	}

	protected virtual CharacterAnimationNamePair GetIdleAnimation()
	{
		return (!_isShattered) ? idleAnim : idleShatteredAnim;
	}

	public virtual void Regenerate()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		currentHealth = MaxHealthValue;
		if (isShattered)
		{
			isShattered = false;
			characterAnimator.Play(regenerateAnim);
			characterAnimator.AddToQueue(GetIdleAnimation());
			((Component)eyeRenderer).transform.localPosition = eyeRendererHomePos;
		}
	}

	protected void RefreshEyeRenderer()
	{
		((Renderer)eyeRenderer).enabled = hasEye && (_isShattered || characterAnimator.currentAnimation.Equals(openCloseAnim));
	}

	public IEnumerator PlayOpenClose(float speed = 1f)
	{
		float originalSpeed = animator.speed;
		animator.speed = speed;
		characterAnimator.PlayFromFrame(openCloseAnim, 0, clearQueue: true);
		openSound.Play(((Component)this).transform.position);
		yield return (object)new WaitWhile((Func<bool>)(() => characterAnimator.IsPlaying(openCloseAnim)));
		closeSound.Play(((Component)this).transform.position);
		animator.speed = originalSpeed;
		characterAnimator.Play(GetIdleAnimation());
	}

	public void SetMaxHealth(int newMaxHealth, bool updateCurrentHealth = false)
	{
		Stats.MaxHealthStat.BaseValue = newMaxHealth;
		if (updateCurrentHealth)
		{
			currentHealth = MaxHealthValue;
		}
	}

	public void SetDefense(int newDefense)
	{
		Stats.DefenseStat.BaseValue = newDefense;
	}

	public void OnHealthUpdated(int delta)
	{
		if (HealthUpdated != null)
		{
			HealthUpdated(delta);
		}
		EventMessenger.Instance.Raise(new HealthUpdatedEvent(this, delta));
	}

	public void OnIncomingDamage(DamageResult damageResult)
	{
		if (IncomingDamage != null)
		{
			IncomingDamage(damageResult);
		}
	}

	public void OnDamageReceived(DamageResult damageResult)
	{
		if (DamageReceived != null)
		{
			DamageReceived(damageResult);
		}
	}

	public void OnIncomingHeal(HealResult healResult)
	{
		if (IncomingHeal != null)
		{
			IncomingHeal(healResult);
		}
	}

	public void OnHealReceived(HealResult healResult)
	{
		if (HealReceived != null)
		{
			HealReceived(healResult);
		}
	}

	public void DoDamage(DamageResult damageResult)
	{
		damageResult.allowDisplay = false;
		if (!isShattered)
		{
			if (damageResult.source != null)
			{
				damageResult.source.OnOutgoingDamage(damageResult);
			}
			OnIncomingDamage(damageResult);
			currentHealth -= damageResult.totalDamage;
			OnDamageReceived(damageResult);
			if (damageResult.source != null)
			{
				damageResult.source.OnDamageDealt(damageResult);
			}
			EventMessenger.Instance.Raise(new DamageResultEvent(damageResult));
			HandleDamageResult(damageResult);
		}
		else
		{
			OnDamageReceived(damageResult);
		}
	}

	protected void HandleDamageResult(DamageResult damageResult)
	{
		if (damageResult.totalDamage <= 0)
		{
			return;
		}
		if (CurrentHealthValue > 0)
		{
			if (damageResult.combatType != CombatType.None && !_isShattered)
			{
				characterAnimator.PlayFromFrame(hurtAnim, 0, clearQueue: true);
				characterAnimator.AddToQueue(GetIdleAnimation());
			}
		}
		else if (!isShattered && !IsDead)
		{
			Kill(damageResult.source);
		}
	}

	public void DoHeal(HealResult healResult)
	{
	}

	public virtual bool CanBeTargetedByAbility(BaseAbility ability)
	{
		return true;
	}

	public virtual void Kill(IDamageSender source)
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (_owner.isDead)
		{
			_owner.Kill(source);
		}
		else if (!isShattered)
		{
			isShattered = true;
			characterAnimator.Play(shatterAnim, clearQueue: true);
			characterAnimator.AddToQueue(GetIdleAnimation());
			deathSound.Play(((Component)this).transform.position);
		}
	}

	public Vector3 GetClosestSidePosition(Vector3 fromPosition)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		float num = Vector3.Distance(FrontPosition, fromPosition);
		float num2 = Vector3.Distance(BackPosition, fromPosition);
		return (!(num < num2)) ? BackPosition : FrontPosition;
	}
}
