public class HealthBarDisplayerShowEvent : GameEvent
{
	public ITargetable targetable { get; private set; }

	public HealthBarDisplayerShowEvent(ITargetable targetable)
	{
		this.targetable = targetable;
	}
}
