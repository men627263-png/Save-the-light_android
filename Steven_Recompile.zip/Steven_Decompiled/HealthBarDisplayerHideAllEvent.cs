public class HealthBarDisplayerHideAllEvent : GameEvent
{
	public bool instant { get; private set; }

	public HealthBarDisplayerHideAllEvent(bool instant)
	{
		this.instant = instant;
	}
}
