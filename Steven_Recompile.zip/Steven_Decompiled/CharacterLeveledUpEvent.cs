public class CharacterLeveledUpEvent : GameEvent
{
	public UILevelUpText levelUpText;

	public CharacterLeveledUpEvent(UILevelUpText levelUpText)
	{
		this.levelUpText = levelUpText;
	}
}
