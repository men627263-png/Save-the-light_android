using System;
using System.Collections;
using DG.Tweening;
using Grumpyface;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Abilities/Enemies/Cannon/Shoot")]
public class Cannon_ShootAbility : BaseAbility
{
	[Serializable]
	private class AbilityData
	{
		[Header("Prefabs")]
		public CannonEnemyBullet bulletPrefab;

		public GameObject bulletHitPrefab;

		[Header("Animations")]
		public CharacterAnimationNamePair attackAnim = default;

		[Header("Tweakables")]
		public DamageInfo damage;

		public float projectileSpeed = 20f;

		public float yOffset = 1.8f;

		public float projectileHitTimeOffset = -0.05f;

		[Header("Sounds")]
		public DelayedAudioEvent shootSound = default;
	}

	[SerializeField]
	private BonusStarData bonusStarData;

	[SerializeField]
	private AbilityData abilityData;

	[NonSerialized]
	private ITargetable target;

	[NonSerialized]
	private CannonEnemy cannonEnemy;

	[NonSerialized]
	private CannonEnemyBullet bullet;

	[NonSerialized]
	private float prevTimeScale;

	public override IEnumerator Play()
	{
		prevTimeScale = Time.timeScale;
		target = targets[0];
		cannonEnemy = (CannonEnemy)caster;
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)caster).transform, 1f)));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(target.transform, 1f)));
		EventMessenger.Instance.Raise(new CameraZoomEvent(1.3f));
		caster.PlayAnim(abilityData.attackAnim, clearQueue: true);
		caster.AddAnimToQueue(caster.GetIdleAnimation());
		abilityData.shootSound.Play(((Component)caster).transform.position);
		Transform launchPosition = ((Component)caster.animatorTk2d).GetComponent<tk2dSpriteAttachPoint>().attachPoints.Find((Transform x) => ((Object)x).name.Equals("ballLaunchPos"));
		bullet = Object.Instantiate<CannonEnemyBullet>(abilityData.bulletPrefab);
		bullet.projectileSpeedInBattle = abilityData.projectileSpeed;
		bullet.arcYOffset = abilityData.yOffset;
		bullet.Init(cannonEnemy, target.damageReceiver, launchPosition.position, new Vector3(0f, 0.75f));
		TweenExtensions.Pause<Tweener>(bullet.bulletTween);
		((Component)bullet).gameObject.SetActive(false);
		int shootFrame = caster.animatorTk2d.CurrentClip.GetFrameWithEventInfo("FireBullet");
		StarBonusCheck bonusCheck = StartBonusCheck(Time.time + (caster.animatorTk2d.CurrentClip.GetFrameTime(shootFrame) - caster.animatorTk2d.ClipTimeSeconds) + TweenExtensions.Duration((Tween)(object)bullet.bulletTween, true), bonusStarData);
		yield return (object)new WaitWhile((Func<bool>)(() => caster.animatorTk2d.CurrentFrame < shootFrame));
		((Component)bullet).gameObject.SetActive(true);
		TweenExtensions.Restart((Tween)(object)bullet.bulletTween, true);
		yield return (object)new WaitUntil((Func<bool>)(() => bullet.isTargetReached));
		LastFrameBonusCheck(bonusCheck);
		DamageResult result = BattleHelper.CalculateDamage(caster, target.damageReceiver, abilityData.damage, allowDeath: true, this);
		result.source = bullet;
		BattleHelper.DoDamage(result, bonusCheck);
		if (bonusCheck.isBonusPerfectSuccess)
		{
			EventMessenger.Instance.Raise(new PerfectAttackEvent(bonusStarMeterOnPerfect));
			if (!preventFreezeDuration)
			{
				yield return (object)new WaitWhile((Func<bool>)(() => Time.timeScale == 0f));
				prevTimeScale = Time.timeScale;
				Time.timeScale = 0f;
				yield return new WaitForSecondsIndependentUnpaused(bonusStarData.bonusPerfectFreezeDuration);
				Time.timeScale = prevTimeScale;
			}
		}
		yield return (object)new WaitUntil((Func<bool>)(() => bullet.isTargetReached));
		ObjectPool.GetObject(abilityData.bulletHitPrefab, ((Component)bullet).transform.position);
		Object.Destroy((Object)(object)((Component)bullet).gameObject);
		bullet = null;
		yield return (object)new WaitForSeconds(1f);
	}

	public override IEnumerator Cancel()
	{
		if ((Object)(object)bullet != (Object)null)
		{
			ObjectPool.GetObject(abilityData.bulletHitPrefab, ((Component)bullet).transform.position);
			Object.Destroy((Object)(object)((Component)bullet).gameObject);
			bullet = null;
		}
		yield break;
	}

	protected override void OnCleanUp()
	{
		base.OnCleanUp();
	}

	public override void ResetForReUse()
	{
		target = null;
		cannonEnemy = null;
		bullet = null;
		base.ResetForReUse();
	}
}
