using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Rewired;
using SimpleSpritePacker;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;
using UnityEngine.UI;

public class UIUpgradeScreen : MonoBehaviour
{
	public enum Mode
	{
		Upgrade,
		Equipment,
		Relationship
	}

	[Serializable]
	public struct CharacterColorPair
	{
		public CharacterName characterName;

		public Color color1;

		public Color color2;
	}

	[Serializable]
	public struct CharacterVectorPair
	{
		public CharacterName characterName;

		public Vector3 vector1;
	}

	public static Dictionary<CharacterName, string> upgradeScreenBGBorders = new Dictionary<CharacterName, string>
	{
		{
			CharacterName.Steven,
			"abliltyunlock_steven_bg"
		},
		{
			CharacterName.Connie,
			"abliltyunlock_connie_bg"
		},
		{
			CharacterName.Garnet,
			"abliltyunlock_garnet_bg"
		},
		{
			CharacterName.Greg,
			"abliltyunlock_greg_bg"
		},
		{
			CharacterName.Amethyst,
			"abliltyunlock_amethyst_bg"
		},
		{
			CharacterName.Pearl,
			"abliltyunlock_pearl_bg"
		},
		{
			CharacterName.Peridot,
			"abliltyunlock_peridot_bg"
		}
	};

	public static Dictionary<CharacterName, string> upgradeScreenHeaderSprites = new Dictionary<CharacterName, string>
	{
		{
			CharacterName.Steven,
			"upgradescreen_header_steven"
		},
		{
			CharacterName.Connie,
			"upgradescreen_header_connie"
		},
		{
			CharacterName.Garnet,
			"upgradescreen_header_garnet"
		},
		{
			CharacterName.Greg,
			"upgradescreen_header_greg"
		},
		{
			CharacterName.Amethyst,
			"upgradescreen_header_amethyst"
		},
		{
			CharacterName.Pearl,
			"upgradescreen_header_pearl"
		},
		{
			CharacterName.Peridot,
			"upgradescreen_header_peridot"
		}
	};

	public static Dictionary<CharacterStatType, string> perkStatIcons = new Dictionary<CharacterStatType, string>
	{
		{
			CharacterStatType.Attack,
			"gui_unlockmove_stat_attack"
		},
		{
			CharacterStatType.Defense,
			"gui_unlockmove_stat_defense"
		},
		{
			CharacterStatType.Luck,
			"gui_unlockmove_stat_luck"
		},
		{
			CharacterStatType.Teamwork,
			"gui_unlockmove_stat_teamwork"
		}
	};

	public Animator animator;

	public UIUpgradeTick tickPrefab;

	public SPInstance uiAtlas;

	public Transform upgradeGrpTransform;

	public TextMeshProUGUI nameText;

	public Image headerSprite;

	public tk2dSprite characterSprite;

	public TextMeshProUGUI levelText;

	public TextMeshProUGUI healthText;

	public Image healthFill;

	public float healthBarFillEmpty = 200f;

	public float healthBarFillFull = 358f;

	public Image xpBarFill;

	public TextMeshProUGUI attackTextLarge;

	public TextMeshProUGUI defenseTextLarge;

	public TextMeshProUGUI luckTextLarge;

	public TextMeshProUGUI teamworkTextLarge;

	public TextMeshProUGUI skillPointsTotalText;

	public TextMeshProUGUI descriptionHeaderText;

	public TextMeshProUGUI descriptionText;

	[Header("Weapon Upgrades")]
	public GameObject weaponDescriptionGrp;

	public TextMeshProUGUI tierHeaderTextTier2;

	public TextMeshProUGUI tierHeaderTextTier3;

	public TextMeshProUGUI tierDescriptionTextTier2;

	public TextMeshProUGUI tierDescriptionTextTier3;

	public TextMeshProUGUI skillPointCostText;

	public GameObject skillPointCostGrp;

	public TextMeshProUGUI badgeHeaderText;

	public RawImage scrollingBG;

	public List<CharacterMaterial> scrollingBGMats;

	public Image bgBorder;

	public GameObject attackTickStart;

	public GameObject defenseTickStart;

	public GameObject luckTickStart;

	public GameObject teamworkTickStart;

	[FormerlySerializedAs("selectorObj")]
	public GameObject selectorObjTick;

	public GameObject selectorObjSquare;

	public GameObject selectorObjCircle;

	public UIOnScreenButton backButton;

	public UIOnScreenButton selectButton;

	public UIOnScreenButton removeButton;

	public UIOnScreenButton clearButton;

	public UIOnScreenButton relationshipButton;

	public GameObject switchScreenButtonParent;

	public UIRelationshipMeter[] relationshipMeters;

	public UIEquipmentSlot weaponSlot;

	public Image weaponUpgradeCrystal0;

	public Image weaponUpgradeCrystal1;

	public Image weaponUpgradeCrystal2;

	public UIEquipmentSlot badgeSlot0;

	public UIEquipmentSlot badgeSlot1;

	public CharacterColorPair[] headerFaceOutlineColors;

	public CharacterVectorPair[] characterSpriteOffsets;

	[Header("Perk Unlock Fields")]
	public Animator perkUnlockAnimator;

	public TextMeshProUGUI perkUnlockHeaderSub;

	public TextMeshProUGUI perkUnlockName;

	public TextMeshProUGUI perkUnlockDescripText;

	public Image perkUnlockIcon;

	public Image perkUnlockIconBG;

	public Image perkUnlockButtonBG;

	public Image perkUnlockButtonBorder;

	public Image perkUnlockDescripBG;

	public Image perkUnlockDescripBorder;

	[Header("Audio Clips")]
	public AudioEvent characterEnterAudio;

	public AudioEvent characterSwitchAudio;

	public AudioEvent switchStatAudio;

	public AudioEvent addPointAudio;

	public SimpleAudioEvent addPointErrorAudio;

	public AudioEvent removePointAudio;

	public AudioEvent comfirmPointsAudio;

	public AudioEvent upgradeScreenExitAudio;

	public AudioEvent perkUnlockReveal;

	private Player playerController;

	private tk2dSpriteAnimator characterSpriteAnimator;

	private AnimatorEventListener animatorEventListener;

	private List<GameObject> upgradeTicks = new List<GameObject>();

	private UICharacterScreen characterScreen;

	private CharacterStats characterStats;

	private PlayerCharacter character;

	private GameObject previousSelectedObj;

	private GameObject previousSelectedUpgradeObj;

	private GameObject previousSelectedEquipObj;

	private Nullable originalBadge0Position;

	private Nullable originalBadge1Position;

	private Tweener skillPointFailTween;

	private Vector3 originalCharacterSpriteLocalPos;

	private AudioSource addPointErrorSource;

	private List<UIUpgradeTick> attackTicks = new List<UIUpgradeTick>();

	private List<UIUpgradeTick> defenseTicks = new List<UIUpgradeTick>();

	private List<UIUpgradeTick> luckTicks = new List<UIUpgradeTick>();

	private List<UIUpgradeTick> teamworkTicks = new List<UIUpgradeTick>();

	private int attackMaxLevel;

	private int defenseMaxLevel;

	private int luckMaxLevel;

	private int teamworkMaxLevel;

	private int attackUpgradeCost;

	private int defenseUpgradeCost;

	private int luckUpgradeCost;

	private int teamworkUpgradeCost;

	private int attackLevelTemp = 5;

	private int defenseLevelTemp = 1;

	private int luckLevelTemp;

	private int teamworkLevelTemp = 8;

	private int skillPointsTemp;

	private bool initialized;

	private Mode mode;

	private PlayerCharacter[] party;

	private static UIUpgradeScreen _instance = null;

	public bool isAnimating { get; set; }

	public bool forceUseOfSkillPoints { get; set; }

	public bool preventCharacterChange { get; set; }

	public bool disableRelationshipButton { get; set; }

	public int currentSkillPointsAvailable => skillPointsTemp;

	public static UIUpgradeScreen instance => _instance;

	private void Awake()
	{
		_instance = this;
	}

	private void Start()
	{
		Canvas[] componentsInChildren = ((Component)this).GetComponentsInChildren<Canvas>();
		Canvas[] array = componentsInChildren;
		foreach (Canvas val in array)
		{
			((Behaviour)val).enabled = true;
		}
	}

	private void OnDestroy()
	{
		_instance = null;
	}

	public void Init(UICharacterScreen characterScreen, PlayerCharacter[] party, PlayerCharacter focusedPartyMember, bool playIntroAnim = true)
	{
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_037a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0581: Unknown result type (might be due to invalid IL or missing references)
		//IL_0586: Unknown result type (might be due to invalid IL or missing references)
		//IL_058c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0591: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0695: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_070b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0710: Unknown result type (might be due to invalid IL or missing references)
		//IL_0712: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_080e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0825: Unknown result type (might be due to invalid IL or missing references)
		//IL_082a: Unknown result type (might be due to invalid IL or missing references)
		//IL_082c: Unknown result type (might be due to invalid IL or missing references)
		//IL_073c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0741: Unknown result type (might be due to invalid IL or missing references)
		//IL_074b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0753: Unknown result type (might be due to invalid IL or missing references)
		//IL_0758: Unknown result type (might be due to invalid IL or missing references)
		//IL_090c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0928: Unknown result type (might be due to invalid IL or missing references)
		//IL_093f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0944: Unknown result type (might be due to invalid IL or missing references)
		//IL_0946: Unknown result type (might be due to invalid IL or missing references)
		//IL_0856: Unknown result type (might be due to invalid IL or missing references)
		//IL_085b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0865: Unknown result type (might be due to invalid IL or missing references)
		//IL_086d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0872: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a26: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a42: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a59: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a60: Unknown result type (might be due to invalid IL or missing references)
		//IL_0970: Unknown result type (might be due to invalid IL or missing references)
		//IL_0975: Unknown result type (might be due to invalid IL or missing references)
		//IL_097f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0987: Unknown result type (might be due to invalid IL or missing references)
		//IL_098c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a8a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a8f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a99: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c17: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c42: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c81: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c9a: Unknown result type (might be due to invalid IL or missing references)
		EventSystem.current.SetSelectedGameObject((GameObject)null);
		mode = Mode.Upgrade;
		this.party = party;
		character = focusedPartyMember;
		this.characterScreen = characterScreen;
		characterStats = character.Stats;
		playerController = ReInput.players.GetPlayer(0);
		animatorEventListener = ((Component)animator).GetComponent<AnimatorEventListener>();
		((Component)perkUnlockAnimator).gameObject.SetActive(false);
		if ((Object)(object)character.characterPageVOClip != (Object)null && Random.value <= GameResources.instance.gameSettings.chanceToPlayCharacterPageVO)
		{
			foreach (PlayerCharacter playerCharacter in party)
			{
				if ((Object)(object)playerCharacter.characterPageVOClip != (Object)null)
				{
					AudioEventManager.Instance.Stop(playerCharacter.characterPageVOClip);
				}
			}
			character.characterPageVOClip.Play();
		}
		if (playIntroAnim)
		{
			characterEnterAudio.Play();
			animator.Play("UpgradeScreen_Intro", 0, 0f);
		}
		attackLevelTemp = character.attackLevel;
		defenseLevelTemp = character.defenseLevel;
		luckLevelTemp = character.luckLevel;
		teamworkLevelTemp = character.teamworkLevel;
		skillPointsTemp = character.skillPoints;
		attackMaxLevel = character.characterDefinition.attackUpgradeInfo.totalUpgradeAmount;
		defenseMaxLevel = character.characterDefinition.defenseUpgradeInfo.totalUpgradeAmount;
		luckMaxLevel = character.characterDefinition.luckUpgradeInfo.totalUpgradeAmount;
		teamworkMaxLevel = character.characterDefinition.teamworkUpgradeInfo.totalUpgradeAmount;
		teamworkUpgradeCost = GameResources.instance.gameSettings.teamworkUpgradeCost;
		nameText.text = Languages.Get(character.characterDefinition.characterName.key, "MENUS, GUI");
		for (int j = 0; j < headerFaceOutlineColors.Length; j++)
		{
			CharacterColorPair characterColorPair = headerFaceOutlineColors[j];
			if (characterColorPair.characterName == character.characterName)
			{
				nameText.faceColor = Color32.op_Implicit(characterColorPair.color1);
				nameText.outlineColor = Color32.op_Implicit(characterColorPair.color2);
				break;
			}
		}
		headerSprite.sprite = uiAtlas.GetSpriteByName(upgradeScreenHeaderSprites[character.characterName]);
		levelText.text = Languages.Get("LVL", "MENUS, GUI") + " " + character.currentLevelDisplay;
		healthText.text = character.currentHealth + "/" + character.Stats.MaxHealthStat.BaseValue;
		xpBarFill.fillAmount = character.currentXPRatio;
		Vector2 sizeDelta = ((Graphic)healthFill).rectTransform.sizeDelta;
		sizeDelta.x = healthBarFillEmpty + (healthBarFillFull - healthBarFillEmpty) * Mathf.Clamp01(character.currentHealthRatio);
		((Graphic)healthFill).rectTransform.sizeDelta = sizeDelta;
		attackTextLarge.text = character.Stats.AttackStat.Value.ToString();
		defenseTextLarge.text = character.Stats.DefenseStat.Value.ToString();
		luckTextLarge.text = character.Stats.LuckStat.Value.ToString();
		teamworkTextLarge.text = character.Stats.TeamworkStat.Value.ToString();
		skillPointsTotalText.text = character.skillPoints.ToString();
		descriptionHeaderText.text = string.Empty;
		descriptionText.text = string.Empty;
		skillPointCostText.text = string.Empty;
		scrollingBG.texture = scrollingBGMats.Find((CharacterMaterial x) => x.characterName == character.characterName).texture;
		bgBorder.sprite = uiAtlas.GetSpriteByName(upgradeScreenBGBorders[character.characterName]);
		characterSprite.SetSprite(character.animatorTk2d.Sprite.Collection, character.animatorTk2d.Sprite.spriteId);
		characterSpriteAnimator = ((Component)characterSprite).GetComponent<tk2dSpriteAnimator>();
		characterSpriteAnimator.Library = character.animatorTk2d.Library;
		characterSpriteAnimator.Play(character.animationNames.idleBattle.FrontName);
		((Behaviour)characterSpriteAnimator).enabled = false;
		originalCharacterSpriteLocalPos = ((Component)characterSprite).transform.localPosition;
		Vector3 val = originalCharacterSpriteLocalPos;
		for (int num = 0; num < characterSpriteOffsets.Length; num++)
		{
			CharacterVectorPair characterVectorPair = characterSpriteOffsets[num];
			if (characterVectorPair.characterName == character.characterName)
			{
				val += characterVectorPair.vector1;
				break;
			}
		}
		((Component)characterSprite).transform.localPosition = val;
		attackTickStart.SetActive(false);
		defenseTickStart.SetActive(false);
		luckTickStart.SetActive(false);
		teamworkTickStart.SetActive(false);
		selectorObjTick.SetActive(false);
		selectorObjSquare.SetActive(false);
		selectorObjCircle.SetActive(false);
		((Component)selectButton).gameObject.SetActive(false);
		((Component)removeButton).gameObject.SetActive(false);
		((Component)clearButton).gameObject.SetActive(false);
		Vector3 val2 = new Vector3(30.858f, -147.0371f);
		if (attackTicks.Count == 0)
		{
			for (int num2 = 0; num2 < attackMaxLevel; num2++)
			{
				UIUpgradeTick uIUpgradeTick = Object.Instantiate<UIUpgradeTick>(tickPrefab);
				((Component)uIUpgradeTick).transform.parent = upgradeGrpTransform;
				((Component)uIUpgradeTick).transform.localScale = Vector3.one;
				Vector3 val3 = new Vector3((float)num2 * val2.x, 0f);
				((Component)uIUpgradeTick).transform.position = attackTickStart.transform.position + val3;
				if (num2 > 0)
				{
					((Component)uIUpgradeTick).transform.localPosition = ((Component)attackTicks[0]).transform.localPosition + Vector3.right * 33.35f * (float)num2;
				}
				uIUpgradeTick.statType = CharacterStatType.Attack;
				((Object)uIUpgradeTick).name = uIUpgradeTick.statType.ToString() + " Tick " + num2;
				attackTicks.Add(uIUpgradeTick);
			}
		}
		if (defenseTicks.Count == 0)
		{
			for (int num3 = 0; num3 < defenseMaxLevel; num3++)
			{
				UIUpgradeTick uIUpgradeTick2 = Object.Instantiate<UIUpgradeTick>(tickPrefab);
				((Component)uIUpgradeTick2).transform.parent = upgradeGrpTransform;
				((Component)uIUpgradeTick2).transform.localScale = Vector3.one;
				Vector3 val4 = new Vector3((float)num3 * val2.x, 0f);
				((Component)uIUpgradeTick2).transform.position = defenseTickStart.transform.position + val4;
				if (num3 > 0)
				{
					((Component)uIUpgradeTick2).transform.localPosition = ((Component)defenseTicks[0]).transform.localPosition + Vector3.right * 33.35f * (float)num3;
				}
				uIUpgradeTick2.statType = CharacterStatType.Defense;
				((Object)uIUpgradeTick2).name = uIUpgradeTick2.statType.ToString() + " Tick " + num3;
				defenseTicks.Add(uIUpgradeTick2);
			}
		}
		if (luckTicks.Count == 0)
		{
			for (int num4 = 0; num4 < luckMaxLevel; num4++)
			{
				UIUpgradeTick uIUpgradeTick3 = Object.Instantiate<UIUpgradeTick>(tickPrefab);
				((Component)uIUpgradeTick3).transform.parent = upgradeGrpTransform;
				((Component)uIUpgradeTick3).transform.localScale = Vector3.one;
				Vector3 val5 = new Vector3((float)num4 * val2.x, 0f);
				((Component)uIUpgradeTick3).transform.position = luckTickStart.transform.position + val5;
				if (num4 > 0)
				{
					((Component)uIUpgradeTick3).transform.localPosition = ((Component)luckTicks[0]).transform.localPosition + Vector3.right * 33.35f * (float)num4;
				}
				uIUpgradeTick3.statType = CharacterStatType.Luck;
				((Object)uIUpgradeTick3).name = uIUpgradeTick3.statType.ToString() + " Tick " + num4;
				luckTicks.Add(uIUpgradeTick3);
			}
		}
		if (teamworkTicks.Count == 0)
		{
			for (int num5 = 0; num5 < teamworkMaxLevel; num5++)
			{
				UIUpgradeTick uIUpgradeTick4 = Object.Instantiate<UIUpgradeTick>(tickPrefab);
				((Component)uIUpgradeTick4).transform.parent = upgradeGrpTransform;
				((Component)uIUpgradeTick4).transform.localScale = Vector3.one;
				Vector3 val6 = new Vector3((float)num5 * val2.x, 0f);
				((Component)uIUpgradeTick4).transform.position = teamworkTickStart.transform.position + val6;
				if (num5 > 0)
				{
					((Component)uIUpgradeTick4).transform.localPosition = ((Component)teamworkTicks[0]).transform.localPosition + Vector3.right * 33.35f * (float)num5;
				}
				uIUpgradeTick4.statType = CharacterStatType.Teamwork;
				((Object)uIUpgradeTick4).name = uIUpgradeTick4.statType.ToString() + " Tick " + num5;
				teamworkTicks.Add(uIUpgradeTick4);
			}
		}
		UpdateStatLevels();
		ItemDefinition item = GameController.Instance.itemDatabase.GetItem(character.equippedWeaponID);
		weaponSlot.Init(item);
		string empty = string.Empty;
		string empty2 = string.Empty;
		if (PlayerGameState.Instance.HasWeaponUpgrade(character.characterName, 1))
		{
			empty = "CharacterScreen_weaponupgrade_silver";
			weaponSlot.UpdateSlotSprite(((Object)item.guiSprite2).name);
		}
		else
		{
			empty = "CharacterScreen_weaponupgrade_base";
		}
		if (PlayerGameState.Instance.HasWeaponUpgrade(character.characterName, 2))
		{
			empty2 = "CharacterScreen_weaponupgrade_gold";
			weaponSlot.UpdateSlotSprite(((Object)item.guiSprite3).name);
		}
		else
		{
			empty2 = "CharacterScreen_weaponupgrade_base";
		}
		weaponUpgradeCrystal1.sprite = uiAtlas.GetSpriteByName(empty);
		weaponUpgradeCrystal2.sprite = uiAtlas.GetSpriteByName(empty2);
		if (!originalBadge0Position.HasValue)
		{
			originalBadge0Position = ((Component)badgeSlot0).transform.localPosition;
		}
		if (!originalBadge1Position.HasValue)
		{
			originalBadge1Position = ((Component)badgeSlot1).transform.localPosition;
		}
		if (character.currentLevel < character.characterDefinition.secondBadgeUnlockLevel)
		{
			Vector3 localPosition = ((Component)badgeSlot0).transform.localPosition;
			localPosition.x = 0f;
			((Component)badgeSlot0).transform.localPosition = localPosition;
			((Component)badgeSlot1).gameObject.SetActive(false);
			badgeHeaderText.text = Languages.Get("BADGES", "MENUS, GUI");
		}
		else
		{
			badgeHeaderText.text = Languages.Get("BADGES", "MENUS, GUI");
		}
		ItemDefinition item2 = GameController.Instance.itemDatabase.GetItem(character.equippedBadgeID);
		ItemDefinition item3 = GameController.Instance.itemDatabase.GetItem(character.equippedBadgeID2);
		if ((Object)(object)item2 != (Object)null)
		{
			badgeSlot0.Init(item2);
		}
		else
		{
			badgeSlot0.ClearSlot();
		}
		if ((Object)(object)item3 != (Object)null)
		{
			badgeSlot1.Init(item3);
		}
		else
		{
			badgeSlot1.ClearSlot();
		}
		isAnimating = true;
		initialized = true;
		((MonoBehaviour)this).StartCoroutine(WaitForScreenEnter());
	}

	private IEnumerator WaitForScreenEnter()
	{
		yield return null;
		while (animator.IsPlaying())
		{
			yield return null;
		}
		isAnimating = false;
		selectorObjTick.SetActive(true);
		InitOnScreenButtons();
		SelectFirstAvailableUpgradeTick();
	}

	public void HideScreen()
	{
		EventSystem.current.SetSelectedGameObject((GameObject)null);
		((Component)selectButton).gameObject.SetActive(false);
		((Component)removeButton).gameObject.SetActive(false);
		((Component)clearButton).gameObject.SetActive(false);
		for (int i = 0; i < attackTicks.Count; i++)
		{
			((Selectable)attackTicks[i].button).interactable = false;
		}
		for (int j = 0; j < defenseTicks.Count; j++)
		{
			((Selectable)defenseTicks[j].button).interactable = false;
		}
		for (int k = 0; k < luckTicks.Count; k++)
		{
			((Selectable)luckTicks[k].button).interactable = false;
		}
		for (int l = 0; l < teamworkTicks.Count; l++)
		{
			((Selectable)teamworkTicks[l].button).interactable = false;
		}
		((Selectable)weaponSlot.button).interactable = false;
		((Selectable)badgeSlot0.button).interactable = false;
		((Selectable)badgeSlot1.button).interactable = false;
		isAnimating = true;
		string text = ((mode != Mode.Upgrade) ? "UpgradeScreen_Outro_Equipment" : "UpgradeScreen_Outro_Upgrade");
		animator.Play(text);
		upgradeScreenExitAudio.Play();
		((MonoBehaviour)this).StartCoroutine(WaitForScreenExit());
	}

	private IEnumerator WaitForScreenExit()
	{
		yield return null;
		while (animator.IsPlaying())
		{
			yield return null;
		}
		if (character.currentLevel < character.characterDefinition.secondBadgeUnlockLevel)
		{
			((Component)badgeSlot0).transform.localPosition = originalBadge0Position.Value;
			((Component)badgeSlot1).transform.localPosition = originalBadge1Position.Value;
			((Component)badgeSlot1).gameObject.SetActive(true);
		}
		((Component)characterSprite).transform.localPosition = originalCharacterSpriteLocalPos;
		isAnimating = false;
		initialized = false;
		characterScreen.InitFromUpgradeScreen();
	}

	private void Update()
	{
		if (!initialized)
		{
			return;
		}
		characterSpriteAnimator.UpdateAnimation(Time.unscaledDeltaTime);
		if (UIDialogBox.instance.dialogBoxActive || isAnimating)
		{
			return;
		}
		int characterSwapDir = GetCharacterSwapDir();
		if (characterSwapDir != 0 && !preventCharacterChange && party.Length > 1)
		{
			isAnimating = true;
			characterSwitchAudio.Play();
			((MonoBehaviour)this).StartCoroutine(WaitForCharacterChange(characterSwapDir));
		}
		if (playerController.GetButtonDown("MenuUISubmit") && mode == Mode.Upgrade)
		{
			ConfirmPressed_Upgrade();
		}
		if (playerController.GetButtonDown("MenuUIModify") && mode == Mode.Upgrade)
		{
			ModifyPressed_Upgrade();
		}
		if (playerController.GetButtonDown("MenuUIOption"))
		{
			if (mode == Mode.Upgrade)
			{
				OptionPressed_Upgrade();
			}
			else if (mode == Mode.Relationship)
			{
				OptionPressed_Relationship();
			}
		}
		if (!playerController.GetButtonDown("MenuUICancel"))
		{
			return;
		}
		if (mode == Mode.Upgrade)
		{
			if (GameController.ConnectedGamepad == GamepadType.Keyboard && ((Component)removeButton).gameObject.activeSelf)
			{
				ModifyPressed_Upgrade();
			}
			else
			{
				CancelPressed_Upgrade();
			}
		}
		else if (mode == Mode.Relationship)
		{
			CancelPressed_Relationship();
		}
	}

	private int GetCharacterSwapDir()
	{
		if (playerController.GetButtonDown("MenuUIPageRight"))
		{
			return 1;
		}
		if (playerController.GetButtonDown("MenuUIPageLeft"))
		{
			return -1;
		}
		return 0;
	}

	private void LateUpdate()
	{
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_0617: Unknown result type (might be due to invalid IL or missing references)
		if (!initialized || UIDialogBox.instance.dialogBoxActive || !((Object)(object)previousSelectedObj != (Object)(object)EventSystem.current.currentSelectedGameObject))
		{
			return;
		}
		previousSelectedObj = EventSystem.current.currentSelectedGameObject;
		if (!((Object)(object)EventSystem.current.currentSelectedGameObject != (Object)null) || mode != Mode.Upgrade)
		{
			return;
		}
		GameObject currentSelectedGameObject = EventSystem.current.currentSelectedGameObject;
		UIUpgradeTick component = currentSelectedGameObject.GetComponent<UIUpgradeTick>();
		UIEquipmentSlot component2 = currentSelectedGameObject.GetComponent<UIEquipmentSlot>();
		switchStatAudio.Play();
		if ((Object)(object)component != (Object)null)
		{
			weaponDescriptionGrp.SetActive(false);
			selectorObjSquare.SetActive(false);
			selectorObjCircle.SetActive(false);
			selectorObjTick.SetActive(true);
			selectorObjTick.transform.position = currentSelectedGameObject.transform.position;
			if (component.isPerk)
			{
				descriptionHeaderText.text = Languages.Get(component.perkInfo.nameKey, "ITEMS, ABILITIES, UPGRADES");
				((Component)descriptionText).gameObject.SetActive(true);
				descriptionText.text = Languages.Get(component.perkInfo.descriptionKey, "ITEMS, ABILITIES, UPGRADES");
				skillPointCostGrp.SetActive(true);
				skillPointCostText.text = component.perkInfo.cost.ToString();
				return;
			}
			CharacterStatUpgradeInfo characterStatUpgradeInfo = null;
			switch (component.statType)
			{
			case CharacterStatType.Attack:
				characterStatUpgradeInfo = character.characterDefinition.attackUpgradeInfo;
				break;
			case CharacterStatType.Defense:
				characterStatUpgradeInfo = character.characterDefinition.defenseUpgradeInfo;
				break;
			case CharacterStatType.Luck:
				characterStatUpgradeInfo = character.characterDefinition.luckUpgradeInfo;
				break;
			case CharacterStatType.Teamwork:
				characterStatUpgradeInfo = character.characterDefinition.teamworkUpgradeInfo;
				break;
			}
			descriptionHeaderText.text = Languages.Get(characterStatUpgradeInfo.minorUpgradeHeaderKey, "ITEMS, ABILITIES, UPGRADES");
			((Component)descriptionText).gameObject.SetActive(true);
			string text = Languages.Get(characterStatUpgradeInfo.minorUpgradeDescriptionKey, "ITEMS, ABILITIES, UPGRADES");
			text = text.Replace("{0}", Languages.Get(character.characterDefinition.characterName.key, "MENUS, GUI"));
			text = text.Replace("{1}", characterStatUpgradeInfo.minorUpgradeAmount.ToString());
			descriptionText.text = text;
			skillPointCostGrp.SetActive(true);
			skillPointCostText.text = ((component.statType == CharacterStatType.Teamwork) ? teamworkUpgradeCost.ToString() : GetMinorUpgradeCost(component.slotIndex).ToString());
		}
		else if ((Object)(object)component2 != (Object)null)
		{
			selectorObjTick.SetActive(false);
			selectorObjSquare.SetActive(false);
			selectorObjCircle.SetActive(false);
			if (component2.slotType == UIEquipmentSlot.SlotType.Weapon)
			{
				Weapon weapon = component2.itemDefinition as Weapon;
				selectorObjSquare.SetActive(true);
				selectorObjSquare.transform.position = currentSelectedGameObject.transform.position;
				((Component)descriptionText).gameObject.SetActive(false);
				skillPointCostGrp.SetActive(false);
				weaponDescriptionGrp.SetActive(true);
				if ((Object)(object)component2.itemDefinition != (Object)null)
				{
					descriptionHeaderText.text = Languages.Get(component2.itemDefinition.itemDescriptionHeaderKey, "ITEMS, ABILITIES, UPGRADES");
					tierHeaderTextTier2.text = "<sprite=\"TMProAtlas\" name=\"CharacterScreen_weaponupgrade_silver\">" + Languages.Get("TIER", "MENUS, GUI") + " 2";
					tierHeaderTextTier3.text = "<sprite=\"TMProAtlas\" name=\"CharacterScreen_weaponupgrade_gold\">" + Languages.Get("TIER", "MENUS, GUI") + " 3";
					string text2 = Languages.Get("???", "MENUS, GUI");
					string text3 = Languages.Get("???", "MENUS, GUI");
					tierDescriptionTextTier2.text = text2;
					tierDescriptionTextTier3.text = text3;
					if (PlayerGameState.Instance.HasWeaponUpgrade(character.characterName, 1))
					{
						descriptionHeaderText.text = Languages.Get("SHINY", "ITEMS, ABILITIES, UPGRADES").Replace("{0}", Languages.Get(component2.itemDefinition.itemDescriptionHeaderKey, "ITEMS, ABILITIES, UPGRADES"));
						tierHeaderTextTier2.text = "<sprite=\"TMProAtlas\" name=\"CharacterScreen_weaponupgrade_silver\">" + Languages.Get(weapon.tier2TitleKey, "ITEMS, ABILITIES, UPGRADES");
						text2 = Languages.Get(weapon.tier2DescriptionKey, "ITEMS, ABILITIES, UPGRADES");
						tierDescriptionTextTier2.text = text2;
					}
					if (PlayerGameState.Instance.HasWeaponUpgrade(character.characterName, 2))
					{
						descriptionHeaderText.text = Languages.Get("SUPER_SHINY", "ITEMS, ABILITIES, UPGRADES").Replace("{0}", Languages.Get(component2.itemDefinition.itemDescriptionHeaderKey, "ITEMS, ABILITIES, UPGRADES"));
						tierHeaderTextTier3.text = "<sprite=\"TMProAtlas\" name=\"CharacterScreen_weaponupgrade_gold\">" + Languages.Get(weapon.tier3TitleKey, "ITEMS, ABILITIES, UPGRADES");
						text3 = Languages.Get(weapon.tier3DescriptionKey, "ITEMS, ABILITIES, UPGRADES");
						tierDescriptionTextTier3.text = text3;
					}
				}
				else
				{
					descriptionHeaderText.text = string.Empty;
					tierHeaderTextTier2.text = string.Empty;
					tierHeaderTextTier3.text = string.Empty;
					tierDescriptionTextTier2.text = string.Empty;
					tierDescriptionTextTier3.text = string.Empty;
				}
			}
			else
			{
				((Component)descriptionText).gameObject.SetActive(true);
				skillPointCostGrp.SetActive(false);
				weaponDescriptionGrp.SetActive(false);
				if (component2.slotType == UIEquipmentSlot.SlotType.Badges)
				{
					selectorObjCircle.SetActive(true);
					selectorObjCircle.transform.position = currentSelectedGameObject.transform.position;
				}
				if ((Object)(object)component2.itemDefinition != (Object)null)
				{
					descriptionHeaderText.text = Languages.Get(component2.itemDefinition.itemNameKey, "ITEMS, ABILITIES, UPGRADES");
					descriptionText.text = Languages.Get(component2.itemDefinition.itemDescriptionKey, "ITEMS, ABILITIES, UPGRADES");
				}
				else
				{
					descriptionHeaderText.text = string.Empty;
					descriptionText.text = string.Empty;
				}
			}
			skillPointCostGrp.SetActive(false);
		}
		else
		{
			descriptionHeaderText.text = string.Empty;
			descriptionText.text = string.Empty;
			skillPointCostGrp.SetActive(false);
		}
	}

	private IEnumerator WaitForCharacterChange(int dir)
	{
		string triggerName = "CharacterSwitch";
		if (mode == Mode.Relationship)
		{
			triggerName = "CharacterSwitchAux";
			mode = Mode.Upgrade;
		}
		animator.SetTrigger(triggerName);
		EventSystem.current.SetSelectedGameObject((GameObject)null);
		bool continueSequence = false;
		Action<AnimationEvent> triggerCharacterChange = (AnimationEvent x) =>
		{
			continueSequence = true;
		};
		animatorEventListener.EventTriggered += triggerCharacterChange;
		while (!continueSequence)
		{
			yield return null;
		}
		animatorEventListener.EventTriggered -= triggerCharacterChange;
		PlayerCharacter nextCharacter = null;
		int startIndex = -1;
		for (int num = 0; num < party.Length; num++)
		{
			if (((object)character).Equals((object?)party[num]))
			{
				startIndex = num;
				break;
			}
		}
		if (startIndex != -1)
		{
			int num2 = startIndex + dir;
			if (num2 >= party.Length)
			{
				num2 = 0;
			}
			else if (num2 < 0)
			{
				num2 = party.Length - 1;
			}
			nextCharacter = party[num2];
		}
		((Component)characterSprite).transform.localPosition = originalCharacterSpriteLocalPos;
		if ((Object)(object)nextCharacter != (Object)null)
		{
			Init(characterScreen, party, nextCharacter, playIntroAnim: false);
		}
		while (animator.IsPlaying())
		{
			yield return null;
		}
		isAnimating = false;
	}

	private void ConfirmPressed_Upgrade()
	{
		//IL_0482: Unknown result type (might be due to invalid IL or missing references)
		//IL_0487: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b9: Unknown result type (might be due to invalid IL or missing references)
		GameObject currentSelectedGameObject = EventSystem.current.currentSelectedGameObject;
		if (!((Object)(object)currentSelectedGameObject != (Object)null))
		{
			return;
		}
		UIUpgradeTick component = currentSelectedGameObject.GetComponent<UIUpgradeTick>();
		UIEquipmentSlot component2 = currentSelectedGameObject.GetComponent<UIEquipmentSlot>();
		if (!((Object)(object)component != (Object)null))
		{
			return;
		}
		bool flag = false;
		bool flag2 = false;
		switch (component.statType)
		{
		case CharacterStatType.Attack:
			if (attackLevelTemp < attackMaxLevel)
			{
				if (component.isPerk)
				{
					SelectFirstAvailableUpgradeTick(CharacterStatType.Attack);
					currentSelectedGameObject = EventSystem.current.currentSelectedGameObject;
					component = currentSelectedGameObject.GetComponent<UIUpgradeTick>();
				}
				if (!component.isPerk || (component.isPerk && component.perkInfo.slotIndex == attackLevelTemp))
				{
					int num2 = ((!component.isPerk) ? GetMinorUpgradeCost(component.slotIndex) : component.perkInfo.cost);
					if (skillPointsTemp >= num2)
					{
						attackLevelTemp = Mathf.Min(attackLevelTemp + 1, attackMaxLevel);
						skillPointsTemp -= num2;
					}
					else
					{
						flag2 = true;
					}
					flag = attackLevelTemp == attackMaxLevel;
				}
			}
			else
			{
				flag = true;
			}
			break;
		case CharacterStatType.Defense:
			if (defenseLevelTemp < defenseMaxLevel)
			{
				if (component.isPerk)
				{
					SelectFirstAvailableUpgradeTick(CharacterStatType.Defense);
					currentSelectedGameObject = EventSystem.current.currentSelectedGameObject;
					component = currentSelectedGameObject.GetComponent<UIUpgradeTick>();
				}
				if (!component.isPerk || (component.isPerk && component.perkInfo.slotIndex == defenseLevelTemp))
				{
					int num4 = ((!component.isPerk) ? GetMinorUpgradeCost(component.slotIndex) : component.perkInfo.cost);
					if (skillPointsTemp >= num4)
					{
						defenseLevelTemp = Mathf.Min(defenseLevelTemp + 1, defenseMaxLevel);
						skillPointsTemp -= num4;
					}
					else
					{
						flag2 = true;
					}
					flag = defenseLevelTemp == defenseMaxLevel;
				}
			}
			else
			{
				flag = true;
			}
			break;
		case CharacterStatType.Luck:
			if (luckLevelTemp < luckMaxLevel)
			{
				if (component.isPerk)
				{
					SelectFirstAvailableUpgradeTick(CharacterStatType.Luck);
					currentSelectedGameObject = EventSystem.current.currentSelectedGameObject;
					component = currentSelectedGameObject.GetComponent<UIUpgradeTick>();
				}
				if (!component.isPerk || (component.isPerk && component.perkInfo.slotIndex == luckLevelTemp))
				{
					int num3 = ((!component.isPerk) ? GetMinorUpgradeCost(component.slotIndex) : component.perkInfo.cost);
					if (skillPointsTemp >= num3)
					{
						luckLevelTemp = Mathf.Min(luckLevelTemp + 1, luckMaxLevel);
						skillPointsTemp -= num3;
					}
					else
					{
						flag2 = true;
					}
					flag = luckLevelTemp == luckMaxLevel;
				}
			}
			else
			{
				flag = true;
			}
			break;
		case CharacterStatType.Teamwork:
			if (teamworkLevelTemp < teamworkMaxLevel)
			{
				if (component.isPerk)
				{
					SelectFirstAvailableUpgradeTick(CharacterStatType.Teamwork);
					currentSelectedGameObject = EventSystem.current.currentSelectedGameObject;
					component = currentSelectedGameObject.GetComponent<UIUpgradeTick>();
				}
				if (!component.isPerk || (component.isPerk && component.perkInfo.slotIndex == teamworkLevelTemp))
				{
					int num = ((!component.isPerk) ? teamworkUpgradeCost : component.perkInfo.cost);
					if (skillPointsTemp >= num)
					{
						teamworkLevelTemp = Mathf.Min(teamworkLevelTemp + 1, teamworkMaxLevel);
						skillPointsTemp -= num;
					}
					else
					{
						flag2 = true;
					}
					flag = teamworkLevelTemp == teamworkMaxLevel;
				}
			}
			else
			{
				flag = true;
			}
			break;
		}
		UpdateStatLevels();
		if (!flag2)
		{
			addPointAudio.Play();
		}
		if (flag2)
		{
			if ((Object)(object)addPointErrorSource != (Object)null && (Object)(object)addPointErrorSource.clip == (Object)(object)addPointErrorAudio.clip)
			{
				addPointErrorSource.Stop();
			}
			addPointErrorSource = addPointErrorAudio.Play();
			component.SignalFailure();
			if (skillPointFailTween == null || (skillPointFailTween != null && !TweenExtensions.IsPlaying((Tween)(object)skillPointFailTween)))
			{
				Vector3 localScale = skillPointsTotalText.transform.localScale;
				skillPointsTotalText.transform.localScale = new Vector3(1.4f, 1.4f, 1.4f);
				skillPointFailTween = TweenSettingsExtensions.SetUpdate<Tweener>(TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOScale(skillPointsTotalText.transform, localScale, 0.3f), (Ease)30), true);
			}
		}
		if (!flag)
		{
			GameObject selectedGameObject = null;
			if (component.statType == CharacterStatType.Attack && attackLevelTemp < attackMaxLevel)
			{
				selectedGameObject = ((Component)attackTicks[attackLevelTemp]).gameObject;
			}
			else if (component.statType == CharacterStatType.Defense && defenseLevelTemp < defenseMaxLevel)
			{
				selectedGameObject = ((Component)defenseTicks[defenseLevelTemp]).gameObject;
			}
			else if (component.statType == CharacterStatType.Luck && luckLevelTemp < luckMaxLevel)
			{
				selectedGameObject = ((Component)luckTicks[luckLevelTemp]).gameObject;
			}
			else if (component.statType == CharacterStatType.Teamwork && teamworkLevelTemp < teamworkMaxLevel)
			{
				selectedGameObject = ((Component)teamworkTicks[teamworkLevelTemp]).gameObject;
			}
			EventSystem.current.SetSelectedGameObject(selectedGameObject);
		}
	}

	private void ModifyPressed_Upgrade()
	{
		if (!((Object)(object)EventSystem.current.currentSelectedGameObject != (Object)null))
		{
			return;
		}
		UIUpgradeTick component = EventSystem.current.currentSelectedGameObject.GetComponent<UIUpgradeTick>();
		if ((Object)(object)component != (Object)null)
		{
			switch (component.statType)
			{
			case CharacterStatType.Attack:
				if (attackLevelTemp > character.attackLevel)
				{
					UIUpgradeTick uIUpgradeTick3 = attackTicks[attackLevelTemp - 1];
					int num3 = ((!uIUpgradeTick3.isPerk) ? GetMinorUpgradeCost(uIUpgradeTick3.slotIndex) : uIUpgradeTick3.perkInfo.cost);
					skillPointsTemp += num3;
				}
				attackLevelTemp = Mathf.Max(attackLevelTemp - 1, character.attackLevel);
				break;
			case CharacterStatType.Defense:
				if (defenseLevelTemp > character.defenseLevel)
				{
					UIUpgradeTick uIUpgradeTick4 = defenseTicks[defenseLevelTemp - 1];
					int num4 = ((!uIUpgradeTick4.isPerk) ? GetMinorUpgradeCost(uIUpgradeTick4.slotIndex) : uIUpgradeTick4.perkInfo.cost);
					skillPointsTemp += num4;
				}
				defenseLevelTemp = Mathf.Max(defenseLevelTemp - 1, character.defenseLevel);
				break;
			case CharacterStatType.Luck:
				if (luckLevelTemp > character.luckLevel)
				{
					UIUpgradeTick uIUpgradeTick2 = luckTicks[luckLevelTemp - 1];
					int num2 = ((!uIUpgradeTick2.isPerk) ? GetMinorUpgradeCost(uIUpgradeTick2.slotIndex) : uIUpgradeTick2.perkInfo.cost);
					skillPointsTemp += num2;
				}
				luckLevelTemp = Mathf.Max(luckLevelTemp - 1, character.luckLevel);
				break;
			case CharacterStatType.Teamwork:
				if (teamworkLevelTemp > character.teamworkLevel)
				{
					UIUpgradeTick uIUpgradeTick = teamworkTicks[teamworkLevelTemp - 1];
					int num = ((!uIUpgradeTick.isPerk) ? teamworkUpgradeCost : uIUpgradeTick.perkInfo.cost);
					skillPointsTemp += num;
				}
				teamworkLevelTemp = Mathf.Max(teamworkLevelTemp - 1, character.teamworkLevel);
				break;
			}
		}
		removePointAudio.Play();
		UpdateStatLevels();
		GameObject val = null;
		if ((Object)(object)component != (Object)null && component.statType == CharacterStatType.Attack && attackLevelTemp >= character.attackLevel && character.attackLevel < attackMaxLevel)
		{
			val = ((Component)attackTicks[attackLevelTemp]).gameObject;
		}
		else if ((Object)(object)component != (Object)null && component.statType == CharacterStatType.Defense && defenseLevelTemp >= character.defenseLevel && character.defenseLevel < defenseMaxLevel)
		{
			val = ((Component)defenseTicks[defenseLevelTemp]).gameObject;
		}
		else if ((Object)(object)component != (Object)null && component.statType == CharacterStatType.Luck && luckLevelTemp >= character.luckLevel && character.luckLevel < luckMaxLevel)
		{
			val = ((Component)luckTicks[luckLevelTemp]).gameObject;
		}
		else if ((Object)(object)component != (Object)null && component.statType == CharacterStatType.Teamwork && teamworkLevelTemp >= character.teamworkLevel && character.teamworkLevel < teamworkMaxLevel)
		{
			val = ((Component)teamworkTicks[teamworkLevelTemp]).gameObject;
		}
		if ((Object)(object)val != (Object)null)
		{
			EventSystem.current.SetSelectedGameObject(val);
		}
	}

	private void OptionPressed_Upgrade()
	{
		int num = attackLevelTemp + defenseLevelTemp + luckLevelTemp + teamworkLevelTemp;
		int num2 = character.attackLevel + character.defenseLevel + character.luckLevel + character.teamworkLevel;
		if (num > num2)
		{
			previousSelectedUpgradeObj = EventSystem.current.currentSelectedGameObject;
			string text = Languages.Get("ACCEPT_SKILL_POINT_CHANGES", "MENUS, GUI");
			string yesText = Languages.Get("YUP", "MENUS, GUI");
			string noText = Languages.Get("NAH", "MENUS, GUI");
			UIDialogBox.instance.ShowDialogBox(text, yesText, noText);
			UIDialogBox uIDialogBox = UIDialogBox.instance;
			uIDialogBox.YesPressed = (Action)Delegate.Combine(uIDialogBox.YesPressed, new Action(AcceptSkillPointChanges));
			UIDialogBox uIDialogBox2 = UIDialogBox.instance;
			uIDialogBox2.DialogBoxClosed = (Action)Delegate.Combine(uIDialogBox2.DialogBoxClosed, new Action(DialogBoxClosedDeclined));
			return;
		}
		animator.Play("UpgradeScreen_RelationshipIntro");
		mode = Mode.Relationship;
		previousSelectedUpgradeObj = EventSystem.current.currentSelectedGameObject;
		EventSystem.current.SetSelectedGameObject((GameObject)null);
		int num3 = 0;
		for (int i = 0; i < party.Length; i++)
		{
			PlayerCharacter playerCharacter = party[i];
			if ((Object)(object)playerCharacter != (Object)(object)character)
			{
				UIRelationshipMeter uIRelationshipMeter = relationshipMeters[num3++];
				((Component)uIRelationshipMeter).gameObject.SetActive(true);
				uIRelationshipMeter.Init(character, playerCharacter, RelationshipPointsManager.Instance.GetRelationshipPoints(character, playerCharacter), 0, UIRelationshipMeter.MeterType.None);
			}
		}
		for (int j = num3; j < relationshipMeters.Length; j++)
		{
			UIRelationshipMeter uIRelationshipMeter2 = relationshipMeters[j];
			((Component)uIRelationshipMeter2).gameObject.SetActive(false);
		}
	}

	private void CancelPressed_Upgrade()
	{
		if (skillPointsTemp < character.skillPoints)
		{
			previousSelectedUpgradeObj = EventSystem.current.currentSelectedGameObject;
			string text = Languages.Get("ACCEPT_SKILL_POINT_CHANGES", "MENUS, GUI");
			string yesText = Languages.Get("YUP", "MENUS, GUI");
			string noText = Languages.Get("NAH", "MENUS, GUI");
			UIDialogBox.instance.ShowDialogBox(text, yesText, noText);
			UIDialogBox uIDialogBox = UIDialogBox.instance;
			uIDialogBox.YesPressed = (Action)Delegate.Combine(uIDialogBox.YesPressed, new Action(AcceptSkillPointChanges));
			UIDialogBox uIDialogBox2 = UIDialogBox.instance;
			uIDialogBox2.DialogBoxClosed = (Action)Delegate.Combine(uIDialogBox2.DialogBoxClosed, new Action(DialogBoxClosedDeclined));
		}
		else if (!forceUseOfSkillPoints || (forceUseOfSkillPoints && skillPointsTemp == 0))
		{
			HideScreen();
		}
	}

	private void AcceptSkillPointChanges()
	{
		UIDialogBox uIDialogBox = UIDialogBox.instance;
		uIDialogBox.YesPressed = (Action)Delegate.Remove(uIDialogBox.YesPressed, new Action(AcceptSkillPointChanges));
		UIDialogBox uIDialogBox2 = UIDialogBox.instance;
		uIDialogBox2.DialogBoxClosed = (Action)Delegate.Remove(uIDialogBox2.DialogBoxClosed, new Action(DialogBoxClosedDeclined));
		UIDialogBox uIDialogBox3 = UIDialogBox.instance;
		uIDialogBox3.DialogBoxClosed = (Action)Delegate.Combine(uIDialogBox3.DialogBoxClosed, new Action(DialogBoxClosedAccepted));
		comfirmPointsAudio.Play();
	}

	private void DialogBoxClosedAccepted()
	{
		UIDialogBox uIDialogBox = UIDialogBox.instance;
		uIDialogBox.DialogBoxClosed = (Action)Delegate.Remove(uIDialogBox.DialogBoxClosed, new Action(DialogBoxClosedAccepted));
		EventSystem.current.SetSelectedGameObject((GameObject)null);
		((MonoBehaviour)this).StartCoroutine(NewPointsSequence());
	}

	private void DialogBoxClosedDeclined()
	{
		UIDialogBox uIDialogBox = UIDialogBox.instance;
		uIDialogBox.YesPressed = (Action)Delegate.Remove(uIDialogBox.YesPressed, new Action(AcceptSkillPointChanges));
		UIDialogBox uIDialogBox2 = UIDialogBox.instance;
		uIDialogBox2.DialogBoxClosed = (Action)Delegate.Remove(uIDialogBox2.DialogBoxClosed, new Action(DialogBoxClosedDeclined));
		if ((Object)(object)previousSelectedUpgradeObj != (Object)null)
		{
			EventSystem.current.SetSelectedGameObject(previousSelectedUpgradeObj);
		}
		else
		{
			SelectFirstAvailableUpgradeTick();
		}
	}

	private IEnumerator NewPointsSequence()
	{
		List<CharacterPerkInfo> perkRewards = new List<CharacterPerkInfo>();
		isAnimating = true;
		int i;
		for (i = 0; i < attackTicks.Count; i++)
		{
			UIUpgradeTick uIUpgradeTick = attackTicks[i];
			if (i <= character.attackLevel - 1 || i + 1 > attackLevelTemp)
			{
				continue;
			}
			uIUpgradeTick.animator.Play("UpgradeScreen_Tick_Add_Anim", 0, 0f);
			if (uIUpgradeTick.isPerk)
			{
				CharacterPerkInfo item = character.characterDefinition.perks.Find((CharacterPerkInfo x) => x.statType == CharacterStatType.Attack && x.slotIndex == i);
				perkRewards.Add(item);
			}
		}
		int i2;
		for (i2 = 0; i2 < defenseTicks.Count; i2++)
		{
			UIUpgradeTick uIUpgradeTick2 = defenseTicks[i2];
			if (i2 <= character.defenseLevel - 1 || i2 + 1 > defenseLevelTemp)
			{
				continue;
			}
			uIUpgradeTick2.animator.Play("UpgradeScreen_Tick_Add_Anim", 0, 0f);
			if (uIUpgradeTick2.isPerk)
			{
				CharacterPerkInfo item2 = character.characterDefinition.perks.Find((CharacterPerkInfo x) => x.statType == CharacterStatType.Defense && x.slotIndex == i2);
				perkRewards.Add(item2);
			}
		}
		int i3;
		for (i3 = 0; i3 < luckTicks.Count; i3++)
		{
			UIUpgradeTick uIUpgradeTick3 = luckTicks[i3];
			if (i3 <= character.luckLevel - 1 || i3 + 1 > luckLevelTemp)
			{
				continue;
			}
			uIUpgradeTick3.animator.Play("UpgradeScreen_Tick_Add_Anim", 0, 0f);
			if (uIUpgradeTick3.isPerk)
			{
				CharacterPerkInfo item3 = character.characterDefinition.perks.Find((CharacterPerkInfo x) => x.statType == CharacterStatType.Luck && x.slotIndex == i3);
				perkRewards.Add(item3);
			}
		}
		int i4;
		for (i4 = 0; i4 < teamworkTicks.Count; i4++)
		{
			UIUpgradeTick uIUpgradeTick4 = teamworkTicks[i4];
			if (i4 <= character.teamworkLevel - 1 || i4 + 1 > teamworkLevelTemp)
			{
				continue;
			}
			uIUpgradeTick4.animator.Play("UpgradeScreen_Tick_Add_Anim", 0, 0f);
			if (uIUpgradeTick4.isPerk)
			{
				CharacterPerkInfo item4 = character.characterDefinition.perks.Find((CharacterPerkInfo x) => x.statType == CharacterStatType.Teamwork && x.slotIndex == i4);
				perkRewards.Add(item4);
			}
		}
		character.attackLevel = attackLevelTemp;
		character.defenseLevel = defenseLevelTemp;
		character.luckLevel = luckLevelTemp;
		character.teamworkLevel = teamworkLevelTemp;
		character.skillPoints = skillPointsTemp;
		characterScreen.gameDataHasChanged = true;
		if (perkRewards.Count == 0)
		{
			if ((Object)(object)character.rewardScreenVOClip != (Object)null && Random.value < GameResources.instance.gameSettings.chanceToPlayRewardVO)
			{
				character.rewardScreenVOClip.Play();
			}
			yield return new WaitForSecondsIndependent(0.1667f);
			UpdateStatLevels();
		}
		else
		{
			yield return new WaitForSecondsIndependent(0.1667f);
			UpdateStatLevels();
			animator.Play("UpgradeScreen_ShowReward");
			((Component)selectButton).gameObject.SetActive(false);
			((Component)removeButton).gameObject.SetActive(false);
			if (GameController.ConnectedGamepad == GamepadType.Keyboard || !((Component)backButton).gameObject.activeSelf)
			{
				((Component)backButton).gameObject.SetActive(true);
			}
			yield return null;
			while (animator.IsPlaying())
			{
				yield return null;
			}
			CharacterMaterial charMaterial = scrollingBGMats.Find((CharacterMaterial x) => x.characterName == character.characterName);
			((Component)perkUnlockAnimator).gameObject.SetActive(true);
			for (int i5 = 0; i5 < perkRewards.Count; i5++)
			{
				CharacterPerkInfo perkInfo = perkRewards[i5];
				Sprite iconSprite = null;
				string subtitleText = string.Empty;
				if (perkInfo.perkType == CharacterPerkInfo.PerkType.Ability)
				{
					iconSprite = uiAtlas.GetSpriteByName(perkInfo.abilityUnlockIconName);
					subtitleText = Languages.Get("WHOA_NEW_ABILITY", "MENUS, GUI");
				}
				else
				{
					iconSprite = uiAtlas.GetSpriteByName(perkStatIcons[perkInfo.statType]);
					subtitleText = Languages.Get("WHOA_NEW_UPGRADE", "MENUS, GUI");
				}
				perkUnlockName.text = Languages.Get(perkInfo.nameKey, "ITEMS, ABILITIES, UPGRADES");
				perkUnlockDescripText.text = Languages.Get(perkInfo.descriptionKey, "ITEMS, ABILITIES, UPGRADES");
				perkUnlockIcon.sprite = iconSprite;
				Image val = perkUnlockButtonBorder;
				Sprite sprite = charMaterial.sprite;
				perkUnlockDescripBorder.sprite = sprite;
				val.sprite = sprite;
				Image val2 = perkUnlockButtonBG;
				Material material = charMaterial.material;
				((Graphic)perkUnlockDescripBG).material = material;
				((Graphic)val2).material = material;
				perkUnlockHeaderSub.text = subtitleText;
				perkUnlockAnimator.Play("PerkUnlock_Intro");
				perkUnlockReveal.Play();
				if ((Object)(object)character != (Object)null && (Object)(object)character.rewardScreenVOClip != (Object)null && Random.value < GameResources.instance.gameSettings.chanceToPlayRewardVO)
				{
					character.rewardScreenVOClip.Play();
				}
				characterSpriteAnimator.Play(character.animationNames.victory.FrontName);
				tk2dSpriteAnimator tk2dSpriteAnimator2 = characterSpriteAnimator;
				tk2dSpriteAnimator2.AnimationCompleted = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>)Delegate.Combine(tk2dSpriteAnimator2.AnimationCompleted, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>(HandleVictoryAnimFinished));
				yield return null;
				while (perkUnlockAnimator.IsName("PerkUnlock_Intro"))
				{
					yield return null;
				}
				EventMessenger.Instance.Raise(new PerkUnlockedEvent(character, perkInfo));
				while (!playerController.GetButtonDown("MenuUISubmit"))
				{
					yield return null;
				}
				perkUnlockAnimator.Play("PerkUnlock_Outro");
				yield return null;
				while (perkUnlockAnimator.IsPlaying())
				{
					yield return null;
				}
			}
			((Component)perkUnlockAnimator).gameObject.SetActive(false);
			animator.Play("UpgradeScreen_ShowRewardOutro");
			yield return null;
			while (animator.IsName("UpgradeScreen_ShowRewardOutro"))
			{
				yield return null;
			}
		}
		InitOnScreenButtons();
		UpdateStatLevels();
		if ((Object)(object)previousSelectedUpgradeObj != (Object)null)
		{
			EventSystem.current.SetSelectedGameObject(previousSelectedUpgradeObj);
		}
		else
		{
			SelectFirstAvailableUpgradeTick();
		}
		isAnimating = false;
	}

	private void HandleVictoryAnimFinished(tk2dSpriteAnimator animator, tk2dSpriteAnimationClip clip)
	{
		tk2dSpriteAnimator tk2dSpriteAnimator2 = characterSpriteAnimator;
		tk2dSpriteAnimator2.AnimationCompleted = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>)Delegate.Remove(tk2dSpriteAnimator2.AnimationCompleted, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>(HandleVictoryAnimFinished));
		characterSpriteAnimator.Play(character.animationNames.idleBattle.FrontName);
	}

	private void UpdateStatLevels()
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_083e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0879: Unknown result type (might be due to invalid IL or missing references)
		//IL_087e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a35: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c81: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ec3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ec8: Unknown result type (might be due to invalid IL or missing references)
		//IL_10f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_10fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_1133: Unknown result type (might be due to invalid IL or missing references)
		//IL_1156: Unknown result type (might be due to invalid IL or missing references)
		//IL_115b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0988: Unknown result type (might be due to invalid IL or missing references)
		//IL_0998: Unknown result type (might be due to invalid IL or missing references)
		//IL_099d: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b44: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b54: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b59: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1192: Unknown result type (might be due to invalid IL or missing references)
		//IL_11b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_104b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d8b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c40: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fd2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fe2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fe7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e87: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bf3: Unknown result type (might be due to invalid IL or missing references)
		//IL_11f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e20: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e30: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e35: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e3a: Unknown result type (might be due to invalid IL or missing references)
		healthText.text = character.currentHealth + "/" + character.Stats.MaxHealthStat.BaseValue;
		Vector2 sizeDelta = ((Graphic)healthFill).rectTransform.sizeDelta;
		sizeDelta.x = healthBarFillEmpty + (healthBarFillFull - healthBarFillEmpty) * Mathf.Clamp01(character.currentHealthRatio);
		((Graphic)healthFill).rectTransform.sizeDelta = sizeDelta;
		skillPointsTotalText.text = skillPointsTemp.ToString();
		attackTextLarge.text = (character.Stats.AttackStat.Value + (attackLevelTemp - character.attackLevel) * character.characterDefinition.attackUpgradeInfo.minorUpgradeAmount).ToString();
		defenseTextLarge.text = (character.Stats.DefenseStat.Value + (defenseLevelTemp - character.defenseLevel) * character.characterDefinition.defenseUpgradeInfo.minorUpgradeAmount).ToString();
		luckTextLarge.text = (character.Stats.LuckStat.Value + (luckLevelTemp - character.luckLevel) * character.characterDefinition.luckUpgradeInfo.minorUpgradeAmount).ToString();
		teamworkTextLarge.text = (character.Stats.TeamworkStat.Value + (teamworkLevelTemp - character.teamworkLevel) * character.characterDefinition.teamworkUpgradeInfo.minorUpgradeAmount).ToString();
		backButton.SetText(Languages.Get("BACK", "MENUS, GUI"));
		selectButton.SetText(Languages.Get("ADD_POINTS", "MENUS, GUI"));
		int num = attackLevelTemp + defenseLevelTemp + luckLevelTemp + teamworkLevelTemp;
		int num2 = character.attackLevel + character.defenseLevel + character.luckLevel + character.teamworkLevel;
		((Component)removeButton).gameObject.SetActive(num > num2);
		((Component)backButton).gameObject.SetActive(!((Component)removeButton).gameObject.activeSelf);
		removeButton.SetText(Languages.Get("REMOVE_POINTS", "MENUS, GUI"));
		((Component)clearButton).gameObject.SetActive(num > num2);
		clearButton.SetText(Languages.Get("CONFIRM", "MENUS, GUI"));
		((Component)relationshipButton).gameObject.SetActive(!disableRelationshipButton && num <= num2);
		UIUpgradeTick enabledAttackTick = null;
		UIUpgradeTick enabledDefenseTick = null;
		UIUpgradeTick enabledLuckTick = null;
		UIUpgradeTick enabledTeamworkTick = null;
		int i;
		for (i = 0; i < attackTicks.Count; i++)
		{
			UIUpgradeTick uIUpgradeTick = attackTicks[i];
			CharacterPerkInfo characterPerkInfo = character.characterDefinition.perks.Find((CharacterPerkInfo x) => x.statType == CharacterStatType.Attack && x.slotIndex == i);
			if (characterPerkInfo != null)
			{
				uIUpgradeTick.InitAsPerkUpgrade(characterPerkInfo, i + 1 <= attackLevelTemp);
				((Selectable)uIUpgradeTick.button).interactable = true;
				continue;
			}
			uIUpgradeTick.InitAsMinorUpgrade(i, i + 1 <= attackLevelTemp, i > character.attackLevel - 1);
			((Selectable)uIUpgradeTick.button).interactable = attackLevelTemp <= attackMaxLevel && i == Mathf.Min(attackLevelTemp, attackMaxLevel - 1);
			if (((Selectable)uIUpgradeTick.button).interactable)
			{
				enabledAttackTick = uIUpgradeTick;
			}
		}
		int i2;
		for (i2 = 0; i2 < defenseTicks.Count; i2++)
		{
			UIUpgradeTick uIUpgradeTick2 = defenseTicks[i2];
			CharacterPerkInfo characterPerkInfo2 = character.characterDefinition.perks.Find((CharacterPerkInfo x) => x.statType == CharacterStatType.Defense && x.slotIndex == i2);
			if (characterPerkInfo2 != null)
			{
				uIUpgradeTick2.InitAsPerkUpgrade(characterPerkInfo2, i2 + 1 <= defenseLevelTemp);
				((Selectable)uIUpgradeTick2.button).interactable = true;
				continue;
			}
			uIUpgradeTick2.InitAsMinorUpgrade(i2, i2 + 1 <= defenseLevelTemp, i2 > character.defenseLevel - 1);
			((Selectable)uIUpgradeTick2.button).interactable = defenseLevelTemp <= defenseMaxLevel && i2 == Mathf.Min(defenseLevelTemp, defenseMaxLevel - 1);
			if (((Selectable)uIUpgradeTick2.button).interactable)
			{
				enabledDefenseTick = uIUpgradeTick2;
			}
		}
		int i3;
		for (i3 = 0; i3 < luckTicks.Count; i3++)
		{
			UIUpgradeTick uIUpgradeTick3 = luckTicks[i3];
			CharacterPerkInfo characterPerkInfo3 = character.characterDefinition.perks.Find((CharacterPerkInfo x) => x.statType == CharacterStatType.Luck && x.slotIndex == i3);
			if (characterPerkInfo3 != null)
			{
				uIUpgradeTick3.InitAsPerkUpgrade(characterPerkInfo3, i3 + 1 <= luckLevelTemp);
				((Selectable)uIUpgradeTick3.button).interactable = true;
				continue;
			}
			uIUpgradeTick3.InitAsMinorUpgrade(i3, i3 + 1 <= luckLevelTemp, i3 > character.luckLevel - 1);
			((Selectable)uIUpgradeTick3.button).interactable = luckLevelTemp <= luckMaxLevel && i3 == Mathf.Min(luckLevelTemp, luckMaxLevel - 1);
			if (((Selectable)uIUpgradeTick3.button).interactable)
			{
				enabledLuckTick = uIUpgradeTick3;
			}
		}
		int i4;
		for (i4 = 0; i4 < teamworkTicks.Count; i4++)
		{
			UIUpgradeTick uIUpgradeTick4 = teamworkTicks[i4];
			CharacterPerkInfo characterPerkInfo4 = character.characterDefinition.perks.Find((CharacterPerkInfo x) => x.statType == CharacterStatType.Teamwork && x.slotIndex == i4);
			if (characterPerkInfo4 != null)
			{
				uIUpgradeTick4.InitAsPerkUpgrade(characterPerkInfo4, i4 + 1 <= teamworkLevelTemp);
				((Selectable)uIUpgradeTick4.button).interactable = true;
				continue;
			}
			uIUpgradeTick4.InitAsMinorUpgrade(i4, i4 + 1 <= teamworkLevelTemp, i4 > character.teamworkLevel - 1);
			((Selectable)uIUpgradeTick4.button).interactable = teamworkLevelTemp <= teamworkMaxLevel && i4 == Mathf.Min(teamworkLevelTemp, teamworkMaxLevel - 1);
			if (((Selectable)uIUpgradeTick4.button).interactable)
			{
				enabledTeamworkTick = uIUpgradeTick4;
			}
		}
		Navigation navigation = default;
		if ((Object)(object)enabledAttackTick != (Object)null)
		{
			int num3 = attackTicks.FindIndex((UIUpgradeTick x) => (Object)(object)x == (Object)(object)enabledAttackTick);
			navigation = ((Selectable)enabledAttackTick.button).navigation;
			bool flag = false;
			for (int num4 = num3 - 1; num4 >= 0; num4--)
			{
				UIUpgradeTick uIUpgradeTick5 = attackTicks[num4];
				if (((Selectable)uIUpgradeTick5.button).IsInteractable())
				{
					navigation.selectOnLeft = (Selectable)(object)uIUpgradeTick5.button;
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				navigation.selectOnLeft = null;
			}
			flag = false;
			for (int num5 = num3 + 1; num5 < attackTicks.Count; num5++)
			{
				UIUpgradeTick uIUpgradeTick6 = attackTicks[num5];
				if (((Selectable)uIUpgradeTick6.button).IsInteractable())
				{
					navigation.selectOnRight = (Selectable)(object)uIUpgradeTick6.button;
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				navigation.selectOnRight = null;
			}
			flag = false;
			float num6 = float.MaxValue;
			Button selectOnDown = null;
			for (int num7 = 0; num7 < defenseTicks.Count; num7++)
			{
				UIUpgradeTick uIUpgradeTick7 = defenseTicks[num7];
				if (((Selectable)uIUpgradeTick7.button).IsInteractable())
				{
					Vector3 val = ((Component)uIUpgradeTick7).transform.position - ((Component)enabledAttackTick).transform.position;
					float sqrMagnitude = val.sqrMagnitude;
					if (sqrMagnitude < num6)
					{
						num6 = sqrMagnitude;
						selectOnDown = uIUpgradeTick7.button;
					}
				}
			}
			navigation.selectOnDown = (Selectable)(object)selectOnDown;
			num6 = float.MaxValue;
			selectOnDown = null;
			((Selectable)enabledAttackTick.button).navigation = navigation;
		}
		if ((Object)(object)enabledDefenseTick != (Object)null)
		{
			int num8 = defenseTicks.FindIndex((UIUpgradeTick x) => (Object)(object)x == (Object)(object)enabledDefenseTick);
			navigation = ((Selectable)enabledDefenseTick.button).navigation;
			bool flag2 = false;
			for (int num9 = num8 - 1; num9 >= 0; num9--)
			{
				UIUpgradeTick uIUpgradeTick8 = defenseTicks[num9];
				if (((Selectable)uIUpgradeTick8.button).IsInteractable())
				{
					navigation.selectOnLeft = (Selectable)(object)uIUpgradeTick8.button;
					flag2 = true;
					break;
				}
			}
			if (!flag2)
			{
				navigation.selectOnLeft = null;
			}
			flag2 = false;
			for (int num10 = num8 + 1; num10 < defenseTicks.Count; num10++)
			{
				UIUpgradeTick uIUpgradeTick9 = defenseTicks[num10];
				if (((Selectable)uIUpgradeTick9.button).IsInteractable())
				{
					navigation.selectOnRight = (Selectable)(object)uIUpgradeTick9.button;
					flag2 = true;
					break;
				}
			}
			if (!flag2)
			{
				navigation.selectOnRight = null;
			}
			flag2 = false;
			float num11 = float.MaxValue;
			Button selectOnUp = null;
			for (int num12 = 0; num12 < attackTicks.Count; num12++)
			{
				UIUpgradeTick uIUpgradeTick10 = attackTicks[num12];
				if (((Selectable)uIUpgradeTick10.button).IsInteractable())
				{
					Vector3 val2 = ((Component)uIUpgradeTick10).transform.position - ((Component)enabledDefenseTick).transform.position;
					float sqrMagnitude2 = val2.sqrMagnitude;
					if (sqrMagnitude2 < num11)
					{
						num11 = sqrMagnitude2;
						selectOnUp = uIUpgradeTick10.button;
					}
				}
			}
			navigation.selectOnUp = (Selectable)(object)selectOnUp;
			num11 = float.MaxValue;
			selectOnUp = null;
			for (int num13 = 0; num13 < luckTicks.Count; num13++)
			{
				UIUpgradeTick uIUpgradeTick11 = luckTicks[num13];
				if (((Selectable)uIUpgradeTick11.button).IsInteractable())
				{
					Vector3 val3 = ((Component)uIUpgradeTick11).transform.position - ((Component)enabledDefenseTick).transform.position;
					float sqrMagnitude3 = val3.sqrMagnitude;
					if (sqrMagnitude3 < num11)
					{
						num11 = sqrMagnitude3;
						selectOnUp = uIUpgradeTick11.button;
					}
				}
			}
			navigation.selectOnDown = (Selectable)(object)selectOnUp;
			((Selectable)enabledDefenseTick.button).navigation = navigation;
		}
		if ((Object)(object)enabledLuckTick != (Object)null)
		{
			int num14 = luckTicks.FindIndex((UIUpgradeTick x) => (Object)(object)x == (Object)(object)enabledLuckTick);
			navigation = ((Selectable)enabledLuckTick.button).navigation;
			bool flag3 = false;
			for (int num15 = num14 - 1; num15 >= 0; num15--)
			{
				UIUpgradeTick uIUpgradeTick12 = luckTicks[num15];
				if (((Selectable)uIUpgradeTick12.button).IsInteractable())
				{
					navigation.selectOnLeft = (Selectable)(object)uIUpgradeTick12.button;
					flag3 = true;
					break;
				}
			}
			if (!flag3)
			{
				navigation.selectOnLeft = null;
			}
			flag3 = false;
			for (int num16 = num14 + 1; num16 < luckTicks.Count; num16++)
			{
				UIUpgradeTick uIUpgradeTick13 = luckTicks[num16];
				if (((Selectable)uIUpgradeTick13.button).IsInteractable())
				{
					navigation.selectOnRight = (Selectable)(object)uIUpgradeTick13.button;
					flag3 = true;
					break;
				}
			}
			if (!flag3)
			{
				navigation.selectOnRight = null;
			}
			flag3 = false;
			float num17 = float.MaxValue;
			Button selectOnUp2 = null;
			for (int num18 = 0; num18 < defenseTicks.Count; num18++)
			{
				UIUpgradeTick uIUpgradeTick14 = defenseTicks[num18];
				if (((Selectable)uIUpgradeTick14.button).IsInteractable())
				{
					Vector3 val4 = ((Component)uIUpgradeTick14).transform.position - ((Component)enabledLuckTick).transform.position;
					float sqrMagnitude4 = val4.sqrMagnitude;
					if (sqrMagnitude4 < num17)
					{
						num17 = sqrMagnitude4;
						selectOnUp2 = uIUpgradeTick14.button;
					}
				}
			}
			navigation.selectOnUp = (Selectable)(object)selectOnUp2;
			num17 = float.MaxValue;
			selectOnUp2 = null;
			for (int num19 = 0; num19 < teamworkTicks.Count; num19++)
			{
				UIUpgradeTick uIUpgradeTick15 = teamworkTicks[num19];
				if (((Selectable)uIUpgradeTick15.button).IsInteractable())
				{
					Vector3 val5 = ((Component)uIUpgradeTick15).transform.position - ((Component)enabledLuckTick).transform.position;
					float sqrMagnitude5 = val5.sqrMagnitude;
					if (sqrMagnitude5 < num17)
					{
						num17 = sqrMagnitude5;
						selectOnUp2 = uIUpgradeTick15.button;
					}
				}
			}
			navigation.selectOnDown = (Selectable)(object)selectOnUp2;
			((Selectable)enabledLuckTick.button).navigation = navigation;
		}
		if ((Object)(object)enabledTeamworkTick != (Object)null)
		{
			int num20 = teamworkTicks.FindIndex((UIUpgradeTick x) => (Object)(object)x == (Object)(object)enabledTeamworkTick);
			navigation = ((Selectable)enabledTeamworkTick.button).navigation;
			bool flag4 = false;
			for (int num21 = num20 - 1; num21 >= 0; num21--)
			{
				UIUpgradeTick uIUpgradeTick16 = teamworkTicks[num21];
				if (((Selectable)uIUpgradeTick16.button).IsInteractable())
				{
					navigation.selectOnLeft = (Selectable)(object)uIUpgradeTick16.button;
					flag4 = true;
					break;
				}
			}
			if (!flag4)
			{
				navigation.selectOnLeft = null;
			}
			flag4 = false;
			for (int num22 = num20 + 1; num22 < teamworkTicks.Count; num22++)
			{
				UIUpgradeTick uIUpgradeTick17 = teamworkTicks[num22];
				if (((Selectable)uIUpgradeTick17.button).IsInteractable())
				{
					navigation.selectOnRight = (Selectable)(object)uIUpgradeTick17.button;
					flag4 = true;
					break;
				}
			}
			if (!flag4)
			{
				navigation.selectOnRight = null;
			}
			flag4 = false;
			float num23 = float.MaxValue;
			Button selectOnUp3 = null;
			for (int num24 = 0; num24 < luckTicks.Count; num24++)
			{
				UIUpgradeTick uIUpgradeTick18 = luckTicks[num24];
				if (((Selectable)uIUpgradeTick18.button).IsInteractable())
				{
					Vector3 val6 = ((Component)uIUpgradeTick18).transform.position - ((Component)enabledTeamworkTick).transform.position;
					float sqrMagnitude6 = val6.sqrMagnitude;
					if (sqrMagnitude6 < num23)
					{
						num23 = sqrMagnitude6;
						selectOnUp3 = uIUpgradeTick18.button;
					}
				}
			}
			navigation.selectOnUp = (Selectable)(object)selectOnUp3;
			navigation.selectOnDown = (Selectable)(object)weaponSlot.button;
			((Selectable)enabledTeamworkTick.button).navigation = navigation;
		}
		Button val7 = null;
		for (int num25 = 0; num25 < teamworkTicks.Count; num25++)
		{
			UIUpgradeTick uIUpgradeTick19 = teamworkTicks[num25];
			if (uIUpgradeTick19.isPerk)
			{
				val7 = uIUpgradeTick19.button;
				break;
			}
		}
		Button val8 = null;
		for (int num26 = teamworkTicks.Count - 1; num26 >= 0; num26--)
		{
			UIUpgradeTick uIUpgradeTick20 = teamworkTicks[num26];
			if (uIUpgradeTick20.isPerk)
			{
				val8 = uIUpgradeTick20.button;
				break;
			}
		}
		navigation = ((Selectable)weaponSlot.button).navigation;
		navigation.selectOnUp = (Selectable)(object)((!((Object)(object)enabledTeamworkTick != (Object)null)) ? val7 : enabledTeamworkTick.button);
		((Selectable)weaponSlot.button).navigation = navigation;
		((Selectable)weaponSlot.button).interactable = true;
		navigation = ((Selectable)badgeSlot0.button).navigation;
		navigation.selectOnUp = (Selectable)(object)((!((Object)(object)enabledTeamworkTick != (Object)null)) ? val8 : enabledTeamworkTick.button);
		((Selectable)badgeSlot0.button).navigation = navigation;
		((Selectable)badgeSlot0.button).interactable = true;
		navigation = ((Selectable)badgeSlot1.button).navigation;
		navigation.selectOnUp = (Selectable)(object)((!((Object)(object)enabledTeamworkTick != (Object)null)) ? val8 : enabledTeamworkTick.button);
		((Selectable)badgeSlot1.button).navigation = navigation;
		((Selectable)badgeSlot1.button).interactable = true;
		UpdatePerkNavigation();
	}

	private void UpdatePerkNavigation()
	{
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_025b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		List<UIUpgradeTick> list = null;
		List<UIUpgradeTick> list2 = null;
		List<UIUpgradeTick> list3 = null;
		for (int i = 0; i < 4; i++)
		{
			switch (i)
			{
			case 0:
				list = attackTicks;
				list2 = null;
				list3 = defenseTicks;
				break;
			case 1:
				list = defenseTicks;
				list2 = attackTicks;
				list3 = luckTicks;
				break;
			case 2:
				list = luckTicks;
				list2 = defenseTicks;
				list3 = teamworkTicks;
				break;
			case 3:
				list = teamworkTicks;
				list2 = luckTicks;
				list3 = null;
				break;
			}
			int count = list.Count;
			for (int j = 0; j < count; j++)
			{
				UIUpgradeTick uIUpgradeTick = list[j];
				if (!uIUpgradeTick.isPerk)
				{
					continue;
				}
				Navigation navigation = ((Selectable)uIUpgradeTick.button).navigation;
				bool flag = false;
				Vector3 position = ((Component)uIUpgradeTick).transform.position;
				for (int num = j - 1; num >= 0; num--)
				{
					UIUpgradeTick uIUpgradeTick2 = list[num];
					if (((Selectable)uIUpgradeTick2.button).IsInteractable())
					{
						navigation.selectOnLeft = (Selectable)(object)uIUpgradeTick2.button;
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					navigation.selectOnLeft = null;
				}
				flag = false;
				for (int k = j + 1; k < count; k++)
				{
					UIUpgradeTick uIUpgradeTick3 = list[k];
					if (((Selectable)uIUpgradeTick3.button).IsInteractable())
					{
						navigation.selectOnRight = (Selectable)(object)uIUpgradeTick3.button;
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					navigation.selectOnRight = null;
				}
				flag = false;
				float num2 = float.MaxValue;
				Button selectOnUp = null;
				if (list2 != null)
				{
					int count2 = list2.Count;
					for (int l = 0; l < count2; l++)
					{
						UIUpgradeTick uIUpgradeTick4 = list2[l];
						if (((Selectable)uIUpgradeTick4.button).IsInteractable())
						{
							Vector3 val = ((Component)uIUpgradeTick4).transform.position - position;
							float sqrMagnitude = val.sqrMagnitude;
							if (sqrMagnitude < num2)
							{
								num2 = sqrMagnitude;
								selectOnUp = uIUpgradeTick4.button;
							}
						}
					}
					navigation.selectOnUp = (Selectable)(object)selectOnUp;
				}
				else
				{
					navigation.selectOnUp = null;
				}
				num2 = float.MaxValue;
				selectOnUp = null;
				if (list3 != null)
				{
					int count3 = list3.Count;
					for (int m = 0; m < count3; m++)
					{
						UIUpgradeTick uIUpgradeTick5 = list3[m];
						if (((Selectable)uIUpgradeTick5.button).IsInteractable())
						{
							Vector3 val2 = ((Component)uIUpgradeTick5).transform.position - position;
							float sqrMagnitude2 = val2.sqrMagnitude;
							if (sqrMagnitude2 < num2)
							{
								num2 = sqrMagnitude2;
								selectOnUp = uIUpgradeTick5.button;
							}
						}
					}
					navigation.selectOnDown = (Selectable)(object)selectOnUp;
				}
				else
				{
					navigation.selectOnDown = null;
					if (i == 3)
					{
						navigation.selectOnDown = (Selectable)(object)weaponSlot.button;
					}
				}
				((Selectable)uIUpgradeTick.button).navigation = navigation;
			}
		}
	}

	private void SelectFirstAvailableUpgradeTick()
	{
		GameObject selectedGameObject = null;
		if (character.attackLevel < attackMaxLevel)
		{
			selectedGameObject = ((Component)attackTicks[attackLevelTemp]).gameObject;
		}
		else if (character.defenseLevel < defenseMaxLevel)
		{
			selectedGameObject = ((Component)defenseTicks[defenseLevelTemp]).gameObject;
		}
		else if (character.luckLevel < luckMaxLevel)
		{
			selectedGameObject = ((Component)luckTicks[luckLevelTemp]).gameObject;
		}
		else if (character.teamworkLevel < teamworkMaxLevel)
		{
			selectedGameObject = ((Component)teamworkTicks[teamworkLevelTemp]).gameObject;
		}
		EventSystem.current.SetSelectedGameObject(selectedGameObject);
	}

	private void SelectFirstAvailableUpgradeTick(CharacterStatType statType)
	{
		GameObject val = null;
		switch (statType)
		{
		case CharacterStatType.Attack:
			val = ((Component)attackTicks[attackLevelTemp]).gameObject;
			break;
		case CharacterStatType.Defense:
			val = ((Component)defenseTicks[defenseLevelTemp]).gameObject;
			break;
		case CharacterStatType.Luck:
			val = ((Component)luckTicks[luckLevelTemp]).gameObject;
			break;
		case CharacterStatType.Teamwork:
			val = ((Component)teamworkTicks[teamworkLevelTemp]).gameObject;
			break;
		}
		if ((Object)(object)val != (Object)null)
		{
			EventSystem.current.SetSelectedGameObject(val);
		}
	}

	private void InitOnScreenButtons()
	{
		((Component)backButton).gameObject.SetActive(true);
		backButton.SetText(Languages.Get("BACK", "MENUS, GUI"));
		((Component)selectButton).gameObject.SetActive(character.skillPoints > 0);
		selectButton.SetText(Languages.Get("ADD_POINTS", "MENUS, GUI"));
		((Component)removeButton).gameObject.SetActive(false);
		removeButton.SetText(Languages.Get("REMOVE_POINTS", "MENUS, GUI"));
		((Component)clearButton).gameObject.SetActive(false);
		clearButton.SetText(Languages.Get("CLEAR_ALL", "MENUS, GUI"));
	}

	private void UpdateEquipmentDescription()
	{
		UIEquipmentSlot component = EventSystem.current.currentSelectedGameObject.GetComponent<UIEquipmentSlot>();
		if ((Object)(object)component != (Object)null)
		{
			if ((Object)(object)component.itemDefinition != (Object)null)
			{
				descriptionHeaderText.text = Languages.Get(component.itemDefinition.itemDescriptionHeaderKey, "ITEMS, ABILITIES, UPGRADES");
				descriptionText.text = Languages.Get(component.itemDefinition.itemDescriptionKey, "ITEMS, ABILITIES, UPGRADES");
			}
			else
			{
				descriptionHeaderText.text = string.Empty;
				descriptionText.text = string.Empty;
			}
		}
	}

	private int GetMinorUpgradeCost(int slotIndex)
	{
		if (slotIndex >= 0 && slotIndex <= 6)
		{
			return GameResources.instance.gameSettings.lowTierUpgradeCost;
		}
		if (slotIndex >= 7 && slotIndex <= 14)
		{
			return GameResources.instance.gameSettings.midTierUpgradeCost;
		}
		if (slotIndex >= 15 && slotIndex <= 24)
		{
			return GameResources.instance.gameSettings.highTierUpgradeCost;
		}
		return 0;
	}

	private void OptionPressed_Relationship()
	{
		animator.Play("UpgradeScreen_RelationshipOutro");
		mode = Mode.Upgrade;
		if ((Object)(object)previousSelectedUpgradeObj != (Object)null)
		{
			EventSystem.current.SetSelectedGameObject(previousSelectedUpgradeObj);
		}
		else
		{
			SelectFirstAvailableUpgradeTick();
		}
	}

	private void CancelPressed_Relationship()
	{
		OptionPressed_Relationship();
	}
}
