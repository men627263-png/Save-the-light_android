using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Image))]
public class UIGamepadButtonImage : MonoBehaviour
{
	public static Dictionary<UIGamepadButtonType, string> buttonSpriteNamesPS4 = new Dictionary<UIGamepadButtonType, string>
	{
		{
			UIGamepadButtonType.FaceButtonTop,
			"gui_button_ps_triangle"
		},
		{
			UIGamepadButtonType.FaceButtonRight,
			"gui_button_ps_circle"
		},
		{
			UIGamepadButtonType.FaceButtonBottom,
			"gui_button_ps_x"
		},
		{
			UIGamepadButtonType.FaceButtonLeft,
			"gui_button_ps_square"
		},
		{
			UIGamepadButtonType.FaceButtonCenterLeft,
			"button_pad"
		},
		{
			UIGamepadButtonType.FaceButtonCenterRight,
			"button_optionbutton"
		},
		{
			UIGamepadButtonType.TriggerLeftOne,
			"PS4_L1"
		},
		{
			UIGamepadButtonType.TriggerLeftTwo,
			"gui_button_ps_square"
		},
		{
			UIGamepadButtonType.TriggerRightOne,
			"PS4_R1"
		},
		{
			UIGamepadButtonType.TriggerRightTwo,
			"gui_button_ps_square"
		},
		{
			UIGamepadButtonType.Dpad,
			"gui_button_ps_dpad"
		},
		{
			UIGamepadButtonType.LeftStick,
			"gui_button_ps_leftstick"
		}
	};

	public static Dictionary<UIGamepadButtonType, string> buttonSpriteNamesXBONE = new Dictionary<UIGamepadButtonType, string>
	{
		{
			UIGamepadButtonType.FaceButtonTop,
			"gui_button_xbox_y"
		},
		{
			UIGamepadButtonType.FaceButtonRight,
			"gui_button_xbox_b"
		},
		{
			UIGamepadButtonType.FaceButtonBottom,
			"gui_button_xbox_a"
		},
		{
			UIGamepadButtonType.FaceButtonLeft,
			"gui_button_xbox_x"
		},
		{
			UIGamepadButtonType.FaceButtonCenterLeft,
			"XboxOne_Windows"
		},
		{
			UIGamepadButtonType.FaceButtonCenterRight,
			"XboxOne_Menu"
		},
		{
			UIGamepadButtonType.TriggerLeftOne,
			"XboxOne_LB"
		},
		{
			UIGamepadButtonType.TriggerLeftTwo,
			"XboxOne_LT"
		},
		{
			UIGamepadButtonType.TriggerRightOne,
			"XboxOne_RB"
		},
		{
			UIGamepadButtonType.TriggerRightTwo,
			"XboxOne_RT"
		},
		{
			UIGamepadButtonType.Dpad,
			"gui_button_xbox_dpad"
		},
		{
			UIGamepadButtonType.LeftStick,
			"gui_button_xbox_leftstick"
		}
	};

	public static Dictionary<UIGamepadButtonType, string> buttonSpriteNamesPC = new Dictionary<UIGamepadButtonType, string>
	{
		{
			UIGamepadButtonType.FaceButtonTop,
			"gui_button_keyboard_topFaceButton"
		},
		{
			UIGamepadButtonType.FaceButtonRight,
			"gui_button_keyboard_rightFaceButton"
		},
		{
			UIGamepadButtonType.FaceButtonBottom,
			"gui_button_keyboard_bottomFaceButton"
		},
		{
			UIGamepadButtonType.FaceButtonLeft,
			"gui_button_keyboard_leftFaceButton"
		},
		{
			UIGamepadButtonType.FaceButtonCenterLeft,
			"button_keyboard_centerLeftFaceButton"
		},
		{
			UIGamepadButtonType.FaceButtonCenterRight,
			"button_keyboard_centerRightFaceButton"
		},
		{
			UIGamepadButtonType.TriggerLeftOne,
			"button_keyboard_leftBumper"
		},
		{
			UIGamepadButtonType.TriggerLeftTwo,
			"button_keyboard_leftTrigger"
		},
		{
			UIGamepadButtonType.TriggerRightOne,
			"button_keyboard_rightBumper"
		},
		{
			UIGamepadButtonType.TriggerRightTwo,
			"button_keyboard_rightTrigger"
		},
		{
			UIGamepadButtonType.Dpad,
			"gui_button_keyboard_dpad"
		},
		{
			UIGamepadButtonType.LeftStick,
			"gui_button_keyboard_leftStick"
		},
		{
			UIGamepadButtonType.DpadLeft,
			"button_keyboard_leftBumper"
		},
		{
			UIGamepadButtonType.DpadUp,
			"button_keyboard_upArrow"
		},
		{
			UIGamepadButtonType.DpadRight,
			"button_keyboard_rightBumper"
		},
		{
			UIGamepadButtonType.DpadDown,
			"button_keyboard_downArrow"
		}
	};

	public Image image;

	public UIGamepadButtonType buttonType;

	public Sprite keyboardOverrideSprite;

	public PlatformButtonSpritesGroup platformButtonSpritesGroup = new PlatformButtonSpritesGroup();

	private void Awake()
	{
		image = ((Component)this).GetComponent<Image>();
	}

	private void OnEnable()
	{
		if (buttonType != UIGamepadButtonType.None)
		{
			DisplayButton(buttonType);
		}
		GameController.GamepadChanged += GamepadChanged;
	}

	private void OnDisable()
	{
		GameController.GamepadChanged -= GamepadChanged;
	}

	private void GamepadChanged(GamepadType gamepad)
	{
		Debug.Log((object)("UPDATING UI TO: " + GameController.ConnectedGamepad), (Object)(object)((Component)this).gameObject);
		if (buttonType != UIGamepadButtonType.None)
		{
			DisplayButton(buttonType);
		}
	}

	public void DisplayButton(UIGamepadButtonType button)
	{
		if (!platformButtonSpritesGroup.ContainsButtonType(button) || button == UIGamepadButtonType.None)
		{
			return;
		}
		buttonType = button;
		if (GameController.ConnectedGamepad == GamepadType.PS4)
		{
			image.sprite = platformButtonSpritesGroup.GetPlatformSpriteForButtonType(button).ps4Sprite;
		}
		else if (GameController.ConnectedGamepad == GamepadType.Xbox)
		{
			image.sprite = platformButtonSpritesGroup.GetPlatformSpriteForButtonType(button).xboxSprite;
		}
		else if (GameController.ConnectedGamepad == GamepadType.Keyboard)
		{
			if ((Object)(object)keyboardOverrideSprite != (Object)null)
			{
				image.sprite = keyboardOverrideSprite;
			}
			else
			{
				image.sprite = platformButtonSpritesGroup.GetPlatformSpriteForButtonType(button).pcSprite;
			}
		}
	}
}
