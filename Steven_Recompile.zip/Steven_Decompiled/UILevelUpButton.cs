using TMPro;
using UnityEngine;

public class UILevelUpButton : MonoBehaviour
{
	public CharacterName characterToLevel;

	public TextMeshProUGUI textMesh;

	private string levelUpMessage;

	private bool showLevelUpMessage;

	private int characterUID = -1;

	private static int messageCount = -1;

	private void Start()
	{
		characterUID = GameController.Instance.characterDatabase.GetCharacter(characterToLevel.ToString()).uid;
		if (PlayerGameState.Instance.HasCharacterInActiveParty(characterUID))
		{
			textMesh.text = "Level up " + characterToLevel;
		}
		else
		{
			textMesh.text = "Add " + characterToLevel.ToString() + " to party";
		}
	}

	public void LevelUpCharacter()
	{
		if (!((Object)(object)GameController.Instance != (Object)null) || GameController.Instance.inBattle)
		{
			return;
		}
		if (PlayerGameState.Instance.HasCharacterInActiveParty(characterUID))
		{
			PlayerCharacter characterFromActiveParty = GameController.Instance.GetCharacterFromActiveParty(characterToLevel);
			characterFromActiveParty.AddXP(characterFromActiveParty.currentLevelData.xpToLevelUp - characterFromActiveParty.currentXP, showLevelUpEffect: false);
			levelUpMessage = characterFromActiveParty.characterName.ToString() + " has level up to Level " + characterFromActiveParty.currentLevel;
			GameController.Instance.debugLevelUpMessages.Add(levelUpMessage);
		}
		else
		{
			PlayerGameState.Instance.AddCharacterToActiveParty(characterUID);
			if (PlayerGameState.Instance.HasCharacterInActiveParty(characterUID))
			{
				textMesh.text = "Level up " + characterToLevel;
			}
		}
	}
}
