using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using DG.Tweening.Core;
using PixelCrushers.DialogueSystem;
using PixelCrushers.DialogueSystem.TextMeshPro;
using SimpleSpritePacker;
using UnityEngine;
using UnityEngine.UI;

public class DialogueSystemListener : MonoBehaviour
{
	private static DialogueSystemListener _instance;

	public Canvas canvas;

	public Camera camera;

	public TextMeshProDialogueUI dialogueUI;

	public UIDialoguePanelFollowCharacter pcFollow;

	public UIDialoguePanelFollowCharacter npcFollow;

	public UIDialoguePanelFollowCharacter smallNpcFollow;

	public UIDialoguePanelSize pcPanelSize;

	public UIDialoguePanelSize npcPanelSize;

	public float panelWidthPadding = 100f;

	public float panelHeightPadding = 80f;

	private Vector2 startingTextBoxSize;

	public RawImage playerBGImage;

	public Image playerDialogueBox;

	public Image[] playerDialogueBoxTails;

	public GameObject playerContinueButton;

	public UIGamepadButtonAction playerActionButton;

	public RawImage npcBGImage;

	public Image npcDialogueBox;

	public Image[] npcDialogueBoxTails;

	public GameObject npcContinueButton;

	public GameObject npcContinueButtonHessonite;

	public UIGamepadButtonAction npcActionButton;

	public Color npcGenericColor = new Color(1f, 1f, 1f, 1f);

	public Texture2D npcGenericBGScroll;

	public Color npcQuestColor = new Color(1f, 1f, 1f, 1f);

	public Color npcQuestFontColor = new Color(1f, 1f, 1f, 1f);

	public Texture2D npcQuestBGScroll;

	public Image phoneCallImage;

	public AudioSource audioSourceTypewriter;

	public AudioSource audioSourceVo1;

	public AudioSource audioSourceVo2;

	public SPInstance atlas;

	public Image responseSpriteBacking;

	public Image responseSpriteGlow;

	public Image responseSpriteFade;

	private IDialogueCharacter lastDialogueCharacterPC;

	private IDialogueCharacter lastDialogueCharacterNPC;

	private IDialogueCharacter lastDialogueCharacter;

	private DialogueEntry lastDialogueEntryPC;

	private DialogueEntry lastDialogueEntryNPC;

	private string lastPCEmotion = string.Empty;

	private string lastNPCEmotion = string.Empty;

	private bool conversationPlaying;

	private Sequence pcPanelSizeTween;

	private Sequence npcPanelSizeTween;

	[Header("Audio")]
	private AudioSource dialogueAudioSource;

	private bool pcWaitingForAudio;

	private bool npcWaitingForAudio;

	private List<string> queue = new List<string>();

	private bool gameControlsPreviouslyOn;

	private bool gameUIControlsPreviouslyOn;

	private bool menuUIControlsPreviouslyOn;

	private bool warpPadControlsPreviouslyOn;

	private DialogueEntry currentDialogueEntry;

	private Coroutine waitForAudioClipEndRoutine;

	private DialogueCharacterDatabase _dialogueCharacterDatabase;

	private ShakeText _shakeTextScriptPC;

	private ShakeText _shakeTextScriptNPC;

	public static DialogueSystemListener Instance => _instance;

	public bool isDialoguePlaying
	{
		get
		{
			if (((Component)pcFollow).gameObject.activeInHierarchy || ((Component)npcFollow).gameObject.activeInHierarchy || conversationPlaying)
			{
				return true;
			}
			return false;
		}
	}

	public bool isConversationPlaying => conversationPlaying;

	private IDialogueCharacter[] allCharacters => GameController.Instance.DialogueCharacters.ToArray();

	public bool movementAllowed { get; set; }

	public DialogueCharacterDatabase dialogueCharacterDatabase
	{
		get
		{
			if ((Object)(object)_dialogueCharacterDatabase == (Object)null)
			{
				_dialogueCharacterDatabase = Resources.Load<DialogueCharacterDatabase>("DialogueCharacterDatabase");
			}
			return _dialogueCharacterDatabase;
		}
	}

	private ShakeText shakeTextScriptPC
	{
		get
		{
			if ((Object)(object)_shakeTextScriptPC == (Object)null)
			{
				_shakeTextScriptPC = ((Component)dialogueUI.dialogue.pcSubtitle.line).gameObject.GetComponent<ShakeText>();
			}
			return _shakeTextScriptPC;
		}
	}

	private ShakeText shakeTextScriptNPC
	{
		get
		{
			if ((Object)(object)_shakeTextScriptNPC == (Object)null)
			{
				_shakeTextScriptNPC = ((Component)dialogueUI.dialogue.npcSubtitle.line).gameObject.GetComponent<ShakeText>();
			}
			return _shakeTextScriptNPC;
		}
	}

	public event Action<string> OnConversationStartEvent;

	public event Action<string> OnConversationEndEvent;

	public DialogueSystemListener()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Awake()
	{
		if (!((Object)(object)_instance != (Object)null))
		{
			_instance = this;
		}
	}

	private void Start()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Expected Obj, but got Unknown
		startingTextBoxSize = ((Component)dialogueUI.dialogue.pcSubtitle.line).GetComponent<RectTransform>().sizeDelta;
		DialogueManager.IsDialogueEntryValid = CheckDialogueEntryIsValid;
	}

	public bool CheckCharacterIsAvailable(DialogueEntry entry)
	{
		Actor actor = DialogueManager.MasterDatabase.GetActor(entry.ActorID);
		if (actor == null)
		{
			return true;
		}
		for (int i = 0; i < allCharacters.Length; i++)
		{
			if (allCharacters[i] != null && allCharacters[i].actorName.Equals(((Asset)actor).Name) && allCharacters[i].actorObject.activeInHierarchy)
			{
				return true;
			}
		}
		return false;
	}

	private bool CheckDialogueEntryIsValid(DialogueEntry entry)
	{
		bool result = CheckForValidEntry(entry);
		if (entry.ActorID == -1)
		{
			result = true;
		}
		return result;
	}

	private bool CheckForValidEntry(DialogueEntry entry)
	{
		if (!CheckCharacterIsAvailable(entry))
		{
			return false;
		}
		bool flag = false;
		if (entry.outgoingLinks.Count > 0)
		{
			for (int i = 0; i < entry.outgoingLinks.Count; i++)
			{
				Link val = entry.outgoingLinks[i];
				DialogueEntry dialogueEntry = DialogueManager.MasterDatabase.GetDialogueEntry(val);
				bool flag2 = CheckAllLinksForValidEntries(dialogueEntry, firstEntry: true);
				string text = Field.LookupValue(dialogueEntry.fields, "Optional");
				if (text == null)
				{
					text = "False";
				}
				if (flag2 || text.Equals("True"))
				{
					return true;
				}
			}
			return false;
		}
		return true;
	}

	private bool CheckAllLinksForValidEntries(DialogueEntry entry, bool firstEntry = false)
	{
		if (!CheckCharacterIsAvailable(entry) && firstEntry)
		{
			return false;
		}
		for (int i = 0; i < entry.outgoingLinks.Count; i++)
		{
			Link val = entry.outgoingLinks[i];
			DialogueEntry dialogueEntry = DialogueManager.MasterDatabase.GetDialogueEntry(val);
			bool flag = CheckAllLinksForValidEntries(dialogueEntry);
			string text = Field.LookupValue(dialogueEntry.fields, "Optional");
			if (text == null)
			{
				text = "False";
			}
			if (!flag && !text.Equals("True"))
			{
				return false;
			}
			if (flag)
			{
				return true;
			}
		}
		return true;
	}

	public void StartConversation(string convoName)
	{
		DialogueManager.StartConversation(convoName);
	}

	public void OnConversationStart()
	{
		conversationPlaying = true;
		movementAllowed = false;
		lastDialogueCharacter = null;
		gameControlsPreviouslyOn = GameController.Instance.GetContollerMapStateForCategory("Game");
		gameUIControlsPreviouslyOn = GameController.Instance.GetContollerMapStateForCategory("GameUI");
		menuUIControlsPreviouslyOn = GameController.Instance.GetContollerMapStateForCategory("MenuUI");
		warpPadControlsPreviouslyOn = GameController.Instance.GetContollerMapStateForCategory("GameWarpPad");
		GameController.Instance.SetMapsEnabled(state: false, "Game");
		GameController.Instance.SetMapsEnabled(state: false, "GameUI");
		GameController.Instance.SetMapsEnabled(state: true, "MenuUI");
		GameController.Instance.SetMapsEnabled(state: false, "GameWarpPad");
		if (OnConversationStartEvent != null)
		{
			OnConversationStartEvent(DialogueManager.Instance.LastConversationStarted);
		}
		dialogueUI.OnDialogueChoiceBegin += DialogueChoiceBegin;
		dialogueUI.OnDialogueChoiceEnd += DialogueChoiceEnd;
	}

	public void OnConversationEnd()
	{
		conversationPlaying = false;
		OnAudioEnd();
		FadeOutSourcesPlaying();
		((Component)phoneCallImage).gameObject.SetActive(false);
		GameController.Instance.SetMapsEnabled(gameControlsPreviouslyOn, "Game");
		GameController.Instance.SetMapsEnabled(gameUIControlsPreviouslyOn, "GameUI");
		GameController.Instance.SetMapsEnabled(menuUIControlsPreviouslyOn, "MenuUI");
		GameController.Instance.SetMapsEnabled(warpPadControlsPreviouslyOn, "GameWarpPad");
		dialogueUI.OnDialogueChoiceBegin -= DialogueChoiceBegin;
		dialogueUI.OnDialogueChoiceEnd -= DialogueChoiceEnd;
		if (OnConversationEndEvent != null)
		{
			OnConversationEndEvent(DialogueManager.Instance.LastConversationStarted);
		}
		ResetDialoguePanelFollowCharacters();
		if (lastDialogueCharacter != null && lastDialogueCharacter is BaseCharacter && !(lastDialogueCharacter is StevenPC))
		{
			((BaseCharacter)lastDialogueCharacter).PlayAnim(((BaseCharacter)lastDialogueCharacter).GetIdleAnimation());
		}
		else if (lastDialogueCharacterPC != null && !GameController.Instance.isFSMActive && lastDialogueCharacterPC is BaseCharacter && ((BaseCharacter)lastDialogueCharacterPC).isGrounded)
		{
			((BaseCharacter)lastDialogueCharacterPC).PlayAnim(((BaseCharacter)lastDialogueCharacterPC).GetIdleAnimation());
		}
		for (int i = 0; i < GameController.Instance.party.Count; i++)
		{
			GameController.Instance.party[i].RichAI2D.SetAnimationsAllowed(allowed: true);
		}
		if (queue.Count > 0)
		{
			DialogueManager.StartConversation(queue[0]);
			queue.RemoveAt(0);
		}
	}

	public void AddConversationToQueue(string convoName)
	{
		if (!queue.Contains(convoName))
		{
			queue.Add(convoName);
		}
	}

	public void StopConversation()
	{
		if (conversationPlaying)
		{
			((MonoBehaviour)this).StopCoroutine("AutoContinue");
			((AbstractDialogueUI)dialogueUI).OnContinue();
			((AbstractUIControls)dialogueUI.dialogue.npcSubtitle).Hide();
			((AbstractUIControls)dialogueUI.dialogue.pcSubtitle).Hide();
			DialogueManager.StopConversation();
			OnConversationEnd();
		}
	}

	private void DialogueChoiceBegin()
	{
		PlayerCharacter characterFromActiveParty = GameController.Instance.GetCharacterFromActiveParty(CharacterName.Steven);
		characterFromActiveParty.RichAI2D.SetAnimationsAllowed(allowed: false);
		characterFromActiveParty.PlayAnim(new CharacterAnimationNamePair("steven_talk_thinking_stop_talking", string.Empty));
	}

	private void DialogueChoiceEnd()
	{
		PlayerCharacter characterFromActiveParty = GameController.Instance.GetCharacterFromActiveParty(CharacterName.Steven);
		characterFromActiveParty.RichAI2D.SetAnimationsAllowed(allowed: true);
		characterFromActiveParty.PlayAnim(characterFromActiveParty.GetIdleAnimation());
	}

	public void SetMovementAllowed(bool allow)
	{
		movementAllowed = allow;
		GameController.Instance.SetMapsEnabled(movementAllowed, "Game");
	}

	public void ResetDialoguePanelFollowCharacters()
	{
		pcFollow.ResetObject();
		npcFollow.ResetObject();
	}

	public void OnTypeWriterBegin()
	{
		dialogueUI.textIsTyping = true;
	}

	public void OnTypeWriterEnd()
	{
		((MonoBehaviour)this).StartCoroutine("DelayEndTextIsTyping");
	}

	private IEnumerator DelayEndTextIsTyping()
	{
		yield return (object)new WaitForSeconds(0.15f);
		dialogueUI.textIsTyping = false;
	}

	private void CheckForDialogueReward(DialogueEntry entry)
	{
		string text = Field.LookupValue(entry.fields, "Dialogue Choice");
		if (text == null || !text.Equals("NonChoiceReward"))
		{
			return;
		}
		string text2 = Field.LookupValue(entry.fields, "Dialogue Choice Reward");
		if (!string.IsNullOrEmpty(text2) && text2.Equals("REL"))
		{
			string text3 = Field.LookupValue(entry.fields, "Dialogue Choice Reward Char");
			string text4 = Field.LookupValue(entry.fields, "Dialogue Choice Reward Char 2");
			string text5 = Field.LookupValue(entry.fields, "Dialogue Choice Reward Amount");
			if (text3 != null && text4 != null && text5 != null)
			{
				RelationshipPointsManager.Instance.AddRelationshipPoints((CharacterName)Enum.Parse(typeof(CharacterName), text3, ignoreCase: true), (CharacterName)Enum.Parse(typeof(CharacterName), text4, ignoreCase: true), int.Parse(text5), showKudos: false);
			}
		}
	}

	public void OnTypeWriterEndPC()
	{
		if (lastDialogueEntryPC != null)
		{
			string text = Field.LookupValue(lastDialogueEntryPC.fields, "Auto Continue");
			if (text != null && text.Equals("True"))
			{
				((MonoBehaviour)this).StopCoroutine("AutoContinue");
				((MonoBehaviour)this).StartCoroutine("AutoContinue");
			}
			CheckForDialogueReward(lastDialogueEntryPC);
		}
		if (!pcWaitingForAudio)
		{
			PlayPCStopTalking();
		}
	}

	public void OnTypeWriterEndNPC()
	{
		if (lastDialogueEntryNPC != null)
		{
			string text = Field.LookupValue(lastDialogueEntryNPC.fields, "Auto Continue");
			if (text != null && text.Equals("True"))
			{
				((MonoBehaviour)this).StopCoroutine("AutoContinue");
				((MonoBehaviour)this).StartCoroutine("AutoContinue");
			}
			CheckForDialogueReward(lastDialogueEntryNPC);
		}
		if (!npcWaitingForAudio)
		{
			PlayNPCStopTalking();
		}
	}

	private void PlayPCStopTalking()
	{
		if (lastDialogueCharacterPC == null || !((Object)(object)lastDialogueCharacterPC.actorAnimator != (Object)null) || string.IsNullOrEmpty(lastPCEmotion))
		{
			return;
		}
		((MonoBehaviour)this).StopCoroutine("WaitForPCIdleAnimation");
		string dialogueCharacterStopTalkAnimationName = GetDialogueCharacterStopTalkAnimationName(lastDialogueCharacterPC.actorName, lastPCEmotion);
		if (!string.IsNullOrEmpty(dialogueCharacterStopTalkAnimationName))
		{
			PlayDialogueCharacterAnim(lastDialogueCharacterPC, dialogueCharacterStopTalkAnimationName);
		}
		if (currentDialogueEntry != null)
		{
			lastDialogueCharacter = lastDialogueCharacterPC;
			string text = Field.LookupValue(currentDialogueEntry.fields, "Dialogue Emotion Hold");
			if (text != null && text.Equals("True"))
			{
				lastDialogueCharacter = null;
			}
		}
		lastPCEmotion = string.Empty;
	}

	private void PlayNPCStopTalking()
	{
		if (lastDialogueCharacterNPC == null || !((Object)(object)lastDialogueCharacterNPC.actorAnimator != (Object)null) || string.IsNullOrEmpty(lastNPCEmotion))
		{
			return;
		}
		((MonoBehaviour)this).StopCoroutine("WaitForNPCIdleAnimation");
		string dialogueCharacterStopTalkAnimationName = GetDialogueCharacterStopTalkAnimationName(lastDialogueCharacterNPC.actorName, lastNPCEmotion);
		tk2dSpriteAnimationClip clipByName = lastDialogueCharacterNPC.actorAnimator.GetClipByName(dialogueCharacterStopTalkAnimationName);
		if (clipByName == null && lastDialogueCharacterNPC is BaseCharacter)
		{
			PlayDialogueCharacterAnim(lastDialogueCharacterNPC, ((BaseCharacter)lastDialogueCharacterNPC).GetIdleAnimation());
		}
		else if (clipByName != null)
		{
			PlayDialogueCharacterAnim(lastDialogueCharacterNPC, clipByName.name);
		}
		lastNPCEmotion = string.Empty;
		if (currentDialogueEntry != null)
		{
			lastDialogueCharacter = lastDialogueCharacterNPC;
			string text = Field.LookupValue(currentDialogueEntry.fields, "Dialogue Emotion Hold");
			if (text != null && text.Equals("True"))
			{
				lastDialogueCharacter = null;
			}
		}
		lastDialogueCharacterNPC = null;
	}

	private void OnAudioEnd()
	{
		if (npcWaitingForAudio)
		{
			npcWaitingForAudio = false;
			PlayNPCStopTalking();
		}
		if (pcWaitingForAudio)
		{
			pcWaitingForAudio = false;
			PlayPCStopTalking();
		}
	}

	private IEnumerator AutoContinue()
	{
		yield return (object)new WaitForSeconds(2f);
		((AbstractDialogueUI)dialogueUI).OnContinue();
	}

	private AudioSource GetAvailableAudioSource()
	{
		if (!audioSourceVo1.isPlaying)
		{
			ShortcutExtensions.DOFade(audioSourceVo2, 0f, 0.02f);
			ShortcutExtensions.DOKill((Component)(object)audioSourceVo1, false);
			audioSourceVo1.volume = 1f;
			return audioSourceVo1;
		}
		if (!audioSourceVo2.isPlaying)
		{
			ShortcutExtensions.DOFade(audioSourceVo1, 0f, 0.02f);
			ShortcutExtensions.DOKill((Component)(object)audioSourceVo2, false);
			audioSourceVo2.volume = 1f;
			return audioSourceVo2;
		}
		ShortcutExtensions.DOKill((Component)(object)audioSourceVo1, false);
		audioSourceVo1.volume = 1f;
		return audioSourceVo1;
	}

	private void FadeOutSourcesPlaying()
	{
		if (audioSourceVo1.isPlaying)
		{
			ShortcutExtensions.DOFade(audioSourceVo1, 0f, 0.1f);
		}
		if (audioSourceVo2.isPlaying)
		{
			ShortcutExtensions.DOFade(audioSourceVo2, 0f, 0.1f);
		}
	}

	public void UpdateDialogueResponseForSteven()
	{
		responseSpriteFade.sprite = atlas.GetSpriteByName("dialogueresponse_star2");
		responseSpriteBacking.sprite = atlas.GetSpriteByName("dialogueresponse_star");
		responseSpriteGlow.sprite = atlas.GetSpriteByName("dialogueresponse_star_glow");
	}

	public void UpdateDialogueResponseForPrism()
	{
		responseSpriteFade.sprite = atlas.GetSpriteByName("dialogueresponse_prism_overlay");
		responseSpriteBacking.sprite = atlas.GetSpriteByName("dialogueresponse_prism");
		responseSpriteGlow.sprite = atlas.GetSpriteByName("dialogueresponse_prism_glow");
	}

	public void OnConversationLine(Subtitle subtitle)
	{
		//IL_0b92: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bc2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0444: Unknown result type (might be due to invalid IL or missing references)
		//IL_0449: Unknown result type (might be due to invalid IL or missing references)
		//IL_044d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0452: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a29: Unknown result type (might be due to invalid IL or missing references)
		//IL_0683: Unknown result type (might be due to invalid IL or missing references)
		//IL_0743: Unknown result type (might be due to invalid IL or missing references)
		//IL_0748: Unknown result type (might be due to invalid IL or missing references)
		//IL_074c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0751: Unknown result type (might be due to invalid IL or missing references)
		//IL_0782: Unknown result type (might be due to invalid IL or missing references)
		//IL_0787: Unknown result type (might be due to invalid IL or missing references)
		//IL_078b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0790: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07db: Unknown result type (might be due to invalid IL or missing references)
		//IL_07df: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bde: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b00: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b21: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a88: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a46: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ad4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b67: Unknown result type (might be due to invalid IL or missing references)
		if (allCharacters == null || subtitle.dialogueEntry.id == 0)
		{
			return;
		}
		currentDialogueEntry = subtitle.dialogueEntry;
		if ((subtitle.dialogueEntry.outgoingLinks == null || subtitle.dialogueEntry.outgoingLinks.Count == 0) && subtitle.dialogueEntry.ActorID == 0)
		{
			OnConversationEnd();
			PlayMakerFSM.BroadcastEvent("DIALOGUE_FINISHED");
		}
		if (subtitle.dialogueEntry.ActorID == -1)
		{
			string text = Field.LookupValue(subtitle.dialogueEntry.fields, "Auto Continue");
			if (text != null && text.Equals("True"))
			{
				((MonoBehaviour)this).StopCoroutine("AutoContinue");
				((MonoBehaviour)this).StartCoroutine("AutoContinue");
				return;
			}
		}
		if (dialogueUI.autoContinueAfterReponse && subtitle.speakerInfo.IsPlayer)
		{
			return;
		}
		if (subtitle.speakerInfo.IsPlayer || subtitle.speakerInfo.IsNPC)
		{
			OnAudioEnd();
			Actor actor = DialogueManager.MasterDatabase.GetActor(subtitle.dialogueEntry.ActorID);
			Actor actor2 = DialogueManager.MasterDatabase.GetActor(subtitle.dialogueEntry.ConversantID);
			string text2 = Field.LookupValue(subtitle.dialogueEntry.fields, "Auto Continue");
			string text3 = Field.LookupValue(subtitle.dialogueEntry.fields, "Shake Text");
			string text4 = Field.LookupValue(subtitle.dialogueEntry.fields, "Play Typewriter Audio");
			bool flag = true;
			bool flag2 = false;
			bool flag3 = true;
			if (text2 != null && text2.Equals("True"))
			{
				flag = false;
			}
			if (text3 != null && text3.Equals("True"))
			{
				flag2 = true;
			}
			if (text4 == null || (text4 != null && text4.Equals("True")))
			{
				flag3 = true;
				audioSourceTypewriter.volume = 1f;
			}
			else
			{
				flag3 = false;
				audioSourceTypewriter.volume = 0f;
			}
			CheckLastCharacterTalkingAnimation(subtitle.dialogueEntry, actor, actor2);
			if (subtitle.speakerInfo.IsPlayer)
			{
				lastDialogueEntryPC = subtitle.dialogueEntry;
				if (!flag3)
				{
					pcWaitingForAudio = true;
				}
				else
				{
					pcWaitingForAudio = false;
				}
				string text5 = Field.LookupValue(subtitle.dialogueEntry.fields, "Dialogue Key");
				string text6 = string.Empty;
				if (text5 != null && !string.IsNullOrEmpty(text5))
				{
					text6 = Languages.Get(text5, "DIALOGUE");
				}
				if (!string.IsNullOrEmpty(text6))
				{
					dialogueUI.dialogue.pcSubtitle.line.text = text6;
				}
				else
				{
					dialogueUI.dialogue.pcSubtitle.line.text = subtitle.dialogueEntry.DialogueText;
				}
				((Component)dialogueUI.dialogue.pcSubtitle.line).GetComponent<RectTransform>().sizeDelta = startingTextBoxSize;
				bool activeSelf = ((Component)dialogueUI.dialogue.pcSubtitle.panel).gameObject.activeSelf;
				bool activeSelf2 = ((Component)dialogueUI.dialogue.pcSubtitle.line).gameObject.activeSelf;
				((Component)dialogueUI.dialogue.pcSubtitle.panel).gameObject.SetActive(true);
				((Component)dialogueUI.dialogue.pcSubtitle.line).gameObject.SetActive(true);
				dialogueUI.dialogue.pcSubtitle.line.ForceMeshUpdate();
				Bounds textBounds = dialogueUI.dialogue.pcSubtitle.line.textBounds;
				float num = Mathf.Max(0f, textBounds.size.x + panelWidthPadding);
				Bounds textBounds2 = dialogueUI.dialogue.pcSubtitle.line.textBounds;
				float num2 = Mathf.Max(0f, textBounds2.size.y + panelHeightPadding);
				RectTransform component = ((Component)dialogueUI.dialogue.pcSubtitle.line).GetComponent<RectTransform>();
				Bounds textBounds3 = dialogueUI.dialogue.pcSubtitle.line.textBounds;
				component.sizeDelta = Vector2.op_Implicit(textBounds3.size);
				if (pcPanelSizeTween != null)
				{
					TweenExtensions.Kill((Tween)(object)pcPanelSizeTween, false);
				}
				TweenSettingsExtensions.Insert(pcPanelSizeTween, 0f, (Tween)(object)DOTween.To((DOGetter<float>)(() => pcPanelSize.width), (DOSetter<float>)((float x) =>
				{
					pcPanelSize.width = x;
				}), num, 0.1f));
				TweenSettingsExtensions.Insert(pcPanelSizeTween, 0f, (Tween)(object)DOTween.To((DOGetter<float>)(() => pcPanelSize.height), (DOSetter<float>)((float x) =>
				{
					pcPanelSize.height = x;
				}), num2, 0.1f));
				((Component)dialogueUI.dialogue.pcSubtitle.panel).gameObject.SetActive(activeSelf);
				((Component)dialogueUI.dialogue.pcSubtitle.line).gameObject.SetActive(activeSelf2);
				if (flag2 && (Object)(object)shakeTextScriptPC != (Object)null)
				{
					((Behaviour)shakeTextScriptPC).enabled = true;
				}
				else if ((Object)(object)shakeTextScriptPC != (Object)null)
				{
					((Behaviour)shakeTextScriptPC).enabled = false;
				}
				if (!flag)
				{
					((Behaviour)playerActionButton).enabled = false;
					playerContinueButton.SetActive(false);
				}
				else
				{
					playerContinueButton.SetActive(true);
					((Behaviour)playerActionButton).enabled = true;
				}
			}
			if (subtitle.speakerInfo.IsNPC)
			{
				if (!flag3)
				{
					npcWaitingForAudio = true;
				}
				else
				{
					npcWaitingForAudio = false;
				}
				lastDialogueEntryNPC = subtitle.dialogueEntry;
				string text7 = Field.LookupValue(subtitle.dialogueEntry.fields, "Dialogue Key");
				string text8 = string.Empty;
				if (text7 != null && !string.IsNullOrEmpty(text7))
				{
					text8 = Languages.Get(text7, "DIALOGUE");
				}
				if (!string.IsNullOrEmpty(text8))
				{
					dialogueUI.dialogue.npcSubtitle.line.text = text8;
				}
				else
				{
					dialogueUI.dialogue.npcSubtitle.line.text = subtitle.dialogueEntry.DialogueText;
				}
				((Component)dialogueUI.dialogue.npcSubtitle.line).GetComponent<RectTransform>().sizeDelta = startingTextBoxSize;
				bool activeSelf3 = ((Component)dialogueUI.dialogue.npcSubtitle.panel).gameObject.activeSelf;
				bool activeSelf4 = ((Component)dialogueUI.dialogue.npcSubtitle.line).gameObject.activeSelf;
				((Component)dialogueUI.dialogue.npcSubtitle.panel).gameObject.SetActive(true);
				((Component)dialogueUI.dialogue.npcSubtitle.line).gameObject.SetActive(true);
				dialogueUI.dialogue.npcSubtitle.line.ForceMeshUpdate();
				Bounds textBounds4 = dialogueUI.dialogue.npcSubtitle.line.textBounds;
				float num3 = Mathf.Max(0f, textBounds4.size.x + panelWidthPadding);
				Bounds textBounds5 = dialogueUI.dialogue.npcSubtitle.line.textBounds;
				float num4 = Mathf.Max(0f, textBounds5.size.y + panelHeightPadding);
				RectTransform component2 = ((Component)dialogueUI.dialogue.npcSubtitle.line).GetComponent<RectTransform>();
				Bounds textBounds6 = dialogueUI.dialogue.npcSubtitle.line.textBounds;
				component2.sizeDelta = Vector2.op_Implicit(textBounds6.size);
				if (npcPanelSizeTween != null)
				{
					TweenExtensions.Kill((Tween)(object)npcPanelSizeTween, false);
				}
				TweenSettingsExtensions.Insert(npcPanelSizeTween, 0f, (Tween)(object)DOTween.To((DOGetter<float>)(() => npcPanelSize.width), (DOSetter<float>)((float x) =>
				{
					npcPanelSize.width = x;
				}), num3, 0.1f));
				TweenSettingsExtensions.Insert(npcPanelSizeTween, 0f, (Tween)(object)DOTween.To((DOGetter<float>)(() => npcPanelSize.height), (DOSetter<float>)((float x) =>
				{
					npcPanelSize.height = x;
				}), num4, 0.1f));
				((Component)dialogueUI.dialogue.npcSubtitle.panel).gameObject.SetActive(activeSelf3);
				((Component)dialogueUI.dialogue.npcSubtitle.line).gameObject.SetActive(activeSelf4);
				if (flag2 && (Object)(object)shakeTextScriptNPC != (Object)null)
				{
					((Behaviour)shakeTextScriptNPC).enabled = true;
				}
				else if ((Object)(object)shakeTextScriptNPC != (Object)null)
				{
					((Behaviour)shakeTextScriptNPC).enabled = false;
				}
				if (!flag)
				{
					((Behaviour)npcActionButton).enabled = false;
					npcContinueButton.SetActive(false);
					npcContinueButtonHessonite.SetActive(false);
				}
				else
				{
					if (actor != null && ((Asset)actor).Name.Equals("Hessonite"))
					{
						npcContinueButtonHessonite.SetActive(true);
						npcContinueButton.SetActive(false);
					}
					else
					{
						npcContinueButton.SetActive(true);
						npcContinueButtonHessonite.SetActive(false);
					}
					((Behaviour)npcActionButton).enabled = true;
				}
			}
			if (actor != null && !string.IsNullOrEmpty(((Asset)actor).Name) && subtitle.dialogueEntry.ActorID >= 0)
			{
				DialogueCharacterDefinition character = dialogueCharacterDatabase.GetCharacter(((Asset)actor).Name.Replace("Call", string.Empty));
				if ((Object)(object)character != (Object)null)
				{
					if (subtitle.speakerInfo.IsPlayer)
					{
						((Graphic)playerDialogueBox).color = character.dialogueBoxColor;
						playerBGImage.texture = (Texture)(object)character.dialogueBGSprite.texture;
						((Graphic)dialogueUI.dialogue.pcSubtitle.line).color = character.characterDialogueFontColor;
						for (int num5 = 0; num5 < playerDialogueBoxTails.Length; num5++)
						{
							((Graphic)playerDialogueBoxTails[num5]).color = character.dialogueBoxColor;
						}
					}
					if (subtitle.speakerInfo.IsNPC)
					{
						if (character.useNPCSetup)
						{
							((Graphic)npcDialogueBox).color = npcGenericColor;
							npcBGImage.texture = (Texture)(object)npcGenericBGScroll;
							((Graphic)dialogueUI.dialogue.npcSubtitle.line).color = Color.black;
							for (int num6 = 0; num6 < npcDialogueBoxTails.Length; num6++)
							{
								((Graphic)npcDialogueBoxTails[num6]).color = npcGenericColor;
							}
						}
						else
						{
							((Graphic)npcDialogueBox).color = character.dialogueBoxColor;
							((Graphic)dialogueUI.dialogue.npcSubtitle.line).color = character.characterDialogueFontColor;
							if ((Object)(object)character.dialogueBGSprite != (Object)null)
							{
								npcBGImage.texture = (Texture)(object)character.dialogueBGSprite.texture;
							}
							for (int num7 = 0; num7 < npcDialogueBoxTails.Length; num7++)
							{
								((Graphic)npcDialogueBoxTails[num7]).color = character.dialogueBoxColor;
							}
						}
					}
				}
				else
				{
					((Graphic)npcDialogueBox).color = npcGenericColor;
					npcBGImage.texture = (Texture)(object)npcGenericBGScroll;
					((Graphic)dialogueUI.dialogue.npcSubtitle.line).color = Color.black;
					for (int num8 = 0; num8 < npcDialogueBoxTails.Length; num8++)
					{
						((Graphic)npcDialogueBoxTails[num8]).color = npcGenericColor;
					}
				}
				bool flag4 = false;
				for (int num9 = 0; num9 < allCharacters.Length; num9++)
				{
					if (allCharacters[num9] == null || !allCharacters[num9].actorName.Equals(((Asset)actor).Name))
					{
						continue;
					}
					flag4 = true;
					if (subtitle.speakerInfo.IsPlayer)
					{
						pcFollow.Init(allCharacters[num9]);
						lastDialogueCharacterPC = allCharacters[num9];
						if (actor2 != null && subtitle.dialogueEntry.ConversantID > -1)
						{
							IDialogueCharacter dialogueCharacterNamed = GetDialogueCharacterNamed(((Asset)actor2).Name);
							if (dialogueCharacterNamed != null && !lastDialogueCharacterPC.actorName.Equals(dialogueCharacterNamed.actorName) && lastDialogueCharacterPC is PlayerCharacter)
							{
								((PlayerCharacter)lastDialogueCharacterPC).FaceTarget(dialogueCharacterNamed.actorObject.transform);
							}
						}
						if ((Object)(object)lastDialogueCharacterPC.actorAnimator != (Object)null)
						{
							lastPCEmotion = string.Empty;
							string text9 = Field.LookupValue(subtitle.dialogueEntry.fields, "Dialogue Emotion");
							if (text9 != null && !string.IsNullOrEmpty(text9) && !text9.Equals("None"))
							{
								lastPCEmotion = text9.ToLower();
								((MonoBehaviour)this).StopCoroutine("WaitForPCIdleAnimation");
								((MonoBehaviour)this).StartCoroutine("WaitForPCIdleAnimation");
							}
						}
					}
					if (subtitle.speakerInfo.IsNPC)
					{
						lastDialogueCharacterNPC = allCharacters[num9];
						if (((Asset)actor).Name.Contains("Call"))
						{
							npcFollow.InitPhoneCall();
							((Component)phoneCallImage).gameObject.SetActive(true);
						}
						else
						{
							npcFollow.Init(lastDialogueCharacterNPC);
						}
						if ((Object)(object)lastDialogueCharacterNPC.actorAnimator != (Object)null)
						{
							if (actor2 != null && subtitle.dialogueEntry.ConversantID > -1)
							{
								IDialogueCharacter dialogueCharacterNamed2 = GetDialogueCharacterNamed(((Asset)actor2).Name);
								if (dialogueCharacterNamed2 != null && !lastDialogueCharacterNPC.actorName.Equals(dialogueCharacterNamed2.actorName))
								{
									if (lastDialogueCharacterNPC is PlayerCharacter)
									{
										((PlayerCharacter)lastDialogueCharacterNPC).FaceTarget(dialogueCharacterNamed2.actorObject.transform);
									}
									else if (lastDialogueCharacterNPC is DialogueCharacter)
									{
										((DialogueCharacter)lastDialogueCharacterNPC).FaceTarget(dialogueCharacterNamed2.actorObject.transform);
									}
								}
							}
							lastNPCEmotion = string.Empty;
							string text10 = Field.LookupValue(subtitle.dialogueEntry.fields, "Dialogue Emotion");
							if (text10 != null && !string.IsNullOrEmpty(text10) && !text10.Equals("None"))
							{
								lastNPCEmotion = text10.ToLower();
								((MonoBehaviour)this).StopCoroutine("WaitForNPCIdleAnimation");
								((MonoBehaviour)this).StartCoroutine("WaitForNPCIdleAnimation");
							}
						}
						string text11 = Field.LookupValue(subtitle.dialogueEntry.fields, "Update Sprite");
						if (text11 != null && !string.IsNullOrEmpty(text11))
						{
							lastDialogueCharacterNPC.actorObject.GetComponent<tk2dSprite>().SetSprite(text11);
						}
					}
					if (subtitle.dialogueEntry.ConversantID == subtitle.dialogueEntry.ActorID || subtitle.dialogueEntry.ConversantID <= -1)
					{
						continue;
					}
					string text12 = Field.LookupValue(subtitle.dialogueEntry.fields, "Dialogue Emotion Conversant");
					if (text12 == null || string.IsNullOrEmpty(text12))
					{
						continue;
					}
					IDialogueCharacter dialogueCharacterNamed3 = GetDialogueCharacterNamed(((Asset)actor2).Name);
					if (dialogueCharacterNamed3 != null)
					{
						string dialogueCharacterStopTalkAnimationName = GetDialogueCharacterStopTalkAnimationName(((Asset)actor2).Name, text12);
						if (!string.IsNullOrEmpty(dialogueCharacterStopTalkAnimationName) && (Object)(object)dialogueCharacterNamed3.actorAnimator != (Object)null)
						{
							PlayDialogueCharacterAnim(dialogueCharacterNamed3, dialogueCharacterStopTalkAnimationName);
						}
					}
				}
			}
			UpdateFacingDirections(subtitle);
			FadeOutSourcesPlaying();
			string text13 = Field.LookupValue(subtitle.dialogueEntry.fields, "Dialogue Audio");
			if (text13 != null && !text13.Equals("-1") && !string.IsNullOrEmpty(text13))
			{
				int uid = int.Parse(text13);
				DialogueAudioData audioData = GameController.Instance.dialogueAudioDatabase.GetAudioData(uid);
				if (audioData != null && (Object)(object)audioData.audioEvent != (Object)null)
				{
					if (waitForAudioClipEndRoutine != null)
					{
						((MonoBehaviour)this).StopCoroutine(waitForAudioClipEndRoutine);
					}
					AudioSource availableAudioSource = GetAvailableAudioSource();
					audioData.audioEvent.Play(availableAudioSource);
					if (npcWaitingForAudio || pcWaitingForAudio)
					{
						waitForAudioClipEndRoutine = ((MonoBehaviour)this).StartCoroutine(WaitForAudioClipEnd(availableAudioSource));
					}
				}
				else
				{
					npcWaitingForAudio = false;
					pcWaitingForAudio = false;
				}
			}
			else
			{
				npcWaitingForAudio = false;
				pcWaitingForAudio = false;
			}
		}
		if (subtitle.dialogueEntry.ActorID == -1 && subtitle.dialogueEntry.ConversantID == -1)
		{
			string text14 = Field.LookupValue(subtitle.dialogueEntry.fields, "Auto Continue");
			if (text14 != null && text14.Equals("True"))
			{
				((MonoBehaviour)this).StopCoroutine("AutoContinue");
				((MonoBehaviour)this).StartCoroutine("AutoContinue");
			}
		}
	}

	public void OnConversationLineEnd(Subtitle subtitle)
	{
	}

	private void UpdateFacingDirections(Subtitle subtitle)
	{
		if (subtitle == null || subtitle.dialogueEntry == null)
		{
			return;
		}
		List<DialogueCharacterFacingDefinition> facingDefinitionsForConvoEntry = dialogueCharacterDatabase.GetFacingDefinitionsForConvoEntry(subtitle.dialogueEntry.conversationID, subtitle.dialogueEntry.id);
		if (facingDefinitionsForConvoEntry == null || facingDefinitionsForConvoEntry.Count <= 0)
		{
			return;
		}
		for (int i = 0; i < facingDefinitionsForConvoEntry.Count; i++)
		{
			DialogueCharacterFacingDefinition dialogueCharacterFacingDefinition = facingDefinitionsForConvoEntry[i];
			DialogueCharacterDefinition character = dialogueCharacterDatabase.GetCharacter(dialogueCharacterFacingDefinition.dialogueCharacterUID);
			if (!((Object)(object)character != (Object)null))
			{
				continue;
			}
			if (character.characterName.Equals("AllFollowers"))
			{
				int count = GameController.Instance.party.Count;
				for (int j = 0; j < count; j++)
				{
					PlayerCharacter playerCharacter = GameController.Instance.party[j];
					if (!playerCharacter.isPartyLeader)
					{
						FaceCharacterInSceneToDirection(dialogueCharacterFacingDefinition, dialogueCharacterDatabase.GetCharacter(playerCharacter.characterName.ToString()));
					}
				}
			}
			else
			{
				FaceCharacterInSceneToDirection(dialogueCharacterFacingDefinition, character);
			}
		}
	}

	private void CheckLastCharacterTalkingAnimation(DialogueEntry nextDialogueEntry, Actor actor, Actor conversant)
	{
		if (lastDialogueCharacter == null || !(lastDialogueCharacter is BaseCharacter))
		{
			return;
		}
		bool flag = true;
		if ((actor != null && ((Asset)actor).Name.Equals(lastDialogueCharacter.actorName)) || (conversant != null && ((Asset)conversant).Name.Equals(lastDialogueCharacter.actorName)))
		{
			string text = Field.LookupValue(nextDialogueEntry.fields, "Dialogue Emotion");
			if (text != null && !string.IsNullOrEmpty(text))
			{
				flag = false;
			}
			string text2 = Field.LookupValue(nextDialogueEntry.fields, "Dialogue Emotion Conversant");
			if (text2 != null && !string.IsNullOrEmpty(text2))
			{
				flag = false;
			}
		}
		Actor actor2 = DialogueManager.MasterDatabase.GetActor(lastDialogueCharacter.actorName);
		List<DialogueCharacterFacingDefinition> facingDefinitionsForConvoEntry = dialogueCharacterDatabase.GetFacingDefinitionsForConvoEntry(nextDialogueEntry.conversationID, nextDialogueEntry.id);
		if (facingDefinitionsForConvoEntry != null && facingDefinitionsForConvoEntry.Count > 0)
		{
			for (int i = 0; i < facingDefinitionsForConvoEntry.Count; i++)
			{
				DialogueCharacterFacingDefinition dialogueCharacterFacingDefinition = facingDefinitionsForConvoEntry[i];
				if (dialogueCharacterFacingDefinition.dialogueCharacterUID == ((Asset)actor2).id && dialogueCharacterFacingDefinition.facingDir == DialogueFacing.PlayAnim)
				{
					flag = false;
					break;
				}
			}
		}
		if (flag)
		{
			((BaseCharacter)lastDialogueCharacter).PlayAnim(((BaseCharacter)lastDialogueCharacter).GetIdleAnimation());
		}
	}

	private void FaceCharacterInSceneToDirection(DialogueCharacterFacingDefinition facingDef, DialogueCharacterDefinition charDef)
	{
		IDialogueCharacter dialogueCharacterFromScene = GameController.Instance.GetDialogueCharacterFromScene(charDef.characterName);
		if (dialogueCharacterFromScene == null || !((Object)(object)charDef != (Object)null))
		{
			return;
		}
		if (facingDef.facingDir == DialogueFacing.FaceLeft)
		{
			if (dialogueCharacterFromScene is BaseCharacter)
			{
				((BaseCharacter)dialogueCharacterFromScene).SetDirections(Direction.Left, Direction.Down);
			}
			if (dialogueCharacterFromScene is DialogueCharacter)
			{
				((DialogueCharacter)dialogueCharacterFromScene).FaceDirection(Direction.Left);
			}
		}
		if (facingDef.facingDir == DialogueFacing.FaceRight)
		{
			if (dialogueCharacterFromScene is BaseCharacter)
			{
				((BaseCharacter)dialogueCharacterFromScene).SetDirections(Direction.Right, Direction.Down);
			}
			if (dialogueCharacterFromScene is DialogueCharacter)
			{
				((DialogueCharacter)dialogueCharacterFromScene).FaceDirection(Direction.Right);
			}
		}
		if (facingDef.facingDir == DialogueFacing.FaceFlip)
		{
			if (dialogueCharacterFromScene is BaseCharacter)
			{
				((BaseCharacter)dialogueCharacterFromScene).SetDirections((((BaseCharacter)dialogueCharacterFromScene).horizontalDir == Direction.Right) ? Direction.Left : Direction.Right, Direction.Down);
			}
			if (dialogueCharacterFromScene is DialogueCharacter)
			{
				((DialogueCharacter)dialogueCharacterFromScene).FaceDirection((((DialogueCharacter)dialogueCharacterFromScene).facingDir == Direction.Right) ? Direction.Left : Direction.Right);
			}
		}
		if (facingDef.facingDir == DialogueFacing.FaceCharacter)
		{
			DialogueCharacterDefinition character = dialogueCharacterDatabase.GetCharacter(facingDef.faceDialogueCharacterUID);
			if ((Object)(object)character != (Object)null)
			{
				IDialogueCharacter dialogueCharacterFromScene2 = GameController.Instance.GetDialogueCharacterFromScene(character.characterName);
				if (dialogueCharacterFromScene2 != null)
				{
					if (dialogueCharacterFromScene is BaseCharacter)
					{
						((BaseCharacter)dialogueCharacterFromScene).FaceTarget(dialogueCharacterFromScene2.actorObject.transform);
					}
					if (dialogueCharacterFromScene is DialogueCharacter)
					{
						((DialogueCharacter)dialogueCharacterFromScene).FaceTarget(dialogueCharacterFromScene2.actorObject.transform);
					}
				}
			}
		}
		if (facingDef.facingDir != DialogueFacing.PlayAnim)
		{
			return;
		}
		DialogueCharacterTalkAnimation talkAnimationAtIndex = charDef.GetTalkAnimationAtIndex(facingDef.dialogueCharacterAnimIndex);
		if (talkAnimationAtIndex != null)
		{
			string stopTalkAnimationName = talkAnimationAtIndex.stopTalkAnimationName;
			if (!string.IsNullOrEmpty(stopTalkAnimationName) && (Object)(object)dialogueCharacterFromScene.actorAnimator != (Object)null)
			{
				PlayDialogueCharacterAnim(dialogueCharacterFromScene, stopTalkAnimationName);
			}
		}
	}

	private IDialogueCharacter GetDialogueCharacterNamed(string name)
	{
		for (int i = 0; i < allCharacters.Length; i++)
		{
			if (allCharacters[i].actorName.Equals(name))
			{
				return allCharacters[i];
			}
		}
		return null;
	}

	private IEnumerator WaitForAudioClipEnd(AudioSource audioSource)
	{
		yield return (object)new WaitForEndOfFrame();
		while ((Object)(object)audioSource != (Object)null && audioSource.isPlaying && audioSource.volume > 0f && (npcWaitingForAudio || pcWaitingForAudio))
		{
			yield return null;
		}
		if ((Object)(object)audioSource != (Object)null && (Object)(object)audioSource.clip != (Object)null)
		{
			audioSource.clip.UnloadAudioData();
		}
		OnAudioEnd();
	}

	private IEnumerator WaitForPCIdleAnimation()
	{
		while (lastDialogueCharacterPC != null && (Object)(object)lastDialogueCharacterPC.actorRichAI2D != (Object)null && lastDialogueCharacterPC.actorRichAI2D.IsMovingAlongPath)
		{
			yield return null;
		}
		yield return (object)new WaitForEndOfFrame();
		if (!movementAllowed && lastDialogueCharacterPC != null && (Object)(object)lastDialogueCharacterPC.actorRichAI2D != (Object)null)
		{
			lastDialogueCharacterPC.actorRichAI2D.SetAnimationsAllowed(allowed: false);
		}
		if (lastDialogueCharacterPC != null && (Object)(object)lastDialogueCharacterPC.actorAnimator != (Object)null)
		{
			string dialogueCharacterTalkAnimationName = GetDialogueCharacterTalkAnimationName(lastDialogueCharacterPC.actorName, lastPCEmotion);
			if (!string.IsNullOrEmpty(dialogueCharacterTalkAnimationName))
			{
				PlayDialogueCharacterAnim(lastDialogueCharacterPC, dialogueCharacterTalkAnimationName);
			}
		}
	}

	private IEnumerator WaitForNPCIdleAnimation()
	{
		while (lastDialogueCharacterNPC != null && (Object)(object)lastDialogueCharacterNPC.actorRichAI2D != (Object)null && lastDialogueCharacterNPC.actorRichAI2D.IsMovingAlongPath)
		{
			yield return null;
		}
		yield return (object)new WaitForEndOfFrame();
		if (!movementAllowed && lastDialogueCharacterNPC != null && (Object)(object)lastDialogueCharacterNPC.actorRichAI2D != (Object)null)
		{
			lastDialogueCharacterNPC.actorRichAI2D.SetAnimationsAllowed(allowed: false);
		}
		if (lastDialogueCharacterNPC != null && (Object)(object)lastDialogueCharacterNPC.actorAnimator != (Object)null)
		{
			string dialogueCharacterTalkAnimationName = GetDialogueCharacterTalkAnimationName(lastDialogueCharacterNPC.actorName, lastNPCEmotion);
			if (!string.IsNullOrEmpty(dialogueCharacterTalkAnimationName))
			{
				PlayDialogueCharacterAnim(lastDialogueCharacterNPC, dialogueCharacterTalkAnimationName);
			}
		}
	}

	private string GetDialogueCharacterTalkAnimationName(string characterName, string emotionName)
	{
		DialogueCharacterDefinition character = dialogueCharacterDatabase.GetCharacter(characterName);
		if ((Object)(object)character != (Object)null)
		{
			DialogueCharacterTalkAnimation talkAnimationNamed = character.GetTalkAnimationNamed(emotionName);
			if (talkAnimationNamed != null)
			{
				return talkAnimationNamed.talkAnimationName;
			}
			return string.Empty;
		}
		return string.Empty;
	}

	private string GetDialogueCharacterStopTalkAnimationName(string characterName, string emotionName)
	{
		DialogueCharacterDefinition character = dialogueCharacterDatabase.GetCharacter(characterName);
		if ((Object)(object)character != (Object)null)
		{
			DialogueCharacterTalkAnimation talkAnimationNamed = character.GetTalkAnimationNamed(emotionName);
			if (talkAnimationNamed != null)
			{
				return talkAnimationNamed.stopTalkAnimationName;
			}
			return string.Empty;
		}
		return string.Empty;
	}

	private void PlayDialogueCharacterAnim(IDialogueCharacter dialogueCharacter, string animationName, bool clearQueue = false)
	{
		if (dialogueCharacter == null)
		{
			Debug.LogError((object)"Non-critical error: PlayDialogueCharacterAnim called with a NULL dialogue character!");
		}
		else if ((Object)(object)dialogueCharacter.actorCharacterAnimator != (Object)null)
		{
			dialogueCharacter.actorCharacterAnimator.Play(new CharacterAnimationNamePair(animationName, string.Empty), clearQueue);
		}
		else if ((Object)(object)dialogueCharacter.actorAnimator != (Object)null)
		{
			dialogueCharacter.actorAnimator.Play(animationName, clearQueue);
		}
	}

	private void PlayDialogueCharacterAnim(IDialogueCharacter dialogueCharacter, CharacterAnimationNamePair animation, bool clearQueue = false)
	{
		if (dialogueCharacter == null)
		{
			Debug.LogError((object)"Non-critical error: PlayDialogueCharacterAnim called with a NULL dialogue character!");
		}
		else if ((Object)(object)dialogueCharacter.actorCharacterAnimator != (Object)null)
		{
			dialogueCharacter.actorCharacterAnimator.Play(animation, clearQueue);
		}
		else if ((Object)(object)dialogueCharacter.actorAnimator != (Object)null && !string.IsNullOrEmpty(animation.frontName))
		{
			dialogueCharacter.actorAnimator.Play(animation.frontName, clearQueue);
		}
	}
}
