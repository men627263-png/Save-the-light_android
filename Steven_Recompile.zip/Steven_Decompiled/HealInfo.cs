using System;
using UnityEngine;

[Serializable]
public class HealInfo
{
	public enum ValueType
	{
		FlatAmount,
		PercentOfMaxHealth,
		PercentOfCurrentHealth,
		FillToMax
	}

	[SerializeField]
	private ValueType _type;

	[SerializeField]
	private int _intValue;

	[SerializeField]
	private float _floatValue;

	[SerializeField]
	private bool _canBeLucky;

	[SerializeField]
	private bool _canOverheal;

	[SerializeField]
	[Range(0f, 1f)]
	private float _overhealPercentageAllowed;

	[SerializeField]
	private StatusEffectInfo _statusEffectInfo;

	public ValueType type => _type;

	public int intValue => _intValue;

	public float floatValue => _floatValue;

	public bool canBeLucky
	{
		get
		{
			return _canBeLucky;
		}
		set
		{
			_canBeLucky = value;
		}
	}

	public bool canOverheal
	{
		get
		{
			return _canOverheal;
		}
		set
		{
			_canOverheal = value;
		}
	}

	public float overhealPercentageAllowed
	{
		get
		{
			return _overhealPercentageAllowed;
		}
		set
		{
			_overhealPercentageAllowed = value;
		}
	}

	public StatusEffectInfo statusEffectInfo => _statusEffectInfo;

	public int flatHealAmount => _intValue;

	public float healPercent => _floatValue;

	public HealInfo()
	{
	}

	public HealInfo(ValueType type, float healValue, bool canBeLucky = false, bool canOverheal = false, float overhealPercentageAllowed = 0f)
	{
		_type = type;
		switch (type)
		{
		case ValueType.PercentOfMaxHealth:
		case ValueType.PercentOfCurrentHealth:
			_floatValue = healValue;
			break;
		default:
			_intValue = Mathf.RoundToInt(healValue);
			break;
		}
		_canBeLucky = canBeLucky;
		_canOverheal = canOverheal;
		_overhealPercentageAllowed = overhealPercentageAllowed;
	}

	public HealInfo(ValueType type, int intValue, float floatValue, bool canBeLucky, bool canOverheal, float overhealPercentageAllowed = 0f)
	{
		_type = type;
		_intValue = intValue;
		_floatValue = floatValue;
		_canBeLucky = canBeLucky;
		_canOverheal = canOverheal;
		_overhealPercentageAllowed = overhealPercentageAllowed;
	}

	public HealInfo(HealInfo other)
	{
		_type = other.type;
		_intValue = other.intValue;
		_floatValue = other.floatValue;
		_canBeLucky = other.canBeLucky;
		_canOverheal = other.canOverheal;
		_overhealPercentageAllowed = other.overhealPercentageAllowed;
		_statusEffectInfo = other.statusEffectInfo;
	}

	public void ModifyValue(float value)
	{
		switch (_type)
		{
		case ValueType.PercentOfMaxHealth:
		case ValueType.PercentOfCurrentHealth:
			_floatValue += value;
			break;
		case ValueType.FlatAmount:
			_intValue += Mathf.RoundToInt(value);
			break;
		}
	}
}
