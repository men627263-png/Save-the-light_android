using UnityEngine;

public class CameraPathColours
{
	public static Color RED = new Color(0.6f, 0f, 0f);

	public static Color GREEN = new Color(0f, 0.5f, 0f);

	public static Color DARKGREEN = new Color(0f, 0.2f, 0f);

	public static Color BLUE = new Color(0f, 0f, 0.6f);

	public static Color GREY = new Color(0.6f, 0.6f, 0.6f);

	public static Color DARKGREY = new Color(0.2f, 0.2f, 0.2f);

	public static Color CYAN = new Color(0f, 0.3f, 0.8f);

	public static Color PURPLE = new Color(0.5f, 0.1f, 0.5f);

	public static Color MAGENTA = new Color(0.8f, 0.1f, 0.8f);

	public static Color WHITE = new Color(1f, 1f, 1f);

	static CameraPathColours()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
	}
}
