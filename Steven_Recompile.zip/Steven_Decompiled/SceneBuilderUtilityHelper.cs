using UnityEngine;

public class SceneBuilderUtilityHelper : MonoBehaviour
{
	private GameObject activeObject;

	private SceneBuilderUtility settings;

	private GameObject[] activeObjects;

	private bool drawChildrenColliders;

	public void DrawActiveObject(GameObject currentObject, SceneBuilderUtility currentSettings)
	{
		activeObject = currentObject;
		settings = currentSettings;
	}

	public void DrawActiveObjects(GameObject[] currentObjects, SceneBuilderUtility currentSettings)
	{
		activeObjects = currentObjects;
		settings = currentSettings;
	}

	private void DrawCollider(Collider collider)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Expected Obj, but got Unknown
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Expected Obj, but got Unknown
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Expected Obj, but got Unknown
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		Gizmos.matrix = ((Component)collider).transform.localToWorldMatrix;
		if (collider is BoxCollider)
		{
			BoxCollider val = (BoxCollider)collider;
			Gizmos.color = settings.selectedColliderColor;
			Gizmos.DrawCube(val.center, val.size);
			Gizmos.color = settings.selectedColliderWireframeColor;
			Gizmos.DrawWireCube(val.center, val.size);
		}
		else if (collider is SphereCollider)
		{
			SphereCollider val2 = (SphereCollider)collider;
			Gizmos.color = settings.selectedColliderColor;
			Gizmos.DrawSphere(val2.center, val2.radius);
			Gizmos.color = settings.selectedColliderWireframeColor;
			Gizmos.DrawWireSphere(val2.center, val2.radius);
		}
		else if (collider is MeshCollider)
		{
			MeshCollider val3 = (MeshCollider)collider;
			Gizmos.color = settings.selectedColliderColor;
			Gizmos.DrawMesh(val3.sharedMesh);
			Gizmos.color = settings.selectedColliderWireframeColor;
			Gizmos.DrawWireMesh(val3.sharedMesh);
		}
		Gizmos.color = Color.white;
		Gizmos.matrix = Matrix4x4.identity;
	}

	private void OnDrawGizmos()
	{
		if ((Object)(object)settings == (Object)null || activeObjects == null || activeObjects.Length <= 0)
		{
			return;
		}
		for (int i = 0; i < activeObjects.Length; i++)
		{
			if (!((Object)(object)activeObjects[i] != (Object)null))
			{
				continue;
			}
			if (settings.drawChildrenColliders)
			{
				Collider[] componentsInChildren = activeObjects[i].GetComponentsInChildren<Collider>();
				if (componentsInChildren != null)
				{
					for (int j = 0; j < componentsInChildren.Length; j++)
					{
						DrawCollider(componentsInChildren[j]);
					}
				}
				continue;
			}
			Collider[] components = activeObjects[i].GetComponents<Collider>();
			if (components != null)
			{
				for (int k = 0; k < components.Length; k++)
				{
					DrawCollider(components[k]);
				}
			}
		}
	}
}
