using UnityEngine;

public class GamePlayEventTrigger : MonoBehaviour
{
	public int gameEventUID;

	public GamePlayEventState activateState;

	private bool hasActivated;

	private void OnTriggerEnter(Collider other)
	{
		if (!hasActivated && (Object)(object)GameController.Instance != (Object)null && (Object)(object)((Component)other).gameObject == (Object)(object)((Component)GameController.Instance.partyLeader).gameObject)
		{
			PlayerGameState.Instance.TriggerGamePlayEvent(gameEventUID, activateState);
			hasActivated = true;
		}
	}
}
