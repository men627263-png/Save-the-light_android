using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Brains/Bosses/Hessonite")]
public class HessoniteBrain : BattleBrain
{
	public override Decision MakeDecision(BaseCharacter caster, List<BaseCharacter> playerParty, List<BaseCharacter> enemyParty, List<ITargetable> playerMinions, List<ITargetable> enemyMinions, List<ITargetable> neutralTargets)
	{
		BaseAbility chosenAbility = null;
		List<ITargetable> targets = null;
		bool moveToTargets = false;
		List<AbilityEntry> list = new List<AbilityEntry>();
		for (int i = 0; i < abilities.Length; i++)
		{
			if (abilities[i].weight > 0)
			{
				list.Add(abilities[i]);
			}
		}
		while ((Object)(object)chosenAbility == (Object)null && list.Count > 0)
		{
			chosenAbility = GetRandomAbilityWeighted(list);
		}
		if ((Object)(object)chosenAbility != (Object)null)
		{
			targets = GetTargets(caster, chosenAbility, playerParty, enemyParty, playerMinions, enemyMinions, neutralTargets);
			moveToTargets = list.Find((AbilityEntry x) => (Object)(object)x.ability == (Object)(object)chosenAbility).moveToTargets;
		}
		return new Decision(chosenAbility, targets, moveToTargets);
	}
}
