using System;
using System.Collections;
using System.Collections.Generic;
using Pathfinding;
using Pathfinding.RVO;
using UnityEngine;

public class AIPath2D : MonoBehaviour
{
	public Transform target;

	public CharacterNavLinkGrid navLinkPrefab;

	public float repathRate = 0.5f;

	public bool canSearch = true;

	public bool canMove = true;

	public float maxSpeed = 3f;

	public float turningSpeed = 5f;

	public float slowdownDistance = 0.6f;

	public float pickNextWaypointDist = 2f;

	public float forwardLook = 1f;

	public float endReachedDistance = 0.2f;

	public bool closestOnPathCheck = true;

	protected float minMoveScale = 0.05f;

	protected Seeker seeker;

	protected Transform tr;

	protected float lastRepath = -9999f;

	protected Path path;

	protected CharacterController controller;

	protected RVOController rvoController;

	protected Rigidbody rigid;

	protected int currentWaypointIndex;

	protected bool targetReached;

	protected bool canSearchAgain = true;

	protected Vector3 lastFoundWaypointPosition;

	protected float lastFoundWaypointTime = -9999f;

	private bool startHasRun;

	private List<Vector3> pathNodes = new List<Vector3>();

	protected Vector3 targetPoint;

	protected Vector3 targetDirection;

	private bool jumpPathCreationActive;

	public bool TargetReached => targetReached;

	protected virtual void Awake()
	{
		seeker = ((Component)this).GetComponent<Seeker>();
		tr = ((Component)this).transform;
		controller = ((Component)this).GetComponent<CharacterController>();
		rvoController = ((Component)this).GetComponent<RVOController>();
		if ((Object)(object)rvoController != (Object)null)
		{
			rvoController.enableRotation = false;
		}
		rigid = ((Component)this).GetComponent<Rigidbody>();
	}

	protected virtual void Start()
	{
		startHasRun = true;
		OnEnable();
	}

	protected virtual void OnEnable()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		lastRepath = -9999f;
		canSearchAgain = true;
		lastFoundWaypointPosition = GetFeetPosition();
		if (startHasRun)
		{
			Seeker seeker = this.seeker;
			seeker.pathCallback = (OnPathDelegate)Delegate.Combine(seeker.pathCallback, new OnPathDelegate(OnPathComplete));
			Seeker seeker2 = this.seeker;
			seeker2.postProcessPath = (OnPathDelegate)Delegate.Combine(seeker2.postProcessPath, new OnPathDelegate(OnPostProcessPath));
			((MonoBehaviour)this).StartCoroutine(RepeatTrySearchPath());
		}
	}

	public void OnDisable()
	{
		if ((Object)(object)this.seeker != (Object)null && !this.seeker.IsDone())
		{
			this.seeker.GetCurrentPath().Error();
		}
		if (path != null)
		{
			path.Release(this);
		}
		path = null;
		Seeker seeker = this.seeker;
		seeker.pathCallback = (OnPathDelegate)Delegate.Remove(seeker.pathCallback, new OnPathDelegate(OnPathComplete));
		Seeker seeker2 = this.seeker;
		seeker2.postProcessPath = (OnPathDelegate)Delegate.Remove(seeker2.postProcessPath, new OnPathDelegate(OnPostProcessPath));
	}

	protected IEnumerator RepeatTrySearchPath()
	{
		while (true)
		{
			float v = TrySearchPath();
			yield return (object)new WaitForSeconds(v);
		}
	}

	public float TrySearchPath()
	{
		if (Time.time - lastRepath >= repathRate && canSearchAgain && canSearch && (Object)(object)target != (Object)null)
		{
			SearchPath();
			return repathRate;
		}
		float num = repathRate - (Time.time - lastRepath);
		return (!(num < 0f)) ? num : 0f;
	}

	public virtual void SearchPath()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)target == (Object)null)
		{
			throw new InvalidOperationException("Target is null");
		}
		lastRepath = Time.time;
		Vector3 position = target.position;
		canSearchAgain = false;
		seeker.StartPath(GetFeetPosition(), position);
	}

	public virtual void OnTargetReached()
	{
	}

	private void OnPostProcessPath(Path p)
	{
		if (!jumpPathCreationActive)
		{
			((MonoBehaviour)this).StartCoroutine(CreateConnectionsToTarget(p));
		}
	}

	public virtual void OnPathComplete(Path _p)
	{
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		if (!(_p is ABPath aBPath))
		{
			throw new Exception("This function only handles ABPaths, do not use special path types");
		}
		canSearchAgain = true;
		aBPath.Claim(this);
		if (aBPath.error)
		{
			aBPath.Release(this);
			return;
		}
		if (path != null)
		{
			path.Release(this);
		}
		path = aBPath;
		pathNodes = path.vectorPath;
		currentWaypointIndex = 0;
		targetReached = false;
		if (closestOnPathCheck)
		{
			Vector3 val = ((!(Time.time - lastFoundWaypointTime < 0.3f)) ? aBPath.originalStartPoint : lastFoundWaypointPosition);
			Vector3 feetPosition = GetFeetPosition();
			Vector3 val2 = feetPosition - val;
			float magnitude = val2.magnitude;
			val2 /= magnitude;
			int num = (int)(magnitude / pickNextWaypointDist);
			for (int i = 0; i <= num; i++)
			{
				CalculateVelocity(val);
				val += val2;
			}
		}
	}

	public virtual Vector3 GetFeetPosition()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)rvoController != (Object)null)
		{
			return tr.position - Vector3.up * rvoController.height * 0.5f;
		}
		if ((Object)(object)controller != (Object)null)
		{
			return tr.position - Vector3.up * controller.height * 0.5f;
		}
		return tr.position;
	}

	public virtual void Update()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		if (canMove)
		{
			Vector3 val = CalculateVelocity(GetFeetPosition());
			if ((Object)(object)rvoController != (Object)null)
			{
				rvoController.Move(val);
			}
			else if ((Object)(object)controller != (Object)null)
			{
				controller.SimpleMove(val);
			}
			else if ((Object)(object)rigid != (Object)null)
			{
				rigid.AddForce(val);
			}
			else
			{
				tr.Translate(val * Time.deltaTime, (Space)0);
			}
		}
	}

	protected float XZSqrMagnitude(Vector3 a, Vector3 b)
	{
		float num = b.x - a.x;
		float num2 = b.z - a.z;
		return num * num + num2 * num2;
	}

	protected Vector3 CalculateVelocity(Vector3 currentPosition)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		if (path == null || path.vectorPath == null || path.vectorPath.Count == 0)
		{
			return Vector3.zero;
		}
		List<Vector3> vectorPath = path.vectorPath;
		if (vectorPath.Count == 1)
		{
			vectorPath.Insert(0, currentPosition);
		}
		if (currentWaypointIndex >= vectorPath.Count)
		{
			currentWaypointIndex = vectorPath.Count - 1;
		}
		if (currentWaypointIndex <= 1)
		{
			currentWaypointIndex = 1;
		}
		while (currentWaypointIndex < vectorPath.Count - 1)
		{
			float num = XZSqrMagnitude(vectorPath[currentWaypointIndex], currentPosition);
			if (num < pickNextWaypointDist * pickNextWaypointDist)
			{
				lastFoundWaypointPosition = currentPosition;
				lastFoundWaypointTime = Time.time;
				currentWaypointIndex++;
				continue;
			}
			break;
		}
		Vector3 val = vectorPath[currentWaypointIndex] - vectorPath[currentWaypointIndex - 1];
		Vector3 val2 = CalculateTargetPoint(currentPosition, vectorPath[currentWaypointIndex - 1], vectorPath[currentWaypointIndex]);
		val = val2 - currentPosition;
		val.y = 0f;
		float magnitude = val.magnitude;
		float num2 = Mathf.Clamp01(magnitude / slowdownDistance);
		targetDirection = val;
		targetPoint = val2;
		if (currentWaypointIndex == vectorPath.Count - 1 && magnitude <= endReachedDistance)
		{
			if (!targetReached)
			{
				targetReached = true;
				OnTargetReached();
			}
			return Vector3.zero;
		}
		Vector3 one = Vector3.one;
		Vector3 normalized = one.normalized;
		float num3 = Vector3.Dot(val.normalized, normalized);
		float num4 = maxSpeed * Mathf.Max(num3, minMoveScale) * num2;
		if (Time.deltaTime > 0f)
		{
			num4 = Mathf.Clamp(num4, 0f, magnitude / (Time.deltaTime * 2f));
		}
		return val.normalized * (maxSpeed * num2);
	}

	protected virtual void RotateTowards(Vector3 dir)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		if (!(dir == Vector3.zero))
		{
			Quaternion val = tr.rotation;
			Quaternion val2 = Quaternion.LookRotation(dir);
			val = Quaternion.Slerp(val, val2, turningSpeed * Time.deltaTime);
			Vector3 eulerAngles = val.eulerAngles;
			eulerAngles.z = 0f;
			eulerAngles.x = 0f;
			val = Quaternion.Euler(eulerAngles);
			tr.rotation = val;
		}
	}

	protected Vector3 CalculateTargetPoint(Vector3 p, Vector3 a, Vector3 b)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		a.y = p.y;
		b.y = p.y;
		Vector3 val = a - b;
		float magnitude = val.magnitude;
		if (magnitude == 0f)
		{
			return a;
		}
		float num = Mathf.Clamp01(VectorMath.ClosestPointOnLineFactor(a, b, p));
		Vector3 val2 = (b - a) * num + a;
		Vector3 val3 = val2 - p;
		float magnitude2 = val3.magnitude;
		float num2 = Mathf.Clamp(forwardLook - magnitude2, 0f, forwardLook);
		float num3 = num2 / magnitude;
		num3 = Mathf.Clamp(num3 + num, 0f, 1f);
		return (b - a) * num3 + a;
	}

	private IEnumerator CreateConnectionsToTarget(Path p)
	{
		if (p == null || p.vectorPath == null || p.vectorPath.Count == 0)
		{
			yield break;
		}
		jumpPathCreationActive = true;
		CharacterController targetController = ((Component)target).GetComponent<CharacterController>();
		while (!targetController.isGrounded)
		{
			yield return null;
		}
		Debug.Log((object)"Creating Jump Path");
		Vector3 startPos = p.vectorPath[p.vectorPath.Count - 1];
		Vector3 endPos = Vector3.zero;
		float distToTargetPos = Vector3.Distance(startPos, target.position);
		if (distToTargetPos > 1f)
		{
			GraphNode closestNode = AstarPath.active.GetNearest(target.position).node;
			if (closestNode.Walkable)
			{
				ABPath abPath = ABPath.Construct((Vector3)closestNode.position, startPos);
				AstarPath.StartPath(abPath);
				yield return ((MonoBehaviour)this).StartCoroutine(abPath.WaitForPath());
				endPos = abPath.endPoint;
				CharacterNavLinkGrid navLink = Object.Instantiate<CharacterNavLinkGrid>(navLinkPrefab);
				navLink.InitLink(path.vectorPath[path.vectorPath.Count - 2], endPos);
			}
		}
	}
}
