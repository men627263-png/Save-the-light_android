using System;
using UnityEngine;

public class CharacterAnimatorTk2d : CharacterAnimator
{
	[SerializeField]
	private tk2dSpriteAnimator animatorTk2d;

	public override bool Playing => animatorTk2d.Playing;

	private void OnEnable()
	{
		tk2dSpriteAnimator tk2dSpriteAnimator2 = animatorTk2d;
		tk2dSpriteAnimator2.AnimationCompleted = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>)Delegate.Combine(tk2dSpriteAnimator2.AnimationCompleted, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>(HandleAnimationCompleted));
	}

	private void OnDisable()
	{
		tk2dSpriteAnimator tk2dSpriteAnimator2 = animatorTk2d;
		tk2dSpriteAnimator2.AnimationCompleted = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>)Delegate.Remove(tk2dSpriteAnimator2.AnimationCompleted, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip>(HandleAnimationCompleted));
	}

	private void HandleAnimationCompleted(tk2dSpriteAnimator animator, tk2dSpriteAnimationClip clip)
	{
		CheckQueue();
	}

	protected override void _Play(CharacterAnimationNamePair anim, bool clearQueue)
	{
		animatorTk2d.Play(GetFacingAnimation(anim));
	}

	protected override void _PlayFrom(CharacterAnimationNamePair anim, float clipStartTime, bool clearQueue)
	{
		animatorTk2d.PlayFrom(GetFacingAnimation(anim), clipStartTime);
	}

	protected override void _PlayFromFrame(CharacterAnimationNamePair anim, int frame, bool clearQueue)
	{
		animatorTk2d.PlayFromFrame(GetFacingAnimation(anim), frame);
	}

	public override void Pause()
	{
		animatorTk2d.Pause();
	}

	public override void Resume()
	{
		animatorTk2d.Resume();
	}

	private string GetFacingAnimation(CharacterAnimationNamePair animPair)
	{
		return animPair.FrontName;
	}
}
