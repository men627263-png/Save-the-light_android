using System;

[Serializable]
public class KudosVOClip
{
	public DelayedAudioEvent audioEvent;

	public bool isCharacterSpecific;

	public CharacterName targetCharacter;
}
