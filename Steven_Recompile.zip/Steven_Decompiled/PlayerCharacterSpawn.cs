using Grumpyface;
using UnityEngine;

[RequireComponent(typeof(SphereCollider))]
public class PlayerCharacterSpawn : MonoBehaviour
{
	public CharacterName characterName;

	public SphereCollider sphereCollider;

	public bool enableWhenNotInParty = true;

	private int characterUID;

	private bool hasJoined;

	private PlayerCharacter tempCharacter;

	private void Start()
	{
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)sphereCollider == (Object)null)
		{
			sphereCollider = ((Component)this).GetComponent<SphereCollider>();
		}
		if (!GameController.startAtWarpPad)
		{
			characterUID = GameController.Instance.characterDatabase.GetCharacter(characterName.ToString()).uid;
			if (GameController.Instance.GetDialogueCharacterFromScene(characterName.ToString()) == null)
			{
				PlayerCharacter objectFromResource = ObjectPool.GetObjectFromResource<PlayerCharacter>(characterName.ToString(), ((Component)this).transform.position, true);
				objectFromResource.ignoreInput = true;
				objectFromResource.PlayAnim(objectFromResource.GetIdleAnimation());
				PlayerGameState.Instance.PlayerDataChanged += HandlePlayerActivePartyChanged;
				PlayerGameState.Instance.PlayerActivePartyChanged += HandlePlayerActivePartyChanged;
				HandlePlayerActivePartyChanged();
			}
		}
	}

	private void OnDestroy()
	{
		PlayerGameState.Instance.PlayerActivePartyChanged -= HandlePlayerActivePartyChanged;
		PlayerGameState.Instance.PlayerDataChanged -= HandlePlayerActivePartyChanged;
	}

	private void OnTriggerEnter(Collider other)
	{
		if (!hasJoined && ((Component)other).tag == "Player")
		{
			tempCharacter = ((Component)other).GetComponent<PlayerCharacter>();
			if ((Object)(object)tempCharacter != (Object)null && (Object)(object)tempCharacter == (Object)(object)GameController.Instance.partyLeader)
			{
				PlayerGameState.Instance.AddCharacterToParty(characterUID);
			}
		}
	}

	private void HandlePlayerActivePartyChanged()
	{
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		if (PlayerGameState.Instance.PlayerData == null)
		{
			return;
		}
		bool flag = PlayerGameState.Instance.HasCharacterInActiveParty(characterUID);
		if (flag != hasJoined)
		{
			hasJoined = flag;
			if (hasJoined)
			{
				Debug.Log((object)"Character is in party");
				((Collider)sphereCollider).enabled = false;
			}
			else if (enableWhenNotInParty)
			{
				Debug.Log((object)"Character is no longer in party");
				PlayerCharacter objectFromResource = ObjectPool.GetObjectFromResource<PlayerCharacter>(characterName.ToString(), ((Component)this).transform.position, true);
				objectFromResource.ignoreInput = true;
				((Collider)sphereCollider).enabled = true;
			}
		}
	}
}
