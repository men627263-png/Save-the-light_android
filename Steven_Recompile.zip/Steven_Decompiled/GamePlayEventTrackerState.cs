using System;

[Serializable]
public class GamePlayEventTrackerState
{
	public int eventUID;

	public int activeCount;

	public GamePlayEventState eventState;

	public GamePlayEventTrackerResult eventResult;

	public GamePlayEventTrackerCondition eventCondition;
}
