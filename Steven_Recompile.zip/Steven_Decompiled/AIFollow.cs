using System;
using System.Collections;
using Pathfinding;
using UnityEngine;

[RequireComponent(typeof(Seeker))]
[RequireComponent(typeof(CharacterController))]
[AddComponentMenu("Pathfinding/AI/AIFollow (deprecated)")]
[HelpURL("http://arongranberg.com/astar/docs/class_a_i_follow.php")]
public class AIFollow : MonoBehaviour
{
	public Transform target;

	public float repathRate = 0.1f;

	public float pickNextWaypointDistance = 1f;

	public float targetReached = 0.2f;

	public float speed = 5f;

	public float rotationSpeed = 1f;

	public bool drawGizmos;

	public bool canSearch = true;

	public bool canMove = true;

	protected Seeker seeker;

	protected CharacterController controller;

	protected Transform tr;

	protected float lastPathSearch = -9999f;

	protected int pathIndex;

	protected Vector3[] path;

	public void Start()
	{
		seeker = ((Component)this).GetComponent<Seeker>();
		controller = ((Component)this).GetComponent<CharacterController>();
		tr = ((Component)this).transform;
		Repath();
	}

	public void Reset()
	{
		path = null;
	}

	public void OnPathComplete(Path p)
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		((MonoBehaviour)this).StartCoroutine(WaitToRepath());
		if (p.error)
		{
			return;
		}
		path = p.vectorPath.ToArray();
		float num = float.PositiveInfinity;
		int num2 = 0;
		for (int i = 0; i < path.Length - 1; i++)
		{
			float num3 = VectorMath.SqrDistancePointSegment(path[i], path[i + 1], tr.position);
			if (num3 < num)
			{
				num2 = 0;
				num = num3;
				pathIndex = i + 1;
			}
			else if (num2 > 6)
			{
				break;
			}
		}
	}

	public IEnumerator WaitToRepath()
	{
		float timeLeft = repathRate - (Time.time - lastPathSearch);
		yield return (object)new WaitForSeconds(timeLeft);
		Repath();
	}

	public void Stop()
	{
		canMove = false;
		canSearch = false;
	}

	public void Resume()
	{
		canMove = true;
		canSearch = true;
	}

	public virtual void Repath()
	{
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		lastPathSearch = Time.time;
		if ((Object)(object)seeker == (Object)null || (Object)(object)target == (Object)null || !canSearch || !seeker.IsDone())
		{
			((MonoBehaviour)this).StartCoroutine(WaitToRepath());
			return;
		}
		Path p = ABPath.Construct(((Component)this).transform.position, target.position);
		seeker.StartPath(p, OnPathComplete);
	}

	public void PathToTarget(Vector3 targetPoint)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		lastPathSearch = Time.time;
		if (!((Object)(object)seeker == (Object)null))
		{
			seeker.StartPath(((Component)this).transform.position, targetPoint, OnPathComplete);
		}
	}

	public virtual void ReachedEndOfPath()
	{
	}

	public void Update()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		if (path == null || pathIndex >= path.Length || pathIndex < 0 || !canMove)
		{
			return;
		}
		Vector3 val = path[pathIndex];
		val.y = tr.position.y;
		while (true)
		{
			Vector3 val2 = val - tr.position;
			if (!(val2.sqrMagnitude < pickNextWaypointDistance * pickNextWaypointDistance))
			{
				break;
			}
			pathIndex++;
			if (pathIndex >= path.Length)
			{
				Vector3 val3 = val - tr.position;
				if (val3.sqrMagnitude < pickNextWaypointDistance * targetReached * (pickNextWaypointDistance * targetReached))
				{
					ReachedEndOfPath();
					return;
				}
				pathIndex--;
				break;
			}
			val = path[pathIndex];
			val.y = tr.position.y;
		}
		Vector3 val4 = val - tr.position;
		tr.rotation = Quaternion.Slerp(tr.rotation, Quaternion.LookRotation(val4), rotationSpeed * Time.deltaTime);
		tr.eulerAngles = new Vector3(0f, tr.eulerAngles.y, 0f);
		Vector3 forward = ((Component)this).transform.forward;
		forward *= speed;
		forward *= Mathf.Clamp01(Vector3.Dot(val4.normalized, tr.forward));
		if ((Object)(object)controller != (Object)null)
		{
			controller.SimpleMove(forward);
		}
		else
		{
			((Component)this).transform.Translate(forward * Time.deltaTime, (Space)0);
		}
	}

	public void OnDrawGizmos()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		if (drawGizmos && path != null && pathIndex < path.Length && pathIndex >= 0)
		{
			Vector3 val = path[pathIndex];
			val.y = tr.position.y;
			Debug.DrawLine(((Component)this).transform.position, val, Color.blue);
			float num = pickNextWaypointDistance;
			if (pathIndex == path.Length - 1)
			{
				num *= targetReached;
			}
			Vector3 val2 = val + num * new Vector3(1f, 0f, 0f);
			for (float num2 = 0f; (double)num2 < Math.PI * 2.0; num2 += 0.1f)
			{
				Vector3 val3 = val + new Vector3((float)Math.Cos(num2) * num, 0f, (float)Math.Sin(num2) * num);
				Debug.DrawLine(val2, val3, Color.yellow);
				val2 = val3;
			}
			Debug.DrawLine(val2, val + num * new Vector3(1f, 0f, 0f), Color.yellow);
		}
	}
}
