using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Actor/Player/Simple Controller")]
[RequireComponent(typeof(CharacterController))]
public class SimpleController : MonoBehaviour
{
	public AnimationClip idle;

	public AnimationClip runForward;

	public AnimationClip runBack;

	public AnimationClip aim;

	public AnimationClip fire;

	public Transform upperBodyMixingTransform;

	public float runSpeed = 5f;

	public float mouseSensitivityX = 15f;

	public float mouseSensitivityY = 10f;

	public float mouseMinimumY = -60f;

	public float mouseMaximumY = 60f;

	public LayerMask fireLayerMask = LayerMask.op_Implicit(1);

	public AudioClip fireSound;

	public float weaponDamage = 100f;

	private CharacterController controller;

	private SmoothCameraWithBumper smoothCamera;

	private AudioSource audioSource;

	private Animation anim;

	private float centralSpeed;

	private float centralVelocity;

	private float lateralSpeed;

	private float lateralVelocity;

	private float cameraRotationY;

	private Quaternion originalCameraRotation;

	private bool firing;

	private bool fired;

	private float endFiringTime;

	public SimpleController()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Awake()
	{
		controller = ((Component)this).GetComponent<CharacterController>();
		smoothCamera = ((Component)this).GetComponentInChildren<SmoothCameraWithBumper>();
		audioSource = ((Component)this).GetComponentInChildren<AudioSource>();
		anim = ((Component)this).GetComponent<Animation>();
	}

	private void Start()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		originalCameraRotation = ((Component)Camera.main).transform.localRotation;
		anim.AddClip((!((Object)(object)aim != (Object)null)) ? idle : aim, "aim");
		anim["aim"].layer = 1;
		anim["aim"].AddMixingTransform(upperBodyMixingTransform);
		anim[((Object)fire).name].layer = 1;
		anim[((Object)fire).name].AddMixingTransform(upperBodyMixingTransform);
	}

	private void Update()
	{
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_032a: Unknown result type (might be due to invalid IL or missing references)
		//IL_032f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0334: Unknown result type (might be due to invalid IL or missing references)
		if (Time.timeScale <= 0f)
		{
			return;
		}
		((Component)this).transform.Rotate(0f, Input.GetAxis("Mouse X") * mouseSensitivityX, 0f);
		cameraRotationY += Input.GetAxis("Mouse Y") * mouseSensitivityY;
		cameraRotationY = ClampAngle(cameraRotationY, mouseMinimumY, mouseMaximumY);
		Quaternion val = Quaternion.AngleAxis(cameraRotationY, -Vector3.right);
		if ((Object)(object)smoothCamera != (Object)null)
		{
			smoothCamera.adjustQuaternion = val;
		}
		else
		{
			((Component)Camera.main).transform.localRotation = originalCameraRotation * val;
		}
		if ((Object)(object)fire != (Object)null && Input.GetButtonDown("Fire1") && !firing)
		{
			anim.CrossFade(((Object)fire).name);
			firing = true;
			fired = false;
			endFiringTime = Time.time + fire.length - 0.3f;
		}
		if (firing && Time.time > endFiringTime)
		{
			anim.CrossFade("aim");
			firing = false;
			if (!fired)
			{
				OnFired();
			}
		}
		float axis = Input.GetAxis("Vertical");
		float axis2 = Input.GetAxis("Horizontal");
		centralSpeed = Mathf.SmoothDamp(centralSpeed, axis, ref centralVelocity, 0.3f);
		lateralSpeed = Mathf.SmoothDamp(lateralSpeed, axis2, ref lateralVelocity, 0.3f);
		if (Mathf.Abs(axis) > 0.1f || Mathf.Abs(axis2) > 0.1f)
		{
			if (axis >= 0f)
			{
				anim[((Object)runForward).name].speed = 1f;
				anim.CrossFade(((Object)runForward).name);
			}
			else if (axis < -0.1f)
			{
				if ((Object)(object)runBack != (Object)null)
				{
					anim.CrossFade(((Object)runBack).name);
				}
				else
				{
					anim[((Object)runForward).name].speed = -1f;
					anim.CrossFade(((Object)runForward).name);
				}
			}
		}
		else
		{
			anim.CrossFade(((Object)idle).name);
		}
		controller.Move(((Component)this).transform.rotation * (Vector3.forward * centralSpeed * runSpeed * Time.deltaTime + Vector3.right * lateralSpeed * runSpeed * Time.deltaTime) + Vector3.down * 20f * Time.deltaTime);
	}

	private void OnConversationStart()
	{
		anim.CrossFade(((Object)idle).name);
		centralSpeed = 0f;
		centralVelocity = 0f;
		lateralSpeed = 0f;
		lateralVelocity = 0f;
		firing = false;
	}

	private void OnFired()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		fired = true;
		if ((Object)(object)fireSound != (Object)null && (Object)(object)audioSource != (Object)null)
		{
			audioSource.PlayOneShot(fireSound);
		}
		Ray val = Camera.main.ScreenPointToRay(new Vector3((float)(Screen.width / 2), (float)(Screen.height / 2)));
		RaycastHit val2 = default;
		if (Physics.Raycast(val, ref val2, float.PositiveInfinity, LayerMask.op_Implicit(fireLayerMask)))
		{
			((Component)val2.collider).gameObject.BroadcastMessage("TakeDamage", (object)weaponDamage, (SendMessageOptions)1);
		}
	}

	public static float ClampAngle(float angle, float min, float max)
	{
		if (angle < -360f)
		{
			angle += 360f;
		}
		if (angle > 360f)
		{
			angle -= 360f;
		}
		return Mathf.Clamp(angle, min, max);
	}
}
