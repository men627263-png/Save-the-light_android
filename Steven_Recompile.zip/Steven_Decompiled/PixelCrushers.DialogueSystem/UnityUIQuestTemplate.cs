using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Quest/Unity UI Quest Template")]
public class UnityUIQuestTemplate : MonoBehaviour
{
	[Header("Quest Heading")]
	[Tooltip("The heading - name or description depends on window setting")]
	public Button heading;

	[Tooltip("Used for Description")]
	public Text description;

	public UnityUIQuestTemplateAlternateDescriptions alternateDescriptions = new UnityUIQuestTemplateAlternateDescriptions();

	[Header("Quest Entries")]
	[Tooltip("(Optional) If set, holds instantiated quest entries")]
	public Transform entryContainer;

	[Tooltip("Used for quest entries")]
	public Text entryDescription;

	public UnityUIQuestTemplateAlternateDescriptions alternateEntryDescriptions = new UnityUIQuestTemplateAlternateDescriptions();

	[Header("Buttons")]
	[Tooltip("Used for Track button if quest is trackable")]
	public Button trackButton;

	[Tooltip("Used for Abandon button if quest is abandonable")]
	public Button abandonButton;

	protected int numEntries;

	public bool ArePropertiesAssigned => (Object)(object)heading != (Object)null && (Object)(object)description != (Object)null && (Object)(object)entryDescription != (Object)null && (Object)(object)trackButton != (Object)null && (Object)(object)abandonButton != (Object)null;

	public virtual void Initialize()
	{
		if ((Object)(object)description != (Object)null)
		{
			((Component)description).gameObject.SetActive(false);
		}
		if ((Object)(object)entryDescription != (Object)null)
		{
			((Component)entryDescription).gameObject.SetActive(false);
		}
		alternateEntryDescriptions.SetActive(value: false);
		if ((Object)(object)entryContainer != (Object)null)
		{
			((Component)entryContainer).gameObject.SetActive(false);
		}
	}

	public virtual void AddEntryDescription(string text, QuestState entryState)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Invalid comparison between Unknown and I4
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Invalid comparison between Unknown and I4
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Invalid comparison between Unknown and I4
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Invalid comparison between Unknown and I4
		if ((Object)(object)entryContainer == (Object)null)
		{
			if ((int)entryState != 1)
			{
				alternateEntryDescriptions.SetActive(value: false);
				if ((Object)(object)entryDescription != (Object)null)
				{
					if (numEntries == 0)
					{
						((Component)entryDescription).gameObject.SetActive(true);
						entryDescription.text = text;
					}
					else
					{
						Text val = entryDescription;
						val.text = val.text + "\n" + text;
					}
				}
			}
		}
		else
		{
			if (numEntries == 0)
			{
				((Component)entryContainer).gameObject.SetActive(true);
				if ((Object)(object)entryDescription != (Object)null)
				{
					((Component)entryDescription).gameObject.SetActive(false);
				}
				alternateEntryDescriptions.SetActive(value: false);
			}
			if ((int)entryState != 2)
			{
				if ((int)entryState != 4)
				{
					if ((int)entryState == 8)
					{
						InstantiateFirstValidTextElement(text, entryContainer, alternateEntryDescriptions.failureDescription, entryDescription);
					}
				}
				else
				{
					InstantiateFirstValidTextElement(text, entryContainer, alternateEntryDescriptions.successDescription, entryDescription);
				}
			}
			else
			{
				InstantiateFirstValidTextElement(text, entryContainer, entryDescription);
			}
		}
		numEntries++;
	}

	protected void InstantiateFirstValidTextElement(string text, Transform container, params Text[] textElements)
	{
		for (int i = 0; i < textElements.Length; i++)
		{
			if ((Object)(object)textElements[i] != (Object)null)
			{
				GameObject val = Object.Instantiate<GameObject>(((Component)textElements[i]).gameObject);
				val.transform.SetParent(((Component)container).transform, false);
				val.SetActive(true);
				Text component = val.GetComponent<Text>();
				if ((Object)(object)component != (Object)null)
				{
					component.text = text;
				}
				break;
			}
		}
	}
}
