using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

public static class UITools
{
	public static Dictionary<Texture2D, Sprite> spriteCache = new Dictionary<Texture2D, Sprite>();

	private static UnityUIDialogueUI dialogueUI = null;

	public static void RequireEventSystem()
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)Object.FindObjectOfType<EventSystem>() == (Object)null)
		{
			if (DialogueDebug.LogWarnings)
			{
				Debug.LogWarning((object)"Dialogue System: The scene is missing an EventSystem. Adding one.");
			}
			new GameObject("EventSystem", new Type[2]
			{
				typeof(EventSystem),
				typeof(StandaloneInputModule)
			});
		}
	}

	public static int GetAnimatorNameHash(AnimatorStateInfo animatorStateInfo)
	{
		return animatorStateInfo.fullPathHash;
	}

	public static void ClearSpriteCache()
	{
		spriteCache.Clear();
	}

	public static Sprite CreateSprite(Texture2D texture)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)texture == (Object)null)
		{
			return null;
		}
		if (spriteCache.ContainsKey(texture))
		{
			return spriteCache[texture];
		}
		Sprite val = Sprite.Create(texture, new Rect(0f, 0f, (float)((Texture)texture).width, (float)((Texture)texture).height), Vector2.zero);
		spriteCache.Add(texture, val);
		return val;
	}

	public static string GetUIFormattedText(FormattedText formattedText)
	{
		if (formattedText == null)
		{
			return string.Empty;
		}
		if (formattedText.italic)
		{
			return "<i>" + formattedText.text + "</i>";
		}
		return formattedText.text;
	}

	public static void SendTextChangeMessage(Text text)
	{
		if (!((Object)(object)text == (Object)null))
		{
			if ((Object)(object)dialogueUI == (Object)null)
			{
				dialogueUI = ((Component)text).GetComponentInParent<UnityUIDialogueUI>();
			}
			if (!((Object)(object)dialogueUI == (Object)null))
			{
				((Component)dialogueUI).SendMessage("OnTextChange", (object)text, (SendMessageOptions)1);
			}
		}
	}
}
