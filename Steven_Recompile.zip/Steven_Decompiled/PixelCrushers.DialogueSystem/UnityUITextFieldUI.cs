using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Dialogue/Text Field UI")]
public class UnityUITextFieldUI : MonoBehaviour, ITextFieldUI
{
	[Tooltip("Optional panel containing the UI elements")]
	public Graphic panel;

	[Tooltip("Optional text element for prompt")]
	public Text label;

	public InputField textField;

	[Tooltip("Optional key code that accepts the input")]
	public KeyCode acceptKey = (KeyCode)13;

	[Tooltip("Optional key code that cancels the input")]
	public KeyCode cancelKey = (KeyCode)27;

	[Tooltip("Automatically open touchscreen keyboard")]
	public bool showTouchScreenKeyboard;

	public UnityEvent onAccept = new UnityEvent();

	public UnityEvent onCancel = new UnityEvent();

	private AcceptedTextDelegate acceptedText;

	private bool isAwaitingInput;

	private TouchScreenKeyboard touchScreenKeyboard;

	public UnityUITextFieldUI()
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected Obj, but got Unknown
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Expected Obj, but got Unknown
	}

	private void Start()
	{
		if (DialogueDebug.LogWarnings && (Object)(object)textField == (Object)null)
		{
			Debug.LogWarning((object)string.Format("{0}: No InputField is assigned to the text field UI {1}. TextInput() sequencer commands or [var?=] won't work.", new object[2]
			{
				"Dialogue System",
				((Object)this).name
			}));
		}
		Hide();
	}

	public void StartTextInput(string labelText, string text, int maxLength, AcceptedTextDelegate acceptedText)
	{
		if ((Object)(object)label != (Object)null)
		{
			label.text = labelText;
		}
		if ((Object)(object)textField != (Object)null)
		{
			textField.text = text;
			textField.characterLimit = maxLength;
		}
		this.acceptedText = acceptedText;
		Show();
		isAwaitingInput = true;
	}

	public void Update()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if (isAwaitingInput)
		{
			if (Input.GetKeyDown(acceptKey))
			{
				AcceptTextInput();
			}
			else if (Input.GetKeyDown(cancelKey))
			{
				CancelTextInput();
			}
		}
	}

	public void CancelTextInput()
	{
		isAwaitingInput = false;
		Hide();
		onCancel.Invoke();
	}

	public void AcceptTextInput()
	{
		isAwaitingInput = false;
		if (acceptedText != null)
		{
			if ((Object)(object)textField != (Object)null)
			{
				acceptedText.Invoke(textField.text);
			}
			acceptedText = null;
		}
		Hide();
		onAccept.Invoke();
	}

	private void Show()
	{
		SetActive(value: true);
		if ((Object)(object)textField != (Object)null)
		{
			if (showTouchScreenKeyboard)
			{
				touchScreenKeyboard = TouchScreenKeyboard.Open(textField.text);
			}
			textField.ActivateInputField();
			if ((Object)(object)EventSystem.current != (Object)null)
			{
				EventSystem.current.SetSelectedGameObject(((Component)textField).gameObject, (BaseEventData)null);
			}
		}
	}

	private void Hide()
	{
		SetActive(value: false);
		if (touchScreenKeyboard != null)
		{
			touchScreenKeyboard.active = false;
			touchScreenKeyboard = null;
		}
	}

	private void SetActive(bool value)
	{
		if ((Object)(object)textField != (Object)null)
		{
			((Behaviour)textField).enabled = value;
		}
		if ((Object)(object)panel != (Object)null)
		{
			Tools.SetGameObjectActive((Component)(object)panel, value);
			return;
		}
		Tools.SetGameObjectActive((Component)(object)label, value);
		Tools.SetGameObjectActive((Component)(object)textField, value);
	}
}
