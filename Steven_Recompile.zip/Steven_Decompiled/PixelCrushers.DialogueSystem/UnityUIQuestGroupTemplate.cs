using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Quest/Unity UI Quest Group Template")]
public class UnityUIQuestGroupTemplate : MonoBehaviour
{
	[Header("Quest Group Heading")]
	[Tooltip("The quest group name")]
	public Text heading;

	public bool ArePropertiesAssigned => (Object)(object)heading != (Object)null;

	public void Initialize()
	{
	}
}
