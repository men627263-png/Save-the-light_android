using System;
using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[Serializable]
public class UnityUIDialogueControls : AbstractDialogueUIControls
{
	[Serializable]
	public class AnimationTransitions
	{
		public string showTrigger = "Show";

		public string hideTrigger = "Hide";
	}

	[Tooltip("Panel containing the entire conversation UI")]
	public Graphic panel;

	public UnityUISubtitleControls npcSubtitle;

	public UnityUISubtitleControls pcSubtitle;

	public UnityUIResponseMenuControls responseMenu;

	[Tooltip("Optional animation transitions; panel should have an Animator")]
	public AnimationTransitions animationTransitions = new AnimationTransitions();

	private bool isVisible;

	private UIShowHideController showHideController;

	public override AbstractUISubtitleControls NPCSubtitle => (AbstractUISubtitleControls)(object)npcSubtitle;

	public override AbstractUISubtitleControls PCSubtitle => (AbstractUISubtitleControls)(object)pcSubtitle;

	public override AbstractUIResponseMenuControls ResponseMenu => (AbstractUIResponseMenuControls)(object)responseMenu;

	public override void SetActive(bool value)
	{
		try
		{
			if (value)
			{
				((AbstractDialogueUIControls)this).SetActive(true);
				((AbstractDialogueUIControls)this).ShowPanel();
			}
			else
			{
				HidePanel();
			}
		}
		finally
		{
			isVisible = value;
		}
	}

	public override void ShowPanel()
	{
		ShowControls();
		if (!isVisible)
		{
			isVisible = true;
			CheckShowHideController();
			showHideController.ClearTrigger(animationTransitions.hideTrigger);
			showHideController.Show(animationTransitions.showTrigger, pause: false, null);
		}
	}

	private void HidePanel()
	{
		if (isVisible)
		{
			CheckShowHideController();
			showHideController.ClearTrigger(animationTransitions.showTrigger);
			showHideController.Hide(animationTransitions.hideTrigger, HideControls);
		}
		else
		{
			HideControls();
		}
	}

	private void CheckShowHideController()
	{
		if (showHideController == null)
		{
			showHideController = new UIShowHideController(null, (Component)(object)panel);
		}
	}

	private void ShowControls()
	{
		if ((Object)(object)panel != (Object)null)
		{
			Tools.SetGameObjectActive((Component)(object)panel, true);
		}
	}

	private void HideControls()
	{
		if ((Object)(object)panel != (Object)null)
		{
			Tools.SetGameObjectActive((Component)(object)panel, false);
		}
		((AbstractDialogueUIControls)this).SetActive(false);
		isVisible = false;
	}
}
