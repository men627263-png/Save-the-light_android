using System;
using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Selection/Unity UI Selector Display")]
public class UnityUISelectorDisplay : MonoBehaviour
{
	[Serializable]
	public class AnimationTransitions
	{
		public string showTrigger = "Show";

		public string hideTrigger = "Hide";
	}

	public Graphic mainGraphic;

	public Text nameText;

	public Text useMessageText;

	public Color inRangeColor = Color.yellow;

	public Color outOfRangeColor = Color.gray;

	public Graphic reticleInRange;

	public Graphic reticleOutOfRange;

	public AnimationTransitions animationTransitions = new AnimationTransitions();

	private Selector selector;

	private ProximitySelector proximitySelector;

	private string defaultUseMessage = string.Empty;

	private Usable usable;

	private bool lastInRange;

	private UsableUnityUI usableUnityUI;

	private Animator animator;

	protected float CurrentDistance => (!((Object)(object)selector != (Object)null)) ? 0f : selector.CurrentDistance;

	public UnityUISelectorDisplay()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
	}

	public void Start()
	{
		FindUIElements();
		ConnectDelegates();
		DeactivateControls();
	}

	public void FindUIElements()
	{
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)mainGraphic == (Object)null && (Object)(object)nameText == (Object)null && (Object)(object)reticleInRange == (Object)null)
		{
			UnityUISelectorElements unityUISelectorElements = Object.FindObjectOfType<UnityUISelectorElements>();
			if ((Object)(object)unityUISelectorElements == (Object)null)
			{
				if (DialogueDebug.LogWarnings)
				{
					Debug.LogWarning((object)"Dialogue System: UnityUISelectorDisplay can't find UI elements", (Object)(object)this);
				}
			}
			else
			{
				if ((Object)(object)mainGraphic == (Object)null)
				{
					mainGraphic = unityUISelectorElements.mainGraphic;
				}
				if ((Object)(object)nameText == (Object)null)
				{
					nameText = unityUISelectorElements.nameText;
				}
				if ((Object)(object)useMessageText == (Object)null)
				{
					useMessageText = unityUISelectorElements.useMessageText;
				}
				inRangeColor = unityUISelectorElements.inRangeColor;
				outOfRangeColor = unityUISelectorElements.outOfRangeColor;
				if ((Object)(object)reticleInRange == (Object)null)
				{
					reticleInRange = unityUISelectorElements.reticleInRange;
				}
				if ((Object)(object)reticleOutOfRange == (Object)null)
				{
					reticleOutOfRange = unityUISelectorElements.reticleOutOfRange;
				}
				animationTransitions = unityUISelectorElements.animationTransitions;
			}
		}
		if ((Object)(object)mainGraphic != (Object)null)
		{
			animator = ((Component)this).GetComponentInChildren<Animator>();
		}
	}

	public void OnEnable()
	{
		ConnectDelegates();
	}

	public void OnDisable()
	{
		DisconnectDelegates();
	}

	private void ConnectDelegates()
	{
		DisconnectDelegates();
		selector = ((Component)this).GetComponent<Selector>();
		if ((Object)(object)selector != (Object)null)
		{
			selector.useDefaultGUI = false;
			selector.SelectedUsableObject += OnSelectedUsable;
			selector.DeselectedUsableObject += OnDeselectedUsable;
			defaultUseMessage = selector.defaultUseMessage;
		}
		proximitySelector = ((Component)this).GetComponent<ProximitySelector>();
		if ((Object)(object)proximitySelector != (Object)null)
		{
			proximitySelector.useDefaultGUI = false;
			proximitySelector.SelectedUsableObject += OnSelectedUsable;
			proximitySelector.DeselectedUsableObject += OnDeselectedUsable;
			if (string.IsNullOrEmpty(defaultUseMessage))
			{
				defaultUseMessage = proximitySelector.defaultUseMessage;
			}
		}
	}

	private void DisconnectDelegates()
	{
		selector = ((Component)this).GetComponent<Selector>();
		if ((Object)(object)selector != (Object)null)
		{
			selector.useDefaultGUI = true;
			selector.SelectedUsableObject -= OnSelectedUsable;
			selector.DeselectedUsableObject -= OnDeselectedUsable;
		}
		proximitySelector = ((Component)this).GetComponent<ProximitySelector>();
		if ((Object)(object)proximitySelector != (Object)null)
		{
			proximitySelector.useDefaultGUI = true;
			proximitySelector.SelectedUsableObject -= OnSelectedUsable;
			proximitySelector.DeselectedUsableObject -= OnDeselectedUsable;
		}
		HideControls();
	}

	private void OnSelectedUsable(Usable usable)
	{
		this.usable = usable;
		usableUnityUI = ((!((Object)(object)usable != (Object)null)) ? null : ((Component)usable).GetComponentInChildren<UsableUnityUI>());
		if ((Object)(object)usableUnityUI != (Object)null)
		{
			usableUnityUI.Show(GetUseMessage());
		}
		else
		{
			ShowControls();
		}
		lastInRange = !IsUsableInRange();
		UpdateDisplay(!lastInRange);
	}

	private void OnDeselectedUsable(Usable usable)
	{
		if ((Object)(object)usableUnityUI != (Object)null)
		{
			usableUnityUI.Hide();
			usableUnityUI = null;
		}
		else
		{
			HideControls();
		}
		this.usable = null;
	}

	private string GetUseMessage()
	{
		return (!string.IsNullOrEmpty(usable.overrideUseMessage)) ? usable.overrideUseMessage : defaultUseMessage;
	}

	private void ShowControls()
	{
		if (!((Object)(object)usable == (Object)null))
		{
			Tools.SetGameObjectActive((Component)(object)mainGraphic, true);
			Tools.SetGameObjectActive((Component)(object)nameText, true);
			Tools.SetGameObjectActive((Component)(object)useMessageText, true);
			if ((Object)(object)nameText != (Object)null)
			{
				nameText.text = usable.GetName();
			}
			if ((Object)(object)useMessageText != (Object)null)
			{
				useMessageText.text = GetUseMessage();
			}
			if (CanTriggerAnimations() && !string.IsNullOrEmpty(animationTransitions.showTrigger))
			{
				animator.SetTrigger(animationTransitions.showTrigger);
			}
		}
	}

	private void HideControls()
	{
		if (CanTriggerAnimations() && !string.IsNullOrEmpty(animationTransitions.hideTrigger))
		{
			animator.SetTrigger(animationTransitions.hideTrigger);
		}
		else
		{
			DeactivateControls();
		}
	}

	private void DeactivateControls()
	{
		Tools.SetGameObjectActive((Component)(object)nameText, false);
		Tools.SetGameObjectActive((Component)(object)useMessageText, false);
		Tools.SetGameObjectActive((Component)(object)reticleInRange, false);
		Tools.SetGameObjectActive((Component)(object)reticleOutOfRange, false);
		Tools.SetGameObjectActive((Component)(object)mainGraphic, false);
	}

	private bool IsUsableInRange()
	{
		return (Object)(object)usable != (Object)null && CurrentDistance <= usable.maxUseDistance;
	}

	public void Update()
	{
		if ((Object)(object)usable != (Object)null)
		{
			UpdateDisplay(IsUsableInRange());
		}
		else
		{
			HideControls();
		}
	}

	public void OnConversationStart(Transform actor)
	{
		HideControls();
	}

	public void OnConversationEnd(Transform actor)
	{
		ShowControls();
	}

	private void UpdateDisplay(bool inRange)
	{
		if ((Object)(object)usable != (Object)null && inRange != lastInRange)
		{
			lastInRange = inRange;
			if ((Object)(object)usableUnityUI != (Object)null)
			{
				usableUnityUI.UpdateDisplay(inRange);
				return;
			}
			UpdateText(inRange);
			UpdateReticle(inRange);
		}
	}

	private void UpdateText(bool inRange)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		Color color = ((!inRange) ? outOfRangeColor : inRangeColor);
		if ((Object)(object)nameText != (Object)null)
		{
			((Graphic)nameText).color = color;
		}
		if ((Object)(object)useMessageText != (Object)null)
		{
			((Graphic)useMessageText).color = color;
		}
	}

	private void UpdateReticle(bool inRange)
	{
		Tools.SetGameObjectActive((Component)(object)reticleInRange, inRange);
		Tools.SetGameObjectActive((Component)(object)reticleOutOfRange, !inRange);
	}

	private bool CanTriggerAnimations()
	{
		return (Object)(object)animator != (Object)null && animationTransitions != null;
	}
}
