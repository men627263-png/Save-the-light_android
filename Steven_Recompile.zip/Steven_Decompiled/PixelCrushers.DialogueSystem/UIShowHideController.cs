using System;
using System.Collections;
using UnityEngine;

namespace PixelCrushers.DialogueSystem;

public class UIShowHideController
{
	public Component panel;

	private Animator animator;

	private bool lookedForAnimator;

	private Coroutine animCoroutine;

	public UIShowHideController(GameObject go, Component panel)
	{
		this.panel = panel;
		animator = ((!((Object)(object)go != (Object)null)) ? null : go.GetComponent<Animator>());
		if ((Object)(object)animator == (Object)null && (Object)(object)panel != (Object)null)
		{
			animator = panel.GetComponent<Animator>();
		}
		animCoroutine = null;
	}

	public void Show(string showTrigger, bool pause, Action callback, bool wait = true)
	{
		float newTimeScale = ((!pause) ? Time.timeScale : 0f);
		CancelCurrentAnim();
		animCoroutine = ((MonoBehaviour)DialogueManager.Instance).StartCoroutine(WaitForAnimation(showTrigger, newTimeScale, panelActive: true, wait, callback));
	}

	public void Hide(string hideTrigger, Action callback)
	{
		CancelCurrentAnim();
		animCoroutine = ((MonoBehaviour)DialogueManager.Instance).StartCoroutine(WaitForAnimation(hideTrigger, Time.timeScale, panelActive: false, wait: true, callback));
	}

	private IEnumerator WaitForAnimation(string triggerName, float newTimeScale, bool panelActive, bool wait, Action callback)
	{
		if (panelActive)
		{
			Tools.SetGameObjectActive(panel, true);
		}
		if (CanTriggerAnimation(triggerName))
		{
			CheckAnimatorModeAndTimescale(triggerName);
			animator.SetTrigger(triggerName);
			float timeout = Time.realtimeSinceStartup + 10f;
			int goalHashID = Animator.StringToHash(triggerName);
			int oldHashId = UITools.GetAnimatorNameHash(animator.GetCurrentAnimatorStateInfo(0));
			int currentHashID = oldHashId;
			if (wait)
			{
				while (currentHashID != goalHashID && currentHashID == oldHashId && Time.realtimeSinceStartup < timeout)
				{
					yield return null;
					currentHashID = UITools.GetAnimatorNameHash(animator.GetCurrentAnimatorStateInfo(0));
					if (!((Component)animator).gameObject.activeInHierarchy)
					{
						break;
					}
				}
				if (Time.realtimeSinceStartup < timeout)
				{
					AnimatorStateInfo currentAnimatorStateInfo = animator.GetCurrentAnimatorStateInfo(0);
					float clipLength = currentAnimatorStateInfo.length;
					if (Mathf.Approximately(0f, Time.timeScale))
					{
						timeout = Time.realtimeSinceStartup + clipLength;
						while (Time.realtimeSinceStartup < timeout)
						{
							yield return null;
						}
					}
					else
					{
						yield return (object)new WaitForSeconds(clipLength);
					}
				}
			}
		}
		if (!panelActive)
		{
			Tools.SetGameObjectActive(panel, false);
		}
		animCoroutine = null;
		callback?.Invoke();
	}

	private void CheckAnimatorModeAndTimescale(string triggerName)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Invalid comparison between Unknown and I4
		if (Mathf.Approximately(0f, Time.timeScale) && (int)animator.updateMode != 2 && DialogueDebug.LogWarnings)
		{
			Debug.LogWarning((object)("Dialogue System: Time is paused but animator mode isn't set to Unscaled Time; the animation triggered by " + triggerName + " won't play."), (Object)(object)animator);
		}
	}

	private void CancelCurrentAnim()
	{
		if (animCoroutine != null)
		{
			((MonoBehaviour)DialogueManager.Instance).StopCoroutine(animCoroutine);
			animCoroutine = null;
		}
	}

	public void ClearTrigger(string triggerName)
	{
		if (HasAnimator() && !string.IsNullOrEmpty(triggerName))
		{
			animator.ResetTrigger(triggerName);
		}
	}

	private bool CanTriggerAnimation(string triggerName)
	{
		return HasAnimator() && !string.IsNullOrEmpty(triggerName);
	}

	private bool HasAnimator()
	{
		if ((Object)(object)animator == (Object)null && !lookedForAnimator)
		{
			lookedForAnimator = true;
			if ((Object)(object)panel != (Object)null)
			{
				animator = panel.GetComponent<Animator>();
				if ((Object)(object)animator == (Object)null)
				{
					animator = panel.GetComponentInChildren<Animator>();
				}
			}
		}
		return (Object)(object)animator != (Object)null;
	}
}
