using PixelCrushers.DialogueSystem.UnityGUI;
using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Actor/Player/Selector Follow Target")]
public class SelectorFollowTarget : MonoBehaviour
{
	public Vector3 offset = Vector3.zero;

	private Selector selector;

	private ProximitySelector proximitySelector;

	private bool previousUseDefaultGUI;

	private Usable lastUsable;

	private string heading = string.Empty;

	private string useMessage = string.Empty;

	private GameObject lastSelectionDrawn;

	private float selectionHeight;

	private Vector2 selectionHeadingSize = Vector2.zero;

	private Vector2 selectionUseMessageSize = Vector2.zero;

	public SelectorFollowTarget()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Awake()
	{
		selector = ((Component)this).GetComponent<Selector>();
		proximitySelector = ((Component)this).GetComponent<ProximitySelector>();
	}

	private void OnEnable()
	{
		if ((Object)(object)selector != (Object)null)
		{
			previousUseDefaultGUI = selector.useDefaultGUI;
			selector.useDefaultGUI = false;
		}
		if ((Object)(object)proximitySelector != (Object)null)
		{
			previousUseDefaultGUI = proximitySelector.useDefaultGUI;
			proximitySelector.useDefaultGUI = false;
		}
	}

	private void OnDisable()
	{
		if ((Object)(object)selector != (Object)null)
		{
			selector.useDefaultGUI = previousUseDefaultGUI;
		}
		if ((Object)(object)proximitySelector != (Object)null)
		{
			proximitySelector.useDefaultGUI = previousUseDefaultGUI;
		}
	}

	public virtual void OnGUI()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)selector != (Object)null)
		{
			DrawOnSelection(selector.CurrentUsable, selector.CurrentDistance, selector.reticle, selector.GuiStyle, selector.defaultUseMessage, selector.inRangeColor, selector.outOfRangeColor, selector.textStyle, selector.textStyleColor);
		}
		else if ((Object)(object)proximitySelector != (Object)null)
		{
			DrawOnSelection(proximitySelector.CurrentUsable, 0f, null, proximitySelector.GuiStyle, proximitySelector.defaultUseMessage, proximitySelector.color, proximitySelector.color, proximitySelector.textStyle, proximitySelector.textStyleColor);
		}
	}

	protected void DrawOnSelection(Usable usable, float distance, Selector.Reticle reticle, GUIStyle guiStyle, string defaultUseMessage, Color inRangeColor, Color outOfRangeColor, TextStyle textStyle, Color textStyleColor)
	{
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Expected Obj, but got Unknown
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Expected Obj, but got Unknown
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_032c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0331: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)usable == (Object)null)
		{
			return;
		}
		if ((Object)(object)usable != (Object)(object)lastUsable || string.IsNullOrEmpty(heading))
		{
			lastUsable = usable;
			heading = usable.GetName();
			useMessage = ((!string.IsNullOrEmpty(usable.overrideUseMessage)) ? usable.overrideUseMessage : defaultUseMessage);
		}
		GameObject gameObject = ((Component)usable).gameObject;
		if ((Object)(object)gameObject != (Object)(object)lastSelectionDrawn)
		{
			selectionHeight = Tools.GetGameObjectHeight(gameObject);
			selectionHeadingSize = guiStyle.CalcSize(new GUIContent(heading));
			selectionUseMessageSize = guiStyle.CalcSize(new GUIContent(useMessage));
		}
		bool flag = distance <= usable.maxUseDistance;
		guiStyle.normal.textColor = ((!flag) ? outOfRangeColor : inRangeColor);
		Vector3 val = Camera.main.WorldToScreenPoint(gameObject.transform.position + Vector3.up * selectionHeight);
		val += offset;
		val = new Vector3(val.x, val.y + selectionUseMessageSize.y + selectionHeadingSize.y, val.z);
		if (val.z < 0f)
		{
			return;
		}
		Rect val2 = new Rect(val.x - selectionHeadingSize.x / 2f, (float)Screen.height - val.y - selectionHeadingSize.y / 2f, selectionHeadingSize.x, selectionHeadingSize.y);
		UnityGUITools.DrawText(val2, heading, guiStyle, textStyle, textStyleColor);
		val = Camera.main.WorldToScreenPoint(gameObject.transform.position + Vector3.up * selectionHeight);
		val += offset;
		val = new Vector3(val.x, val.y + selectionUseMessageSize.y, val.z);
		val2 = new Rect(val.x - selectionUseMessageSize.x / 2f, (float)Screen.height - val.y - selectionUseMessageSize.y / 2f, selectionUseMessageSize.x, selectionUseMessageSize.y);
		UnityGUITools.DrawText(val2, useMessage, guiStyle, textStyle, textStyleColor);
		if (reticle != null)
		{
			Texture2D val3 = ((!flag) ? reticle.outOfRange : reticle.inRange);
			if ((Object)(object)val3 != (Object)null)
			{
				val = Camera.main.WorldToScreenPoint(gameObject.transform.position + Vector3.up * 0.5f * selectionHeight);
				val2 = new Rect(val.x - reticle.width / 2f, (float)Screen.height - val.y - reticle.height / 2f, reticle.width, reticle.height);
				GUI.Label(val2, (Texture)(object)val3);
			}
		}
	}
}
