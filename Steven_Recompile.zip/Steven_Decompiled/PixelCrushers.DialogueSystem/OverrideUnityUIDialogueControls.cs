using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Dialogue/Override/Override Unity UI Dialogue Controls")]
public class OverrideUnityUIDialogueControls : MonoBehaviour
{
	[Tooltip("Use these controls when playing subtitles through this actor")]
	public UnityUISubtitleControls subtitle;

	[Tooltip("Use these controls when showing subtitle reminders for actor")]
	public UnityUISubtitleControls subtitleReminder;

	[Tooltip("Use these controls when showing a response menu involving this actor")]
	public UnityUIResponseMenuControls responseMenu;

	public virtual void Start()
	{
		if (subtitle != null)
		{
			((AbstractUIControls)subtitle).SetActive(false);
		}
		if (subtitleReminder != null)
		{
			((AbstractUIControls)subtitleReminder).SetActive(false);
		}
		if (responseMenu != null)
		{
			((AbstractUIControls)responseMenu).SetActive(false);
		}
	}
}
