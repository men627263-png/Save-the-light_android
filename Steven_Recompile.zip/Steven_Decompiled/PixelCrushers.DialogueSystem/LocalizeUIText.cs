using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Effects/Localize UI Text")]
public class LocalizeUIText : MonoBehaviour
{
	[Tooltip("Optional; overrides the Dialogue Manager's table")]
	public LocalizedTextTable localizedTextTable;

	protected Text text;

	protected string fieldName = string.Empty;

	protected List<string> fieldNames = new List<string>();

	protected bool started;

	protected Dropdown dropdown;

	protected virtual void Start()
	{
		started = true;
		LocalizeText();
	}

	protected virtual void OnEnable()
	{
		LocalizeText();
	}

	public virtual void LocalizeText()
	{
		if (!started || string.IsNullOrEmpty(Localization.Language))
		{
			return;
		}
		if ((Object)(object)localizedTextTable == (Object)null)
		{
			localizedTextTable = DialogueManager.DisplaySettings.localizationSettings.localizedText;
			if ((Object)(object)localizedTextTable == (Object)null)
			{
				if (DialogueDebug.LogWarnings)
				{
					Debug.LogWarning((object)("Dialogue System: No localized text table is assigned to " + ((Object)this).name + " or the Dialogue Manager."), (Object)(object)this);
				}
				return;
			}
		}
		if (!HasCurrentLanguage())
		{
			if (DialogueDebug.LogWarnings)
			{
				Debug.LogWarning((object)string.Concat(new object[5]
				{
					"Dialogue SystemLocalized text table '",
					localizedTextTable,
					"' does not have a language '",
					Localization.Language,
					"'"
				}), (Object)(object)this);
			}
			return;
		}
		if ((Object)(object)text == (Object)null && (Object)(object)dropdown == (Object)null)
		{
			text = ((Component)this).GetComponent<Text>();
			dropdown = ((Component)this).GetComponent<Dropdown>();
			if ((Object)(object)text == (Object)null && (Object)(object)dropdown == (Object)null)
			{
				if (DialogueDebug.LogWarnings)
				{
					Debug.LogWarning((object)("Dialogue System: LocalizeUILabel didn't find a Text or Dropdown component on " + ((Object)this).name + "."), (Object)(object)this);
				}
				return;
			}
		}
		if (string.IsNullOrEmpty(fieldName))
		{
			fieldName = ((!((Object)(object)text != (Object)null)) ? string.Empty : text.text);
		}
		if (fieldNames.Count == 0 && (Object)(object)dropdown != (Object)null)
		{
			dropdown.options.ForEach((OptionData opt) =>
			{
				fieldNames.Add(opt.text);
			});
		}
		if ((Object)(object)text != (Object)null)
		{
			if (!localizedTextTable.ContainsField(fieldName))
			{
				if (DialogueDebug.LogWarnings)
				{
					Debug.LogWarning((object)("Dialogue System: Localized text table '" + ((Object)localizedTextTable).name + "' does not have a field: " + fieldName), (Object)(object)this);
				}
			}
			else
			{
				text.text = localizedTextTable[fieldName];
			}
		}
		if (!((Object)(object)dropdown != (Object)null))
		{
			return;
		}
		for (int num = 0; num < dropdown.options.Count; num++)
		{
			if (num < fieldNames.Count)
			{
				dropdown.options[num].text = localizedTextTable[fieldNames[num]];
			}
		}
		dropdown.captionText.text = localizedTextTable[fieldNames[dropdown.value]];
	}

	protected virtual bool HasCurrentLanguage()
	{
		if ((Object)(object)localizedTextTable == (Object)null)
		{
			return false;
		}
		foreach (string language in localizedTextTable.languages)
		{
			if (string.Equals(language, Localization.Language))
			{
				return true;
			}
		}
		return false;
	}

	public virtual void UpdateFieldName(string newFieldName = "")
	{
		if ((Object)(object)text == (Object)null)
		{
			text = ((Component)this).GetComponent<Text>();
		}
		fieldName = ((!string.IsNullOrEmpty(newFieldName)) ? newFieldName : text.text);
	}

	public virtual void UpdateOptions()
	{
		fieldNames.Clear();
		LocalizeText();
	}
}
