using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Third Party/TextMesh Pro/TextMesh Pro Typewriter Effect")]
[DisallowMultipleComponent]
public class TextMeshProTypewriterEffect : MonoBehaviour
{
	[Serializable]
	public class AutoScrollSettings
	{
		[Tooltip("Automatically scroll to bottom of scroll rect. Useful for long text. Works best with left justification.")]
		public bool autoScrollEnabled;

		public ScrollRect scrollRect;

		public UnityUIScrollbarEnabler scrollbarEnabler;
	}

	[Tooltip("How fast to type. This is separate from Dialogue Manager > Subtitle Settings > Chars Per Second")]
	public float charactersPerSecond = 50f;

	[Tooltip("Optional audio clip to play with each character")]
	public AudioClip audioClip;

	[Tooltip("Optional audio source through which to play the clip")]
	public AudioSource audioSource;

	[Tooltip("If audio clip is still playing from previous character, stop and restart it when typing next character")]
	public bool interruptAudioClip;

	[Tooltip("Ensure this GameObject has only one typewriter effect")]
	public bool removeDuplicateTypewriterEffects = true;

	[Tooltip("Wait one frame to allow layout elements to setup first")]
	public bool waitOneFrameBeforeStarting;

	public AutoScrollSettings autoScrollSettings = new AutoScrollSettings();

	public UnityEvent onBegin = new UnityEvent();

	public UnityEvent onCharacter = new UnityEvent();

	public UnityEvent onEnd = new UnityEvent();

	private float minDisplayTime = 0.33f;

	private float lastStopTime;

	private TMP_Text textComponent;

	private bool started;

	private bool paused;

	private int charactersTyped;

	public bool IsPlaying { get; private set; }

	public int VisibleCharacters => ((Component)textComponent).gameObject.activeInHierarchy ? textComponent.text.Length : 0;

	public bool startedEffect { get; private set; }

	public int totalCharacters { get; private set; }

	public TextMeshProTypewriterEffect()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Expected Obj, but got Unknown
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Expected Obj, but got Unknown
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Expected Obj, but got Unknown
	}

	public void Awake()
	{
		textComponent = ((Component)this).GetComponent<TMP_Text>();
		if ((Object)(object)audioSource == (Object)null)
		{
			audioSource = ((Component)this).GetComponent<AudioSource>();
		}
		if (removeDuplicateTypewriterEffects)
		{
			RemoveIfDuplicate();
		}
		EventMessenger.Instance.AddListener<PauseEvent>(HandlePauseEvent);
	}

	private void OnDestroy()
	{
		EventMessenger.Instance.RemoveListener<PauseEvent>(HandlePauseEvent);
	}

	private void HandlePauseEvent(PauseEvent evt)
	{
		if (evt.isPaused)
		{
			Pause();
		}
		else if (!evt.isPaused)
		{
			Unpause();
		}
	}

	private void RemoveIfDuplicate()
	{
		TextMeshProTypewriterEffect[] components = ((Component)this).GetComponents<TextMeshProTypewriterEffect>();
		if (components.Length <= 1)
		{
			return;
		}
		TextMeshProTypewriterEffect textMeshProTypewriterEffect = components[0];
		for (int i = 1; i < components.Length; i++)
		{
			if (((Object)components[i]).GetInstanceID() < ((Object)textMeshProTypewriterEffect).GetInstanceID())
			{
				textMeshProTypewriterEffect = components[i];
			}
		}
		for (int j = 0; j < components.Length; j++)
		{
			if ((Object)(object)components[j] != (Object)(object)textMeshProTypewriterEffect)
			{
				Object.Destroy((Object)(object)components[j]);
			}
		}
	}

	public void Start()
	{
		textComponent.maxVisibleCharacters = 0;
		started = true;
	}

	public void OnEnable()
	{
	}

	public void StartEffect()
	{
		if (!IsPlaying && started && ((Component)this).gameObject.activeInHierarchy)
		{
			textComponent.maxVisibleCharacters = 0;
			TMP_TextInfo textInfo = textComponent.textInfo;
			totalCharacters = textInfo.characterCount;
			startedEffect = true;
			((MonoBehaviour)this).StopAllCoroutines();
			((MonoBehaviour)this).StartCoroutine(Play());
		}
	}

	public void OnDisable()
	{
		Stop();
		startedEffect = false;
	}

	public void Pause()
	{
		paused = true;
	}

	public void Unpause()
	{
		paused = false;
	}

	public void SetMaxVisibleCharacter(int maxVisible)
	{
		textComponent.maxVisibleCharacters = maxVisible;
	}

	public void Rewind()
	{
		charactersTyped = 0;
		StartEffect();
	}

	public bool ShowingAllCharacters()
	{
		if (textComponent.maxVisibleCharacters >= totalCharacters)
		{
			return true;
		}
		return false;
	}

	public IEnumerator Play()
	{
		if ((Object)(object)textComponent != (Object)null && charactersPerSecond > 0f)
		{
			if (waitOneFrameBeforeStarting)
			{
				yield return null;
			}
			if ((Object)(object)audioSource != (Object)null)
			{
				audioSource.clip = audioClip;
			}
			onBegin.Invoke();
			IsPlaying = true;
			paused = false;
			float delay = 1f / charactersPerSecond;
			float lastTime = DialogueTime.time;
			float elapsed = 0f;
			textComponent.maxVisibleCharacters = 0;
			textComponent.ForceMeshUpdate();
			yield return null;
			textComponent.maxVisibleCharacters = 0;
			textComponent.ForceMeshUpdate();
			TMP_TextInfo textInfo = textComponent.textInfo;
			int totalVisibleCharacters = textInfo.characterCount;
			charactersTyped = 0;
			while (charactersTyped < totalVisibleCharacters)
			{
				if (!paused)
				{
					float num = DialogueTime.time - lastTime;
					elapsed += num;
					float num2 = elapsed * charactersPerSecond;
					while ((float)charactersTyped < num2)
					{
						PlayCharacterAudio();
						onCharacter.Invoke();
						charactersTyped++;
					}
				}
				else
				{
					StopCharacterAudio();
				}
				textComponent.maxVisibleCharacters = charactersTyped;
				HandleAutoScroll();
				lastTime = DialogueTime.time;
				float delayTime = DialogueTime.time + delay;
				int delaySafeguard = 0;
				while (DialogueTime.time < delayTime && delaySafeguard < 999)
				{
					delaySafeguard++;
					yield return null;
				}
			}
		}
		lastStopTime = Time.time;
		Stop();
	}

	private void PlayCharacterAudio()
	{
		if ((Object)(object)audioClip == (Object)null || (Object)(object)audioSource == (Object)null)
		{
			return;
		}
		if (interruptAudioClip)
		{
			if (audioSource.isPlaying)
			{
				audioSource.Stop();
			}
			audioSource.Play();
		}
		else if (!audioSource.isPlaying)
		{
			audioSource.Play();
		}
	}

	private void StopCharacterAudio()
	{
		if (!((Object)(object)audioClip == (Object)null) && !((Object)(object)audioSource == (Object)null) && audioSource.isPlaying)
		{
			audioSource.Stop();
		}
	}

	public bool ReachedMinDisplayTime()
	{
		return Time.time - lastStopTime > minDisplayTime;
	}

	public void Stop()
	{
		((MonoBehaviour)this).StopAllCoroutines();
		StopCharacterAudio();
		if (IsPlaying)
		{
			onEnd.Invoke();
		}
		IsPlaying = false;
		if ((Object)(object)textComponent != (Object)null)
		{
			textComponent.maxVisibleCharacters = textComponent.textInfo.characterCount;
		}
		HandleAutoScroll();
	}

	private void HandleAutoScroll()
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		if (autoScrollSettings.autoScrollEnabled)
		{
			if ((Object)(object)autoScrollSettings.scrollRect != (Object)null)
			{
				autoScrollSettings.scrollRect.normalizedPosition = new Vector2(0f, 0f);
			}
			if ((Object)(object)autoScrollSettings.scrollbarEnabler != (Object)null)
			{
				autoScrollSettings.scrollbarEnabler.CheckScrollbar();
			}
		}
	}
}
