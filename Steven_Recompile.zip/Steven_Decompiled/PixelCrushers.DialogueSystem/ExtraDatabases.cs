using System.Collections;
using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Miscellaneous/Extra Databases")]
public class ExtraDatabases : MonoBehaviour
{
	public DialogueTriggerEvent addTrigger = (DialogueTriggerEvent)16;

	public DialogueTriggerEvent removeTrigger = (DialogueTriggerEvent)1024;

	public DialogueDatabase[] databases = new DialogueDatabase[0];

	public Condition condition = new Condition();

	public bool once;

	private bool trying;

	public ExtraDatabases()
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Expected Obj, but got Unknown
	}

	private void TryAddDatabases(Transform interactor, bool immediate)
	{
		if (trying)
		{
			return;
		}
		trying = true;
		try
		{
			if (condition == null || condition.IsTrue(interactor))
			{
				AddDatabases(immediate);
				if (once)
				{
					Object.Destroy((Object)(object)this);
				}
			}
		}
		finally
		{
			trying = false;
		}
	}

	public void AddDatabases(bool immediate)
	{
		if (immediate)
		{
			AddDatabasesImmediate();
		}
		else if (((Component)this).gameObject.activeInHierarchy && ((Behaviour)this).enabled)
		{
			((MonoBehaviour)this).StartCoroutine(AddDatabasesCoroutine());
		}
	}

	private void AddDatabasesImmediate()
	{
		DialogueDatabase[] array = databases;
		foreach (DialogueDatabase database in array)
		{
			AddDatabase(database);
		}
	}

	private IEnumerator AddDatabasesCoroutine()
	{
		DialogueDatabase[] array = databases;
		foreach (DialogueDatabase database in array)
		{
			AddDatabase(database);
			yield return null;
		}
	}

	private void AddDatabase(DialogueDatabase database)
	{
		if ((Object)(object)database != (Object)null)
		{
			if (DialogueDebug.LogInfo)
			{
				Debug.Log((object)string.Format("{0}: Adding database {1}", new object[2]
				{
					"Dialogue System",
					((Object)database).name
				}), (Object)(object)this);
			}
			DialogueManager.AddDatabase(database);
		}
	}

	private void TryRemoveDatabases(Transform interactor, bool immediate)
	{
		if (trying)
		{
			return;
		}
		trying = true;
		try
		{
			if (condition == null || condition.IsTrue(interactor))
			{
				RemoveDatabases(immediate);
				if (once)
				{
					Object.Destroy((Object)(object)this);
				}
			}
		}
		finally
		{
			trying = false;
		}
	}

	public void RemoveDatabases(bool immediate)
	{
		if (immediate)
		{
			RemoveDatabasesImmediate();
		}
		else if (((Component)this).gameObject.activeInHierarchy && ((Behaviour)this).enabled)
		{
			((MonoBehaviour)this).StartCoroutine(RemoveDatabasesCoroutine());
		}
	}

	private void RemoveDatabasesImmediate()
	{
		DialogueDatabase[] array = databases;
		foreach (DialogueDatabase database in array)
		{
			RemoveDatabase(database);
		}
	}

	private IEnumerator RemoveDatabasesCoroutine()
	{
		DialogueDatabase[] array = databases;
		foreach (DialogueDatabase database in array)
		{
			RemoveDatabase(database);
			yield return null;
		}
	}

	private void RemoveDatabase(DialogueDatabase database)
	{
		if ((Object)(object)database != (Object)null)
		{
			if (DialogueDebug.LogInfo)
			{
				Debug.Log((object)string.Format("{0}: Removing database {1}", new object[2]
				{
					"Dialogue System",
					((Object)database).name
				}), (Object)(object)this);
			}
			DialogueManager.RemoveDatabase(database);
		}
	}

	public IEnumerator Start()
	{
		yield return null;
		if ((int)addTrigger == 16)
		{
			TryAddDatabases(null, immediate: false);
		}
		if ((int)removeTrigger == 16)
		{
			TryRemoveDatabases(null, immediate: false);
		}
	}

	public void OnEnable()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Invalid comparison between Unknown and I4
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Invalid comparison between Unknown and I4
		if ((int)addTrigger == 64)
		{
			TryAddDatabases(null, immediate: false);
		}
		if ((int)removeTrigger == 64)
		{
			TryRemoveDatabases(null, immediate: false);
		}
	}

	public void OnDisable()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Invalid comparison between Unknown and I4
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Invalid comparison between Unknown and I4
		if ((int)addTrigger == 256)
		{
			TryAddDatabases(null, immediate: true);
		}
		if ((int)removeTrigger == 256)
		{
			TryRemoveDatabases(null, immediate: true);
		}
	}

	public void OnDestroy()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Invalid comparison between Unknown and I4
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Invalid comparison between Unknown and I4
		if ((int)addTrigger == 512)
		{
			TryAddDatabases(null, immediate: true);
		}
		if ((int)removeTrigger == 512)
		{
			TryRemoveDatabases(null, immediate: true);
		}
	}

	public void OnUse(Transform actor)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Invalid comparison between Unknown and I4
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Invalid comparison between Unknown and I4
		if (((Behaviour)this).enabled)
		{
			if ((int)addTrigger == 32)
			{
				TryAddDatabases(actor, immediate: false);
			}
			if ((int)removeTrigger == 32)
			{
				TryRemoveDatabases(actor, immediate: false);
			}
		}
	}

	public void OnUse(string message)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Invalid comparison between Unknown and I4
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Invalid comparison between Unknown and I4
		if (((Behaviour)this).enabled)
		{
			if ((int)addTrigger == 32)
			{
				TryAddDatabases(null, immediate: false);
			}
			if ((int)removeTrigger == 32)
			{
				TryRemoveDatabases(null, immediate: false);
			}
		}
	}

	public void OnUse()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Invalid comparison between Unknown and I4
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Invalid comparison between Unknown and I4
		if (((Behaviour)this).enabled)
		{
			if ((int)addTrigger == 32)
			{
				TryAddDatabases(null, immediate: false);
			}
			if ((int)removeTrigger == 32)
			{
				TryRemoveDatabases(null, immediate: false);
			}
		}
	}

	public void OnTriggerEnter(Collider other)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Invalid comparison between Unknown and I4
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Invalid comparison between Unknown and I4
		if (((Behaviour)this).enabled)
		{
			if ((int)addTrigger == 8)
			{
				TryAddDatabases(((Component)other).transform, immediate: false);
			}
			if ((int)removeTrigger == 8)
			{
				TryRemoveDatabases(((Component)other).transform, immediate: false);
			}
		}
	}

	public void OnTriggerEnter2D(Collider2D other)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Invalid comparison between Unknown and I4
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Invalid comparison between Unknown and I4
		if (((Behaviour)this).enabled)
		{
			if ((int)addTrigger == 8)
			{
				TryAddDatabases(((Component)other).transform, immediate: false);
			}
			if ((int)removeTrigger == 8)
			{
				TryRemoveDatabases(((Component)other).transform, immediate: false);
			}
		}
	}

	public void OnTriggerExit(Collider other)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Invalid comparison between Unknown and I4
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Invalid comparison between Unknown and I4
		if (((Behaviour)this).enabled)
		{
			if ((int)addTrigger == 128)
			{
				TryAddDatabases(((Component)other).transform, immediate: false);
			}
			if ((int)removeTrigger == 128)
			{
				TryRemoveDatabases(((Component)other).transform, immediate: false);
			}
		}
	}

	public void OnTriggerExit2D(Collider2D other)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Invalid comparison between Unknown and I4
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Invalid comparison between Unknown and I4
		if (((Behaviour)this).enabled)
		{
			if ((int)addTrigger == 128)
			{
				TryAddDatabases(((Component)other).transform, immediate: false);
			}
			if ((int)removeTrigger == 128)
			{
				TryRemoveDatabases(((Component)other).transform, immediate: false);
			}
		}
	}
}
