using System.Runtime.CompilerServices;
using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Actor/Player/Smooth Camera With Bumper (community)")]
public class SmoothCameraWithBumper : MonoBehaviour
{
	public Transform target;

	[SerializeField]
	private float distance = 3f;

	[SerializeField]
	private float height = 1f;

	[SerializeField]
	private float damping = 5f;

	[SerializeField]
	private bool smoothRotation = true;

	[SerializeField]
	private float rotationDamping = 10f;

	[SerializeField]
	private Vector3 targetLookAtOffset;

	[SerializeField]
	private float bumperDistanceCheck = 2.5f;

	[SerializeField]
	private float bumperCameraHeight = 1f;

	[SerializeField]
	private Vector3 bumperRayOffset;

	private Quaternion originalRotation;

	public Quaternion adjustQuaternion
	{
		[CompilerGenerated]
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return field;
		}
		[CompilerGenerated]
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			field = value;
		}
	}

	private void Awake()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		Camera component = ((Component)this).GetComponent<Camera>();
		if ((Object)(object)component != (Object)null)
		{
			((Component)component).transform.parent = target;
		}
		adjustQuaternion = Quaternion.identity;
	}

	private void Start()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		originalRotation = ((Component)this).transform.localRotation;
	}

	private void FixedUpdate()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = target.TransformPoint(0f, height, 0f - distance);
		Vector3 val2 = ((Component)target).transform.TransformDirection(-1f * Vector3.forward);
		RaycastHit val3 = default;
		if (Physics.Raycast(target.TransformPoint(bumperRayOffset), val2, ref val3, bumperDistanceCheck) && (Object)(object)val3.transform != (Object)(object)target)
		{
			val.x = val3.point.x;
			val.z = val3.point.z;
			val.y = Mathf.Lerp(val3.point.y + bumperCameraHeight, val.y, Time.deltaTime * damping);
		}
		((Component)this).transform.position = Vector3.Lerp(((Component)this).transform.position, val, Time.deltaTime * damping);
		Vector3 val4 = target.TransformPoint(targetLookAtOffset);
		if (smoothRotation)
		{
			Quaternion val5 = Quaternion.LookRotation(val4 - ((Component)this).transform.position, target.up);
			((Component)this).transform.rotation = Quaternion.Slerp(((Component)this).transform.rotation, val5, Time.deltaTime * rotationDamping);
		}
		else
		{
			((Component)this).transform.rotation = Quaternion.LookRotation(val4 - ((Component)this).transform.position, target.up);
		}
		((Component)this).transform.localRotation = originalRotation * adjustQuaternion;
	}
}
