using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Effects/Unity UI Continue Button Fast Forward")]
public class UnityUIContinueButtonFastForward : MonoBehaviour
{
	public UnityUIDialogueUI dialogueUI;

	public UnityUITypewriterEffect typewriterEffect;

	public virtual void Awake()
	{
		if ((Object)(object)dialogueUI == (Object)null)
		{
			dialogueUI = Tools.GetComponentAnywhere<UnityUIDialogueUI>(((Component)this).gameObject);
		}
		if ((Object)(object)typewriterEffect == (Object)null)
		{
			typewriterEffect = ((Component)this).GetComponentInChildren<UnityUITypewriterEffect>();
		}
	}

	public virtual void OnFastForward()
	{
		if ((Object)(object)typewriterEffect != (Object)null && typewriterEffect.IsPlaying)
		{
			typewriterEffect.Stop();
		}
		else if ((Object)(object)dialogueUI != (Object)null)
		{
			((AbstractDialogueUI)dialogueUI).OnContinue();
		}
	}
}
