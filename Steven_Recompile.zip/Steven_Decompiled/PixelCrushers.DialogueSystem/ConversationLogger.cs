using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Miscellaneous/Conversation Logger")]
public class ConversationLogger : MonoBehaviour
{
	public Color playerColor = Color.blue;

	public Color npcColor = Color.red;

	public ConversationLogger()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
	}

	public void OnConversationStart(Transform actor)
	{
		Debug.Log((object)string.Format("{0}: Starting conversation with {1}", new object[2]
		{
			((Object)this).name,
			GetActorName(actor)
		}));
	}

	public void OnConversationLine(Subtitle subtitle)
	{
		if (!((subtitle == null) | (subtitle.formattedText == null) | string.IsNullOrEmpty(subtitle.formattedText.text)))
		{
			string text = ((subtitle.speakerInfo == null || !((Object)(object)subtitle.speakerInfo.transform != (Object)null)) ? "(null speaker)" : ((Object)subtitle.speakerInfo.transform).name);
			Debug.Log((object)string.Format("<color={0}>{1}: {2}</color>", new object[3]
			{
				GetActorColor(subtitle),
				text,
				subtitle.formattedText.text
			}));
		}
	}

	public void OnConversationEnd(Transform actor)
	{
		Debug.Log((object)$"{((Object)this).name}: Ending conversation with {GetActorName(actor)}");
	}

	private string GetActorName(Transform actor)
	{
		return (!((Object)(object)actor != (Object)null)) ? "(null transform)" : ((Object)actor).name;
	}

	private string GetActorColor(Subtitle subtitle)
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		if ((subtitle == null) | (subtitle.speakerInfo == null))
		{
			return "white";
		}
		return Tools.ToWebColor((!subtitle.speakerInfo.IsPlayer) ? npcColor : playerColor);
	}

	public void OnPrepareConversationLine(DialogueEntry entry)
	{
		if (entry != null)
		{
			Debug.Log((object)$"Preparing line {entry.DialogueText}");
		}
	}

	public void OnConversationLineCancelled(Subtitle subtitle)
	{
		if (!((subtitle == null) | (subtitle.formattedText == null) | string.IsNullOrEmpty(subtitle.formattedText.text)))
		{
			string text = ((subtitle.speakerInfo == null || !((Object)(object)subtitle.speakerInfo.transform != (Object)null)) ? "(null speaker)" : ((Object)subtitle.speakerInfo.transform).name);
			Debug.Log((object)string.Format("<color={0}>Line cancelled - {1}: {2}</color>", new object[3]
			{
				GetActorColor(subtitle),
				text,
				subtitle.formattedText.text
			}));
		}
	}

	public void OnConversationLineEnd(Subtitle subtitle)
	{
		if (!((subtitle == null) | (subtitle.formattedText == null) | string.IsNullOrEmpty(subtitle.formattedText.text)))
		{
			string text = ((subtitle.speakerInfo == null || !((Object)(object)subtitle.speakerInfo.transform != (Object)null)) ? "(null speaker)" : ((Object)subtitle.speakerInfo.transform).name);
			Debug.Log((object)string.Format("<color={0}>Line ended - {1}: {2}</color>", new object[3]
			{
				GetActorColor(subtitle),
				text,
				subtitle.formattedText.text
			}));
		}
	}

	public void OnConversationResponseMenu(Response[] responses)
	{
		Debug.Log((object)"Showing conversation response menu.");
	}

	public void OnConversationTimeout()
	{
		Debug.Log((object)"Conversation timed out.");
	}

	public void OnLinkedConversationStart(Transform actor)
	{
		Debug.Log((object)"Starting linked conversation.");
	}
}
