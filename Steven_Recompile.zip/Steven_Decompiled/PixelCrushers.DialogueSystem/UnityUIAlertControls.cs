using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[Serializable]
public class UnityUIAlertControls : AbstractUIAlertControls
{
	[Serializable]
	public class AnimationTransitions
	{
		public string showTrigger = "Show";

		public string hideTrigger = "Hide";
	}

	[Tooltip("Optional panel containing the alert line; can contain other doodads and effects, too")]
	public Graphic panel;

	[Tooltip("Shows the alert message text")]
	public Text line;

	[Tooltip("Optional continue button; configure OnClick to invoke dialogue UI's OnContinue method")]
	public Button continueButton;

	[Tooltip("Wait for previous alerts to finish before showing new alert; if unticked, new alerts replace old")]
	public bool queueAlerts;

	[Tooltip("Optional animation transitions; panel should have an Animator")]
	public AnimationTransitions animationTransitions = new AnimationTransitions();

	private bool isVisible;

	private UIShowHideController showHideController;

	public override bool IsVisible => isVisible;

	public override void SetActive(bool value)
	{
		try
		{
			if (value)
			{
				ShowPanel();
			}
			else
			{
				HidePanel();
			}
		}
		finally
		{
			isVisible = value;
		}
	}

	private void ShowPanel()
	{
		ShowControls();
		CheckShowHideController();
		showHideController.ClearTrigger(animationTransitions.hideTrigger);
		showHideController.Show(animationTransitions.showTrigger, pause: false, null);
		isVisible = true;
	}

	private void HidePanel()
	{
		CheckShowHideController();
		showHideController.ClearTrigger(animationTransitions.showTrigger);
		if (isVisible)
		{
			showHideController.Hide(animationTransitions.hideTrigger, HideControls);
		}
		else
		{
			HideControls();
		}
	}

	private void CheckShowHideController()
	{
		if (showHideController == null)
		{
			showHideController = new UIShowHideController(null, (Component)(object)panel);
		}
	}

	private void ShowControls()
	{
		Tools.SetGameObjectActive((Component)(object)panel, true);
		Tools.SetGameObjectActive((Component)(object)line, true);
	}

	private void HideControls()
	{
		Tools.SetGameObjectActive((Component)(object)panel, false);
		Tools.SetGameObjectActive((Component)(object)line, false);
	}

	public override void SetMessage(string message, float duration)
	{
		if ((Object)(object)line != (Object)null)
		{
			line.text = FormattedText.Parse(message, DialogueManager.MasterDatabase.emphasisSettings).text;
		}
	}

	public void AutoFocus()
	{
		if ((Object)(object)continueButton != (Object)null && (Object)(object)EventSystem.current != (Object)null)
		{
			EventSystem.current.SetSelectedGameObject(((Component)continueButton).gameObject, (BaseEventData)null);
		}
	}
}
