using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Dialogue/Use Animated Portraits")]
public class UseAnimatedPortraits : MonoBehaviour
{
	private UnityUIDialogueUI dialogueUI;

	private Animator npcPortraitAnimator;

	private Animator npcReminderPortraitAnimator;

	private Animator pcPortraitAnimator;

	private Dictionary<Transform, AnimatedPortrait> animatedPortraits = new Dictionary<Transform, AnimatedPortrait>();

	private Transform lastSpeaker;

	public void OnConversationLine(Subtitle subtitle)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Invalid comparison between Unknown and I4
		if (FindDialogueUI())
		{
			if ((int)subtitle.speakerInfo.characterType == 1)
			{
				SetAnimatorController(dialogueUI.dialogue.npcSubtitle.portraitImage, subtitle.speakerInfo.transform, ref npcPortraitAnimator);
			}
			else
			{
				SetAnimatorController(dialogueUI.dialogue.pcSubtitle.portraitImage, subtitle.speakerInfo.transform, ref pcPortraitAnimator);
			}
			lastSpeaker = subtitle.speakerInfo.transform;
		}
	}

	public void OnConversationResponseMenu(Response[] responses)
	{
		if (FindDialogueUI())
		{
			SetAnimatorController(dialogueUI.dialogue.responseMenu.subtitleReminder.portraitImage, lastSpeaker, ref npcReminderPortraitAnimator);
		}
	}

	public void OnConversationEnd(Transform actor)
	{
		animatedPortraits.Clear();
	}

	private bool FindDialogueUI()
	{
		if ((Object)(object)dialogueUI == (Object)null && Object.op_Implicit((Object)(object)DialogueManager.DisplaySettings.dialogueUI))
		{
			dialogueUI = DialogueManager.DisplaySettings.dialogueUI.GetComponent<UnityUIDialogueUI>();
		}
		return (Object)(object)dialogueUI != (Object)null;
	}

	private void SetAnimatorController(Image image, Transform speaker, ref Animator animator)
	{
		if ((Object)(object)speaker == (Object)null || (Object)(object)image == (Object)null)
		{
			return;
		}
		if ((Object)(object)animator == (Object)null)
		{
			animator = ((Component)image).GetComponent<Animator>();
		}
		if ((Object)(object)animator == (Object)null)
		{
			animator = ((Component)image).gameObject.AddComponent<Animator>();
		}
		if (!animatedPortraits.ContainsKey(speaker))
		{
			AnimatedPortrait value = ((!((Object)(object)speaker != (Object)null)) ? null : ((Component)speaker).GetComponentInChildren<AnimatedPortrait>());
			animatedPortraits.Add(speaker, value);
		}
		if ((Object)(object)animatedPortraits[speaker] != (Object)null)
		{
			RuntimeAnimatorController animatorController = animatedPortraits[speaker].animatorController;
			if ((Object)(object)animator.runtimeAnimatorController != (Object)(object)animatorController)
			{
				animator.runtimeAnimatorController = animatorController;
			}
		}
	}
}
