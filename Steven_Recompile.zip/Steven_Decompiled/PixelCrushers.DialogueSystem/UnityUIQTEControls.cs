using System;
using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[Serializable]
public class UnityUIQTEControls : AbstractUIQTEControls
{
	public Graphic[] qteIndicators;

	private int numVisibleQTEIndicators;

	public override bool AreVisible => numVisibleQTEIndicators > 0;

	public UnityUIQTEControls(Graphic[] qteIndicators)
	{
		this.qteIndicators = qteIndicators;
	}

	public override void SetActive(bool value)
	{
		if (!value)
		{
			numVisibleQTEIndicators = 0;
			Graphic[] array = qteIndicators;
			foreach (Graphic val in array)
			{
				Tools.SetGameObjectActive((Component)(object)val, false);
			}
		}
	}

	public override void ShowIndicator(int index)
	{
		if (IsValidQTEIndex(index) && !IsQTEIndicatorVisible(index))
		{
			Tools.SetGameObjectActive((Component)(object)qteIndicators[index], true);
			numVisibleQTEIndicators++;
		}
	}

	public override void HideIndicator(int index)
	{
		if (IsValidQTEIndex(index) && IsQTEIndicatorVisible(index))
		{
			Tools.SetGameObjectActive((Component)(object)qteIndicators[index], false);
			numVisibleQTEIndicators--;
		}
	}

	private bool IsQTEIndicatorVisible(int index)
	{
		return IsValidQTEIndex(index) && ((Component)qteIndicators[index]).gameObject.activeSelf;
	}

	private bool IsValidQTEIndex(int index)
	{
		return 0 <= index && index < qteIndicators.Length;
	}
}
