using System;
using System.Collections.Generic;
using PixelCrushers.DialogueSystem.UnityGUI;
using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Actor/Player/Proximity Selector")]
public class ProximitySelector : MonoBehaviour
{
	[Serializable]
	public class Reticle
	{
		public Texture2D inRange;

		public Texture2D outOfRange;

		public float width = 64f;

		public float height = 64f;
	}

	public bool useDefaultGUI = true;

	public GUISkin guiSkin;

	public string guiStyleName = "label";

	public TextAnchor alignment = (TextAnchor)1;

	public Color color = Color.yellow;

	public TextStyle textStyle = (TextStyle)1;

	public Color textStyleColor = Color.black;

	public string defaultUseMessage = "(spacebar to interact)";

	public KeyCode useKey = (KeyCode)32;

	public string useButton = "Fire2";

	public bool enableTouch;

	public ScaledRect touchArea = new ScaledRect(ScaledRect.empty);

	public bool broadcastToChildren = true;

	public Transform actorTransform;

	private List<Usable> usablesInRange = new List<Usable>();

	private Usable currentUsable;

	private string currentHeading = string.Empty;

	private string currentUseMessage = string.Empty;

	private GUIStyle guiStyle;

	private const float MinTimeBetweenUseButton = 0.5f;

	private float timeToEnableUseButton;

	public Usable CurrentUsable => currentUsable;

	public GUIStyle GuiStyle
	{
		get
		{
			SetGuiStyle();
			return guiStyle;
		}
	}

	public event SelectedUsableObjectDelegate SelectedUsableObject;

	public event DeselectedUsableObjectDelegate DeselectedUsableObject;

	public ProximitySelector()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Expected Obj, but got Unknown
	}

	public void OnConversationEnd(Transform actor)
	{
		timeToEnableUseButton = Time.time + 0.5f;
	}

	private void Update()
	{
		if (!((Behaviour)this).enabled || Time.timeScale <= 0f)
		{
			return;
		}
		if (DialogueManager.IsConversationActive)
		{
			timeToEnableUseButton = Time.time + 0.5f;
		}
		if (IsUseButtonDown() && (Object)(object)currentUsable != (Object)null && Time.time >= timeToEnableUseButton)
		{
			Transform val = ((!((Object)(object)actorTransform != (Object)null)) ? ((Component)this).transform : actorTransform);
			if (broadcastToChildren)
			{
				((Component)currentUsable).gameObject.BroadcastMessage("OnUse", (object)val, (SendMessageOptions)1);
			}
			else
			{
				((Component)currentUsable).gameObject.SendMessage("OnUse", (object)val, (SendMessageOptions)1);
			}
		}
	}

	private bool IsUseButtonDown()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		if (enableTouch && IsTouchDown())
		{
			return true;
		}
		return ((int)useKey != 0 && Input.GetKeyDown(useKey)) || (!string.IsNullOrEmpty(useButton) && Input.GetButtonUp(useButton));
	}

	private bool IsTouchDown()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		if (Input.touchCount >= 1)
		{
			Touch[] touches = Input.touches;
			for (int i = 0; i < touches.Length; i++)
			{
				Touch val = touches[i];
				Vector2 val2 = new Vector2(val.position.x, (float)Screen.height - val.position.y);
				Rect pixelRect = touchArea.GetPixelRect();
				if (pixelRect.Contains(val2))
				{
					return true;
				}
			}
		}
		return false;
	}

	private void OnTriggerEnter(Collider other)
	{
		CheckTriggerEnter(((Component)other).gameObject);
	}

	private void OnTriggerEnter2D(Collider2D other)
	{
		CheckTriggerEnter(((Component)other).gameObject);
	}

	private void OnTriggerExit(Collider other)
	{
		CheckTriggerExit(((Component)other).gameObject);
	}

	private void OnTriggerExit2D(Collider2D other)
	{
		CheckTriggerExit(((Component)other).gameObject);
	}

	private void CheckTriggerEnter(GameObject other)
	{
		Usable component = other.GetComponent<Usable>();
		if ((Object)(object)component != (Object)null)
		{
			SetCurrentUsable(component);
			if (!usablesInRange.Contains(component))
			{
				usablesInRange.Add(component);
			}
			if (SelectedUsableObject != null)
			{
				SelectedUsableObject(component);
			}
		}
	}

	private void CheckTriggerExit(GameObject other)
	{
		Usable component = other.GetComponent<Usable>();
		if (!((Object)(object)component != (Object)null))
		{
			return;
		}
		if (usablesInRange.Contains(component))
		{
			usablesInRange.Remove(component);
		}
		if (!((Object)(object)currentUsable == (Object)(object)component))
		{
			return;
		}
		if (DeselectedUsableObject != null)
		{
			DeselectedUsableObject(component);
		}
		Usable usable = null;
		if (usablesInRange.Count > 0)
		{
			usable = usablesInRange[0];
			if (SelectedUsableObject != null)
			{
				SelectedUsableObject(usable);
			}
		}
		SetCurrentUsable(usable);
	}

	private void SetCurrentUsable(Usable usable)
	{
		currentUsable = usable;
		if ((Object)(object)usable != (Object)null)
		{
			currentHeading = currentUsable.GetName();
			currentUseMessage = ((!string.IsNullOrEmpty(currentUsable.overrideUseMessage)) ? currentUsable.overrideUseMessage : defaultUseMessage);
		}
		else
		{
			currentHeading = string.Empty;
			currentUseMessage = string.Empty;
		}
	}

	public virtual void OnGUI()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Expected Obj, but got Unknown
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		if (useDefaultGUI)
		{
			SetGuiStyle();
			Rect val = new Rect(0f, 0f, (float)Screen.width, (float)Screen.height);
			if ((Object)(object)currentUsable != (Object)null)
			{
				UnityGUITools.DrawText(val, currentHeading, guiStyle, textStyle, textStyleColor);
				UnityGUITools.DrawText(new Rect(0f, guiStyle.CalcSize(new GUIContent("Ay")).y, (float)Screen.width, (float)Screen.height), currentUseMessage, guiStyle, textStyle, textStyleColor);
			}
		}
	}

	protected void SetGuiStyle()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Expected Obj, but got Unknown
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		GUI.skin = UnityGUITools.GetValidGUISkin(guiSkin);
		if (guiStyle == null)
		{
			guiStyle = new GUIStyle(GUI.skin.FindStyle(guiStyleName) ?? GUI.skin.label);
			guiStyle.alignment = alignment;
			guiStyle.normal.textColor = color;
		}
	}
}
