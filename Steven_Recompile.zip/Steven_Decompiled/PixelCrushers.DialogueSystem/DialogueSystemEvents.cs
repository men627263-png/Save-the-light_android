using System;
using UnityEngine;
using UnityEngine.Events;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Miscellaneous/Dialogue System Events")]
public class DialogueSystemEvents : MonoBehaviour
{
	[Serializable]
	public class StringEvent : UnityEvent<string>
	{
	}

	[Serializable]
	public class TransformEvent : UnityEvent<Transform>
	{
	}

	[Serializable]
	public class SubtitleEvent : UnityEvent<Subtitle>
	{
	}

	[Serializable]
	public class ResponsesEvent : UnityEvent<Response[]>
	{
	}

	[Serializable]
	public class ConversationEvents
	{
		[Tooltip("Invoked when a conversation starts. Transform is primary actor (typically player).")]
		public TransformEvent onConversationStart = new TransformEvent();

		[Tooltip("Invoked when a conversation ends. Transform is primary actor (typically player).")]
		public TransformEvent onConversationEnd = new TransformEvent();

		[Tooltip("Invoked when a conversation is cancelled. Transform is primary actor (typically player).")]
		public TransformEvent onConversationCancelled = new TransformEvent();

		[Tooltip("Invoked just before a line is delivered. Passes Subtitle.")]
		public SubtitleEvent onConversationLine = new SubtitleEvent();

		[Tooltip("Invoked when a line has finished. Passes Subtitle.")]
		public SubtitleEvent onConversationLineEnd = new SubtitleEvent();

		[Tooltip("Invoked if player presses cancel button while line is being delivered.")]
		public SubtitleEvent onConversationLineCancelled = new SubtitleEvent();

		[Tooltip("Invoked when showing a response menu. Passes Response[] array.")]
		public ResponsesEvent onConversationResponseMenu = new ResponsesEvent();

		[Tooltip("Invoked when a response menu times out.")]
		public UnityEvent onConversationResponseMenuTimeout = new UnityEvent();

		[Tooltip("Invoked when a conversation follows a link to another conversation. Transform is primary actor (typically player).")]
		public TransformEvent onLinkedConversationStart = new TransformEvent();

		public ConversationEvents()
		{
			//IL_004e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0058: Expected Obj, but got Unknown
		}
	}

	[Serializable]
	public class BarkEvents
	{
		[Tooltip("Invoked when a bark starts. Transform is recipient of bark.")]
		public TransformEvent onBarkStart = new TransformEvent();

		[Tooltip("Invoked when a bark ends. Transform is recipient of bark.")]
		public TransformEvent onBarkEnd = new TransformEvent();

		[Tooltip("Invoked just before a bark line is delivered. Passes Subtitle.")]
		public SubtitleEvent onBarkLine = new SubtitleEvent();
	}

	[Serializable]
	public class SequenceEvents
	{
		[Tooltip("Invoked when a sequence starts. Transform is 'listener' of sequence.")]
		public TransformEvent onSequenceStart = new TransformEvent();

		[Tooltip("Invoked when a sequence ends. Transform is 'listener' of sequence.")]
		public TransformEvent onSequenceEnd = new TransformEvent();
	}

	[Serializable]
	public class QuestEvents
	{
		[Tooltip("Invoked when a quest state or quest entry state changes. String is quest title.")]
		public StringEvent onQuestStateChange = new StringEvent();

		[Tooltip("Invoked when tracking is enabled for a quest. String is quest title.")]
		public StringEvent onQuestTrackingEnabled = new StringEvent();

		[Tooltip("Invoked when tracking is disabled for a quest. String is quest title.")]
		public StringEvent onQuestTrackingDisabled = new StringEvent();

		[Tooltip("Invoked when updating quest tracker.")]
		public UnityEvent onUpdateQuestTracker = new UnityEvent();

		public QuestEvents()
		{
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			//IL_002c: Expected Obj, but got Unknown
		}
	}

	[Serializable]
	public class PauseEvents
	{
		[Tooltip("Invoked when DialogueManager.Pause() is called.")]
		public UnityEvent onDialogueSystemPause = new UnityEvent();

		[Tooltip("Invoked when DialogueManager.Unpause() is called.")]
		public UnityEvent onDialogueSystemUnpause = new UnityEvent();

		public PauseEvents()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected Obj, but got Unknown
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected Obj, but got Unknown
		}
	}

	public ConversationEvents conversationEvents = new ConversationEvents();

	public BarkEvents barkEvents = new BarkEvents();

	public SequenceEvents sequenceEvents = new SequenceEvents();

	public QuestEvents questEvents = new QuestEvents();

	public PauseEvents pauseEvents = new PauseEvents();

	public void OnConversationStart(Transform actor)
	{
		((UnityEvent<Transform>)conversationEvents.onConversationStart).Invoke(actor);
	}

	public void OnConversationEnd(Transform actor)
	{
		((UnityEvent<Transform>)conversationEvents.onConversationEnd).Invoke(actor);
	}

	public void OnConversationCancelled(Transform actor)
	{
		((UnityEvent<Transform>)conversationEvents.onConversationCancelled).Invoke(actor);
	}

	public void OnConversationLine(Subtitle subtitle)
	{
		((UnityEvent<Subtitle>)conversationEvents.onConversationLine).Invoke(subtitle);
	}

	public void OnConversationLineEnd(Subtitle subtitle)
	{
		((UnityEvent<Subtitle>)conversationEvents.onConversationLineEnd).Invoke(subtitle);
	}

	public void OnConversationLineCancelled(Subtitle subtitle)
	{
		((UnityEvent<Subtitle>)conversationEvents.onConversationLineCancelled).Invoke(subtitle);
	}

	public void OnConversationResponseMenu(Response[] responses)
	{
		((UnityEvent<Response[]>)conversationEvents.onConversationResponseMenu).Invoke(responses);
	}

	public void OnConversationTimeout()
	{
		conversationEvents.onConversationResponseMenuTimeout.Invoke();
	}

	public void OnLinkedConversationStart(Transform actor)
	{
		((UnityEvent<Transform>)conversationEvents.onLinkedConversationStart).Invoke(actor);
	}

	public void OnBarkStart(Transform actor)
	{
		((UnityEvent<Transform>)barkEvents.onBarkStart).Invoke(actor);
	}

	public void OnBarkEnd(Transform actor)
	{
		((UnityEvent<Transform>)barkEvents.onBarkEnd).Invoke(actor);
	}

	public void OnBarkLine(Subtitle subtitle)
	{
		((UnityEvent<Subtitle>)barkEvents.onBarkLine).Invoke(subtitle);
	}

	public void OnSequenceStart(Transform actor)
	{
		((UnityEvent<Transform>)sequenceEvents.onSequenceStart).Invoke(actor);
	}

	public void OnSequenceEnd(Transform actor)
	{
		((UnityEvent<Transform>)sequenceEvents.onSequenceEnd).Invoke(actor);
	}

	public void OnQuestStateChange(string title)
	{
		((UnityEvent<string>)questEvents.onQuestStateChange).Invoke(title);
	}

	public void OnQuestTrackingEnabled(string title)
	{
		((UnityEvent<string>)questEvents.onQuestTrackingEnabled).Invoke(title);
	}

	public void OnQuestTrackingDisabled(string title)
	{
		((UnityEvent<string>)questEvents.onQuestTrackingDisabled).Invoke(title);
	}

	public void UpdateTracker()
	{
		questEvents.onUpdateQuestTracker.Invoke();
	}

	public void OnDialogueSystemPause()
	{
		pauseEvents.onDialogueSystemPause.Invoke();
	}

	public void OnDialogueSystemUnpause()
	{
		pauseEvents.onDialogueSystemUnpause.Invoke();
	}
}
