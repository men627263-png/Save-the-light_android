using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Actor/Usable")]
public class Usable : MonoBehaviour
{
	public string overrideName;

	public string overrideUseMessage;

	public float maxUseDistance = 5f;

	public string GetName()
	{
		if (string.IsNullOrEmpty(overrideName))
		{
			return ((Object)this).name;
		}
		if (overrideName.Contains("[lua") || overrideName.Contains("[var"))
		{
			return FormattedText.Parse(overrideName, DialogueManager.MasterDatabase.emphasisSettings).text;
		}
		return overrideName;
	}

	public virtual void Start()
	{
		if (string.IsNullOrEmpty(overrideName))
		{
			OverrideActorName componentInChildren = ((Component)this).GetComponentInChildren<OverrideActorName>();
			if ((Object)(object)componentInChildren != (Object)null)
			{
				overrideName = componentInChildren.overrideName;
			}
		}
	}
}
