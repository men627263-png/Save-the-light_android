using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Dialogue/Timer")]
public class UnityUITimer : MonoBehaviour
{
	private Slider slider;

	public virtual void Awake()
	{
		slider = ((Component)this).GetComponent<Slider>();
	}

	public virtual void StartCountdown(float duration, Action timeoutHandler)
	{
		((MonoBehaviour)this).StartCoroutine(Countdown(duration, timeoutHandler));
	}

	private IEnumerator Countdown(float duration, Action timeoutHandler)
	{
		float startTime = DialogueTime.time;
		float endTime = startTime + duration;
		while (DialogueTime.time < endTime)
		{
			float elapsed = DialogueTime.time - startTime;
			UpdateTimeLeft(Mathf.Clamp(1f - elapsed / duration, 0f, 1f));
			yield return null;
		}
		timeoutHandler?.Invoke();
	}

	public virtual void UpdateTimeLeft(float normalizedTimeLeft)
	{
		if (!((Object)(object)slider == (Object)null))
		{
			slider.value = normalizedTimeLeft;
		}
	}

	public virtual void OnDisable()
	{
		((MonoBehaviour)this).StopAllCoroutines();
	}
}
