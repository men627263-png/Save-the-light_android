using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Effects/Unity UI Color Text")]
public class UnityUIColorText : MonoBehaviour
{
	public Color color;

	public Text text;

	private Color originalColor;

	private void Awake()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)text == (Object)null)
		{
			text = ((Component)this).GetComponentInChildren<Text>();
		}
		if ((Object)(object)text != (Object)null)
		{
			originalColor = ((Graphic)text).color;
		}
	}

	public void ApplyColor()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)text != (Object)null)
		{
			originalColor = ((Graphic)text).color;
			((Graphic)text).color = color;
		}
	}

	public void UndoColor()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)text != (Object)null)
		{
			((Graphic)text).color = originalColor;
		}
	}
}
