using System;
using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Bark/Bark UI")]
public class UnityUIBarkUI : MonoBehaviour, IBarkUI
{
	[Serializable]
	public class AnimationTransitions
	{
		public string showTrigger = "Show";

		public string hideTrigger = "Hide";
	}

	[Tooltip("Optional canvas group, for example to play fade animations.")]
	public CanvasGroup canvasGroup;

	[Tooltip("UI text control for the bark text.")]
	public Text barkText;

	[Tooltip("Optional UI text control for the actor's name if Include Name is ticked. If unassigned and Include Name is ticked, the name is prepended to the Bark Text.")]
	public Text nameText;

	[Tooltip("Show the barker's name.")]
	public bool includeName;

	[HideInInspector]
	public float doneTime;

	public AnimationTransitions animationTransitions = new AnimationTransitions();

	public float duration = 4f;

	public bool waitUntilSequenceEnds;

	public bool waitForContinueButton;

	public BarkSubtitleSetting textDisplaySetting;

	private Canvas canvas;

	private Animator animator;

	public bool IsPlaying => (Object)(object)canvas != (Object)null && ((Behaviour)canvas).enabled && DialogueTime.time < doneTime;

	public void Awake()
	{
		canvas = ((Component)this).GetComponentInChildren<Canvas>();
		animator = ((Component)this).GetComponentInChildren<Animator>();
		if ((Object)(object)animator == (Object)null && (Object)(object)canvasGroup != (Object)null)
		{
			animator = ((Component)canvasGroup).GetComponentInChildren<Animator>();
		}
	}

	public void Start()
	{
		if ((Object)(object)canvas != (Object)null)
		{
			if (waitForContinueButton && (Object)(object)canvas.worldCamera == (Object)null)
			{
				canvas.worldCamera = Camera.main;
			}
			((Behaviour)canvas).enabled = false;
		}
		if ((Object)(object)nameText != (Object)null)
		{
			((Component)nameText).gameObject.SetActive(includeName);
		}
	}

	public bool ShouldShowText(Subtitle subtitle)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		bool flag = (int)textDisplaySetting == 1 || ((int)textDisplaySetting == 0 && DialogueManager.DisplaySettings.subtitleSettings.showNPCSubtitlesDuringLine);
		bool flag2 = subtitle != null && !string.IsNullOrEmpty(subtitle.formattedText.text);
		return flag && flag2;
	}

	public void Bark(Subtitle subtitle)
	{
		if (!ShouldShowText(subtitle))
		{
			return;
		}
		SetUIElementsActive(value: false);
		string text = subtitle.formattedText.text;
		if (includeName)
		{
			if ((Object)(object)nameText != (Object)null)
			{
				nameText.text = subtitle.speakerInfo.Name;
			}
			else
			{
				text = $"{text}: {subtitle.formattedText.text}";
			}
		}
		if ((Object)(object)barkText != (Object)null)
		{
			barkText.text = text;
		}
		SetUIElementsActive(value: true);
		if (CanTriggerAnimations() && !string.IsNullOrEmpty(animationTransitions.showTrigger))
		{
			animator.SetTrigger(animationTransitions.showTrigger);
		}
		((MonoBehaviour)this).CancelInvoke("Hide");
		if (!waitUntilSequenceEnds && !waitForContinueButton)
		{
			((MonoBehaviour)this).Invoke("Hide", duration);
		}
		doneTime = DialogueTime.time + duration;
	}

	private void SetUIElementsActive(bool value)
	{
		if ((Object)(object)nameText != (Object)null && (Object)(object)((Component)nameText).gameObject != (Object)(object)((Component)this).gameObject)
		{
			((Component)nameText).gameObject.SetActive(value);
		}
		if ((Object)(object)barkText != (Object)null && (Object)(object)((Component)barkText).gameObject != (Object)(object)((Component)this).gameObject)
		{
			((Component)barkText).gameObject.SetActive(value);
		}
		if ((Object)(object)canvas != (Object)null && (Object)(object)((Component)canvas).gameObject != (Object)(object)((Component)this).gameObject)
		{
			((Component)canvas).gameObject.SetActive(value);
		}
		if (value && (Object)(object)canvas != (Object)null)
		{
			((Behaviour)canvas).enabled = true;
		}
	}

	public void OnBarkEnd(Transform actor)
	{
		if (waitUntilSequenceEnds && !waitForContinueButton)
		{
			Hide();
		}
	}

	public void OnContinue()
	{
		Hide();
	}

	private void Hide()
	{
		if (CanTriggerAnimations() && !string.IsNullOrEmpty(animationTransitions.hideTrigger))
		{
			if (!string.IsNullOrEmpty(animationTransitions.hideTrigger))
			{
				animator.ResetTrigger(animationTransitions.showTrigger);
			}
			animator.SetTrigger(animationTransitions.hideTrigger);
		}
		else if ((Object)(object)canvas != (Object)null)
		{
			((Behaviour)canvas).enabled = false;
		}
	}

	private bool CanTriggerAnimations()
	{
		return (Object)(object)animator != (Object)null && animationTransitions != null;
	}
}
