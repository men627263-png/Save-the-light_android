using System;
using System.Runtime.CompilerServices;
using PixelCrushers.DialogueSystem.UnityGUI;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Actor/Player/Selector")]
public class Selector : MonoBehaviour
{
	[Serializable]
	public class Reticle
	{
		public Texture2D inRange;

		public Texture2D outOfRange;

		public float width = 64f;

		public float height = 64f;
	}

	public enum SelectAt
	{
		CenterOfScreen,
		MousePosition,
		CustomPosition
	}

	public enum DistanceFrom
	{
		Camera,
		GameObject
	}

	public enum Dimension
	{
		In2D,
		In3D
	}

	private static LayerMask DefaultLayer = LayerMask.op_Implicit(1);

	[Tooltip("Layer mask to use when targeting objects; objects on others layers are ignored")]
	public LayerMask layerMask = DefaultLayer;

	[Tooltip("How to target")]
	public SelectAt selectAt;

	[Tooltip("How to compute range to targeted object")]
	public DistanceFrom distanceFrom;

	[Tooltip("Don't target objects farther than this; targets may still be unusable if beyond their usable range")]
	public float maxSelectionDistance = 30f;

	public Dimension runRaycasts = Dimension.In3D;

	[Tooltip("Tick to check all objects within raycast range for usables, even passing through obstacles")]
	public bool raycastAll;

	[Tooltip("")]
	public bool useDefaultGUI = true;

	[Tooltip("The GUI skin to use for the target's information (name and use message)")]
	public GUISkin guiSkin;

	[Tooltip("The name of the GUI style in the skin")]
	public string guiStyleName = "label";

	public TextAnchor alignment = (TextAnchor)1;

	public TextStyle textStyle = (TextStyle)1;

	public Color textStyleColor = Color.black;

	[Tooltip("The color of the information labels when the target is in range")]
	public Color inRangeColor = Color.yellow;

	[Tooltip("The color of the information labels when the target is out of range")]
	public Color outOfRangeColor = Color.gray;

	public Reticle reticle;

	public KeyCode useKey = (KeyCode)32;

	public string useButton = "Fire2";

	[Tooltip("Default use message; can be overridden in the target's Usable component")]
	public string defaultUseMessage = "(spacebar to interact)";

	[Tooltip("Tick to also broadcast to the usable object's children")]
	public bool broadcastToChildren = true;

	[Tooltip("Actor transform to send with OnUse; defaults to this transform")]
	public Transform actorTransform;

	[Tooltip("If set, show this alert message if attempt to use something beyond its usable range")]
	public string tooFarMessage = string.Empty;

	public UnityEvent tooFarEvent = new UnityEvent();

	[Tooltip("Tick to draw gizmos in Scene view")]
	public bool debug;

	private GameObject selection;

	private Usable usable;

	private GameObject clickedDownOn;

	private string heading = string.Empty;

	private string useMessage = string.Empty;

	private float distance;

	private GUIStyle guiStyle;

	private Ray lastRay = default;

	private RaycastHit lastHit = default;

	private RaycastHit[] lastHits = new RaycastHit[0];

	public Vector3 CustomPosition
	{
		[CompilerGenerated]
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return field;
		}
		[CompilerGenerated]
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			field = value;
		}
	}

	public Usable CurrentUsable => usable;

	public float CurrentDistance => distance;

	public GUIStyle GuiStyle
	{
		get
		{
			SetGuiStyle();
			return guiStyle;
		}
	}

	public event SelectedUsableObjectDelegate SelectedUsableObject;

	public event DeselectedUsableObjectDelegate DeselectedUsableObject;

	public Selector()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Expected Obj, but got Unknown
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Update()
	{
		if (!((Behaviour)this).enabled || Time.timeScale <= 0f || (Object)(object)Camera.main == (Object)null || (selectAt == SelectAt.MousePosition && (Object)(object)EventSystem.current != (Object)null && EventSystem.current.IsPointerOverGameObject()))
		{
			return;
		}
		switch (runRaycasts)
		{
		case Dimension.In2D:
			Run2DRaycast();
			break;
		default:
			Run3DRaycast();
			break;
		}
		if (!IsUseButtonDown() || !((Object)(object)usable != (Object)null))
		{
			return;
		}
		if (distance <= usable.maxUseDistance)
		{
			Transform val = ((!((Object)(object)actorTransform != (Object)null)) ? ((Component)this).transform : actorTransform);
			if (broadcastToChildren)
			{
				((Component)usable).gameObject.BroadcastMessage("OnUse", (object)val, (SendMessageOptions)1);
			}
			else
			{
				((Component)usable).gameObject.SendMessage("OnUse", (object)val, (SendMessageOptions)1);
			}
		}
		else
		{
			if (!string.IsNullOrEmpty(tooFarMessage))
			{
				DialogueManager.ShowAlert(tooFarMessage);
			}
			tooFarEvent.Invoke();
		}
	}

	private void Run2DRaycast()
	{
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		if (raycastAll)
		{
			RaycastHit2D[] array = Physics2D.RaycastAll(Vector2.op_Implicit(Camera.main.ScreenToWorldPoint(GetSelectionPoint())), Vector2.zero, maxSelectionDistance, LayerMask.op_Implicit(layerMask));
			bool flag = false;
			RaycastHit2D[] array2 = array;
			for (int i = 0; i < array2.Length; i++)
			{
				RaycastHit2D val = array2[i];
				float num = ((distanceFrom != DistanceFrom.Camera) ? Vector3.Distance(((Component)this).gameObject.transform.position, ((Component)val.collider).transform.position) : 0f);
				if ((Object)(object)selection == (Object)(object)((Component)val.collider).gameObject)
				{
					flag = true;
					distance = num;
					break;
				}
				Usable component = ((Component)val.collider).gameObject.GetComponent<Usable>();
				if ((Object)(object)component != (Object)null)
				{
					flag = true;
					distance = num;
					usable = component;
					selection = ((Component)val.collider).gameObject;
					if (SelectedUsableObject != null)
					{
						SelectedUsableObject(usable);
					}
					break;
				}
			}
			if (!flag)
			{
				DeselectTarget();
			}
			return;
		}
		RaycastHit2D val2 = Physics2D.Raycast(Vector2.op_Implicit(Camera.main.ScreenToWorldPoint(GetSelectionPoint())), Vector2.zero, maxSelectionDistance, LayerMask.op_Implicit(layerMask));
		if ((Object)(object)val2.collider != (Object)null)
		{
			distance = ((distanceFrom != DistanceFrom.Camera) ? Vector3.Distance(((Component)this).gameObject.transform.position, ((Component)val2.collider).transform.position) : 0f);
			if (!((Object)(object)selection != (Object)(object)((Component)val2.collider).gameObject))
			{
				return;
			}
			Usable component2 = ((Component)val2.collider).gameObject.GetComponent<Usable>();
			if ((Object)(object)component2 != (Object)null)
			{
				usable = component2;
				selection = ((Component)val2.collider).gameObject;
				heading = string.Empty;
				useMessage = string.Empty;
				if (SelectedUsableObject != null)
				{
					SelectedUsableObject(usable);
				}
			}
			else
			{
				DeselectTarget();
			}
		}
		else
		{
			DeselectTarget();
		}
	}

	private void Run3DRaycast()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		Ray val = (lastRay = Camera.main.ScreenPointToRay(GetSelectionPoint()));
		if (raycastAll)
		{
			RaycastHit[] array = Physics.RaycastAll(val, maxSelectionDistance, LayerMask.op_Implicit(layerMask));
			lastRay = val;
			lastHits = array;
			bool flag = false;
			RaycastHit[] array2 = array;
			for (int i = 0; i < array2.Length; i++)
			{
				RaycastHit val2 = array2[i];
				float num = ((distanceFrom != DistanceFrom.Camera) ? Vector3.Distance(((Component)this).gameObject.transform.position, ((Component)val2.collider).transform.position) : val2.distance);
				if ((Object)(object)selection == (Object)(object)((Component)val2.collider).gameObject)
				{
					flag = true;
					distance = num;
					break;
				}
				Usable component = ((Component)val2.collider).gameObject.GetComponent<Usable>();
				if ((Object)(object)component != (Object)null)
				{
					flag = true;
					distance = num;
					usable = component;
					selection = ((Component)val2.collider).gameObject;
					if (SelectedUsableObject != null)
					{
						SelectedUsableObject(usable);
					}
					break;
				}
			}
			if (!flag)
			{
				DeselectTarget();
			}
			return;
		}
		RaycastHit val3 = default;
		if (Physics.Raycast(val, ref val3, maxSelectionDistance, LayerMask.op_Implicit(layerMask)))
		{
			distance = ((distanceFrom != DistanceFrom.Camera) ? Vector3.Distance(((Component)this).gameObject.transform.position, ((Component)val3.collider).transform.position) : val3.distance);
			if ((Object)(object)selection != (Object)(object)((Component)val3.collider).gameObject)
			{
				Usable component2 = ((Component)val3.collider).gameObject.GetComponent<Usable>();
				if ((Object)(object)component2 != (Object)null)
				{
					usable = component2;
					selection = ((Component)val3.collider).gameObject;
					heading = string.Empty;
					useMessage = string.Empty;
					if (SelectedUsableObject != null)
					{
						SelectedUsableObject(usable);
					}
				}
				else
				{
					DeselectTarget();
				}
			}
		}
		else
		{
			DeselectTarget();
		}
		lastHit = val3;
	}

	private void DeselectTarget()
	{
		if ((Object)(object)usable != (Object)null && DeselectedUsableObject != null)
		{
			DeselectedUsableObject(usable);
		}
		usable = null;
		selection = null;
		heading = string.Empty;
		useMessage = string.Empty;
	}

	private bool IsUseButtonDown()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		if (!string.IsNullOrEmpty(useButton) && Input.GetButtonDown(useButton))
		{
			clickedDownOn = selection;
		}
		return ((int)useKey != 0 && Input.GetKeyDown(useKey)) || (!string.IsNullOrEmpty(useButton) && Input.GetButtonUp(useButton) && (Object)(object)selection == (Object)(object)clickedDownOn);
	}

	private Vector3 GetSelectionPoint()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		return selectAt switch
		{
			SelectAt.MousePosition => Input.mousePosition, 
			SelectAt.CustomPosition => CustomPosition, 
			_ => new Vector3((float)(Screen.width / 2), (float)(Screen.height / 2)), 
		};
	}

	public virtual void OnGUI()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Expected Obj, but got Unknown
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		if (!useDefaultGUI)
		{
			return;
		}
		SetGuiStyle();
		Rect val = new Rect(0f, 0f, (float)Screen.width, (float)Screen.height);
		if ((Object)(object)usable != (Object)null)
		{
			bool flag = distance <= usable.maxUseDistance;
			guiStyle.normal.textColor = ((!flag) ? outOfRangeColor : inRangeColor);
			if (string.IsNullOrEmpty(heading))
			{
				heading = usable.GetName();
				useMessage = ((!string.IsNullOrEmpty(usable.overrideUseMessage)) ? usable.overrideUseMessage : defaultUseMessage);
			}
			UnityGUITools.DrawText(val, heading, guiStyle, textStyle, textStyleColor);
			UnityGUITools.DrawText(new Rect(0f, guiStyle.CalcSize(new GUIContent("Ay")).y, (float)Screen.width, (float)Screen.height), useMessage, guiStyle, textStyle, textStyleColor);
			Texture2D val2 = ((!flag) ? reticle.outOfRange : reticle.inRange);
			if ((Object)(object)val2 != (Object)null)
			{
				GUI.Label(new Rect(0.5f * ((float)Screen.width - reticle.width), 0.5f * ((float)Screen.height - reticle.height), reticle.width, reticle.height), (Texture)(object)val2);
			}
		}
	}

	protected void SetGuiStyle()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Expected Obj, but got Unknown
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		GUI.skin = UnityGUITools.GetValidGUISkin(guiSkin);
		if (guiStyle == null)
		{
			guiStyle = new GUIStyle(GUI.skin.FindStyle(guiStyleName) ?? GUI.skin.label);
			guiStyle.alignment = alignment;
		}
	}

	public virtual void OnDrawGizmos()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		if (!debug)
		{
			return;
		}
		Gizmos.color = Color.yellow;
		Gizmos.DrawLine(lastRay.origin, lastRay.origin + lastRay.direction * maxSelectionDistance);
		if (raycastAll)
		{
			RaycastHit[] array = lastHits;
			for (int i = 0; i < array.Length; i++)
			{
				RaycastHit val = array[i];
				Gizmos.color = ((!((Object)(object)((Component)val.collider).GetComponent<Usable>() != (Object)null)) ? Color.red : Color.green);
				Gizmos.DrawWireSphere(val.point, 0.2f);
			}
		}
		else if ((Object)(object)lastHit.collider != (Object)null)
		{
			Gizmos.color = ((!((Object)(object)((Component)lastHit.collider).GetComponent<Usable>() != (Object)null)) ? Color.red : Color.green);
			Gizmos.DrawWireSphere(lastHit.point, 0.2f);
		}
	}

	static Selector()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
	}
}
