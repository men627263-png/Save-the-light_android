using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Dialogue/Unity UI Dialogue UI")]
public class UnityUIDialogueUI : AbstractDialogueUI
{
	private class QueuedAlert
	{
		public string message;

		public float duration;

		public QueuedAlert(string message, float duration)
		{
			this.message = message;
			this.duration = duration;
		}
	}

	[HideInInspector]
	public UnityUIRoot unityUIRoot;

	public UnityUIDialogueControls dialogue;

	public Graphic[] qteIndicators;

	public UnityUIAlertControls alert;

	[Tooltip("Always keep a control focused; useful for gamepads")]
	public bool autoFocus;

	[Tooltip("Look for OverrideUnityUIDialogueControls on actors")]
	public bool findActorOverrides;

	[Tooltip("Add an EventSystem if one isn't in the scene")]
	public bool addEventSystemIfNeeded = true;

	private UnityUIQTEControls qteControls;

	private Queue<QueuedAlert> alertQueue = new Queue<QueuedAlert>();

	private UnityUISubtitleControls originalNPCSubtitle;

	private UnityUISubtitleControls originalPCSubtitle;

	private UnityUIResponseMenuControls originalResponseMenu;

	private Dictionary<Transform, OverrideUnityUIDialogueControls> overrideCache = new Dictionary<Transform, OverrideUnityUIDialogueControls>();

	public override AbstractUIRoot UIRoot => (AbstractUIRoot)(object)unityUIRoot;

	public override AbstractDialogueUIControls Dialogue => (AbstractDialogueUIControls)(object)dialogue;

	public override AbstractUIQTEControls QTEs => (AbstractUIQTEControls)(object)qteControls;

	public override AbstractUIAlertControls Alert => (AbstractUIAlertControls)(object)alert;

	public override void Awake()
	{
		((AbstractDialogueUI)this).Awake();
		FindControls();
	}

	public virtual void OnEnable()
	{
		SceneManager.sceneLoaded -= OnSceneLoaded;
		SceneManager.sceneLoaded += OnSceneLoaded;
	}

	public virtual void OnDisable()
	{
		SceneManager.sceneLoaded -= OnSceneLoaded;
	}

	private void FindControls()
	{
		UITools.RequireEventSystem();
		qteControls = new UnityUIQTEControls(qteIndicators);
		if (DialogueDebug.LogErrors && DialogueDebug.LogWarnings)
		{
			if ((Object)(object)dialogue.npcSubtitle.line == (Object)null)
			{
				Debug.LogWarning((object)string.Format("{0}: UnityUIDialogueUI NPC Subtitle Line needs to be assigned.", "Dialogue System"));
			}
			if ((Object)(object)dialogue.pcSubtitle.line == (Object)null)
			{
				Debug.LogWarning((object)string.Format("{0}: UnityUIDialogueUI PC Subtitle Line needs to be assigned.", "Dialogue System"));
			}
			if (dialogue.responseMenu.buttons.Length == 0 && (Object)(object)dialogue.responseMenu.buttonTemplate == (Object)null)
			{
				Debug.LogWarning((object)string.Format("{0}: UnityUIDialogueUI Response buttons need to be assigned.", "Dialogue System"));
			}
			if ((Object)(object)alert.line == (Object)null)
			{
				Debug.LogWarning((object)string.Format("{0}: UnityUIDialogueUI Alert Line needs to be assigned.", "Dialogue System"));
			}
		}
		originalNPCSubtitle = dialogue.npcSubtitle;
		originalPCSubtitle = dialogue.pcSubtitle;
		originalResponseMenu = dialogue.responseMenu;
	}

	private OverrideUnityUIDialogueControls FindActorOverride(Transform actor)
	{
		if ((Object)(object)actor == (Object)null)
		{
			return null;
		}
		if (!overrideCache.ContainsKey(actor))
		{
			overrideCache.Add(actor, (!((Object)(object)actor != (Object)null)) ? null : ((Component)actor).GetComponentInChildren<OverrideUnityUIDialogueControls>());
		}
		return overrideCache[actor];
	}

	public void OnSceneLoaded(Scene scene, LoadSceneMode mode)
	{
		UITools.RequireEventSystem();
	}

	public override void Open()
	{
		overrideCache.Clear();
		((AbstractDialogueUI)this).Open();
	}

	public override void ShowAlert(string message, float duration)
	{
		if (alert.queueAlerts)
		{
			alertQueue.Enqueue(new QueuedAlert(message, duration));
			if (!((AbstractUIAlertControls)alert).IsVisible)
			{
				ShowNextQueuedAlert();
			}
		}
		else
		{
			StartShowingAlert(message, duration);
		}
	}

	public override void HideAlert()
	{
		((AbstractDialogueUI)this).HideAlert();
		if (alert.queueAlerts)
		{
			ShowNextQueuedAlert();
		}
	}

	public override void OnContinue()
	{
		((MonoBehaviour)this).CancelInvoke("HideAlert");
		((AbstractDialogueUI)this).OnContinue();
	}

	private void ShowNextQueuedAlert()
	{
		if (alertQueue.Count > 0)
		{
			QueuedAlert queuedAlert = alertQueue.Dequeue();
			StartShowingAlert(queuedAlert.message, queuedAlert.duration);
		}
	}

	private void StartShowingAlert(string message, float duration)
	{
		((AbstractDialogueUI)this).ShowAlert(message, duration);
		if (autoFocus)
		{
			alert.AutoFocus();
		}
		((MonoBehaviour)this).CancelInvoke("HideAlert");
		((MonoBehaviour)this).Invoke("HideAlert", duration);
	}

	public override void ShowSubtitle(Subtitle subtitle)
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Invalid comparison between Unknown and I4
		if (findActorOverrides && subtitle != null)
		{
			OverrideUnityUIDialogueControls overrideUnityUIDialogueControls = ((subtitle.speakerInfo == null) ? null : FindActorOverride(subtitle.speakerInfo.transform));
			if (subtitle.speakerInfo == null || (int)subtitle.speakerInfo.characterType == 1)
			{
				dialogue.npcSubtitle = ((!((Object)(object)overrideUnityUIDialogueControls != (Object)null)) ? originalNPCSubtitle : overrideUnityUIDialogueControls.subtitle);
			}
			else
			{
				dialogue.pcSubtitle = ((!((Object)(object)overrideUnityUIDialogueControls != (Object)null)) ? originalPCSubtitle : overrideUnityUIDialogueControls.subtitle);
			}
		}
		((AbstractDialogueUI)this).HideResponses();
		((AbstractDialogueUI)this).ShowSubtitle(subtitle);
		CheckSubtitleAutoFocus(subtitle);
	}

	public void CheckSubtitleAutoFocus(Subtitle subtitle)
	{
		if (autoFocus)
		{
			if (subtitle.speakerInfo.IsPlayer)
			{
				dialogue.pcSubtitle.AutoFocus();
			}
			else
			{
				dialogue.npcSubtitle.AutoFocus();
			}
		}
	}

	public override void ShowResponses(Subtitle subtitle, Response[] responses, float timeout)
	{
		if (findActorOverrides)
		{
			OverrideUnityUIDialogueControls overrideUnityUIDialogueControls = ((subtitle == null || subtitle.speakerInfo == null) ? null : FindActorOverride(subtitle.speakerInfo.transform));
			UnityUISubtitleControls subtitleReminder = ((!((Object)(object)overrideUnityUIDialogueControls != (Object)null)) ? originalResponseMenu.subtitleReminder : overrideUnityUIDialogueControls.subtitleReminder);
			if ((Object)(object)overrideUnityUIDialogueControls != (Object)null && (Object)(object)overrideUnityUIDialogueControls.responseMenu.panel != (Object)null)
			{
				dialogue.responseMenu = ((!((Object)(object)overrideUnityUIDialogueControls != (Object)null) || !((Object)(object)overrideUnityUIDialogueControls.responseMenu.panel != (Object)null)) ? originalResponseMenu : overrideUnityUIDialogueControls.responseMenu);
			}
			else
			{
				overrideUnityUIDialogueControls = ((subtitle == null || subtitle.listenerInfo == null) ? null : FindActorOverride(subtitle.listenerInfo.transform));
				dialogue.responseMenu = ((!((Object)(object)overrideUnityUIDialogueControls != (Object)null) || !((Object)(object)overrideUnityUIDialogueControls.responseMenu.panel != (Object)null)) ? originalResponseMenu : overrideUnityUIDialogueControls.responseMenu);
			}
			dialogue.responseMenu.subtitleReminder = subtitleReminder;
		}
		((AbstractDialogueUI)this).ShowResponses(subtitle, responses, timeout);
		CheckResponseMenuAutoFocus();
	}

	public void CheckResponseMenuAutoFocus()
	{
		if (autoFocus)
		{
			dialogue.responseMenu.AutoFocus();
		}
	}

	public override void HideResponses()
	{
		dialogue.responseMenu.DestroyInstantiatedButtons();
		((AbstractDialogueUI)this).HideResponses();
	}
}
