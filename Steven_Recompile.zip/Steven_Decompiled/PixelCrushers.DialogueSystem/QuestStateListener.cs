using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Events;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Miscellaneous/Quest Indicators/Quest State Listener")]
public class QuestStateListener : MonoBehaviour
{
	[Serializable]
	public class QuestStateIndicatorLevel
	{
		[Tooltip("Quest state to listen for.")]
		public QuestState questState;

		[Tooltip("Conditions that must also be true.")]
		public Condition condition;

		[Tooltip("Indicator level to use when this quest state is reached.")]
		public int indicatorLevel;

		public UnityEvent onEnterState = new UnityEvent();

		public QuestStateIndicatorLevel()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected Obj, but got Unknown
		}
	}

	[Serializable]
	public class QuestEntryStateIndicatorLevel
	{
		[Tooltip("Quest entry number.")]
		public int entryNumber;

		[Tooltip("Quest entry state to listen for.")]
		public QuestState questState;

		[Tooltip("Conditions that must also be true.")]
		public Condition condition;

		[Tooltip("Indicator level to use when this quest state is reached.")]
		public int indicatorLevel;

		public UnityEvent onEnterState = new UnityEvent();

		public QuestEntryStateIndicatorLevel()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected Obj, but got Unknown
		}
	}

	[QuestPopup(true)]
	public string questName;

	public QuestStateIndicatorLevel[] questStateIndicatorLevels = new QuestStateIndicatorLevel[0];

	public QuestEntryStateIndicatorLevel[] questEntryStateIndicatorLevels = new QuestEntryStateIndicatorLevel[0];

	private QuestStateDispatcher m_questStateDispatcher;

	private QuestStateIndicator m_questStateIndicator;

	private bool m_started;

	private void Awake()
	{
		m_questStateDispatcher = Object.FindObjectOfType<QuestStateDispatcher>();
		m_questStateIndicator = ((Component)this).GetComponent<QuestStateIndicator>();
		if ((Object)(object)m_questStateDispatcher == (Object)null)
		{
			if (DialogueDebug.LogWarnings)
			{
				Debug.LogWarning((object)("Dialogue System: " + ((Object)this).name + ": Can't find a QuestStateDispatcher on the Dialogue Manager."), (Object)(object)this);
			}
			((Behaviour)this).enabled = false;
		}
	}

	private IEnumerator Start()
	{
		yield return null;
		if (((Behaviour)this).enabled)
		{
			if (DialogueDebug.LogInfo)
			{
				Debug.Log((object)("Dialogue System: " + ((Object)this).name + ": Listening for state changes to quest '" + questName + "'."), (Object)(object)this);
			}
			m_started = true;
			m_questStateDispatcher.AddListener(this);
			UpdateIndicator();
		}
	}

	private void OnEnable()
	{
		if (m_started)
		{
			m_questStateDispatcher.AddListener(this);
		}
	}

	private void OnDisable()
	{
		if ((Object)(object)m_questStateDispatcher != (Object)null)
		{
			m_questStateDispatcher.RemoveListener(this);
		}
	}

	public void OnChange()
	{
		UpdateIndicator();
	}

	public void UpdateIndicator()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		QuestState questState = QuestLog.GetQuestState(questName);
		for (int i = 0; i < questStateIndicatorLevels.Length; i++)
		{
			QuestStateIndicatorLevel questStateIndicatorLevel = questStateIndicatorLevels[i];
			if (questState == questStateIndicatorLevel.questState && questStateIndicatorLevel.condition.IsTrue((Transform)null))
			{
				if (DialogueDebug.LogInfo)
				{
					Debug.Log((object)string.Concat(new object[7]
					{
						"Dialogue System: ",
						((Object)this).name,
						": Quest '",
						questName,
						"' changed to state ",
						questState,
						"."
					}), (Object)(object)this);
				}
				if ((Object)(object)m_questStateIndicator != (Object)null)
				{
					m_questStateIndicator.SetIndicatorLevel(this, questStateIndicatorLevel.indicatorLevel);
				}
				questStateIndicatorLevel.onEnterState.Invoke();
			}
		}
		for (int j = 0; j < questEntryStateIndicatorLevels.Length; j++)
		{
			QuestEntryStateIndicatorLevel questEntryStateIndicatorLevel = questEntryStateIndicatorLevels[j];
			QuestState questEntryState = QuestLog.GetQuestEntryState(questName, questEntryStateIndicatorLevel.entryNumber);
			if (questEntryState == questEntryStateIndicatorLevel.questState && questEntryStateIndicatorLevel.condition.IsTrue((Transform)null))
			{
				if (DialogueDebug.LogInfo)
				{
					Debug.Log((object)string.Concat(new object[9]
					{
						"Dialogue System: ",
						((Object)this).name,
						": Quest '",
						questName,
						"' entry ",
						questEntryStateIndicatorLevel.entryNumber,
						" changed to state ",
						questEntryState,
						"."
					}), (Object)(object)this);
				}
				if ((Object)(object)m_questStateIndicator != (Object)null)
				{
					m_questStateIndicator.SetIndicatorLevel(this, questEntryStateIndicatorLevel.indicatorLevel);
				}
				questEntryStateIndicatorLevel.onEnterState.Invoke();
			}
		}
	}
}
