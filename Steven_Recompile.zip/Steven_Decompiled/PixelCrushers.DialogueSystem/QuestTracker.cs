using System.Collections;
using System.Collections.Generic;
using PixelCrushers.DialogueSystem.UnityGUI;
using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity GUI/Quest/Quest Tracker HUD (add to Dialogue Manager)")]
public class QuestTracker : MonoBehaviour
{
	public enum QuestDescriptionSource
	{
		Title,
		Description
	}

	private class QuestTrackerLine
	{
		public string guiStyleName;

		public GUIStyle guiStyle;

		public string text;
	}

	public ScaledRect rect = new ScaledRect((ScaledRectAlignment)2, (ScaledRectAlignment)2, ScaledValue.FromPixelValue(0f), ScaledValue.FromPixelValue(0f), ScaledValue.FromNormalizedValue(0.25f), ScaledValue.FromNormalizedValue(1f), 64f, 32f);

	public GUISkin guiSkin;

	public string TitleStyle;

	public string SuccessTitleStyle;

	public string FailureTitleStyle;

	public string ActiveEntryStyle;

	public string SuccessEntryStyle;

	public string FailureEntryStyle;

	public bool showActiveQuests = true;

	public bool showCompletedQuests;

	public bool showCompletedEntryText;

	public QuestDescriptionSource questDescriptionSource;

	private Rect screenRect;

	private List<QuestTrackerLine> lines = new List<QuestTrackerLine>();

	public QuestTracker()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Expected Obj, but got Unknown
	}

	public void Start()
	{
		((MonoBehaviour)this).StartCoroutine(UpdateTrackerAfterOneFrame());
	}

	private IEnumerator UpdateTrackerAfterOneFrame()
	{
		yield return null;
		UpdateTracker();
	}

	public void OnQuestTrackingEnabled(string quest)
	{
		UpdateTracker();
	}

	public void OnQuestTrackingDisabled(string quest)
	{
		UpdateTracker();
	}

	public void OnConversationEnd(Transform actor)
	{
		UpdateTracker();
	}

	public void UpdateTracker()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		screenRect = rect.GetPixelRect();
		lines.Clear();
		QuestState val = (QuestState)((showActiveQuests ? 2 : 0) | (showCompletedQuests ? 12 : 0));
		string[] allQuests = QuestLog.GetAllQuests(val);
		foreach (string text in allQuests)
		{
			if (QuestLog.IsQuestTrackingEnabled(text))
			{
				AddQuestTitle(text);
				AddQuestEntries(text);
			}
		}
	}

	private void AddQuestTitle(string quest)
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		QuestTrackerLine questTrackerLine = new QuestTrackerLine();
		string text = ((questDescriptionSource != QuestDescriptionSource.Title) ? QuestLog.GetQuestDescription(quest) : QuestLog.GetQuestTitle(quest));
		questTrackerLine.text = FormattedText.Parse(text, DialogueManager.MasterDatabase.emphasisSettings).text;
		questTrackerLine.guiStyleName = GetTitleStyleName(QuestLog.GetQuestState(quest));
		questTrackerLine.guiStyle = null;
		lines.Add(questTrackerLine);
	}

	private void AddQuestEntries(string quest)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Invalid comparison between Unknown and I4
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		int questEntryCount = QuestLog.GetQuestEntryCount(quest);
		for (int i = 1; i <= questEntryCount; i++)
		{
			QuestState questEntryState = QuestLog.GetQuestEntryState(quest, i);
			if ((int)questEntryState != 1)
			{
				QuestTrackerLine questTrackerLine = new QuestTrackerLine();
				string questEntryText = GetQuestEntryText(quest, i, questEntryState);
				questTrackerLine.text = FormattedText.Parse(questEntryText, DialogueManager.MasterDatabase.emphasisSettings).text;
				questTrackerLine.guiStyleName = GetEntryStyleName(questEntryState);
				questTrackerLine.guiStyle = null;
				lines.Add(questTrackerLine);
			}
		}
	}

	private string GetQuestEntryText(string quest, int entryNum, QuestState entryState)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Invalid comparison between Unknown and I4
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Invalid comparison between Unknown and I4
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Invalid comparison between Unknown and I4
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Invalid comparison between Unknown and I4
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		if ((int)entryState == 1 || (int)entryState == 16)
		{
			return string.Empty;
		}
		if ((int)entryState == 4 && showCompletedEntryText)
		{
			Result questField = DialogueLua.GetQuestField(quest, "Entry " + entryNum + " Success");
			string asString = questField.AsString;
			if (!string.IsNullOrEmpty(asString))
			{
				return asString;
			}
		}
		else if ((int)entryState == 8 && showCompletedEntryText)
		{
			Result questField2 = DialogueLua.GetQuestField(quest, "Entry " + entryNum + " Failure");
			string asString2 = questField2.AsString;
			if (!string.IsNullOrEmpty(asString2))
			{
				return asString2;
			}
		}
		return QuestLog.GetQuestEntry(quest, entryNum);
	}

	private string GetTitleStyleName(QuestState state)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Expected I4, but got Unknown
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Invalid comparison between Unknown and I4
		switch (state - 2)
		{
		default:
			if ((int)state == 8)
			{
				return FailureTitleStyle;
			}
			return TitleStyle;
		case 0:
			return TitleStyle;
		case 2:
			return SuccessTitleStyle;
		}
	}

	private string GetEntryStyleName(QuestState entryState)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Expected I4, but got Unknown
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Invalid comparison between Unknown and I4
		switch (entryState - 2)
		{
		default:
			if ((int)entryState == 8)
			{
				return FailureEntryStyle;
			}
			return ActiveEntryStyle;
		case 0:
			return ActiveEntryStyle;
		case 2:
			return SuccessEntryStyle;
		}
	}

	private void OnGUI()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)guiSkin != (Object)null)
		{
			GUI.skin = guiSkin;
		}
		GUILayout.BeginArea(screenRect);
		foreach (QuestTrackerLine line in lines)
		{
			if (line.guiStyle == null)
			{
				line.guiStyle = UnityGUITools.GetGUIStyle(line.guiStyleName, GUI.skin.label);
			}
			GUILayout.Label(line.text, line.guiStyle, new GUILayoutOption[0]);
		}
		GUILayout.EndArea();
	}
}
