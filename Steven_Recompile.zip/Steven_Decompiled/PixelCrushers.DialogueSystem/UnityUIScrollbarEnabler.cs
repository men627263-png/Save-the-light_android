using System.Collections;
using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Effects/Unity UI Scrollbar Enabler")]
public class UnityUIScrollbarEnabler : MonoBehaviour
{
	public RectTransform container;

	public RectTransform content;

	public GameObject scrollbar;

	private bool started;

	private bool isChecking;

	private void Start()
	{
		started = true;
		CheckScrollbar();
	}

	public void OnEnable()
	{
		if (started)
		{
			CheckScrollbar();
		}
	}

	public void OnDisable()
	{
		isChecking = false;
	}

	public void CheckScrollbar()
	{
		if (!isChecking && !((Object)(object)container == (Object)null) && !((Object)(object)content == (Object)null) && !((Object)(object)scrollbar == (Object)null))
		{
			((MonoBehaviour)this).StartCoroutine(CheckScrollbarAfterUIUpdate());
		}
	}

	private IEnumerator CheckScrollbarAfterUIUpdate()
	{
		isChecking = true;
		yield return null;
		GameObject val = scrollbar;
		Rect rect = content.rect;
		float height = rect.height;
		Rect rect2 = container.rect;
		val.SetActive(height > rect2.height);
		isChecking = false;
	}
}
