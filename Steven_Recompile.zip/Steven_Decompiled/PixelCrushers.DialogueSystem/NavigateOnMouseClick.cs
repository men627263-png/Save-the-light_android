using UnityEngine;
using UnityEngine.AI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Actor/Player/Navigate On Mouse Click")]
[RequireComponent(typeof(NavMeshAgent))]
public class NavigateOnMouseClick : MonoBehaviour
{
	public enum MouseButtonType
	{
		Left,
		Right,
		Middle
	}

	public AnimationClip idle;

	public AnimationClip run;

	public MouseButtonType mouseButton;

	private Transform myTransform;

	private NavMeshAgent navMeshAgent;

	private Animation anim;

	private void Awake()
	{
		myTransform = ((Component)this).transform;
		anim = ((Component)this).GetComponent<Animation>();
		navMeshAgent = ((Component)this).GetComponent<NavMeshAgent>();
		if ((Object)(object)navMeshAgent == (Object)null)
		{
			Debug.LogWarning((object)string.Format("{0}: No NavMeshAgent found on {1}. Disabling {2}.", "Dialogue System", ((Object)this).name, ((object)this).GetType().Name));
			((Behaviour)this).enabled = false;
		}
	}

	private void Update()
	{
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		if (navMeshAgent.remainingDistance < 0.5f)
		{
			if ((Object)(object)idle != (Object)null && (Object)(object)anim != (Object)null)
			{
				anim.CrossFade(((Object)idle).name);
			}
		}
		else if ((Object)(object)run != (Object)null && (Object)(object)anim != (Object)null)
		{
			anim.CrossFade(((Object)run).name);
		}
		if (Input.GetMouseButtonDown((int)mouseButton) && GUIUtility.hotControl == 0)
		{
			Plane val = new Plane(Vector3.up, myTransform.position);
			Ray val2 = Camera.main.ScreenPointToRay(Input.mousePosition);
			float num = 0f;
			if (val.Raycast(val2, ref num))
			{
				navMeshAgent.SetDestination(val2.GetPoint(num));
			}
		}
		else if (Input.GetMouseButton((int)mouseButton) && GUIUtility.hotControl == 0)
		{
			Plane val3 = new Plane(Vector3.up, myTransform.position);
			Ray val4 = Camera.main.ScreenPointToRay(Input.mousePosition);
			float num2 = 0f;
			if (val3.Raycast(val4, ref num2))
			{
				navMeshAgent.SetDestination(val4.GetPoint(num2));
			}
		}
	}
}
