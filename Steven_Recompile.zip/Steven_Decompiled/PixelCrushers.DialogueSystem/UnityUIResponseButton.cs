using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Dialogue/Response Button")]
public class UnityUIResponseButton : MonoBehaviour
{
	public Button button;

	public Text label;

	[Tooltip("Set the button's text to this color by default")]
	public Color defaultColor = Color.white;

	[Tooltip("Apply emphasis tag colors to the button background")]
	public bool setButtonColor;

	[Tooltip("Apply emphasis tag colors to the button text")]
	public bool setLabelColor = true;

	public string Text
	{
		get
		{
			return (!((Object)(object)label != (Object)null)) ? string.Empty : label.text;
		}
		set
		{
			if ((Object)(object)label != (Object)null)
			{
				label.text = value;
				UITools.SendTextChangeMessage(label);
			}
			else if (DialogueDebug.LogErrors)
			{
				Debug.LogError((object)string.Format("{0}: No Text UI element is unassigned on {1}", new object[2]
				{
					"Dialogue System",
					((Object)this).name
				}));
			}
		}
	}

	public bool clickable
	{
		get
		{
			return (Object)(object)button != (Object)null && ((Selectable)button).interactable;
		}
		set
		{
			if ((Object)(object)button != (Object)null)
			{
				((Selectable)button).interactable = value;
			}
		}
	}

	public bool visible { get; set; }

	public Response response { get; set; }

	public Transform target { get; set; }

	public UnityUIResponseButton()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
	}

	public void Reset()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		Text = string.Empty;
		clickable = false;
		visible = false;
		response = null;
		SetColor(defaultColor);
	}

	public void SetFormattedText(FormattedText formattedText)
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		if (formattedText != null)
		{
			Text = UITools.GetUIFormattedText(formattedText);
			SetColor((formattedText.emphases.Length <= 0) ? defaultColor : formattedText.emphases[0].color);
		}
	}

	public void SetUnformattedText(string unformattedText)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		Text = unformattedText;
		SetColor(defaultColor);
	}

	protected virtual void SetColor(Color currentColor)
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)button != (Object)null) && DialogueDebug.LogWarnings)
		{
			Debug.LogWarning((object)string.Format("{0}: No Button is assigned to {1}", new object[2]
			{
				"Dialogue System",
				((Object)this).name
			}));
		}
		if ((Object)(object)label != (Object)null)
		{
			if (setLabelColor)
			{
				((Graphic)label).color = currentColor;
			}
		}
		else if (DialogueDebug.LogWarnings)
		{
			Debug.LogWarning((object)string.Format("{0}: No Text is assigned to {1}", new object[2]
			{
				"Dialogue System",
				((Object)this).name
			}));
		}
	}

	public void OnClick()
	{
		if ((Object)(object)target != (Object)null)
		{
			((Component)target).SendMessage("OnClick", (object)response, (SendMessageOptions)0);
		}
	}
}
