using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Save System/Persistent Destructible")]
public class PersistentDestructible : MonoBehaviour
{
	public enum RecordOn
	{
		Destroy,
		Disable
	}

	[Tooltip("Record destroyed on Destroy or Disable.")]
	public RecordOn recordOn;

	[Tooltip("Unique Dialogue System variable (Boolean) to record whether the GameObject has been destroyed/disabled.")]
	public string variableName = string.Empty;

	protected bool listenForOnDestroy;

	protected string ActualVariableName => (!string.IsNullOrEmpty(variableName)) ? variableName : OverrideActorName.GetInternalName(((Component)this).transform);

	protected virtual void OnEnable()
	{
		PersistentDataManager.RegisterPersistentData(((Component)this).gameObject);
		listenForOnDestroy = true;
	}

	public void OnApplyPersistentData()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		Result variable = DialogueLua.GetVariable(ActualVariableName);
		if (variable.AsBool)
		{
			((Component)this).gameObject.BroadcastMessage("OnLevelWillBeUnloaded", (SendMessageOptions)1);
			switch (recordOn)
			{
			case RecordOn.Destroy:
				Object.Destroy((Object)(object)((Component)this).gameObject);
				break;
			case RecordOn.Disable:
				((Component)this).gameObject.SetActive(false);
				break;
			}
		}
	}

	public void OnLevelWillBeUnloaded()
	{
		listenForOnDestroy = false;
	}

	public void OnApplicationQuit()
	{
		listenForOnDestroy = false;
	}

	public void OnDestroy()
	{
		if (listenForOnDestroy && recordOn == RecordOn.Destroy)
		{
			MarkDestroyed();
		}
	}

	private void MarkDestroyed()
	{
		DialogueLua.SetVariable(ActualVariableName, (object)true);
	}

	public void OnDisable()
	{
		if (listenForOnDestroy && recordOn == RecordOn.Disable)
		{
			MarkDestroyed();
			PersistentDataManager.UnregisterPersistentData(((Component)this).gameObject);
		}
	}
}
