using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Effects/Unity UI Ignore Pause Codes")]
[DisallowMultipleComponent]
public class UnityUIIgnorePauseCodes : MonoBehaviour
{
	private Text control;

	public void Awake()
	{
		control = ((Component)this).GetComponent<Text>();
	}

	public void Start()
	{
		CheckText();
	}

	public void OnEnable()
	{
		CheckText();
	}

	public void CheckText()
	{
		if ((Object)(object)control != (Object)null && control.text.Contains("\\"))
		{
			((MonoBehaviour)this).StartCoroutine(Clean());
		}
	}

	private IEnumerator Clean()
	{
		control.text = UnityUITypewriterEffect.StripRPGMakerCodes(control.text);
		yield return null;
		control.text = UnityUITypewriterEffect.StripRPGMakerCodes(control.text);
	}
}
