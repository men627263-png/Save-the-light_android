using UnityEngine;
using UnityEngine.Events;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Actor/Range Trigger")]
public class RangeTrigger : MonoBehaviour
{
	[Tooltip("These conditions must be true for the Range Trigger to affect GameObjects and components and invoke events")]
	public Condition condition;

	[Tooltip("Activate these GameObjects on trigger enter, deactivate them on trigger exit")]
	public GameObject[] gameObjects;

	[Tooltip("Enable these components on trigger enter, disable them on trigger exit")]
	public Component[] components;

	public UnityEvent onEnter = new UnityEvent();

	public UnityEvent onExit = new UnityEvent();

	public RangeTrigger()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected Obj, but got Unknown
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Expected Obj, but got Unknown
	}

	public void OnTriggerEnter(Collider other)
	{
		if (condition.IsTrue(((Component)other).transform))
		{
			SetTargets(value: true);
		}
	}

	public void OnTriggerExit(Collider other)
	{
		if (condition.IsTrue(((Component)other).transform))
		{
			SetTargets(value: false);
		}
	}

	public void OnTriggerEnter2D(Collider2D other)
	{
		if (condition.IsTrue(((Component)other).transform))
		{
			SetTargets(value: true);
		}
	}

	public void OnTriggerExit2D(Collider2D other)
	{
		if (condition.IsTrue(((Component)other).transform))
		{
			SetTargets(value: false);
		}
	}

	private void SetTargets(bool value)
	{
		GameObject[] array = gameObjects;
		foreach (GameObject val in array)
		{
			val.SetActive(value);
		}
		Component[] array2 = components;
		foreach (Component val2 in array2)
		{
			if (val2 is Collider)
			{
				((Collider)((val2 is Collider) ? val2 : null)).enabled = value;
			}
			else if (val2 is Renderer)
			{
				((Renderer)((val2 is Renderer) ? val2 : null)).enabled = value;
			}
			else if (val2 is Animation)
			{
				((Behaviour)((val2 is Animation) ? val2 : null)).enabled = value;
			}
			else if (val2 is Animator)
			{
				((Behaviour)((val2 is Animator) ? val2 : null)).enabled = value;
			}
			else if (val2 is Behaviour)
			{
				((Behaviour)((val2 is Behaviour) ? val2 : null)).enabled = value;
			}
			else if (DialogueDebug.LogWarnings)
			{
				Debug.LogWarning((object)string.Format("{0}: Internal error - Range Trigger doesn't know how to handle {1} of type {2}", new object[3]
				{
					"Dialogue System",
					val2,
					((object)val2).GetType().Name
				}));
			}
		}
		if (value)
		{
			onEnter.Invoke();
		}
		else
		{
			onExit.Invoke();
		}
	}
}
