using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Quest/Quest Track Template")]
public class UnityUIQuestTrackTemplate : MonoBehaviour
{
	[Header("Quest Heading")]
	[Tooltip("The heading - name or description depends on tracker setting")]
	public Text description;

	public UnityUIQuestTemplateAlternateDescriptions alternateDescriptions = new UnityUIQuestTemplateAlternateDescriptions();

	[Header("Quest Entries")]
	[Tooltip("(Optional) If set, holds instantiated quest entries")]
	public Transform entryContainer;

	[Tooltip("Used for quest entries")]
	public Text entryDescription;

	public UnityUIQuestTemplateAlternateDescriptions alternateEntryDescriptions = new UnityUIQuestTemplateAlternateDescriptions();

	private int numEntries;

	public bool ArePropertiesAssigned => (Object)(object)description != (Object)null && (Object)(object)entryDescription != (Object)null;

	public void Initialize()
	{
		if ((Object)(object)description != (Object)null)
		{
			((Component)description).gameObject.SetActive(false);
		}
		alternateDescriptions.SetActive(value: false);
		if ((Object)(object)entryDescription != (Object)null)
		{
			((Component)entryDescription).gameObject.SetActive(false);
		}
		alternateEntryDescriptions.SetActive(value: false);
		if ((Object)(object)entryContainer != (Object)null)
		{
			((Component)entryContainer).gameObject.SetActive(false);
		}
	}

	public void SetDescription(string text, QuestState questState)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected I4, but got Unknown
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Invalid comparison between Unknown and I4
		if (text == null)
		{
			return;
		}
		switch (questState - 2)
		{
		case 0:
			SetFirstValidTextElement(text, description);
			return;
		case 2:
			SetFirstValidTextElement(text, alternateDescriptions.successDescription, description);
			return;
		}
		if ((int)questState == 8)
		{
			SetFirstValidTextElement(text, alternateDescriptions.failureDescription, description);
		}
	}

	private void SetFirstValidTextElement(string text, params Text[] textElements)
	{
		for (int i = 0; i < textElements.Length; i++)
		{
			if ((Object)(object)textElements[i] != (Object)null)
			{
				((Component)textElements[i]).gameObject.SetActive(true);
				textElements[i].text = text;
				break;
			}
		}
	}

	public void AddEntryDescription(string text, QuestState entryState)
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Invalid comparison between Unknown and I4
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Invalid comparison between Unknown and I4
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Invalid comparison between Unknown and I4
		if ((Object)(object)entryContainer == (Object)null)
		{
			alternateEntryDescriptions.SetActive(value: false);
			if ((Object)(object)entryDescription != (Object)null)
			{
				if (numEntries == 0)
				{
					((Component)entryDescription).gameObject.SetActive(true);
					entryDescription.text = text;
				}
				else
				{
					Text val = entryDescription;
					val.text = val.text + "\n" + text;
				}
			}
		}
		else
		{
			if (numEntries == 0)
			{
				((Component)entryContainer).gameObject.SetActive(true);
				if ((Object)(object)entryDescription != (Object)null)
				{
					((Component)entryDescription).gameObject.SetActive(false);
				}
				alternateEntryDescriptions.SetActive(value: false);
			}
			if ((int)entryState != 2)
			{
				if ((int)entryState != 4)
				{
					if ((int)entryState == 8)
					{
						InstantiateFirstValidTextElement(text, entryContainer, alternateEntryDescriptions.failureDescription, entryDescription);
					}
				}
				else
				{
					InstantiateFirstValidTextElement(text, entryContainer, alternateEntryDescriptions.successDescription, entryDescription);
				}
			}
			else
			{
				InstantiateFirstValidTextElement(text, entryContainer, entryDescription);
			}
		}
		numEntries++;
	}

	private void InstantiateFirstValidTextElement(string text, Transform container, params Text[] textElements)
	{
		for (int i = 0; i < textElements.Length; i++)
		{
			if ((Object)(object)textElements[i] != (Object)null)
			{
				GameObject val = Object.Instantiate<GameObject>(((Component)textElements[i]).gameObject);
				val.transform.SetParent(((Component)container).transform, false);
				val.SetActive(true);
				Text component = val.GetComponent<Text>();
				if ((Object)(object)component != (Object)null)
				{
					component.text = text;
				}
				break;
			}
		}
	}
}
