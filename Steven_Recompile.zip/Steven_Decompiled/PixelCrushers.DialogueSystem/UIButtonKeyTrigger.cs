using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Effects/UI Button Key Trigger")]
public class UIButtonKeyTrigger : MonoBehaviour
{
	public KeyCode key;

	public string buttonName = string.Empty;

	private Button button;

	private void Awake()
	{
		button = ((Component)this).GetComponent<Button>();
		if ((Object)(object)button == (Object)null)
		{
			((Behaviour)this).enabled = false;
		}
	}

	private void Update()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Expected Obj, but got Unknown
		if (Input.GetKeyDown(key) || (!string.IsNullOrEmpty(buttonName) && Input.GetButtonDown(buttonName)))
		{
			PointerEventData val = new PointerEventData(EventSystem.current);
			ExecuteEvents.Execute<ISubmitHandler>(((Component)button).gameObject, (BaseEventData)(object)val, ExecuteEvents.submitHandler);
		}
	}
}
