using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Quest/Unity UI Quest Log Window")]
public class UnityUIQuestLogWindow : QuestLogWindow
{
	[Serializable]
	public class AnimationTransitions
	{
		public string showTrigger = "Show";

		public string hideTrigger = "Hide";
	}

	public Graphic mainPanel;

	public Button activeQuestsButton;

	public Button completedQuestsButton;

	public Graphic questTable;

	public UnityUIQuestGroupTemplate questGroupTemplate;

	public UnityUIQuestTemplate questTemplate;

	public Graphic abandonPopup;

	public Text abandonQuestTitle;

	public bool autoFocus;

	public UnityEvent onOpen = new UnityEvent();

	public UnityEvent onClose = new UnityEvent();

	public UnityEvent onContentChanged = new UnityEvent();

	public AnimationTransitions animationTransitions = new AnimationTransitions();

	private Action confirmAbandonQuestHandler;

	private UIShowHideController showHideController;

	private List<string> collapsedGroups = new List<string>();

	public UnityUIQuestLogWindow()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected Obj, but got Unknown
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Expected Obj, but got Unknown
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Expected Obj, but got Unknown
	}

	public override void Awake()
	{
		showHideController = new UIShowHideController(((Component)this).gameObject, (Component)(object)mainPanel);
	}

	public virtual void Start()
	{
		UITools.RequireEventSystem();
		Tools.SetGameObjectActive((Component)(object)mainPanel, false);
		Tools.SetGameObjectActive((Component)(object)abandonPopup, false);
		Tools.SetGameObjectActive((Component)(object)questGroupTemplate, false);
		Tools.SetGameObjectActive((Component)(object)questTemplate, false);
		SetStateButtonListeners();
		SetStateToggleButtons();
		if (DialogueDebug.LogWarnings)
		{
			if ((Object)(object)mainPanel == (Object)null)
			{
				Debug.LogWarning((object)string.Format("{0}: {1} Main Panel is unassigned", new object[2]
				{
					"Dialogue System",
					((Object)this).name
				}));
			}
			if ((Object)(object)questTable == (Object)null)
			{
				Debug.LogWarning((object)string.Format("{0}: {1} Quest Table is unassigned", new object[2]
				{
					"Dialogue System",
					((Object)this).name
				}));
			}
			if (base.useGroups && ((Object)(object)questTemplate == (Object)null || !questTemplate.ArePropertiesAssigned))
			{
				Debug.LogWarning((object)string.Format("{0}: {1} Quest Group Template or one of its properties is unassigned", new object[2]
				{
					"Dialogue System",
					((Object)this).name
				}));
			}
			if ((Object)(object)questTemplate == (Object)null || !questTemplate.ArePropertiesAssigned)
			{
				Debug.LogWarning((object)string.Format("{0}: {1} Quest Template or one of its properties is unassigned", new object[2]
				{
					"Dialogue System",
					((Object)this).name
				}));
			}
		}
	}

	public override void OpenWindow(Action openedWindowHandler)
	{
		showHideController.Show(animationTransitions.showTrigger, base.pauseWhileOpen, openedWindowHandler, wait: false);
		((QuestLogWindow)this).IsOpen = true;
		AutoFocus();
		onOpen.Invoke();
	}

	public void AutoFocus()
	{
		if (autoFocus && (Object)(object)EventSystem.current != (Object)null)
		{
			GameObject selectedGameObject = ((!((Component)completedQuestsButton).gameObject.activeSelf) ? ((Component)activeQuestsButton).gameObject : ((Component)completedQuestsButton).gameObject);
			EventSystem.current.SetSelectedGameObject(selectedGameObject);
		}
	}

	public override void CloseWindow(Action closedWindowHandler)
	{
		showHideController.Hide(animationTransitions.hideTrigger, closedWindowHandler);
		((QuestLogWindow)this).IsOpen = false;
		onClose.Invoke();
	}

	public override void OnQuestListUpdated()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Expected Obj, but got Unknown
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Expected Obj, but got Unknown
		if (!((Object)(object)questTable == (Object)null))
		{
			ClearQuestTable();
			if (((QuestLogWindow)this).Quests.Length == 0)
			{
				AddQuestToTable(new QuestInfo(string.Empty, new FormattedText(((QuestLogWindow)this).NoQuestsMessage, (Emphasis[])null, false, -1, true, 0, 0, 0, (string)null), FormattedText.empty, new FormattedText[0], new QuestState[0], false, false, false), 0);
			}
			else
			{
				AddQuestsToTable();
			}
			SetStateToggleButtons();
		}
	}

	private void SetStateButtonListeners()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Expected Obj, but got Unknown
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Expected Obj, but got Unknown
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Expected Obj, but got Unknown
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Expected Obj, but got Unknown
		if ((Object)(object)activeQuestsButton != (Object)null)
		{
			((UnityEvent)activeQuestsButton.onClick).RemoveListener((UnityAction)(() =>
			{
				((QuestLogWindow)this).ClickShowActiveQuestsButton();
			}));
			((UnityEvent)activeQuestsButton.onClick).AddListener((UnityAction)(() =>
			{
				((QuestLogWindow)this).ClickShowActiveQuestsButton();
			}));
		}
		if ((Object)(object)completedQuestsButton != (Object)null)
		{
			((UnityEvent)completedQuestsButton.onClick).RemoveListener((UnityAction)(() =>
			{
				((QuestLogWindow)this).ClickShowCompletedQuestsButton();
			}));
			((UnityEvent)completedQuestsButton.onClick).AddListener((UnityAction)(() =>
			{
				((QuestLogWindow)this).ClickShowCompletedQuestsButton();
			}));
		}
	}

	private void SetStateToggleButtons()
	{
		if ((Object)(object)activeQuestsButton != (Object)null)
		{
			((Selectable)activeQuestsButton).interactable = !((QuestLogWindow)this).IsShowingActiveQuests;
		}
		if ((Object)(object)completedQuestsButton != (Object)null)
		{
			((Selectable)completedQuestsButton).interactable = ((QuestLogWindow)this).IsShowingActiveQuests;
		}
	}

	private void ClearQuestTable()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Expected Obj, but got Unknown
		if ((Object)(object)questTable == (Object)null)
		{
			return;
		}
		foreach (Transform item in ((Component)questTable).transform)
		{
			Transform val = item;
			if (((Component)val).gameObject.activeSelf)
			{
				Object.Destroy((Object)(object)((Component)val).gameObject);
			}
		}
		NotifyContentChanged();
	}

	private void AddQuestsToTable()
	{
		if ((Object)(object)questTable == (Object)null)
		{
			return;
		}
		string text = null;
		bool flag = false;
		for (int i = 0; i < ((QuestLogWindow)this).Quests.Length; i++)
		{
			if (!string.Equals(((QuestLogWindow)this).Quests[i].Group, text))
			{
				text = ((QuestLogWindow)this).Quests[i].Group;
				AddQuestGroupToTable(text);
				flag = collapsedGroups.Contains(text);
			}
			if (!flag)
			{
				AddQuestToTable(((QuestLogWindow)this).Quests[i], i);
			}
		}
		NotifyContentChanged();
	}

	private void AddQuestGroupToTable(string group)
	{
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Expected Obj, but got Unknown
		if (string.IsNullOrEmpty(group) || (Object)(object)questGroupTemplate == (Object)null || !questGroupTemplate.ArePropertiesAssigned)
		{
			return;
		}
		GameObject val = Object.Instantiate<GameObject>(((Component)questGroupTemplate).gameObject);
		if ((Object)(object)val == (Object)null)
		{
			Debug.LogError((object)string.Format("{0}: {1} couldn't instantiate quest group template", new object[2]
			{
				"Dialogue System",
				((Object)this).name
			}));
			return;
		}
		((Object)val).name = group;
		val.transform.SetParent(((Component)questTable).transform, false);
		val.SetActive(true);
		UnityUIQuestGroupTemplate component = val.GetComponent<UnityUIQuestGroupTemplate>();
		if ((Object)(object)component == (Object)null)
		{
			return;
		}
		component.Initialize();
		component.heading.text = group;
		Button componentInChildren = val.GetComponentInChildren<Button>();
		if ((Object)(object)componentInChildren != (Object)null)
		{
			((UnityEvent)componentInChildren.onClick).AddListener((UnityAction)(() =>
			{
				ClickQuestGroupFoldout(group);
			}));
		}
	}

	private void AddQuestToTable(QuestInfo questInfo, int questIndex)
	{
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Expected Obj, but got Unknown
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Expected Obj, but got Unknown
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Expected Obj, but got Unknown
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Expected Obj, but got Unknown
		//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b5: Expected Obj, but got Unknown
		if ((Object)(object)questTable == (Object)null || (Object)(object)questTemplate == (Object)null || !questTemplate.ArePropertiesAssigned)
		{
			return;
		}
		GameObject val = Object.Instantiate<GameObject>(((Component)questTemplate).gameObject);
		if ((Object)(object)val == (Object)null)
		{
			Debug.LogError((object)string.Format("{0}: {1} couldn't instantiate quest template", new object[2]
			{
				"Dialogue System",
				((Object)this).name
			}));
			return;
		}
		((Object)val).name = questInfo.Heading.text;
		val.transform.SetParent(((Component)questTable).transform, false);
		val.SetActive(true);
		UnityUIQuestTemplate component = val.GetComponent<UnityUIQuestTemplate>();
		if ((Object)(object)component == (Object)null)
		{
			return;
		}
		component.Initialize();
		Button heading = component.heading;
		Text componentInChildren = ((Component)heading).GetComponentInChildren<Text>();
		if ((Object)(object)componentInChildren != (Object)null)
		{
			componentInChildren.text = questInfo.Heading.text;
		}
		((UnityEvent)heading.onClick).AddListener((UnityAction)(() =>
		{
			ClickQuestFoldout(questInfo.Title);
		}));
		if (((QuestLogWindow)this).IsSelectedQuest(questInfo))
		{
			if ((int)base.questHeadingSource == 0)
			{
				component.description.text = questInfo.Description.text;
				Tools.SetGameObjectActive((Component)(object)component.description, true);
			}
			if (questInfo.EntryStates.Length > 0)
			{
				for (int num = 0; num < questInfo.Entries.Length; num++)
				{
					component.AddEntryDescription(questInfo.Entries[num].text, questInfo.EntryStates[num]);
				}
			}
			UnityUIQuestTitle unityUIQuestTitle = null;
			if ((Object)(object)component.trackButton != (Object)null)
			{
				unityUIQuestTitle = ((Component)component.trackButton).gameObject.AddComponent<UnityUIQuestTitle>();
				unityUIQuestTitle.questTitle = questInfo.Title;
				((UnityEvent)component.trackButton.onClick).RemoveListener((UnityAction)(() =>
				{
					((QuestLogWindow)this).ClickTrackQuestButton();
				}));
				((UnityEvent)component.trackButton.onClick).AddListener((UnityAction)(() =>
				{
					((QuestLogWindow)this).ClickTrackQuestButton();
				}));
				Tools.SetGameObjectActive((Component)(object)component.trackButton, questInfo.Trackable);
			}
			if ((Object)(object)component.abandonButton != (Object)null)
			{
				unityUIQuestTitle = ((Component)component.abandonButton).gameObject.AddComponent<UnityUIQuestTitle>();
				unityUIQuestTitle.questTitle = questInfo.Title;
				((UnityEvent)component.abandonButton.onClick).RemoveListener((UnityAction)(() =>
				{
					((QuestLogWindow)this).ClickAbandonQuestButton();
				}));
				((UnityEvent)component.abandonButton.onClick).AddListener((UnityAction)(() =>
				{
					((QuestLogWindow)this).ClickAbandonQuestButton();
				}));
				Tools.SetGameObjectActive((Component)(object)component.abandonButton, questInfo.Abandonable);
			}
		}
		else
		{
			Tools.SetGameObjectActive((Component)(object)component.description, false);
			Tools.SetGameObjectActive((Component)(object)component.entryDescription, false);
			Tools.SetGameObjectActive((Component)(object)component.trackButton, false);
			Tools.SetGameObjectActive((Component)(object)component.abandonButton, false);
		}
	}

	public void NotifyContentChanged()
	{
		onContentChanged.Invoke();
	}

	public void ClickQuestFoldout(string questTitle)
	{
		((QuestLogWindow)this).ClickQuest((object)questTitle);
	}

	public void ClickQuestGroupFoldout(string group)
	{
		if (collapsedGroups.Contains(group))
		{
			collapsedGroups.Remove(group);
		}
		else
		{
			collapsedGroups.Add(group);
		}
		((QuestLogWindow)this).OnQuestListUpdated();
	}

	private void OnTrackButtonClicked(GameObject button)
	{
		((QuestLogWindow)this).SelectedQuest = button.GetComponent<UnityUIQuestTitle>().questTitle;
		((QuestLogWindow)this).ClickTrackQuest((object)((QuestLogWindow)this).SelectedQuest);
	}

	private void OnAbandonButtonClicked(GameObject button)
	{
		((QuestLogWindow)this).SelectedQuest = button.GetComponent<UnityUIQuestTitle>().questTitle;
		((QuestLogWindow)this).ClickAbandonQuest((object)((QuestLogWindow)this).SelectedQuest);
	}

	public override void ConfirmAbandonQuest(string title, Action confirmAbandonQuestHandler)
	{
		this.confirmAbandonQuestHandler = confirmAbandonQuestHandler;
		OpenAbandonPopup(title);
	}

	private void OpenAbandonPopup(string title)
	{
		if (!((Object)(object)abandonPopup != (Object)null))
		{
			return;
		}
		Tools.SetGameObjectActive((Component)(object)abandonPopup, true);
		if ((Object)(object)abandonQuestTitle != (Object)null)
		{
			abandonQuestTitle.text = title;
		}
		if (autoFocus && (Object)(object)EventSystem.current != (Object)null)
		{
			Button componentInChildren = ((Component)abandonPopup).GetComponentInChildren<Button>();
			if ((Object)(object)componentInChildren != (Object)null)
			{
				EventSystem.current.SetSelectedGameObject(((Component)componentInChildren).gameObject);
			}
		}
		else
		{
			confirmAbandonQuestHandler();
		}
	}

	private void CloseAbandonPopup()
	{
		Tools.SetGameObjectActive((Component)(object)abandonPopup, false);
	}

	public void ClickConfirmAbandonQuestButton()
	{
		CloseAbandonPopup();
		confirmAbandonQuestHandler();
	}

	public void ClickCancelAbandonQuestButton()
	{
		CloseAbandonPopup();
	}
}
