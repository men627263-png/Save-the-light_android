using System.Collections.Generic;
using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Miscellaneous/Quest Indicators/Quest State Indicator")]
public class QuestStateIndicator : MonoBehaviour
{
	[Tooltip("GameObject such as a world space canvas element associated with each indicator level. A typical use is to associate indicator level 0 = nothing (unassigned), level 1 = question mark, and level 2 = exclamation mark.")]
	public GameObject[] indicators = new GameObject[0];

	private List<List<QuestStateListener>> m_currentIndicatorCount = new List<List<QuestStateListener>>();

	private void Awake()
	{
		InitializeCurrentIndicatorCount();
	}

	private void Start()
	{
		UpdateIndicator();
	}

	private void InitializeCurrentIndicatorCount()
	{
		m_currentIndicatorCount.Clear();
		for (int i = 0; i < indicators.Length; i++)
		{
			m_currentIndicatorCount.Add(new List<QuestStateListener>());
		}
	}

	public void SetIndicatorLevel(QuestStateListener listener, int indicatorLevel)
	{
		if (DialogueDebug.LogInfo)
		{
			Debug.Log((object)string.Concat(new object[7]
			{
				"Dialogue System: ",
				((Object)this).name,
				": SetIndicatorLevel(",
				listener,
				", ",
				indicatorLevel,
				")"
			}), (Object)(object)listener);
		}
		for (int i = 0; i < indicators.Length; i++)
		{
			if (m_currentIndicatorCount[i].Contains(listener))
			{
				m_currentIndicatorCount[i].Remove(listener);
				break;
			}
		}
		if (0 <= indicatorLevel && indicatorLevel < indicators.Length)
		{
			m_currentIndicatorCount[indicatorLevel].Add(listener);
		}
		UpdateIndicator();
	}

	public void UpdateIndicator()
	{
		for (int i = 0; i < indicators.Length; i++)
		{
			if ((Object)(object)indicators[i] != (Object)null)
			{
				indicators[i].SetActive(false);
			}
		}
		for (int num = indicators.Length - 1; num >= 0; num--)
		{
			if (m_currentIndicatorCount[num].Count > 0)
			{
				if ((Object)(object)indicators[num] != (Object)null)
				{
					indicators[num].SetActive(true);
					if (DialogueDebug.LogInfo)
					{
						Debug.Log((object)("Dialogue System: " + ((Object)this).name + ": Activating GameObject associated with indicator level " + num), (Object)(object)this);
					}
				}
				break;
			}
		}
	}
}
