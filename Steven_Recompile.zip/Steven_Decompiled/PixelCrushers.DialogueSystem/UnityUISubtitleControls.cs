using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[Serializable]
public class UnityUISubtitleControls : AbstractUISubtitleControls
{
	[Serializable]
	public class AnimationTransitions
	{
		public string showTrigger = string.Empty;

		public string hideTrigger = string.Empty;
	}

	[Tooltip("Optional panel for the subtitle elements")]
	public Graphic panel;

	[Tooltip("Subtitle text")]
	public Text line;

	[Tooltip("Optional image for speaker's portrait")]
	public Image portraitImage;

	[Tooltip("Optional label for speaker's name")]
	public Text portraitName;

	[Tooltip("Optional continue button; configure OnClick to invoke dialogue UI's OnContinue method")]
	public Button continueButton;

	[Tooltip("Ignore RPGMaker-style pause codes")]
	public bool ignorePauseCodes;

	[Tooltip("Optional animation transitions; panel should have an Animator")]
	public AnimationTransitions animationTransitions = new AnimationTransitions();

	[Tooltip("Never hide this subtitle panel")]
	public bool alwaysVisible;

	private bool haveSavedOriginalColor;

	private Color originalColor = Color.white;

	private UIShowHideController showHideController;

	public override bool HasText => (Object)(object)line != (Object)null && !string.IsNullOrEmpty(line.text);

	public UnityUISubtitleControls()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
	}

	public override void SetActive(bool value)
	{
		if (value || alwaysVisible)
		{
			ShowPanel();
		}
		else
		{
			HidePanel();
		}
	}

	private void ShowPanel()
	{
		ShowControls();
		CheckShowHideController();
		showHideController.Show(animationTransitions.showTrigger, pause: false, null);
	}

	private void HidePanel()
	{
		CheckShowHideController();
		showHideController.Hide(animationTransitions.hideTrigger, HideControls);
	}

	private void CheckShowHideController()
	{
		if (showHideController == null)
		{
			showHideController = new UIShowHideController(null, (Component)(object)panel);
		}
	}

	private void ShowControls()
	{
		Tools.SetGameObjectActive((Component)(object)line, true);
		Tools.SetGameObjectActive((Component)(object)portraitImage, true);
		Tools.SetGameObjectActive((Component)(object)portraitName, true);
		Tools.SetGameObjectActive((Component)(object)continueButton, true);
	}

	private void HideControls()
	{
		Tools.SetGameObjectActive((Component)(object)line, alwaysVisible);
		Tools.SetGameObjectActive((Component)(object)portraitImage, alwaysVisible);
		Tools.SetGameObjectActive((Component)(object)portraitName, alwaysVisible);
		Tools.SetGameObjectActive((Component)(object)continueButton, alwaysVisible);
	}

	public override void ShowContinueButton()
	{
		Tools.SetGameObjectActive((Component)(object)continueButton, true);
	}

	public override void HideContinueButton()
	{
		Tools.SetGameObjectActive((Component)(object)continueButton, false);
	}

	public override void SetSubtitle(Subtitle subtitle)
	{
		if (subtitle != null && !string.IsNullOrEmpty(subtitle.formattedText.text))
		{
			if ((Object)(object)portraitImage != (Object)null)
			{
				portraitImage.sprite = UITools.CreateSprite(subtitle.GetSpeakerPortrait());
			}
			if ((Object)(object)portraitName != (Object)null)
			{
				portraitName.text = subtitle.speakerInfo.Name;
				UITools.SendTextChangeMessage(portraitName);
			}
			if ((Object)(object)line != (Object)null)
			{
				UnityUITypewriterEffect component = ((Component)line).GetComponent<UnityUITypewriterEffect>();
				if ((Object)(object)component != (Object)null && ((Behaviour)component).enabled)
				{
					component.Stop();
				}
				SetFormattedText(line, subtitle.formattedText);
				if ((Object)(object)component != (Object)null && ((Behaviour)component).enabled)
				{
					component.OnEnable();
				}
			}
			((AbstractUIControls)this).Show();
			if (alwaysVisible && (Object)(object)line != (Object)null)
			{
				UnityUITypewriterEffect component2 = ((Component)line).GetComponent<UnityUITypewriterEffect>();
				if ((Object)(object)component2 != (Object)null)
				{
					component2.OnEnable();
				}
			}
		}
		else
		{
			if ((Object)(object)line != (Object)null && subtitle != null)
			{
				SetFormattedText(line, subtitle.formattedText);
			}
			((AbstractUIControls)this).Hide();
		}
	}

	public override void ClearSubtitle()
	{
		SetFormattedText(line, null);
	}

	private void SetFormattedText(Text label, FormattedText formattedText)
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)label != (Object)null))
		{
			return;
		}
		if (formattedText != null)
		{
			string text = UITools.GetUIFormattedText(formattedText);
			if (ignorePauseCodes)
			{
				text = UnityUITypewriterEffect.StripRPGMakerCodes(text);
			}
			label.text = text;
			UITools.SendTextChangeMessage(label);
			if (!haveSavedOriginalColor)
			{
				originalColor = ((Graphic)label).color;
				haveSavedOriginalColor = true;
			}
			((Graphic)label).color = ((formattedText.emphases.Length <= 0) ? originalColor : formattedText.emphases[0].color);
		}
		else
		{
			label.text = string.Empty;
		}
	}

	public override void SetActorPortraitTexture(string actorName, Texture2D portraitTexture)
	{
		if (base.currentSubtitle != null && string.Equals(base.currentSubtitle.speakerInfo.nameInDatabase, actorName) && (Object)(object)portraitImage != (Object)null)
		{
			portraitImage.sprite = UITools.CreateSprite(AbstractDialogueUI.GetValidPortraitTexture(actorName, portraitTexture));
		}
	}

	public void AutoFocus()
	{
		if ((Object)(object)continueButton != (Object)null && (Object)(object)EventSystem.current != (Object)null)
		{
			EventSystem.current.SetSelectedGameObject(((Component)continueButton).gameObject, (BaseEventData)null);
		}
	}
}
