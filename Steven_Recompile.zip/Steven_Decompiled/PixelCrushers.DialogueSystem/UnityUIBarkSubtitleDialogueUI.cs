using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Dialogue/Bark Subtitle Dialogue UI")]
public class UnityUIBarkSubtitleDialogueUI : UnityUIDialogueUI
{
	public override void ShowSubtitle(Subtitle subtitle)
	{
		UnityUIBarkUI componentInChildren = ((Component)subtitle.speakerInfo.transform).GetComponentInChildren<UnityUIBarkUI>();
		if ((Object)(object)componentInChildren == (Object)null)
		{
			Debug.Log((object)("Null bark UI: " + subtitle.formattedText.text));
		}
		else
		{
			componentInChildren.Bark(subtitle);
		}
		((AbstractDialogueUI)this).HideResponses();
	}
}
