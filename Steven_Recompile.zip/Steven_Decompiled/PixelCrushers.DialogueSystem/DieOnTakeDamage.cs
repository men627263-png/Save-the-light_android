using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Actor/Die On TakeDamage")]
public class DieOnTakeDamage : MonoBehaviour
{
	public GameObject deadPrefab;

	private void TakeDamage(float damage)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)deadPrefab != (Object)null)
		{
			GameObject val = Object.Instantiate<GameObject>(deadPrefab, ((Component)this).transform.position, ((Component)this).transform.rotation);
			if ((Object)(object)val != (Object)null)
			{
				val.transform.parent = ((Component)this).transform.parent;
			}
		}
		Object.Destroy((Object)(object)((Component)this).gameObject);
	}

	private void Damage(float damage)
	{
		TakeDamage(damage);
	}
}
