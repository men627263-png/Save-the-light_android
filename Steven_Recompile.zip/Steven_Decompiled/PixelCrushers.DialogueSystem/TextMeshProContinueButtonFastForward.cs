using PixelCrushers.DialogueSystem.TextMeshPro;
using UnityEngine;

namespace PixelCrushers.DialogueSystem;

public class TextMeshProContinueButtonFastForward : MonoBehaviour
{
	public TextMeshProDialogueUI dialogueUI;

	public TextMeshProTypewriterEffect typewriterEffect;

	public GameObject dialoguePanel;

	public Animator animator;

	public virtual void Awake()
	{
		if ((Object)(object)dialogueUI == (Object)null)
		{
			dialogueUI = Tools.GetComponentAnywhere<TextMeshProDialogueUI>(((Component)this).gameObject);
		}
		if ((Object)(object)typewriterEffect == (Object)null)
		{
			typewriterEffect = ((Component)this).GetComponentInChildren<TextMeshProTypewriterEffect>();
		}
	}

	public virtual void OnFastForward()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		if (!((Behaviour)this).enabled || !(dialoguePanel.transform.localScale.x > 0.9f) || !typewriterEffect.startedEffect)
		{
			return;
		}
		if ((Object)(object)typewriterEffect != (Object)null && typewriterEffect.IsPlaying)
		{
			typewriterEffect.Stop();
			if ((Object)(object)animator != (Object)null)
			{
				animator.Play("DialoguePopup_ContinueButton_X");
			}
		}
		else if ((Object)(object)dialogueUI != (Object)null && typewriterEffect.ReachedMinDisplayTime() && typewriterEffect.ShowingAllCharacters())
		{
			((AbstractDialogueUI)dialogueUI).OnContinue();
			if ((Object)(object)animator != (Object)null)
			{
				animator.Play("DialoguePopup_ContinueButton_X");
			}
		}
	}
}
