using System.Collections.Generic;
using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Quest/Unity UI Quest Tracker HUD (on Dialogue Manager or child)")]
public class UnityUIQuestTracker : MonoBehaviour
{
	public enum QuestDescriptionSource
	{
		Title,
		Description
	}

	[Tooltip("UI container that will hold instances of quest track template.")]
	public Transform container;

	[Tooltip("Show Container even if there's nothing to track.")]
	public bool showContainerIfEmpty = true;

	[Tooltip("Template to instantiate for each tracked quest.")]
	public UnityUIQuestTrackTemplate questTrackTemplate;

	[Tooltip("Show active quests.")]
	public bool showActiveQuests = true;

	[Tooltip("Show successful and failed quests.")]
	public bool showCompletedQuests;

	[Tooltip("Show Entry n Success or Entry n Failure text if quest entry is in success/failure state.")]
	public bool showCompletedEntryText;

	[Tooltip("Source for the quest tracker text.")]
	public QuestDescriptionSource questDescriptionSource;

	private List<GameObject> instantiatedItems = new List<GameObject>();

	public void Start()
	{
		if ((Object)(object)container == (Object)null)
		{
			Debug.LogWarning((object)string.Format("{0}: {1} Container is unassigned", new object[2]
			{
				"Dialogue System",
				((Object)this).name
			}));
		}
		if ((Object)(object)questTrackTemplate == (Object)null)
		{
			Debug.LogWarning((object)string.Format("{0}: {1} Quest Track Template is unassigned", new object[2]
			{
				"Dialogue System",
				((Object)this).name
			}));
		}
		else
		{
			((Component)questTrackTemplate).gameObject.SetActive(false);
		}
		((MonoBehaviour)this).Invoke("UpdateTracker", 0.5f);
	}

	public void OnQuestTrackingEnabled(string quest)
	{
		UpdateTracker();
	}

	public void OnQuestTrackingDisabled(string quest)
	{
		UpdateTracker();
	}

	public void OnConversationEnd(Transform actor)
	{
		UpdateTracker();
	}

	public void UpdateTracker()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		DestroyInstantiatedItems();
		int num = 0;
		QuestState val = (QuestState)((showActiveQuests ? 2 : 0) | (showCompletedQuests ? 12 : 0));
		string[] allQuests = QuestLog.GetAllQuests(val);
		foreach (string text in allQuests)
		{
			if (QuestLog.IsQuestTrackingEnabled(text))
			{
				InstantiateQuestTrack(text);
				num++;
			}
		}
		if ((Object)(object)container != (Object)null)
		{
			((Component)container).gameObject.SetActive(showContainerIfEmpty || num > 0);
		}
	}

	public void DestroyInstantiatedItems()
	{
		foreach (GameObject instantiatedItem in instantiatedItems)
		{
			Object.Destroy((Object)(object)instantiatedItem);
		}
		instantiatedItems.Clear();
	}

	private void InstantiateQuestTrack(string quest)
	{
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)container == (Object)null || (Object)(object)questTrackTemplate == (Object)null)
		{
			return;
		}
		GameObject val = Object.Instantiate<GameObject>(((Component)questTrackTemplate).gameObject);
		if ((Object)(object)val == (Object)null)
		{
			Debug.LogError((object)string.Format("{0}: {1} couldn't instantiate quest track template", new object[2]
			{
				"Dialogue System",
				((Object)this).name
			}));
			return;
		}
		instantiatedItems.Add(val);
		string text = ((questDescriptionSource != QuestDescriptionSource.Title) ? QuestLog.GetQuestDescription(quest) : QuestLog.GetQuestTitle(quest));
		string text2 = (((Object)val).name = FormattedText.Parse(text, DialogueManager.MasterDatabase.emphasisSettings).text);
		val.transform.SetParent(((Component)container).transform, false);
		val.SetActive(true);
		UnityUIQuestTrackTemplate component = val.GetComponent<UnityUIQuestTrackTemplate>();
		if (!((Object)(object)component != (Object)null))
		{
			return;
		}
		component.Initialize();
		QuestState questState = QuestLog.GetQuestState(quest);
		component.SetDescription(text2, questState);
		int questEntryCount = QuestLog.GetQuestEntryCount(quest);
		for (int i = 1; i <= questEntryCount; i++)
		{
			QuestState questEntryState = QuestLog.GetQuestEntryState(quest, i);
			string text4 = FormattedText.Parse(GetQuestEntryText(quest, i, questEntryState), DialogueManager.MasterDatabase.emphasisSettings).text;
			if (!string.IsNullOrEmpty(text4))
			{
				component.AddEntryDescription(text4, questEntryState);
			}
		}
	}

	private string GetQuestEntryText(string quest, int entryNum, QuestState entryState)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Invalid comparison between Unknown and I4
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Invalid comparison between Unknown and I4
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Invalid comparison between Unknown and I4
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Invalid comparison between Unknown and I4
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Invalid comparison between Unknown and I4
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Invalid comparison between Unknown and I4
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		if ((int)entryState == 1 || (int)entryState == 16)
		{
			return string.Empty;
		}
		if (((int)entryState == 4 || (int)entryState == 8) && !showCompletedEntryText)
		{
			return string.Empty;
		}
		if ((int)entryState == 4)
		{
			Result questField = DialogueLua.GetQuestField(quest, "Entry " + entryNum + " Success");
			string asString = questField.AsString;
			if (!string.IsNullOrEmpty(asString))
			{
				return asString;
			}
		}
		else if ((int)entryState == 8)
		{
			Result questField2 = DialogueLua.GetQuestField(quest, "Entry " + entryNum + " Failure");
			string asString2 = questField2.AsString;
			if (!string.IsNullOrEmpty(asString2))
			{
				return asString2;
			}
		}
		return QuestLog.GetQuestEntry(quest, entryNum);
	}
}
