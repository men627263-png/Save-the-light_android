using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Miscellaneous/Pause Game On Conversation")]
public class PauseGameOnConversation : MonoBehaviour
{
	private float preConversationTimeScale = 1f;

	public void OnConversationStart(Transform actor)
	{
		if (((Behaviour)this).enabled)
		{
			preConversationTimeScale = Time.timeScale;
			Time.timeScale = 0f;
		}
	}

	public void OnConversationEnd(Transform actor)
	{
		if (((Behaviour)this).enabled)
		{
			Time.timeScale = preConversationTimeScale;
		}
	}
}
