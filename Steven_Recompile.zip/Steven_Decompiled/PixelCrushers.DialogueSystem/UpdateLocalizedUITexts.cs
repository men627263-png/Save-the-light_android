using System.Collections;
using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Effects/Update Localized UI Texts")]
public class UpdateLocalizedUITexts : MonoBehaviour
{
	public string languagePlayerPrefsKey = "Language";

	private IEnumerator Start()
	{
		yield return null;
		string languageCode = string.Empty;
		if (!string.IsNullOrEmpty(languagePlayerPrefsKey) && PlayerPrefs.HasKey(languagePlayerPrefsKey))
		{
			languageCode = PlayerPrefs.GetString(languagePlayerPrefsKey);
		}
		if (string.IsNullOrEmpty(languageCode))
		{
			languageCode = DialogueManager.DisplaySettings.localizationSettings.language;
		}
		UpdateTexts(languageCode);
	}

	public void UpdateTexts(string languageCode)
	{
		if (DialogueDebug.LogInfo)
		{
			Debug.Log((object)("Dialogue System: Setting language to '" + languageCode + "'."), (Object)(object)this);
		}
		DialogueManager.DisplaySettings.localizationSettings.useSystemLanguage = false;
		DialogueManager.DisplaySettings.localizationSettings.language = languageCode;
		Localization.Language = languageCode;
		if (!string.IsNullOrEmpty(languagePlayerPrefsKey))
		{
			PlayerPrefs.SetString(languagePlayerPrefsKey, languageCode);
		}
		LocalizeUIText[] array = Object.FindObjectsOfType<LocalizeUIText>();
		foreach (LocalizeUIText localizeUIText in array)
		{
			localizeUIText.LocalizeText();
		}
	}
}
