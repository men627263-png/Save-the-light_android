using System;
using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Selection/Usable Unity UI")]
public class UsableUnityUI : MonoBehaviour
{
	[Serializable]
	public class AnimationTransitions
	{
		public string showTrigger = "Show";

		public string hideTrigger = "Hide";
	}

	public Text nameText;

	public Text useMessageText;

	public Color inRangeColor = Color.yellow;

	public Color outOfRangeColor = Color.gray;

	public Graphic reticleInRange;

	public Graphic reticleOutOfRange;

	public AnimationTransitions animationTransitions = new AnimationTransitions();

	private Canvas canvas;

	private Animator animator;

	public UsableUnityUI()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
	}

	public void Awake()
	{
		canvas = ((Component)this).GetComponent<Canvas>();
		animator = ((Component)this).GetComponent<Animator>();
	}

	public void Start()
	{
		Usable componentAnywhere = Tools.GetComponentAnywhere<Usable>(((Component)this).gameObject);
		if ((Object)(object)componentAnywhere != (Object)null && (Object)(object)nameText != (Object)null)
		{
			nameText.text = componentAnywhere.GetName();
		}
		if ((Object)(object)canvas != (Object)null)
		{
			((Behaviour)canvas).enabled = false;
		}
	}

	public void Show(string useMessage)
	{
		if ((Object)(object)canvas != (Object)null)
		{
			((Behaviour)canvas).enabled = true;
		}
		if ((Object)(object)useMessageText != (Object)null)
		{
			useMessageText.text = useMessage;
		}
		if (CanTriggerAnimations() && !string.IsNullOrEmpty(animationTransitions.showTrigger))
		{
			animator.SetTrigger(animationTransitions.showTrigger);
		}
	}

	public void Hide()
	{
		if (CanTriggerAnimations() && !string.IsNullOrEmpty(animationTransitions.hideTrigger))
		{
			animator.SetTrigger(animationTransitions.hideTrigger);
		}
		else if ((Object)(object)canvas != (Object)null)
		{
			((Behaviour)canvas).enabled = false;
		}
	}

	public void OnBarkStart(Transform actor)
	{
		Hide();
	}

	public void UpdateDisplay(bool inRange)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		Color color = ((!inRange) ? outOfRangeColor : inRangeColor);
		if ((Object)(object)nameText != (Object)null)
		{
			((Graphic)nameText).color = color;
		}
		if ((Object)(object)useMessageText != (Object)null)
		{
			((Graphic)useMessageText).color = color;
		}
		Tools.SetGameObjectActive((Component)(object)reticleInRange, inRange);
		Tools.SetGameObjectActive((Component)(object)reticleOutOfRange, !inRange);
	}

	private bool CanTriggerAnimations()
	{
		return (Object)(object)animator != (Object)null && animationTransitions != null;
	}
}
