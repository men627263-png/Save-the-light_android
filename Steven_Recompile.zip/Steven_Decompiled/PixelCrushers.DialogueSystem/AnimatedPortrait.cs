using UnityEngine;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Dialogue/Use Animated Portraits")]
public class AnimatedPortrait : MonoBehaviour
{
	[Tooltip("Animator controller that runs this actor's animated portrait. It should animate an Image component, not a SpriteRenderer.")]
	public RuntimeAnimatorController animatorController;
}
