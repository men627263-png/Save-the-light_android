using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[Serializable]
public class UnityUIResponseMenuControls : AbstractUIResponseMenuControls
{
	[Serializable]
	public class AnimationTransitions
	{
		[Tooltip("Trigger to set when showing the response menu panel.")]
		public string showTrigger = string.Empty;

		[Tooltip("Trigger to set when hiding the response menu panel.")]
		public string hideTrigger = string.Empty;
	}

	[Serializable]
	public class AutonumberSettings
	{
		[Tooltip("Enable autonumbering of responses.")]
		public bool enabled;

		[Tooltip("Format for response button text, where {0} is the number and {1} is the menu text.")]
		public string format = "{0}. {1}";
	}

	[Tooltip("The panel containing the response menu controls. A panel is optional, but you may want one so you can include a background image, panel-wide effects, etc.")]
	public Graphic panel;

	[Tooltip("The PC portrait image to show during the response menu.")]
	public Image pcImage;

	[Tooltip("The label that will show the PC name.")]
	public Text pcName;

	[Tooltip("The reminder of the last subtitle.")]
	public UnityUISubtitleControls subtitleReminder;

	[Tooltip("The (optional) timer.")]
	public Slider timer;

	[Tooltip("Select the currently-focused response on timeout.")]
	public bool selectCurrentOnTimeout;

	[Tooltip("Design-time positioned response buttons")]
	public UnityUIResponseButton[] buttons;

	[Tooltip("Template from which to instantiate response buttons; optional to use instead of positioned buttons above")]
	public UnityUIResponseButton buttonTemplate;

	[Tooltip("If using Button Template, instantiated buttons are parented under this GameObject")]
	public Graphic buttonTemplateHolder;

	[Tooltip("Optional scrollbar if the instantiated button holder is in a scroll rect")]
	public Scrollbar buttonTemplateScrollbar;

	[Tooltip("Reset the scroll bar to this value when preparing the response menu")]
	public float buttonTemplateScrollbarResetValue = 1f;

	[Tooltip("Automatically set up explicit navigation for instantiated template buttons instead of using Automatic navigation")]
	public bool explicitNavigationForTemplateButtons = true;

	public AutonumberSettings autonumber = new AutonumberSettings();

	public AnimationTransitions animationTransitions = new AnimationTransitions();

	public UnityEvent onContentChanged = new UnityEvent();

	[HideInInspector]
	public List<GameObject> instantiatedButtons = new List<GameObject>();

	public Action TimeoutHandler;

	private UnityUITimer unityUITimer;

	private Texture2D pcPortraitTexture;

	private string pcPortraitName;

	private Animator animator;

	private bool lookedForAnimator;

	private bool isVisible;

	private bool isHiding;

	public override AbstractUISubtitleControls SubtitleReminder => (AbstractUISubtitleControls)(object)subtitleReminder;

	public UnityUIResponseMenuControls()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Expected Obj, but got Unknown
	}

	public override void SetPCPortrait(Texture2D portraitTexture, string portraitName)
	{
		pcPortraitTexture = portraitTexture;
		pcPortraitName = portraitName;
	}

	public override void SetActorPortraitTexture(string actorName, Texture2D portraitTexture)
	{
		if (string.Equals(actorName, pcPortraitName))
		{
			Texture2D texture = (pcPortraitTexture = AbstractDialogueUI.GetValidPortraitTexture(actorName, portraitTexture));
			if ((Object)(object)pcImage != (Object)null && DialogueManager.MasterDatabase.IsPlayer(actorName))
			{
				pcImage.sprite = UITools.CreateSprite(texture);
			}
		}
	}

	public override void SetActive(bool value)
	{
		try
		{
			((AbstractUIControls)((AbstractUIResponseMenuControls)this).SubtitleReminder).SetActive(value && ((AbstractUIResponseMenuControls)this).SubtitleReminder.HasText);
			Tools.SetGameObjectActive((Component)(object)buttonTemplate, false);
			UnityUIResponseButton[] array = buttons;
			foreach (UnityUIResponseButton unityUIResponseButton in array)
			{
				if ((Object)(object)unityUIResponseButton != (Object)null)
				{
					Tools.SetGameObjectActive((Component)(object)unityUIResponseButton, value && unityUIResponseButton.visible);
				}
			}
			Tools.SetGameObjectActive((Component)(object)timer, false);
			Tools.SetGameObjectActive((Component)(object)pcName, value);
			Tools.SetGameObjectActive((Component)(object)pcImage, value);
			if (value)
			{
				if ((Object)(object)pcImage != (Object)null && (Object)(object)pcPortraitTexture != (Object)null)
				{
					pcImage.sprite = UITools.CreateSprite(pcPortraitTexture);
				}
				if ((Object)(object)pcName != (Object)null && pcPortraitName != null)
				{
					pcName.text = pcPortraitName;
				}
				Tools.SetGameObjectActive((Component)(object)panel, true);
				if (!isVisible && CanTriggerAnimation(animationTransitions.showTrigger))
				{
					animator.SetTrigger(animationTransitions.showTrigger);
				}
				if (explicitNavigationForTemplateButtons)
				{
					SetupTemplateButtonNavigation();
				}
			}
			else if (isVisible && CanTriggerAnimation(animationTransitions.hideTrigger))
			{
				animator.SetTrigger(animationTransitions.hideTrigger);
				((MonoBehaviour)DialogueManager.Instance).StartCoroutine(DisableAfterAnimation(panel));
			}
			else if (!isHiding && (Object)(object)panel != (Object)null)
			{
				Tools.SetGameObjectActive((Component)(object)panel, false);
			}
		}
		finally
		{
			isVisible = value;
		}
	}

	protected override void ClearResponseButtons()
	{
		DestroyInstantiatedButtons();
		if (buttons != null)
		{
			for (int i = 0; i < buttons.Length; i++)
			{
				buttons[i].Reset();
				buttons[i].visible = base.showUnusedButtons;
			}
		}
	}

	protected override void SetResponseButtons(Response[] responses, Transform target)
	{
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		DestroyInstantiatedButtons();
		if (buttons != null && responses != null)
		{
			int num = 0;
			for (int i = 0; i < responses.Length; i++)
			{
				if (responses[i].formattedText.position != -1)
				{
					int num2 = Mathf.Clamp(responses[i].formattedText.position, 0, buttons.Length - 1);
					SetResponseButton(buttons[num2], responses[i], target, num++);
				}
			}
			if ((Object)(object)buttonTemplate != (Object)null && (Object)(object)buttonTemplateHolder != (Object)null)
			{
				if ((Object)(object)buttonTemplateScrollbar != (Object)null)
				{
					buttonTemplateScrollbar.value = buttonTemplateScrollbarResetValue;
				}
				for (int j = 0; j < responses.Length; j++)
				{
					GameObject val = Object.Instantiate<GameObject>(((Component)buttonTemplate).gameObject);
					if ((Object)(object)val == (Object)null)
					{
						Debug.LogError((object)string.Format("{0}: Couldn't instantiate response button template", "Dialogue System"));
						continue;
					}
					instantiatedButtons.Add(val);
					val.transform.SetParent(((Component)buttonTemplateHolder).transform, false);
					val.SetActive(true);
					UnityUIResponseButton component = val.GetComponent<UnityUIResponseButton>();
					SetResponseButton(component, responses[j], target, num++);
					if ((Object)(object)component != (Object)null)
					{
						((Object)val).name = "Response: " + component.Text;
					}
				}
			}
			else if ((int)base.buttonAlignment == 0)
			{
				for (int k = 0; k < Mathf.Min(buttons.Length, responses.Length); k++)
				{
					if (responses[k].formattedText.position == -1)
					{
						int num3 = Mathf.Clamp(GetNextAvailableResponseButtonPosition(0, 1), 0, buttons.Length - 1);
						SetResponseButton(buttons[num3], responses[k], target, num++);
					}
				}
			}
			else
			{
				for (int num4 = Mathf.Min(buttons.Length, responses.Length) - 1; num4 >= 0; num4--)
				{
					if (responses[num4].formattedText.position == -1)
					{
						int num5 = Mathf.Clamp(GetNextAvailableResponseButtonPosition(buttons.Length - 1, -1), 0, buttons.Length - 1);
						SetResponseButton(buttons[num5], responses[num4], target, num++);
					}
				}
			}
		}
		NotifyContentChanged();
	}

	private void SetResponseButton(UnityUIResponseButton button, Response response, Transform target, int buttonNumber)
	{
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)button != (Object)null))
		{
			return;
		}
		button.visible = true;
		button.clickable = response.enabled;
		button.target = target;
		if (response != null)
		{
			button.SetFormattedText(response.formattedText);
		}
		button.response = response;
		if (autonumber.enabled)
		{
			button.Text = string.Format(autonumber.format, buttonNumber + 1, button.Text);
			UIButtonKeyTrigger uIButtonKeyTrigger = ((Component)button).GetComponent<UIButtonKeyTrigger>();
			if ((Object)(object)uIButtonKeyTrigger == (Object)null)
			{
				uIButtonKeyTrigger = ((Component)button).gameObject.AddComponent<UIButtonKeyTrigger>();
			}
			uIButtonKeyTrigger.key = (KeyCode)(49 + buttonNumber);
		}
	}

	private int GetNextAvailableResponseButtonPosition(int start, int direction)
	{
		if (buttons != null)
		{
			for (int i = start; 0 <= i && i < buttons.Length; i += direction)
			{
				if (!buttons[i].visible || buttons[i].response == null)
				{
					return i;
				}
			}
		}
		return 5;
	}

	private void SetupTemplateButtonNavigation()
	{
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < instantiatedButtons.Count; i++)
		{
			Button button = instantiatedButtons[i].GetComponent<UnityUIResponseButton>().button;
			Button val = ((i != 0) ? instantiatedButtons[i - 1].GetComponent<UnityUIResponseButton>().button : null);
			Button val2 = ((i != instantiatedButtons.Count - 1) ? instantiatedButtons[i + 1].GetComponent<UnityUIResponseButton>().button : null);
			Navigation navigation = default;
			navigation.mode = (Mode)4;
			navigation.selectOnUp = (Selectable)(object)val;
			navigation.selectOnLeft = (Selectable)(object)val;
			navigation.selectOnDown = (Selectable)(object)val2;
			navigation.selectOnRight = (Selectable)(object)val2;
			((Selectable)button).navigation = navigation;
		}
	}

	public void DestroyInstantiatedButtons()
	{
		foreach (GameObject instantiatedButton in instantiatedButtons)
		{
			Object.Destroy((Object)(object)instantiatedButton);
		}
		instantiatedButtons.Clear();
		NotifyContentChanged();
	}

	public void NotifyContentChanged()
	{
		onContentChanged.Invoke();
	}

	public override void StartTimer(float timeout)
	{
		if (!((Object)(object)timer != (Object)null))
		{
			return;
		}
		if ((Object)(object)unityUITimer == (Object)null)
		{
			Tools.SetGameObjectActive((Component)(object)timer, true);
			unityUITimer = ((Component)timer).GetComponent<UnityUITimer>();
			if ((Object)(object)unityUITimer == (Object)null)
			{
				unityUITimer = ((Component)timer).gameObject.AddComponent<UnityUITimer>();
			}
			Tools.SetGameObjectActive((Component)(object)timer, false);
		}
		if ((Object)(object)unityUITimer != (Object)null)
		{
			Tools.SetGameObjectActive((Component)(object)timer, true);
			unityUITimer.StartCountdown(timeout, OnTimeout);
		}
		else if (DialogueDebug.LogWarnings)
		{
			Debug.LogWarning((object)string.Format("{0}: No UnityUITimer component found on timer", "Dialogue System"));
		}
	}

	public virtual void OnTimeout()
	{
		if (TimeoutHandler != null)
		{
			TimeoutHandler();
		}
		else
		{
			DefaultTimeoutHandler();
		}
	}

	public void DefaultTimeoutHandler()
	{
		if (selectCurrentOnTimeout)
		{
			UnityUIResponseButton component = EventSystem.current.currentSelectedGameObject.GetComponent<UnityUIResponseButton>();
			if ((Object)(object)component != (Object)null)
			{
				component.OnClick();
				return;
			}
		}
		((Component)DialogueManager.Instance).SendMessage("OnConversationTimeout");
	}

	public void AutoFocus()
	{
		if ((Object)(object)EventSystem.current == (Object)null)
		{
			return;
		}
		if (instantiatedButtons.Count > 0)
		{
			EventSystem.current.SetSelectedGameObject(instantiatedButtons[0].gameObject, (BaseEventData)null);
			return;
		}
		for (int i = 0; i < buttons.Length; i++)
		{
			if (buttons[i].clickable)
			{
				EventSystem.current.SetSelectedGameObject(((Component)buttons[i]).gameObject, (BaseEventData)null);
				break;
			}
		}
	}

	private bool CanTriggerAnimation(string triggerName)
	{
		return CanTriggerAnimations() && !string.IsNullOrEmpty(triggerName);
	}

	private bool CanTriggerAnimations()
	{
		if ((Object)(object)animator == (Object)null && !lookedForAnimator)
		{
			lookedForAnimator = true;
			if ((Object)(object)panel != (Object)null)
			{
				animator = ((Component)panel).GetComponentInParent<Animator>();
			}
		}
		return (Object)(object)animator != (Object)null && animationTransitions != null;
	}

	private IEnumerator DisableAfterAnimation(Graphic panel)
	{
		isHiding = true;
		if ((Object)(object)animator != (Object)null)
		{
			float timeout = Time.realtimeSinceStartup + 10f;
			int oldHashId = UITools.GetAnimatorNameHash(animator.GetCurrentAnimatorStateInfo(0));
			while (UITools.GetAnimatorNameHash(animator.GetCurrentAnimatorStateInfo(0)) == oldHashId && Time.realtimeSinceStartup < timeout)
			{
				yield return null;
			}
			DialogueSystemController instance = DialogueManager.Instance;
			AnimatorStateInfo currentAnimatorStateInfo = animator.GetCurrentAnimatorStateInfo(0);
			yield return ((MonoBehaviour)instance).StartCoroutine(DialogueTime.WaitForSeconds(currentAnimatorStateInfo.length));
		}
		isHiding = false;
		if ((Object)(object)panel != (Object)null)
		{
			Tools.SetGameObjectActive((Component)(object)panel, false);
		}
	}
}
