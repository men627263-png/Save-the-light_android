using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/UI/Unity UI/Effects/Unity UI Typewriter Effect")]
[DisallowMultipleComponent]
public class UnityUITypewriterEffect : MonoBehaviour
{
	[Serializable]
	public class AutoScrollSettings
	{
		[Tooltip("Automatically scroll to bottom of scroll rect. Useful for long text. Works best with left justification.")]
		public bool autoScrollEnabled;

		public ScrollRect scrollRect;

		public UnityUIScrollbarEnabler scrollbarEnabler;
	}

	private enum TokenType
	{
		Character,
		BoldOpen,
		BoldClose,
		ItalicOpen,
		ItalicClose,
		ColorOpen,
		ColorClose,
		Quad,
		Pause,
		InstantOpen,
		InstantClose
	}

	private class Token
	{
		public TokenType tokenType;

		public char character;

		public string code;

		public float duration;

		public Token(TokenType tokenType, char character, string code, float duration)
		{
			this.tokenType = tokenType;
			this.character = character;
			this.code = code;
			this.duration = duration;
		}
	}

	[Tooltip("Tick for right-to-left text such as Arabic.")]
	public bool rightToLeft;

	[Tooltip("How fast to type. This is separate from Dialogue Manager > Subtitle Settings > Chars Per Second.")]
	public float charactersPerSecond = 50f;

	[Tooltip("Optional audio clip to play with each character.")]
	public AudioClip audioClip;

	[Tooltip("Optional audio source through which to play the clip.")]
	public AudioSource audioSource;

	[Tooltip("If audio clip is still playing from previous character, stop and restart it when typing next character.")]
	public bool interruptAudioClip;

	[Tooltip("Duration to pause on when text contains '\\.'")]
	public float fullPauseDuration = 1f;

	[Tooltip("Duration to pause when text contains '\\,'")]
	public float quarterPauseDuration = 0.25f;

	[Tooltip("Ensure this GameObject has only one typewriter effect.")]
	public bool removeDuplicateTypewriterEffects = true;

	[Tooltip("Wait one frame to allow layout elements to setup first.")]
	public bool waitOneFrameBeforeStarting;

	public AutoScrollSettings autoScrollSettings = new AutoScrollSettings();

	public UnityEvent onBegin = new UnityEvent();

	public UnityEvent onCharacter = new UnityEvent();

	public UnityEvent onEnd = new UnityEvent();

	private const string RichTextBoldOpen = "<b>";

	private const string RichTextBoldClose = "</b>";

	private const string RichTextItalicOpen = "<i>";

	private const string RichTextItalicClose = "</i>";

	private const string RichTextColorOpenPrefix = "<color=";

	private const string RichTextColorClose = "</color>";

	private const string QuadPrefix = "<quad ";

	private const string RPGMakerCodeQuarterPause = "\\,";

	private const string RPGMakerCodeFullPause = "\\.";

	private const string RPGMakerCodeSkipToEnd = "\\^";

	private const string RPGMakerCodeInstantOpen = "\\>";

	private const string RPGMakerCodeInstantClose = "\\<";

	private Text control;

	private bool started;

	private bool paused;

	private string original = string.Empty;

	private int MaxSafeguard = 16384;

	public bool IsPlaying { get; private set; }

	public UnityUITypewriterEffect()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Expected Obj, but got Unknown
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Expected Obj, but got Unknown
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Expected Obj, but got Unknown
	}

	public void Awake()
	{
		control = ((Component)this).GetComponent<Text>();
		if ((Object)(object)audioSource == (Object)null)
		{
			audioSource = ((Component)this).GetComponent<AudioSource>();
		}
		if (removeDuplicateTypewriterEffects)
		{
			RemoveIfDuplicate();
		}
	}

	private void RemoveIfDuplicate()
	{
		UnityUITypewriterEffect[] components = ((Component)this).GetComponents<UnityUITypewriterEffect>();
		if (components.Length <= 1)
		{
			return;
		}
		UnityUITypewriterEffect unityUITypewriterEffect = components[0];
		for (int i = 1; i < components.Length; i++)
		{
			if (((Object)components[i]).GetInstanceID() < ((Object)unityUITypewriterEffect).GetInstanceID())
			{
				unityUITypewriterEffect = components[i];
			}
		}
		for (int j = 0; j < components.Length; j++)
		{
			if ((Object)(object)components[j] != (Object)(object)unityUITypewriterEffect)
			{
				Object.Destroy((Object)(object)components[j]);
			}
		}
	}

	public void Start()
	{
		if ((Object)(object)control != (Object)null)
		{
			control.supportRichText = true;
		}
		if (!IsPlaying)
		{
			((MonoBehaviour)this).StopAllCoroutines();
			((MonoBehaviour)this).StartCoroutine(Play());
		}
		started = true;
	}

	public void OnEnable()
	{
		if (!IsPlaying && started && ((Component)this).gameObject.activeInHierarchy)
		{
			((MonoBehaviour)this).StopAllCoroutines();
			((MonoBehaviour)this).StartCoroutine(Play());
		}
	}

	public void OnDisable()
	{
		Stop();
	}

	public void Pause()
	{
		paused = true;
	}

	public void Unpause()
	{
		paused = false;
	}

	public IEnumerator Play()
	{
		if ((Object)(object)control != (Object)null && charactersPerSecond > 0f)
		{
			if (waitOneFrameBeforeStarting)
			{
				yield return null;
			}
			if ((Object)(object)audioSource != (Object)null)
			{
				audioSource.clip = audioClip;
			}
			onBegin.Invoke();
			IsPlaying = true;
			paused = false;
			float delay = 1f / charactersPerSecond;
			float lastTime = DialogueTime.time;
			float elapsed = 0f;
			int charactersTyped = 0;
			original = control.text;
			List<Token> tokens = Tokenize(original);
			List<TokenType> openTokenTypes = new List<TokenType>();
			StringBuilder current = new StringBuilder();
			while (tokens.Count > 0)
			{
				if (!paused)
				{
					float deltaTime = DialogueTime.time - lastTime;
					elapsed += deltaTime;
					float goal = elapsed * charactersPerSecond;
					bool isCodeNext = false;
					while (((float)charactersTyped < goal || isCodeNext) && tokens.Count > 0)
					{
						Token token = GetNextToken(tokens);
						switch (token.tokenType)
						{
						case TokenType.Character:
							if (rightToLeft)
							{
								current.Insert(0, token.character);
							}
							else
							{
								current.Append(token.character);
							}
							PlayCharacterAudio();
							onCharacter.Invoke();
							charactersTyped++;
							break;
						case TokenType.BoldOpen:
						case TokenType.ItalicOpen:
						case TokenType.ColorOpen:
							OpenRichText(current, token, openTokenTypes);
							break;
						case TokenType.BoldClose:
						case TokenType.ItalicClose:
						case TokenType.ColorClose:
							CloseRichText(current, token, openTokenTypes);
							break;
						case TokenType.Quad:
							current.Append(token.code);
							break;
						case TokenType.Pause:
						{
							control.text = GetCurrentText(current, openTokenTypes, tokens);
							paused = true;
							float continueTime = DialogueTime.time + token.duration;
							int pauseSafeguard = 0;
							while (DialogueTime.time < continueTime && pauseSafeguard < 999)
							{
								pauseSafeguard++;
								yield return null;
							}
							paused = false;
							break;
						}
						case TokenType.InstantOpen:
							AddInstantText(current, openTokenTypes, tokens);
							break;
						}
						isCodeNext = tokens.Count > 0 && tokens[0].tokenType != TokenType.Character;
					}
				}
				control.text = GetCurrentText(current, openTokenTypes, tokens);
				HandleAutoScroll();
				lastTime = DialogueTime.time;
				float delayTime = DialogueTime.time + delay;
				int delaySafeguard = 0;
				while (DialogueTime.time < delayTime && delaySafeguard < 999)
				{
					delaySafeguard++;
					yield return null;
				}
			}
		}
		Stop();
	}

	private void PlayCharacterAudio()
	{
		if ((Object)(object)audioClip == (Object)null || (Object)(object)audioSource == (Object)null)
		{
			return;
		}
		if (interruptAudioClip)
		{
			if (audioSource.isPlaying)
			{
				audioSource.Stop();
			}
			audioSource.Play();
		}
		else if (!audioSource.isPlaying)
		{
			audioSource.Play();
		}
	}

	private Token GetNextToken(List<Token> tokens)
	{
		if (tokens.Count == 0)
		{
			return null;
		}
		int index = (rightToLeft ? (tokens.Count - 1) : 0);
		Token result = tokens[index];
		tokens.RemoveAt(index);
		return result;
	}

	private void OpenRichText(StringBuilder current, Token token, List<TokenType> openTokens)
	{
		switch (token.tokenType)
		{
		case TokenType.BoldOpen:
			current.Append("<b>");
			break;
		case TokenType.ItalicOpen:
			current.Append("<i>");
			break;
		case TokenType.ColorOpen:
			current.Append(token.code);
			break;
		}
		openTokens.Insert(0, token.tokenType);
	}

	private void CloseRichText(StringBuilder current, Token token, List<TokenType> openTokens)
	{
		TokenType tokenType = TokenType.BoldOpen;
		switch (token.tokenType)
		{
		case TokenType.BoldClose:
			current.Append("</b>");
			tokenType = TokenType.BoldOpen;
			break;
		case TokenType.ItalicClose:
			current.Append("</i>");
			tokenType = TokenType.ItalicOpen;
			break;
		case TokenType.ColorClose:
			current.Append("</color>");
			tokenType = TokenType.ColorOpen;
			break;
		}
		int num = -1;
		for (int i = 0; i < openTokens.Count; i++)
		{
			if (openTokens[i] == tokenType)
			{
				num = i;
				break;
			}
		}
		if (num != -1)
		{
			openTokens.RemoveAt(num);
		}
	}

	private void AddInstantText(StringBuilder current, List<TokenType> openTokenTypes, List<Token> tokens)
	{
		int num = 0;
		while (tokens.Count > 0 && num < MaxSafeguard)
		{
			num++;
			Token nextToken = GetNextToken(tokens);
			switch (nextToken.tokenType)
			{
			case TokenType.Character:
				current.Append(nextToken.character);
				break;
			case TokenType.BoldOpen:
			case TokenType.ItalicOpen:
			case TokenType.ColorOpen:
				OpenRichText(current, nextToken, openTokenTypes);
				break;
			case TokenType.BoldClose:
			case TokenType.ItalicClose:
			case TokenType.ColorClose:
				CloseRichText(current, nextToken, openTokenTypes);
				break;
			case TokenType.InstantClose:
				return;
			}
		}
	}

	private string GetCurrentText(StringBuilder current, List<TokenType> openTokenTypes, List<Token> tokens)
	{
		StringBuilder stringBuilder = new StringBuilder(current.ToString());
		for (int i = 0; i < openTokenTypes.Count; i++)
		{
			switch (openTokenTypes[i])
			{
			case TokenType.BoldOpen:
				stringBuilder.Append("</b>");
				break;
			case TokenType.ItalicOpen:
				stringBuilder.Append("</i>");
				break;
			case TokenType.ColorOpen:
				stringBuilder.Append("</color>");
				break;
			}
		}
		StringBuilder stringBuilder2 = new StringBuilder();
		if (!autoScrollSettings.autoScrollEnabled)
		{
			stringBuilder2.Append("<color=#00000000>");
			for (int num = openTokenTypes.Count - 1; num >= 0; num--)
			{
				switch (openTokenTypes[num])
				{
				case TokenType.BoldOpen:
					stringBuilder2.Append("<b>");
					break;
				case TokenType.ItalicOpen:
					stringBuilder2.Append("<i>");
					break;
				}
			}
			for (int j = 0; j < tokens.Count; j++)
			{
				Token token = tokens[j];
				switch (token.tokenType)
				{
				case TokenType.BoldOpen:
					stringBuilder2.Append("<b>");
					break;
				case TokenType.BoldClose:
					stringBuilder2.Append("</b>");
					break;
				case TokenType.ItalicOpen:
					stringBuilder2.Append("<i>");
					break;
				case TokenType.ItalicClose:
					stringBuilder2.Append("</i>");
					break;
				case TokenType.Character:
					stringBuilder2.Append(token.character);
					break;
				}
			}
			stringBuilder2.Append("</color>");
		}
		if (rightToLeft)
		{
			stringBuilder.Insert(0, stringBuilder2);
		}
		else
		{
			stringBuilder.Append((object?)stringBuilder2);
		}
		return stringBuilder.ToString();
	}

	private List<Token> Tokenize(string text)
	{
		List<Token> list = new List<Token>();
		string remainder = text;
		int num = 0;
		while (!string.IsNullOrEmpty(remainder) && num < MaxSafeguard)
		{
			num++;
			Token token = null;
			if (remainder.StartsWith("<"))
			{
				token = TryTokenize("<b>", TokenType.BoldOpen, 0f, ref remainder);
				if (token == null)
				{
					token = TryTokenize("</b>", TokenType.BoldClose, 0f, ref remainder);
				}
				if (token == null)
				{
					token = TryTokenize("<i>", TokenType.ItalicOpen, 0f, ref remainder);
				}
				if (token == null)
				{
					token = TryTokenize("</i>", TokenType.ItalicClose, 0f, ref remainder);
				}
				if (token == null)
				{
					token = TryTokenize("</color>", TokenType.ColorClose, 0f, ref remainder);
				}
				if (token == null)
				{
					token = TryTokenizeColorOpen(ref remainder);
				}
				if (token == null)
				{
					token = TryTokenizeQuad(ref remainder);
				}
			}
			else if (remainder.StartsWith("\\"))
			{
				token = TryTokenize("\\.", TokenType.Pause, fullPauseDuration, ref remainder);
				if (token == null)
				{
					token = TryTokenize("\\,", TokenType.Pause, quarterPauseDuration, ref remainder);
				}
				if (token == null)
				{
					token = TryTokenize("\\>", TokenType.InstantOpen, 0f, ref remainder);
				}
				if (token == null)
				{
					token = TryTokenize("\\<", TokenType.InstantClose, 0f, ref remainder);
				}
				if (token == null)
				{
					token = TryTokenize("\\^", TokenType.InstantOpen, 0f, ref remainder);
				}
			}
			if (token == null)
			{
				token = new Token(TokenType.Character, remainder[0], string.Empty, 0f);
				remainder = remainder.Remove(0, 1);
			}
			list.Add(token);
		}
		return list;
	}

	private Token TryTokenize(string code, TokenType tokenType, float duration, ref string remainder)
	{
		if (remainder.StartsWith(code))
		{
			remainder = remainder.Remove(0, code.Length);
			return new Token(tokenType, ' ', string.Empty, duration);
		}
		return null;
	}

	private Token TryTokenizeColorOpen(ref string remainder)
	{
		if (remainder.StartsWith("<color="))
		{
			string text = remainder.Substring(0, remainder.IndexOf('>') + 1);
			remainder = remainder.Remove(0, text.Length);
			return new Token(TokenType.ColorOpen, ' ', text, 0f);
		}
		return null;
	}

	private Token TryTokenizeQuad(ref string remainder)
	{
		if (remainder.StartsWith("<quad "))
		{
			string text = remainder.Substring(0, remainder.IndexOf('>') + 1);
			remainder = remainder.Remove(0, text.Length);
			return new Token(TokenType.Quad, ' ', text, 0f);
		}
		return null;
	}

	public static string StripRPGMakerCodes(string s)
	{
		return (!s.Contains("\\")) ? s : s.Replace("\\,", string.Empty).Replace("\\.", string.Empty).Replace("\\^", string.Empty)
			.Replace("\\>", string.Empty)
			.Replace("\\<", string.Empty);
	}

	public void Stop()
	{
		((MonoBehaviour)this).StopAllCoroutines();
		if (IsPlaying)
		{
			onEnd.Invoke();
		}
		IsPlaying = false;
		if ((Object)(object)control != (Object)null)
		{
			control.text = StripRPGMakerCodes(original);
		}
		original = string.Empty;
		HandleAutoScroll();
	}

	private void HandleAutoScroll()
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		if (autoScrollSettings.autoScrollEnabled)
		{
			if ((Object)(object)autoScrollSettings.scrollRect != (Object)null)
			{
				autoScrollSettings.scrollRect.normalizedPosition = new Vector2(0f, 0f);
			}
			if ((Object)(object)autoScrollSettings.scrollbarEnabler != (Object)null)
			{
				autoScrollSettings.scrollbarEnabler.CheckScrollbar();
			}
		}
	}
}
