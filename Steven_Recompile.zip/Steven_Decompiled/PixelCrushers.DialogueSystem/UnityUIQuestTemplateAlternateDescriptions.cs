using System;
using UnityEngine;
using UnityEngine.UI;

namespace PixelCrushers.DialogueSystem;

[Serializable]
public class UnityUIQuestTemplateAlternateDescriptions
{
	[Tooltip("(Optional) If set, use if state is success")]
	public Text successDescription;

	[Tooltip("(Optional) If set, use if state is failure")]
	public Text failureDescription;

	public void SetActive(bool value)
	{
		if ((Object)(object)successDescription != (Object)null)
		{
			((Component)successDescription).gameObject.SetActive(value);
		}
		if ((Object)(object)failureDescription != (Object)null)
		{
			((Component)failureDescription).gameObject.SetActive(value);
		}
	}
}
