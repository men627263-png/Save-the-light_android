using UnityEngine;
using UnityEngine.Events;

namespace PixelCrushers.DialogueSystem;

[AddComponentMenu("Dialogue System/Actor/Increment On Destroy")]
public class IncrementOnDestroy : MonoBehaviour
{
	public enum IncrementOn
	{
		Destroy,
		Disable
	}

	[Tooltip("Increment on Destroy or Disable.")]
	public IncrementOn incrementOn;

	[Tooltip("Increment this Dialogue System variable.")]
	public string variable = string.Empty;

	[Tooltip("Increment the variable by this amount. Use a negative value to decrement.")]
	public int increment = 1;

	[Tooltip("After incrementing, ensure that the variable is at least this value.")]
	public int min;

	[Tooltip("After incrementing, ensure that the variable is no more than this value.")]
	public int max = 100;

	[Tooltip("Optional alert message to show when incrementing.")]
	public string alertMessage = string.Empty;

	[Tooltip("Duration to show alert, or 0 to use default duration.")]
	public float alertDuration;

	[Tooltip("If set, only increment if the conditions are true.")]
	public Condition condition = new Condition();

	public UnityEvent onIncrement = new UnityEvent();

	private bool listenForOnDestroy;

	protected string ActualVariableName => (!string.IsNullOrEmpty(variable)) ? variable : OverrideActorName.GetInternalName(((Component)this).transform);

	public IncrementOnDestroy()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Expected Obj, but got Unknown
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Expected Obj, but got Unknown
	}

	public void OnEnable()
	{
		listenForOnDestroy = true;
		PersistentDataManager.RegisterPersistentData(((Component)this).gameObject);
	}

	public void OnLevelWillBeUnloaded()
	{
		listenForOnDestroy = false;
	}

	public void OnApplicationQuit()
	{
		listenForOnDestroy = false;
	}

	public void OnDestroy()
	{
		if (incrementOn == IncrementOn.Destroy)
		{
			TryIncrement();
		}
	}

	public void OnDisable()
	{
		PersistentDataManager.UnregisterPersistentData(((Component)this).gameObject);
		if (incrementOn == IncrementOn.Disable)
		{
			TryIncrement();
		}
	}

	public void TryIncrement()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (!listenForOnDestroy || !condition.IsTrue((Transform)null))
		{
			return;
		}
		Result val = DialogueLua.GetVariable(ActualVariableName);
		int asInt = val.AsInt;
		int num = Mathf.Clamp(asInt + increment, min, max);
		DialogueLua.SetVariable(ActualVariableName, (object)num);
		DialogueManager.SendUpdateTracker();
		if (!string.IsNullOrEmpty(alertMessage) && !((Object)(object)DialogueManager.Instance == (Object)null))
		{
			if (Mathf.Approximately(0f, alertDuration))
			{
				DialogueManager.ShowAlert(alertMessage);
			}
			else
			{
				DialogueManager.ShowAlert(alertMessage, alertDuration);
			}
		}
		onIncrement.Invoke();
	}
}
