using UnityEngine;

public class DisplayBattleTextEvent : GameEvent
{
	public string message { get; private set; }

	public Transform target { get; private set; }

	public DisplayBattleTextEvent(string message, Transform target)
	{
		this.message = message;
		this.target = target;
	}
}
