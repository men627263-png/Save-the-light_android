using SimpleSpritePacker;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIAbilityDescription : MonoBehaviour
{
	[SerializeField]
	private SPInstance uiAtlas;

	[SerializeField]
	private Animator animator;

	[SerializeField]
	private AnimatorEventListener animatorEventListener;

	[SerializeField]
	private Image backingImage;

	[SerializeField]
	private Image abilityBGImage;

	[SerializeField]
	private Image abilityIconImage;

	[SerializeField]
	private TextMeshProUGUI headerText;

	[SerializeField]
	private TextMeshProUGUI descriptionText;

	[SerializeField]
	private float delay = 0.5f;

	private float delayTimer;

	private BaseCharacter _character;

	private AbilityDefinition _abilityDef;

	public BaseCharacter character => _character;

	public AbilityDefinition abilityDef => _abilityDef;

	private void Awake()
	{
		((Component)animator).gameObject.SetActive(false);
	}

	private void OnEnable()
	{
		animatorEventListener.EventTriggered += HandleAnimatorEventListener;
		EventMessenger.Instance.AddListener<UIAbilityButtonSelectionEvent>(HandleUIAbilityButtonSelectionEvent);
	}

	private void OnDisable()
	{
		animatorEventListener.EventTriggered -= HandleAnimatorEventListener;
		EventMessenger.Instance.RemoveListener<UIAbilityButtonSelectionEvent>(HandleUIAbilityButtonSelectionEvent);
	}

	private void Update()
	{
		if ((Object)(object)_character != (Object)null && _abilityDef != null && delayTimer > 0f)
		{
			delayTimer -= Time.deltaTime;
			if (delayTimer <= 0f)
			{
				Refresh();
				Show();
			}
		}
	}

	public void Show()
	{
		if (!((Component)animator).gameObject.activeSelf)
		{
			((Component)animator).gameObject.SetActive(true);
		}
		animator.Play("intro", 0, 0f);
		animator.Update(0f);
	}

	public void Hide()
	{
		animator.Play("outro");
	}

	private void HandleAnimatorEventListener(AnimationEvent evt)
	{
		string stringParameter = evt.stringParameter;
		if (stringParameter != null && stringParameter == "outroComplete")
		{
			((Component)animator).gameObject.SetActive(false);
		}
	}

	private void HandleUIAbilityButtonSelectionEvent(UIAbilityButtonSelectionEvent evt)
	{
		_character = evt.character;
		_abilityDef = ((!((Object)(object)_character != (Object)null) || !((Object)(object)evt.button != (Object)null)) ? null : _character.characterDefinition.GetAbilityDefinition(((Object)evt.button.ability).name));
		if ((Object)(object)_character != (Object)null && _abilityDef != null)
		{
			if (delay > 0f)
			{
				delayTimer = delay;
				Hide();
			}
			else
			{
				Refresh();
				Show();
			}
		}
		else
		{
			Hide();
		}
	}

	private void Refresh()
	{
		if ((Object)(object)_character != (Object)null)
		{
			backingImage.overrideSprite = _character.characterDefinition.abilityDescriptionBGSprite;
			abilityBGImage.overrideSprite = character.characterDefinition.abilityButtonBGSprite;
		}
		else
		{
			backingImage.overrideSprite = null;
			abilityBGImage.overrideSprite = null;
		}
		if (_abilityDef != null)
		{
			abilityIconImage.overrideSprite = uiAtlas.GetSpriteByName(_abilityDef.iconSpriteName);
			headerText.text = Languages.Get(_abilityDef.abilityName.key, "ITEMS, ABILITIES, UPGRADES");
			descriptionText.text = Languages.Get(_abilityDef.abilityDescription.key, "ITEMS, ABILITIES, UPGRADES");
		}
		else
		{
			abilityIconImage.overrideSprite = null;
			headerText.text = string.Empty;
			descriptionText.text = string.Empty;
		}
	}
}
