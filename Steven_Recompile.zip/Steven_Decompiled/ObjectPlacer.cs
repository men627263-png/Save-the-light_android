using Pathfinding;
using UnityEngine;

[HelpURL("http://arongranberg.com/astar/docs/class_object_placer.php")]
public class ObjectPlacer : MonoBehaviour
{
	public GameObject go;

	public bool direct;

	public bool issueGUOs = true;

	private void Start()
	{
	}

	private void Update()
	{
		if (Input.GetKeyDown("p"))
		{
			PlaceObject();
		}
		if (Input.GetKeyDown("r"))
		{
			RemoveObject();
		}
	}

	public void PlaceObject()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		Ray val = Camera.main.ScreenPointToRay(Input.mousePosition);
		RaycastHit val2 = default;
		if (!Physics.Raycast(val, ref val2, float.PositiveInfinity))
		{
			return;
		}
		Vector3 point = val2.point;
		GameObject val3 = Object.Instantiate<GameObject>(go, point, Quaternion.identity);
		if (issueGUOs)
		{
			Bounds bounds = val3.GetComponent<Collider>().bounds;
			GraphUpdateObject ob = new GraphUpdateObject(bounds);
			AstarPath.active.UpdateGraphs(ob);
			if (direct)
			{
				AstarPath.active.FlushGraphUpdates();
			}
		}
	}

	public void RemoveObject()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		Ray val = Camera.main.ScreenPointToRay(Input.mousePosition);
		RaycastHit val2 = default;
		if (!Physics.Raycast(val, ref val2, float.PositiveInfinity) || val2.collider.isTrigger || ((Object)((Component)val2.transform).gameObject).name == "Ground")
		{
			return;
		}
		Bounds bounds = val2.collider.bounds;
		Object.Destroy((Object)(object)val2.collider);
		Object.Destroy((Object)(object)((Component)val2.collider).gameObject);
		if (issueGUOs)
		{
			GraphUpdateObject ob = new GraphUpdateObject(bounds);
			AstarPath.active.UpdateGraphs(ob, 0f);
			if (direct)
			{
				AstarPath.active.FlushGraphUpdates();
			}
		}
	}
}
