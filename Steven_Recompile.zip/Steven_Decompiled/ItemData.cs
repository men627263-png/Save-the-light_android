using System;
using UnityEngine;

[Serializable]
public class ItemData
{
	public int itemUID;

	public int itemCount;

	[NonSerialized]
	private ItemDefinition _itemDef;

	public ItemDefinition itemDef
	{
		get
		{
			if ((Object)(object)_itemDef == (Object)null)
			{
				_itemDef = GameController.Instance.itemDatabase.GetItem(itemUID);
			}
			return _itemDef;
		}
	}

	public bool canBeUsedInBattle
	{
		get
		{
			if (itemDef is Consumable)
			{
				return ((Consumable)itemDef).canUseInBattle;
			}
			return false;
		}
	}

	public bool canBeUsedInExplore
	{
		get
		{
			if (itemDef is Consumable)
			{
				return ((Consumable)itemDef).canUseInExplore;
			}
			if (itemDef is QuestItem)
			{
				return true;
			}
			return false;
		}
	}

	public string iconSpriteName
	{
		get
		{
			if ((Object)(object)itemDef != (Object)null && (Object)(object)itemDef.guiSprite != (Object)null)
			{
				return ((Object)itemDef.guiSprite).name;
			}
			return string.Empty;
		}
	}

	public Vector3 iconSpriteLocalScale
	{
		get
		{
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			if ((Object)(object)itemDef != (Object)null)
			{
				return itemDef.guiSpriteLocalScale;
			}
			return Vector3.zero;
		}
	}

	public Vector3 iconSpriteLocalPosition
	{
		get
		{
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			if ((Object)(object)itemDef != (Object)null)
			{
				return itemDef.guiSpriteLocalPosition;
			}
			return Vector3.zero;
		}
	}

	public AbilityTargetType targetType
	{
		get
		{
			if ((Object)(object)itemDef != (Object)null && itemDef is Consumable)
			{
				return ((Consumable)itemDef).targetType;
			}
			return AbilityTargetType.None;
		}
	}

	public bool canTargetNonCharacters
	{
		get
		{
			if ((Object)(object)itemDef != (Object)null && itemDef is Consumable)
			{
				return ((Consumable)itemDef).canTargetNonCharacters;
			}
			return false;
		}
	}

	public BackpackItemType backpackItemType
	{
		get
		{
			if ((Object)(object)itemDef != (Object)null && itemDef is IBackpackItem)
			{
				return ((IBackpackItem)itemDef).backpackItemType;
			}
			return BackpackItemType.None;
		}
	}

	public ItemData(int itemUID, int itemCount)
	{
		this.itemUID = itemUID;
		this.itemCount = itemCount;
	}

	public ItemData Copy()
	{
		return new ItemData(itemUID, itemCount);
	}
}
