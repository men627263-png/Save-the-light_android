using Grumpyface;
using TMPro;
using UnityEngine;

public class UISimpleBattleMessage : MonoBehaviour, IPoolable
{
	public TMP_Text textMesh;

	public RectTransform rectTransform
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Expected Obj, but got Unknown
			return (RectTransform)((Component)this).transform;
		}
	}

	public void ResetObject()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		((Transform)rectTransform).localScale = Vector3.one;
	}
}
