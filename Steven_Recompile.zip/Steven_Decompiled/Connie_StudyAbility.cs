using System;
using System.Collections;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Abilities/Player Characters/Connie/Study")]
public class Connie_StudyAbility : BaseAbility
{
	[Serializable]
	private class AbilityData
	{
		[Header("Animations")]
		public CharacterAnimationNamePair mainAnim = default;

		[Header("Tweakables")]
		public float damageBonus;
	}

	[SerializeField]
	private AbilityData abilityData;

	[NonSerialized]
	private ITargetable target;

	protected sealed override void OnInit()
	{
		base.OnInit();
		target = targets[0];
	}

	public override IEnumerator Play()
	{
		yield return (object)new WaitForSeconds(0.5f);
		caster.PlayAnim(abilityData.mainAnim, clearQueue: true);
		caster.AddAnimToQueue(caster.GetIdleAnimation());
		target.StatusEffectManager.AddStatusEffect(new Studied(target, (Object)(object)caster, abilityData.damageBonus));
		if (caster.HasPerkUnlocked(9))
		{
			for (int i = 0; i < GameController.Instance.Players.Count; i++)
			{
				BaseCharacter baseCharacter = GameController.Instance.Players[i];
				if (!object.ReferenceEquals(baseCharacter, caster) && Vector3.Distance(caster.positionXZ, baseCharacter.positionXZ) <= 5f)
				{
					baseCharacter.StatusEffectManager.AddStatusEffect(new Studied(baseCharacter, (Object)(object)caster, abilityData.damageBonus));
				}
			}
		}
		yield return (object)new WaitWhile((Func<bool>)(() => caster.IsAnimPlaying(abilityData.mainAnim)));
	}

	public override IEnumerator Cancel()
	{
		yield break;
	}

	protected sealed override void OnCleanUp()
	{
		target = null;
		base.OnCleanUp();
	}

	public override void ResetForReUse()
	{
		target = null;
		base.ResetForReUse();
	}
}
