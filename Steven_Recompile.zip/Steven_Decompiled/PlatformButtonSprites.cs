using System;
using UnityEngine;

[Serializable]
public class PlatformButtonSprites
{
	public UIGamepadButtonType buttonType;

	public Sprite ps4Sprite;

	public Sprite xboxSprite;

	public Sprite pcSprite;
}
