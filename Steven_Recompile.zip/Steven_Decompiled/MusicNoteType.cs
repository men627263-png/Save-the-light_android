public enum MusicNoteType
{
	None,
	Up,
	Down,
	Left,
	Right,
	LeftBumper,
	RightBumper
}
