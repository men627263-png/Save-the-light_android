using System;
using UnityEngine;

public interface IHealSender
{
	GameObject gameObject { get; }

	int LuckValue { get; }

	event Action<HealResult> OutgoingHeal;

	void OnOutgoingHeal(HealResult healResult);
}
