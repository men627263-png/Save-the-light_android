public class DamageResultEvent : GameEvent
{
	public DamageResult result { get; private set; }

	public DamageResultEvent(DamageResult result)
	{
		this.result = result;
	}
}
