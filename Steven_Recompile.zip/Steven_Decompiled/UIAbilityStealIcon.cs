using Grumpyface;
using SimpleSpritePacker;
using UnityEngine;
using UnityEngine.UI;

public class UIAbilityStealIcon : MonoBehaviour, IPoolable
{
	[SerializeField]
	private Image abilityIcon;

	[SerializeField]
	private Image noSymbol;

	[SerializeField]
	private SPInstance uiAtlas;

	[SerializeField]
	private UIFollowCharacter _uiFollowCharacter;

	public UIFollowCharacter uiFollowCharacter => _uiFollowCharacter;

	public void Init(AbilityDefinition ability, bool isDisabled = false)
	{
		abilityIcon.overrideSprite = uiAtlas.GetSpriteByName(ability.iconSpriteName);
		((Component)noSymbol).gameObject.SetActive(isDisabled);
	}

	public void ResetObject()
	{
		abilityIcon.overrideSprite = null;
		((Component)noSymbol).gameObject.SetActive(true);
	}
}
