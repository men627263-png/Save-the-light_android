using System.Collections.Generic;
using DG.Tweening;
using Grumpyface;
using UnityEngine;

public class BattleDisplayTextManager : MonoBehaviour
{
	public static BattleDisplayTextManager instance;

	public GameObject displayTextPrefab;

	public GameObject normalNotifierRightPrefab;

	public GameObject normalNotifierLeftPrefab;

	public GameObject perfectNotifierRightPrefab;

	public GameObject perfectNotifierLeftPrefab;

	public GameObject tooEarlyLateNotifierPrefab;

	public GameObject tooHighNotifierPrefab;

	public GameObject simpleBattleMessagePrefab;

	public GameObject luckyNotifierRightPrefab;

	public GameObject luckyNotifierLeftPrefab;

	public bool showDamageNumbers;

	public bool showHealNumbers;

	public bool showMessages;

	public bool showStarPoints;

	public float perfectScale = 0.5f;

	public float normalScale = 0.5f;

	public float tooEarlyLateScale = 0.5f;

	public float luckyScale = 0.5f;

	private Canvas uiCanvas;

	private UIStarMeter starMeter;

	private bool useLeft;

	private List<UISimpleBattleMessage> activeSimpleBattleMessages = new List<UISimpleBattleMessage>();

	private Dictionary<ITargetable, UISimpleBattleMessage> activeTooHighMessages = new Dictionary<ITargetable, UISimpleBattleMessage>();

	private void Awake()
	{
		if ((Object)(object)instance != (Object)null)
		{
			Object.Destroy((Object)(object)this);
		}
		else
		{
			instance = this;
		}
	}

	private void OnEnable()
	{
		EventMessenger.Instance.AddListener<DamageResultEvent>(HandleDamageResultEvent);
		EventMessenger.Instance.AddListener<HealResultEvent>(HandleHealResultEvent);
		EventMessenger.Instance.AddListener<DisplayBattleTextEvent>(HandleDisplayBattleTextEvent);
		EventMessenger.Instance.AddListener<DisplayTooHighMessageEvent>(HandleDisplayTooHighMessageEvent);
		EventMessenger.Instance.AddListener<AddStarPointsEvent>(HandleAddStarPointsEvent);
		EventMessenger.Instance.AddListener<StarPointsAddedEvent>(HandleStarPointsAddedEvent);
		EventMessenger.Instance.AddListener<BonusStarEvent>(HandleBonusStarEvent);
		EventMessenger.Instance.AddListener<SimpleBattleMessageEvent>(HandleSimpleBattleMessageEvent);
		EventMessenger.Instance.AddListener<SpecialItemEffectMessageEvent>(HandleSpecialItemMessageEvent);
		EventMessenger.Instance.AddListener<StatusEffectAddedEvent>(HandleStatusEffectAddedEvent);
		EventMessenger.Instance.AddListener<StatusEffectImmuneEvent>(HandleStatusEffectImmuneEvent);
		EventMessenger.Instance.AddListener<BattleFinishedEvent>(HandleBattleFinishedEvent);
	}

	private void Start()
	{
		uiCanvas = GameController.Instance.uiCanvas;
		starMeter = UIStarMeter.instance;
	}

	private void OnDisable()
	{
		EventMessenger.Instance.RemoveListener<DamageResultEvent>(HandleDamageResultEvent);
		EventMessenger.Instance.RemoveListener<HealResultEvent>(HandleHealResultEvent);
		EventMessenger.Instance.RemoveListener<DisplayBattleTextEvent>(HandleDisplayBattleTextEvent);
		EventMessenger.Instance.RemoveListener<DisplayTooHighMessageEvent>(HandleDisplayTooHighMessageEvent);
		EventMessenger.Instance.RemoveListener<AddStarPointsEvent>(HandleAddStarPointsEvent);
		EventMessenger.Instance.RemoveListener<StarPointsAddedEvent>(HandleStarPointsAddedEvent);
		EventMessenger.Instance.RemoveListener<BonusStarEvent>(HandleBonusStarEvent);
		EventMessenger.Instance.RemoveListener<SimpleBattleMessageEvent>(HandleSimpleBattleMessageEvent);
		EventMessenger.Instance.RemoveListener<SpecialItemEffectMessageEvent>(HandleSpecialItemMessageEvent);
		EventMessenger.Instance.RemoveListener<StatusEffectAddedEvent>(HandleStatusEffectAddedEvent);
		EventMessenger.Instance.RemoveListener<StatusEffectImmuneEvent>(HandleStatusEffectImmuneEvent);
		EventMessenger.Instance.RemoveListener<BattleFinishedEvent>(HandleBattleFinishedEvent);
	}

	private void OnDestroy()
	{
		instance = null;
	}

	private void HandleDamageResultEvent(DamageResultEvent evt)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Expected Obj, but got Unknown
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		if (evt.result.allowDisplay)
		{
			if (showDamageNumbers)
			{
				UIStatusText uIStatusText = ObjectPool.GetObject<UIStatusText>(displayTextPrefab, default(Vector3), true);
				uIStatusText.Init(evt.result.totalDamage.ToString(), uiCanvas, evt.result.displayFollowTarget, new Vector3(0f, 2f), new Color(1f, 0.016f, 0.016f, 1f), Color.white, string.Empty, -1f, (Ease)0);
			}
			if (showMessages && evt.result.isCritical && evt.result.target is BaseCharacter)
			{
				RectTransform val = (RectTransform)ObjectPool.GetObject((!useLeft) ? luckyNotifierRightPrefab : luckyNotifierLeftPrefab).transform;
				((Transform)val).parent = ((Component)uiCanvas).transform;
				((Component)val).GetComponent<UIFollowCharacter>().Init(uiCanvas, (BaseCharacter)evt.result.target, setParent: true, useInitialPosition: true);
				((Transform)val).localScale = new Vector3(luckyScale, luckyScale, luckyScale);
				useLeft = !useLeft;
			}
		}
	}

	private void HandleHealResultEvent(HealResultEvent evt)
	{
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Expected Obj, but got Unknown
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		if (showHealNumbers)
		{
			if (evt.delta > 0)
			{
				UIStatusText uIStatusText = ObjectPool.GetObject<UIStatusText>(displayTextPrefab, default(Vector3), true);
				uIStatusText.Init(evt.healResult.totalHealAmount.ToString(), uiCanvas, evt.healResult.target.gameObject.transform, new Vector3(0f, 2f), new Color(0.016f, 1f, 0.016f, 1f), Color.black, string.Empty, -1f, (Ease)0);
			}
			else
			{
				UIStatusText uIStatusText2 = ObjectPool.GetObject<UIStatusText>(displayTextPrefab, default(Vector3), true);
				uIStatusText2.Init(Languages.Get("FULL", "MENUS, GUI"), uiCanvas, evt.healResult.target.gameObject.transform, new Vector3(0f, 2f), new Color(0.016f, 1f, 0.016f, 1f), Color.black, string.Empty, -1f, (Ease)0);
			}
		}
		if (showMessages && evt.healResult.isCritical && evt.healResult.target is BaseCharacter)
		{
			RectTransform val = (RectTransform)ObjectPool.GetObject((!useLeft) ? luckyNotifierRightPrefab : luckyNotifierLeftPrefab).transform;
			((Transform)val).parent = ((Component)uiCanvas).transform;
			((Component)val).GetComponent<UIFollowCharacter>().Init(uiCanvas, (BaseCharacter)evt.healResult.target, setParent: true, useInitialPosition: true);
			((Transform)val).localScale = new Vector3(luckyScale, luckyScale, luckyScale);
			useLeft = !useLeft;
		}
	}

	private void HandleDisplayBattleTextEvent(DisplayBattleTextEvent evt)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		if (showMessages)
		{
			UIStatusText uIStatusText = ObjectPool.GetObject<UIStatusText>(displayTextPrefab, default(Vector3), true);
			uIStatusText.Init(evt.message, uiCanvas, evt.target, new Vector3(0f, 2f), new Color(0.016f, 1f, 0.016f, 1f), Color.black, string.Empty, -1f, (Ease)0);
		}
	}

	private void HandleDisplayTooHighMessageEvent(DisplayTooHighMessageEvent evt)
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		if (showMessages)
		{
			if (activeTooHighMessages.ContainsKey(evt.target) && ((Component)activeTooHighMessages[evt.target]).gameObject.activeSelf)
			{
				ObjectPool.PoolObject(((Component)activeTooHighMessages[evt.target]).gameObject);
			}
			UISimpleBattleMessage uISimpleBattleMessage = ObjectPool.GetObject<UISimpleBattleMessage>(tooHighNotifierPrefab, default(Vector3), true);
			((Component)uISimpleBattleMessage).GetComponent<UIFollow>().Init(uiCanvas, evt.target.CenterPosition, setParent: false);
			GameUI.instance.AddElementToLayer(uISimpleBattleMessage.rectTransform, GameUI.instance.gameUILayer, worldPositionStays: true);
			((Component)uISimpleBattleMessage).GetComponent<UIFollow>().ForceRefreshPosition();
			((Transform)uISimpleBattleMessage.rectTransform).localScale = new Vector3(1f, 1f, 1f);
			if (!activeTooHighMessages.ContainsKey(evt.target))
			{
				activeTooHighMessages.Add(evt.target, uISimpleBattleMessage);
			}
			else
			{
				activeTooHighMessages[evt.target] = uISimpleBattleMessage;
			}
		}
	}

	private void HandleAddStarPointsEvent(AddStarPointsEvent evt)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		if (showStarPoints && (Object)(object)evt.source != (Object)null)
		{
			UIStatusText uIStatusText = ObjectPool.GetObject<UIStatusText>(displayTextPrefab, default(Vector3), true);
			uIStatusText.Init(evt.amount.ToString(), uiCanvas, evt.source, new Vector3(0f, 150f), new Color(0.016f, 1f, 0.016f, 1f), Color.black, "item_starpoint_blank", 2f, (Ease)10);
		}
	}

	private void HandleStarPointsAddedEvent(StarPointsAddedEvent evt)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		if (showStarPoints)
		{
			UIStatusText uIStatusText = ObjectPool.GetObject<UIStatusText>(displayTextPrefab, default(Vector3), true);
			uIStatusText.Init(evt.originalAmount.ToString(), uiCanvas, ((Component)starMeter).transform, new Vector3(0f, 150f), new Color(0.016f, 1f, 0.016f, 1f), Color.black, "item_starpoint_blank", 2f, (Ease)10);
		}
	}

	private void HandleBonusStarEvent(BonusStarEvent evt)
	{
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Expected Obj, but got Unknown
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		if (showMessages)
		{
			UISimpleBattleMessage uISimpleBattleMessage = null;
			switch (evt.bonusType)
			{
			case AbilityStarBonusType.Perfect:
			{
				RectTransform val = (RectTransform)ObjectPool.GetObject((!useLeft) ? perfectNotifierRightPrefab : perfectNotifierLeftPrefab).transform;
				((Transform)val).parent = ((Component)uiCanvas).transform;
				((Component)val).GetComponent<UIFollowCharacter>().Init(uiCanvas, evt.bonusStars[Random.Range(0, evt.bonusStars.Count)].target, setParent: true, useInitialPosition: true);
				((Transform)val).localScale = new Vector3(perfectScale, perfectScale, perfectScale);
				useLeft = !useLeft;
				break;
			}
			case AbilityStarBonusType.Normal:
				uISimpleBattleMessage = ObjectPool.GetObject<UISimpleBattleMessage>((!useLeft) ? normalNotifierRightPrefab : normalNotifierLeftPrefab, default(Vector3), true);
				((Component)uISimpleBattleMessage).transform.parent = ((Component)uiCanvas).transform;
				((Component)uISimpleBattleMessage).GetComponent<UIFollowCharacter>().Init(uiCanvas, evt.bonusStars[Random.Range(0, evt.bonusStars.Count)].target, setParent: true, useInitialPosition: true);
				((Transform)uISimpleBattleMessage.rectTransform).localScale = new Vector3(normalScale, normalScale, normalScale);
				uISimpleBattleMessage.textMesh.text = Languages.Get(GameResources.instance.gameSettings.starBonusMessages[Random.Range(0, GameResources.instance.gameSettings.starBonusMessages.Length)].key, "MENUS, GUI");
				useLeft = !useLeft;
				break;
			case AbilityStarBonusType.CancelEarly:
				uISimpleBattleMessage = ObjectPool.GetObject<UISimpleBattleMessage>(tooEarlyLateNotifierPrefab, default(Vector3), true);
				((Component)uISimpleBattleMessage).transform.parent = ((Component)uiCanvas).transform;
				((Component)uISimpleBattleMessage).GetComponent<UIFollowCharacter>().Init(uiCanvas, evt.bonusStars[Random.Range(0, evt.bonusStars.Count)].target, setParent: true, useInitialPosition: true);
				((Transform)uISimpleBattleMessage.rectTransform).localScale = new Vector3(tooEarlyLateScale, tooEarlyLateScale, tooEarlyLateScale);
				uISimpleBattleMessage.textMesh.text = Languages.Get("TOO_EARLY", "MENUS, GUI");
				break;
			case AbilityStarBonusType.CancelLate:
				uISimpleBattleMessage = ObjectPool.GetObject<UISimpleBattleMessage>(tooEarlyLateNotifierPrefab, default(Vector3), true);
				((Component)uISimpleBattleMessage).transform.parent = ((Component)uiCanvas).transform;
				((Component)uISimpleBattleMessage).GetComponent<UIFollowCharacter>().Init(uiCanvas, evt.bonusStars[Random.Range(0, evt.bonusStars.Count)].target, setParent: true, useInitialPosition: true);
				((Transform)uISimpleBattleMessage.rectTransform).localScale = new Vector3(tooEarlyLateScale, tooEarlyLateScale, tooEarlyLateScale);
				uISimpleBattleMessage.textMesh.text = Languages.Get("TOO_LATE", "MENUS, GUI");
				break;
			case AbilityStarBonusType.None:
			case AbilityStarBonusType.PerfectStart:
				break;
			}
		}
	}

	private void HandleSimpleBattleMessageEvent(SimpleBattleMessageEvent evt)
	{
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		if (!showMessages)
		{
			return;
		}
		UISimpleBattleMessage uISimpleBattleMessage = null;
		for (int num = activeSimpleBattleMessages.Count - 1; num >= 0; num--)
		{
			uISimpleBattleMessage = activeSimpleBattleMessages[num];
			if (((Component)uISimpleBattleMessage).gameObject.activeSelf && uISimpleBattleMessage.textMesh.text.Equals(evt.message))
			{
				ObjectPool.PoolObject(((Component)uISimpleBattleMessage).gameObject);
			}
			if (!((Component)uISimpleBattleMessage).gameObject.activeSelf)
			{
				activeSimpleBattleMessages.RemoveAt(num);
			}
		}
		uISimpleBattleMessage = ObjectPool.GetObject<UISimpleBattleMessage>(simpleBattleMessagePrefab, default(Vector3), true);
		if (evt.isWorldPosition)
		{
			((Component)uISimpleBattleMessage).GetComponent<UIFollow>().Init(uiCanvas, evt.anchoredPosition, setParent: false);
			GameUI.instance.AddElementToLayer(uISimpleBattleMessage.rectTransform, GameUI.instance.gameUILayer, worldPositionStays: true);
			((Transform)uISimpleBattleMessage.rectTransform).localScale = new Vector3(evt.scale, evt.scale, evt.scale);
			((Component)uISimpleBattleMessage).GetComponent<UIFollow>().ForceRefreshPosition();
		}
		else
		{
			GameUI.instance.AddElementToLayer(uISimpleBattleMessage.rectTransform, GameUI.instance.gameUILayer, worldPositionStays: true);
			((Transform)uISimpleBattleMessage.rectTransform).localScale = new Vector3(evt.scale, evt.scale, evt.scale);
			uISimpleBattleMessage.rectTransform.anchoredPosition3D = evt.anchoredPosition;
		}
		uISimpleBattleMessage.textMesh.text = evt.message;
		uISimpleBattleMessage.textMesh.faceColor = Color32.op_Implicit(evt.faceColor);
		activeSimpleBattleMessages.Add(uISimpleBattleMessage);
	}

	private void HandleSpecialItemMessageEvent(SpecialItemEffectMessageEvent evt)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		if (showMessages)
		{
			UISimpleBattleMessage uISimpleBattleMessage = ObjectPool.GetObject<UISimpleBattleMessage>((!useLeft) ? normalNotifierRightPrefab : normalNotifierLeftPrefab, default(Vector3), true);
			((Component)uISimpleBattleMessage).transform.parent = ((Component)uiCanvas).transform;
			((Component)uISimpleBattleMessage).GetComponent<UIFollowCharacter>().Init(uiCanvas, evt.target);
			((Transform)uISimpleBattleMessage.rectTransform).localScale = new Vector3(normalScale, normalScale, normalScale);
			uISimpleBattleMessage.textMesh.text = evt.message;
			uISimpleBattleMessage.textMesh.faceColor = Color32.op_Implicit(evt.faceColor);
			useLeft = !useLeft;
		}
	}

	private void HandleStatusEffectAddedEvent(StatusEffectAddedEvent evt)
	{
	}

	private void HandleStatusEffectImmuneEvent(StatusEffectImmuneEvent evt)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		if (showMessages)
		{
			EventMessenger.Instance.Raise(new SimpleBattleMessageEvent(Languages.Get("IMMUNE", "MENUS, GUI"), evt.owner.CenterTopPosition + Vector3.up, 0.4f, new Color(1f, 1f, 1f), isWorldPosition: true));
		}
	}

	private void HandleBattleFinishedEvent(BattleFinishedEvent evt)
	{
		activeTooHighMessages.Clear();
	}
}
