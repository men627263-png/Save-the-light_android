using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace Pathfinding.RVO.Sampled;

public class Agent : IAgent
{
	public struct VO
	{
		public Vector2 origin;

		public Vector2 center;

		private Vector2 line1;

		private Vector2 line2;

		private Vector2 dir1;

		private Vector2 dir2;

		private Vector2 cutoffLine;

		private Vector2 cutoffDir;

		private float sqrCutoffDistance;

		private bool leftSide;

		private bool colliding;

		private float radius;

		private float weightFactor;

		public VO(Vector2 offset, Vector2 p0, Vector2 dir, float weightFactor)
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_001b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0031: Unknown result type (might be due to invalid IL or missing references)
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_004c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Unknown result type (might be due to invalid IL or missing references)
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			colliding = true;
			line1 = p0;
			dir1 = -dir;
			origin = Vector2.zero;
			center = Vector2.zero;
			line2 = Vector2.zero;
			dir2 = Vector2.zero;
			cutoffLine = Vector2.zero;
			cutoffDir = Vector2.zero;
			sqrCutoffDistance = 0f;
			leftSide = false;
			radius = 0f;
			this.weightFactor = weightFactor * 0.5f;
		}

		public VO(Vector2 offset, Vector2 p1, Vector2 p2, Vector2 tang1, Vector2 tang2, float weightFactor)
		{
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_0027: Unknown result type (might be due to invalid IL or missing references)
			//IL_002c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			//IL_0039: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			//IL_0042: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Unknown result type (might be due to invalid IL or missing references)
			//IL_0056: Unknown result type (might be due to invalid IL or missing references)
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0062: Unknown result type (might be due to invalid IL or missing references)
			//IL_0067: Unknown result type (might be due to invalid IL or missing references)
			//IL_006c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0072: Unknown result type (might be due to invalid IL or missing references)
			//IL_0077: Unknown result type (might be due to invalid IL or missing references)
			//IL_007d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			this.weightFactor = weightFactor * 0.5f;
			colliding = false;
			cutoffLine = p1;
			Vector2 val = p2 - p1;
			cutoffDir = val.normalized;
			line1 = p1;
			dir1 = tang1;
			line2 = p2;
			dir2 = tang2;
			dir2 = -dir2;
			cutoffDir = -cutoffDir;
			origin = Vector2.zero;
			center = Vector2.zero;
			sqrCutoffDistance = 0f;
			leftSide = false;
			radius = 0f;
			weightFactor = 5f;
		}

		public VO(Vector2 center, Vector2 offset, float radius, Vector2 sideChooser, float inverseDt, float weightFactor)
		{
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
			//IL_0110: Unknown result type (might be due to invalid IL or missing references)
			//IL_0111: Unknown result type (might be due to invalid IL or missing references)
			//IL_0119: Unknown result type (might be due to invalid IL or missing references)
			//IL_0124: Unknown result type (might be due to invalid IL or missing references)
			//IL_0129: Unknown result type (might be due to invalid IL or missing references)
			//IL_0148: Unknown result type (might be due to invalid IL or missing references)
			//IL_014f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0154: Unknown result type (might be due to invalid IL or missing references)
			//IL_015b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0160: Unknown result type (might be due to invalid IL or missing references)
			//IL_0161: Unknown result type (might be due to invalid IL or missing references)
			//IL_0166: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
			//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
			//IL_0200: Unknown result type (might be due to invalid IL or missing references)
			//IL_0207: Unknown result type (might be due to invalid IL or missing references)
			//IL_020c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0224: Unknown result type (might be due to invalid IL or missing references)
			//IL_022a: Unknown result type (might be due to invalid IL or missing references)
			//IL_022f: Unknown result type (might be due to invalid IL or missing references)
			//IL_024e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0255: Unknown result type (might be due to invalid IL or missing references)
			//IL_025a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0261: Unknown result type (might be due to invalid IL or missing references)
			//IL_0266: Unknown result type (might be due to invalid IL or missing references)
			//IL_0267: Unknown result type (might be due to invalid IL or missing references)
			//IL_026c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0273: Unknown result type (might be due to invalid IL or missing references)
			//IL_0278: Unknown result type (might be due to invalid IL or missing references)
			//IL_0279: Unknown result type (might be due to invalid IL or missing references)
			//IL_027e: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Unknown result type (might be due to invalid IL or missing references)
			//IL_006c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0073: Unknown result type (might be due to invalid IL or missing references)
			//IL_0078: Unknown result type (might be due to invalid IL or missing references)
			//IL_007f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0084: Unknown result type (might be due to invalid IL or missing references)
			//IL_0085: Unknown result type (might be due to invalid IL or missing references)
			//IL_008a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0090: Unknown result type (might be due to invalid IL or missing references)
			//IL_0095: Unknown result type (might be due to invalid IL or missing references)
			//IL_009b: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
			this.weightFactor = weightFactor * 0.5f;
			origin = offset;
			weightFactor = 0.5f;
			if (center.magnitude < radius)
			{
				colliding = true;
				leftSide = false;
				line1 = center.normalized * (center.magnitude - radius);
				Vector2 val = new Vector2(line1.y, 0f - line1.x);
				dir1 = val.normalized;
				line1 += offset;
				cutoffDir = Vector2.zero;
				cutoffLine = Vector2.zero;
				sqrCutoffDistance = 0f;
				dir2 = Vector2.zero;
				line2 = Vector2.zero;
				this.center = Vector2.zero;
				this.radius = 0f;
			}
			else
			{
				colliding = false;
				center *= inverseDt;
				radius *= inverseDt;
				Vector2 val2 = center + offset;
				sqrCutoffDistance = center.magnitude - radius;
				this.center = center;
				cutoffLine = center.normalized * sqrCutoffDistance;
				Vector2 val3 = new Vector2(0f - cutoffLine.y, cutoffLine.x);
				cutoffDir = val3.normalized;
				cutoffLine += offset;
				sqrCutoffDistance *= sqrCutoffDistance;
				float num = Mathf.Atan2(0f - center.y, 0f - center.x);
				float num2 = Mathf.Abs(Mathf.Acos(radius / center.magnitude));
				this.radius = radius;
				leftSide = VectorMath.RightOrColinear(Vector2.zero, center, sideChooser);
				line1 = new Vector2(Mathf.Cos(num + num2), Mathf.Sin(num + num2)) * radius;
				Vector2 val4 = new Vector2(line1.y, 0f - line1.x);
				dir1 = val4.normalized;
				line2 = new Vector2(Mathf.Cos(num - num2), Mathf.Sin(num - num2)) * radius;
				Vector2 val5 = new Vector2(line2.y, 0f - line2.x);
				dir2 = val5.normalized;
				line1 += val2;
				line2 += val2;
			}
		}

		public static bool Left(Vector2 a, Vector2 dir, Vector2 p)
		{
			return dir.x * (p.y - a.y) - (p.x - a.x) * dir.y <= 0f;
		}

		public static float Det(Vector2 a, Vector2 dir, Vector2 p)
		{
			return (p.x - a.x) * dir.y - dir.x * (p.y - a.y);
		}

		public Vector2 Sample(Vector2 p, out float weight)
		{
			//IL_0079: Unknown result type (might be due to invalid IL or missing references)
			//IL_007f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0084: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
			//IL_00af: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
			//IL_009d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0072: Unknown result type (might be due to invalid IL or missing references)
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Unknown result type (might be due to invalid IL or missing references)
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
			//IL_0178: Unknown result type (might be due to invalid IL or missing references)
			//IL_017f: Unknown result type (might be due to invalid IL or missing references)
			//IL_013e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0145: Unknown result type (might be due to invalid IL or missing references)
			//IL_0117: Unknown result type (might be due to invalid IL or missing references)
			//IL_011e: Unknown result type (might be due to invalid IL or missing references)
			if (colliding)
			{
				float num = Det(line1, dir1, p);
				if (num >= 0f)
				{
					weight = num * weightFactor;
					return new Vector2(0f - dir1.y, dir1.x) * weight * GlobalIncompressibility;
				}
				weight = 0f;
				return new Vector2(0f, 0f);
			}
			float num2 = Det(cutoffLine, cutoffDir, p);
			if (num2 <= 0f)
			{
				weight = 0f;
				return Vector2.zero;
			}
			float num3 = Det(line1, dir1, p);
			float num4 = Det(line2, dir2, p);
			if (num3 >= 0f && num4 >= 0f)
			{
				if (leftSide)
				{
					if (num2 < radius)
					{
						weight = num2 * weightFactor;
						return new Vector2(0f - cutoffDir.y, cutoffDir.x) * weight;
					}
					weight = num3;
					return new Vector2(0f - dir1.y, dir1.x) * weight;
				}
				if (num2 < radius)
				{
					weight = num2 * weightFactor;
					return new Vector2(0f - cutoffDir.y, cutoffDir.x) * weight;
				}
				weight = num4 * weightFactor;
				return new Vector2(0f - dir2.y, dir2.x) * weight;
			}
			weight = 0f;
			return new Vector2(0f, 0f);
		}

		public float ScalarSample(Vector2 p)
		{
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0045: Unknown result type (might be due to invalid IL or missing references)
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Unknown result type (might be due to invalid IL or missing references)
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_006e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0076: Unknown result type (might be due to invalid IL or missing references)
			//IL_007c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0081: Unknown result type (might be due to invalid IL or missing references)
			if (colliding)
			{
				float num = Det(line1, dir1, p);
				if (num >= 0f)
				{
					return num * GlobalIncompressibility * weightFactor;
				}
				return 0f;
			}
			float num2 = Det(cutoffLine, cutoffDir, p);
			if (num2 <= 0f)
			{
				return 0f;
			}
			float num3 = Det(line1, dir1, p);
			float num4 = Det(line2, dir2, p);
			if (num3 >= 0f && num4 >= 0f)
			{
				if (leftSide)
				{
					if (num2 < radius)
					{
						return num2 * weightFactor;
					}
					return num3 * weightFactor;
				}
				if (num2 < radius)
				{
					return num2 * weightFactor;
				}
				return num4 * weightFactor;
			}
			return 0f;
		}
	}

	private Vector3 smoothPos;

	public float radius;

	public float height;

	public float maxSpeed;

	public float neighbourDist;

	public float agentTimeHorizon;

	public float obstacleTimeHorizon;

	public float weight;

	public bool locked;

	private RVOLayer layer;

	private RVOLayer collidesWith;

	public int maxNeighbours;

	public Vector3 position;

	public Vector3 desiredVelocity;

	public Vector3 prevSmoothPos;

	internal Agent next;

	private Vector3 velocity;

	internal Vector3 newVelocity;

	public Simulator simulator;

	public List<Agent> neighbours = new List<Agent>();

	public List<float> neighbourDists = new List<float>();

	private List<ObstacleVertex> obstaclesBuffered = new List<ObstacleVertex>();

	private List<ObstacleVertex> obstacles = new List<ObstacleVertex>();

	private List<float> obstacleDists = new List<float>();

	public static Stopwatch watch1 = new Stopwatch();

	public static Stopwatch watch2 = new Stopwatch();

	public static float DesiredVelocityWeight = 0.02f;

	public static float DesiredVelocityScale = 0.1f;

	public static float GlobalIncompressibility = 30f;

	private const float WallWeight = 5f;

	public Vector3 Position
	{
		[CompilerGenerated]
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return field;
		}
		[CompilerGenerated]
		private set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			field = value;
		}
	}

	public Vector3 InterpolatedPosition
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return smoothPos;
		}
	}

	public Vector3 DesiredVelocity
	{
		[CompilerGenerated]
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return field;
		}
		[CompilerGenerated]
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			field = value;
		}
	}

	public RVOLayer Layer { get; set; }

	public RVOLayer CollidesWith { get; set; }

	public bool Locked { get; set; }

	public float Radius { get; set; }

	public float Height { get; set; }

	public float MaxSpeed { get; set; }

	public float NeighbourDist { get; set; }

	public float AgentTimeHorizon { get; set; }

	public float ObstacleTimeHorizon { get; set; }

	public Vector3 Velocity
	{
		[CompilerGenerated]
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return field;
		}
		[CompilerGenerated]
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			field = value;
		}
	}

	public bool DebugDraw { get; set; }

	public int MaxNeighbours { get; set; }

	public List<ObstacleVertex> NeighbourObstacles => null;

	public Agent(Vector3 pos)
	{
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		MaxSpeed = 2f;
		NeighbourDist = 15f;
		AgentTimeHorizon = 2f;
		ObstacleTimeHorizon = 2f;
		Height = 5f;
		Radius = 5f;
		MaxNeighbours = 10;
		Locked = false;
		position = pos;
		Position = position;
		prevSmoothPos = position;
		smoothPos = position;
		Layer = RVOLayer.DefaultAgent;
		CollidesWith = (RVOLayer)(-1);
	}

	public void Teleport(Vector3 pos)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		Position = pos;
		smoothPos = pos;
		prevSmoothPos = pos;
	}

	public void SetYPosition(float yCoordinate)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		Position = new Vector3(Position.x, yCoordinate, Position.z);
		smoothPos.y = yCoordinate;
		prevSmoothPos.y = yCoordinate;
	}

	public void BufferSwitch()
	{
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		radius = Radius;
		height = Height;
		maxSpeed = MaxSpeed;
		neighbourDist = NeighbourDist;
		agentTimeHorizon = AgentTimeHorizon;
		obstacleTimeHorizon = ObstacleTimeHorizon;
		maxNeighbours = MaxNeighbours;
		desiredVelocity = DesiredVelocity;
		locked = Locked;
		collidesWith = CollidesWith;
		layer = Layer;
		Velocity = velocity;
		List<ObstacleVertex> list = obstaclesBuffered;
		obstaclesBuffered = obstacles;
		obstacles = list;
	}

	public void Update()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		velocity = newVelocity;
		prevSmoothPos = smoothPos;
		position = prevSmoothPos;
		position += velocity * simulator.DeltaTime;
		Position = position;
	}

	public void Interpolate(float t)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		smoothPos = prevSmoothPos + (Position - prevSmoothPos) * t;
	}

	public void CalculateNeighbours()
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		neighbours.Clear();
		neighbourDists.Clear();
		if (!locked)
		{
			float num;
			if (MaxNeighbours > 0)
			{
				num = neighbourDist * neighbourDist;
				simulator.Quadtree.Query(new Vector2(position.x, position.z), neighbourDist, this);
			}
			obstacles.Clear();
			obstacleDists.Clear();
			num = obstacleTimeHorizon * maxSpeed + radius;
			num *= num;
		}
	}

	private float Sqr(float x)
	{
		return x * x;
	}

	public float InsertAgentNeighbour(Agent agent, float rangeSq)
	{
		if (this == agent)
		{
			return rangeSq;
		}
		if ((agent.layer & collidesWith) == 0)
		{
			return rangeSq;
		}
		float num = Sqr(agent.position.x - position.x) + Sqr(agent.position.z - position.z);
		if (num < rangeSq)
		{
			if (neighbours.Count < maxNeighbours)
			{
				neighbours.Add(agent);
				neighbourDists.Add(num);
			}
			int num2 = neighbours.Count - 1;
			if (num < neighbourDists[num2])
			{
				while (num2 != 0 && num < neighbourDists[num2 - 1])
				{
					neighbours[num2] = neighbours[num2 - 1];
					neighbourDists[num2] = neighbourDists[num2 - 1];
					num2--;
				}
				neighbours[num2] = agent;
				neighbourDists[num2] = num;
			}
			if (neighbours.Count == maxNeighbours)
			{
				rangeSq = neighbourDists[neighbourDists.Count - 1];
			}
		}
		return rangeSq;
	}

	public void InsertObstacleNeighbour(ObstacleVertex ob1, float rangeSq)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		ObstacleVertex obstacleVertex = ob1.next;
		float num = VectorMath.SqrDistancePointSegment(ob1.position, obstacleVertex.position, Position);
		if (num < rangeSq)
		{
			obstacles.Add(ob1);
			obstacleDists.Add(num);
			int num2 = obstacles.Count - 1;
			while (num2 != 0 && num < obstacleDists[num2 - 1])
			{
				obstacles[num2] = obstacles[num2 - 1];
				obstacleDists[num2] = obstacleDists[num2 - 1];
				num2--;
			}
			obstacles[num2] = ob1;
			obstacleDists[num2] = num;
		}
	}

	private static Vector3 To3D(Vector2 p)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		return new Vector3(p.x, 0f, p.y);
	}

	private static void DrawCircle(Vector2 _p, float radius, Color col)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		DrawCircle(_p, radius, 0f, (float)Math.PI * 2f, col);
	}

	private static void DrawCircle(Vector2 _p, float radius, float a0, float a1, Color col)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = To3D(_p);
		while (a0 > a1)
		{
			a0 -= (float)Math.PI * 2f;
		}
		Vector3 val2 = new Vector3(Mathf.Cos(a0) * radius, 0f, Mathf.Sin(a0) * radius);
		for (int i = 0; (float)i <= 40f; i++)
		{
			Vector3 val3 = new Vector3(Mathf.Cos(Mathf.Lerp(a0, a1, (float)i / 40f)) * radius, 0f, Mathf.Sin(Mathf.Lerp(a0, a1, (float)i / 40f)) * radius);
			Debug.DrawLine(val + val2, val + val3, col);
			val2 = val3;
		}
	}

	private static void DrawVO(Vector2 circleCenter, float radius, Vector2 origin)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		float num = Mathf.Atan2((origin - circleCenter).y, (origin - circleCenter).x);
		Vector2 val = origin - circleCenter;
		float num2 = radius / val.magnitude;
		float num3 = ((!(num2 <= 1f)) ? 0f : Mathf.Abs(Mathf.Acos(num2)));
		DrawCircle(circleCenter, radius, num - num3, num + num3, Color.black);
		Vector2 val2 = new Vector2(Mathf.Cos(num - num3), Mathf.Sin(num - num3)) * radius;
		Vector2 val3 = new Vector2(Mathf.Cos(num + num3), Mathf.Sin(num + num3)) * radius;
		Vector2 p = -new Vector2(0f - val2.y, val2.x);
		Vector2 p2 = new Vector2(0f - val3.y, val3.x);
		val2 += circleCenter;
		val3 += circleCenter;
		Vector3 val4 = To3D(val2);
		Vector3 val5 = To3D(p);
		Debug.DrawRay(val4, val5.normalized * 100f, Color.black);
		Vector3 val6 = To3D(val3);
		Vector3 val7 = To3D(p2);
		Debug.DrawRay(val6, val7.normalized * 100f, Color.black);
	}

	private static void DrawCross(Vector2 p, float size = 1f)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		DrawCross(p, Color.white, size);
	}

	private static void DrawCross(Vector2 p, Color col, float size = 1f)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		size *= 0.5f;
		Debug.DrawLine(new Vector3(p.x, 0f, p.y) - Vector3.right * size, new Vector3(p.x, 0f, p.y) + Vector3.right * size, col);
		Debug.DrawLine(new Vector3(p.x, 0f, p.y) - Vector3.forward * size, new Vector3(p.x, 0f, p.y) + Vector3.forward * size, col);
	}

	internal void CalculateVelocity(Simulator.WorkerContext context)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0520: Unknown result type (might be due to invalid IL or missing references)
		//IL_0525: Unknown result type (might be due to invalid IL or missing references)
		//IL_0810: Unknown result type (might be due to invalid IL or missing references)
		//IL_0823: Unknown result type (might be due to invalid IL or missing references)
		//IL_0828: Unknown result type (might be due to invalid IL or missing references)
		//IL_0846: Unknown result type (might be due to invalid IL or missing references)
		//IL_0848: Unknown result type (might be due to invalid IL or missing references)
		//IL_0869: Unknown result type (might be due to invalid IL or missing references)
		//IL_086a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0882: Unknown result type (might be due to invalid IL or missing references)
		//IL_0888: Unknown result type (might be due to invalid IL or missing references)
		//IL_088d: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_042a: Unknown result type (might be due to invalid IL or missing references)
		//IL_042f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0444: Unknown result type (might be due to invalid IL or missing references)
		//IL_0471: Unknown result type (might be due to invalid IL or missing references)
		//IL_0476: Unknown result type (might be due to invalid IL or missing references)
		//IL_0477: Unknown result type (might be due to invalid IL or missing references)
		//IL_047c: Unknown result type (might be due to invalid IL or missing references)
		//IL_047e: Unknown result type (might be due to invalid IL or missing references)
		//IL_047f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0481: Unknown result type (might be due to invalid IL or missing references)
		//IL_0486: Unknown result type (might be due to invalid IL or missing references)
		//IL_072b: Unknown result type (might be due to invalid IL or missing references)
		//IL_075e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0767: Unknown result type (might be due to invalid IL or missing references)
		//IL_076c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_049d: Unknown result type (might be due to invalid IL or missing references)
		//IL_049e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_04af: Unknown result type (might be due to invalid IL or missing references)
		//IL_0494: Unknown result type (might be due to invalid IL or missing references)
		//IL_0496: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_08fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0903: Unknown result type (might be due to invalid IL or missing references)
		//IL_0944: Unknown result type (might be due to invalid IL or missing references)
		//IL_094b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0950: Unknown result type (might be due to invalid IL or missing references)
		//IL_0952: Unknown result type (might be due to invalid IL or missing references)
		//IL_0959: Unknown result type (might be due to invalid IL or missing references)
		//IL_095e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0791: Unknown result type (might be due to invalid IL or missing references)
		//IL_0796: Unknown result type (might be due to invalid IL or missing references)
		//IL_079b: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0779: Unknown result type (might be due to invalid IL or missing references)
		//IL_077b: Unknown result type (might be due to invalid IL or missing references)
		//IL_077c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0781: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_04be: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0971: Unknown result type (might be due to invalid IL or missing references)
		//IL_0993: Unknown result type (might be due to invalid IL or missing references)
		//IL_0998: Unknown result type (might be due to invalid IL or missing references)
		//IL_09c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_09c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0573: Unknown result type (might be due to invalid IL or missing references)
		//IL_0578: Unknown result type (might be due to invalid IL or missing references)
		//IL_057d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a01: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a54: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a59: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a93: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a99: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a9e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0db3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0db8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d93: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d95: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d96: Unknown result type (might be due to invalid IL or missing references)
		//IL_0306: Unknown result type (might be due to invalid IL or missing references)
		//IL_030b: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_0335: Unknown result type (might be due to invalid IL or missing references)
		//IL_033a: Unknown result type (might be due to invalid IL or missing references)
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_0344: Unknown result type (might be due to invalid IL or missing references)
		//IL_0349: Unknown result type (might be due to invalid IL or missing references)
		//IL_034d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0352: Unknown result type (might be due to invalid IL or missing references)
		//IL_035b: Unknown result type (might be due to invalid IL or missing references)
		//IL_035c: Unknown result type (might be due to invalid IL or missing references)
		//IL_035e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0360: Unknown result type (might be due to invalid IL or missing references)
		//IL_0362: Unknown result type (might be due to invalid IL or missing references)
		//IL_058e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0598: Unknown result type (might be due to invalid IL or missing references)
		//IL_059a: Unknown result type (might be due to invalid IL or missing references)
		//IL_059b: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_05df: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0601: Unknown result type (might be due to invalid IL or missing references)
		//IL_0606: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0642: Unknown result type (might be due to invalid IL or missing references)
		//IL_0644: Unknown result type (might be due to invalid IL or missing references)
		//IL_0649: Unknown result type (might be due to invalid IL or missing references)
		//IL_0650: Unknown result type (might be due to invalid IL or missing references)
		//IL_0655: Unknown result type (might be due to invalid IL or missing references)
		//IL_065a: Unknown result type (might be due to invalid IL or missing references)
		//IL_066b: Unknown result type (might be due to invalid IL or missing references)
		//IL_066d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0677: Unknown result type (might be due to invalid IL or missing references)
		//IL_0681: Unknown result type (might be due to invalid IL or missing references)
		//IL_0686: Unknown result type (might be due to invalid IL or missing references)
		//IL_068b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0690: Unknown result type (might be due to invalid IL or missing references)
		//IL_0699: Unknown result type (might be due to invalid IL or missing references)
		//IL_069e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0637: Unknown result type (might be due to invalid IL or missing references)
		//IL_063b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0640: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d84: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d86: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06df: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b33: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b5b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b60: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b62: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b67: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c89: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c8e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cda: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ceb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cfb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d03: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d08: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d0d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d24: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d29: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d2e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b97: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bbe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c46: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c4b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c17: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c1c: Unknown result type (might be due to invalid IL or missing references)
		if (locked)
		{
			newVelocity = Vector2.op_Implicit(Vector2.zero);
			return;
		}
		if (context.vos.Length < neighbours.Count + simulator.obstacles.Count)
		{
			context.vos = new VO[Mathf.Max(context.vos.Length * 2, neighbours.Count + simulator.obstacles.Count)];
		}
		Vector2 val = new Vector2(position.x, position.z);
		VO[] vos = context.vos;
		int num = 0;
		Vector2 val2 = new Vector2(velocity.x, velocity.z);
		float num2 = 1f / agentTimeHorizon;
		float wallThickness = simulator.WallThickness;
		float num3 = ((simulator.algorithm != Simulator.SamplingAlgorithm.GradientDecent) ? 5f : 1f);
		for (int i = 0; i < simulator.obstacles.Count; i++)
		{
			ObstacleVertex obstacleVertex = simulator.obstacles[i];
			ObstacleVertex obstacleVertex2 = obstacleVertex;
			do
			{
				if (obstacleVertex2.ignore || position.y > obstacleVertex2.position.y + obstacleVertex2.height || position.y + height < obstacleVertex2.position.y || (obstacleVertex2.layer & collidesWith) == 0)
				{
					obstacleVertex2 = obstacleVertex2.next;
					continue;
				}
				float num4 = VO.Det(new Vector2(obstacleVertex2.position.x, obstacleVertex2.position.z), obstacleVertex2.dir, val);
				float num5 = num4;
				float num6 = Vector2.Dot(obstacleVertex2.dir, val - new Vector2(obstacleVertex2.position.x, obstacleVertex2.position.z));
				int num7;
				if (!(num6 <= wallThickness * 0.05f))
				{
					Vector2 val3 = new Vector2(obstacleVertex2.position.x, obstacleVertex2.position.z) - new Vector2(obstacleVertex2.next.position.x, obstacleVertex2.next.position.z);
					num7 = ((num6 >= val3.magnitude - wallThickness * 0.05f) ? 1 : 0);
				}
				else
				{
					num7 = 1;
				}
				bool flag = (byte)num7 != 0;
				if (Mathf.Abs(num5) < neighbourDist)
				{
					if (num5 <= 0f && !flag && num5 > 0f - wallThickness)
					{
						ref VO reference = ref vos[num];
						reference = new VO(val, new Vector2(obstacleVertex2.position.x, obstacleVertex2.position.z) - val, obstacleVertex2.dir, num3 * 2f);
						num++;
					}
					else if (num5 > 0f)
					{
						Vector2 p = new Vector2(obstacleVertex2.position.x, obstacleVertex2.position.z) - val;
						Vector2 p2 = new Vector2(obstacleVertex2.next.position.x, obstacleVertex2.next.position.z) - val;
						Vector2 normalized = p.normalized;
						Vector2 normalized2 = p2.normalized;
						ref VO reference2 = ref vos[num];
						reference2 = new VO(val, p, p2, normalized, normalized2, num3);
						num++;
					}
				}
				obstacleVertex2 = obstacleVertex2.next;
			}
			while (obstacleVertex2 != obstacleVertex);
		}
		for (int j = 0; j < neighbours.Count; j++)
		{
			Agent agent = neighbours[j];
			if (agent == this)
			{
				continue;
			}
			float num8 = Math.Min(position.y + height, agent.position.y + agent.height);
			float num9 = Math.Max(position.y, agent.position.y);
			if (!(num8 - num9 < 0f))
			{
				Vector2 val4 = new Vector2(agent.Velocity.x, agent.velocity.z);
				float num10 = radius + agent.radius;
				Vector2 val5 = new Vector2(agent.position.x, agent.position.z) - val;
				Vector2 sideChooser = val2 - val4;
				Vector2 val6 = ((!agent.locked) ? ((val2 + val4) * 0.5f) : val4);
				ref VO reference3 = ref vos[num];
				reference3 = new VO(val5, val6, num10, sideChooser, num2, 1f);
				num++;
				if (DebugDraw)
				{
					DrawVO(val + val5 * num2 + val6, num10 * num2, val + val6);
				}
			}
		}
		Vector2 zero = Vector2.zero;
		if (simulator.algorithm == Simulator.SamplingAlgorithm.GradientDecent)
		{
			if (DebugDraw)
			{
				for (int k = 0; k < 40; k++)
				{
					for (int l = 0; l < 40; l++)
					{
						Vector2 val7 = new Vector2((float)k * 15f / 40f, (float)l * 15f / 40f);
						Vector2 val8 = Vector2.zero;
						float num11 = 0f;
						for (int m = 0; m < num; m++)
						{
							val8 += vos[m].Sample(val7 - val, out var num12);
							if (num12 > num11)
							{
								num11 = num12;
							}
						}
						Vector2 val9 = new Vector2(desiredVelocity.x, desiredVelocity.z) - (val7 - val);
						val8 += val9 * DesiredVelocityScale;
						if (val9.magnitude * DesiredVelocityWeight > num11)
						{
							num11 = val9.magnitude * DesiredVelocityWeight;
						}
						if (num11 > 0f)
						{
							val8 /= num11;
						}
						Debug.DrawRay(To3D(val7), To3D(val9 * 0f), Color.blue);
						float score = 0f;
						Vector2 val10 = val7 - Vector2.one * 15f * 0.5f;
						Vector2 val11 = Trace(vos, num, val10, 0.01f, out score);
						Vector2 val12 = val10 - val11;
						if (val12.sqrMagnitude < Sqr(0.375f) * 2.6f)
						{
							Debug.DrawRay(To3D(val11 + val), Vector3.up * 1f, Color.red);
						}
					}
				}
			}
			float score2 = float.PositiveInfinity;
			Vector2 val13 = new Vector2(velocity.x, velocity.z);
			float cutoff = val13.magnitude * simulator.qualityCutoff;
			zero = Trace(vos, num, new Vector2(desiredVelocity.x, desiredVelocity.z), cutoff, out score2);
			if (DebugDraw)
			{
				DrawCross(zero + val, Color.yellow, 0.5f);
			}
			Vector2 p3 = Vector2.op_Implicit(Velocity);
			Vector2 val14 = Trace(vos, num, p3, cutoff, out var score3);
			if (score3 < score2)
			{
				zero = val14;
				score2 = score3;
			}
			if (DebugDraw)
			{
				DrawCross(val14 + val, Color.magenta, 0.5f);
			}
		}
		else
		{
			Vector2[] samplePos = context.samplePos;
			float[] sampleSize = context.sampleSize;
			int num13 = 0;
			Vector2 val15 = new Vector2(desiredVelocity.x, desiredVelocity.z);
			float num14 = radius;
			float magnitude = val15.magnitude;
			Vector3 val16 = Velocity;
			float num15 = Mathf.Max(num14, Mathf.Max(magnitude, val16.magnitude));
			samplePos[num13] = val15;
			sampleSize[num13] = num15 * 0.3f;
			num13++;
			samplePos[num13] = val2;
			sampleSize[num13] = num15 * 0.3f;
			num13++;
			Vector2 val17 = val2 * 0.5f;
			Vector2 val18 = new Vector2(val17.y, 0f - val17.x);
			for (int n = 0; n < 8; n++)
			{
				ref Vector2 reference4 = ref samplePos[num13];
				reference4 = val18 * Mathf.Sin((float)n * (float)Math.PI * 2f / 8f) + val17 * (1f + Mathf.Cos((float)n * (float)Math.PI * 2f / 8f));
				sampleSize[num13] = (1f - Mathf.Abs((float)n - 4f) / 8f) * num15 * 0.5f;
				num13++;
			}
			val17 *= 0.6f;
			val18 *= 0.6f;
			for (int num16 = 0; num16 < 6; num16++)
			{
				ref Vector2 reference5 = ref samplePos[num13];
				reference5 = val18 * Mathf.Cos(((float)num16 + 0.5f) * (float)Math.PI * 2f / 6f) + val17 * (1.6666666f + Mathf.Sin(((float)num16 + 0.5f) * (float)Math.PI * 2f / 6f));
				sampleSize[num13] = num15 * 0.3f;
				num13++;
			}
			for (int num17 = 0; num17 < 6; num17++)
			{
				ref Vector2 reference6 = ref samplePos[num13];
				reference6 = val2 + new Vector2(num15 * 0.2f * Mathf.Cos(((float)num17 + 0.5f) * (float)Math.PI * 2f / 6f), num15 * 0.2f * Mathf.Sin(((float)num17 + 0.5f) * (float)Math.PI * 2f / 6f));
				sampleSize[num13] = num15 * 0.2f * 2f;
				num13++;
			}
			ref Vector2 reference7 = ref samplePos[num13];
			reference7 = val2 * 0.5f;
			sampleSize[num13] = num15 * 0.4f;
			num13++;
			Vector2[] bestPos = context.bestPos;
			float[] bestSizes = context.bestSizes;
			float[] bestScores = context.bestScores;
			for (int num18 = 0; num18 < 3; num18++)
			{
				bestScores[num18] = float.PositiveInfinity;
			}
			bestScores[3] = float.NegativeInfinity;
			Vector2 val19 = val2;
			float num19 = float.PositiveInfinity;
			for (int num20 = 0; num20 < 3; num20++)
			{
				for (int num21 = 0; num21 < num13; num21++)
				{
					float num22 = 0f;
					for (int num23 = 0; num23 < num; num23++)
					{
						num22 = Math.Max(num22, vos[num23].ScalarSample(samplePos[num21]));
					}
					Vector2 val20 = samplePos[num21] - val15;
					float magnitude2 = val20.magnitude;
					float num24 = num22 + magnitude2 * DesiredVelocityWeight;
					num22 += magnitude2 * 0.001f;
					if (DebugDraw)
					{
						DrawCross(val + samplePos[num21], Rainbow(Mathf.Log(num22 + 1f) * 5f), sampleSize[num21] * 0.5f);
					}
					if (num24 < bestScores[0])
					{
						for (int num25 = 0; num25 < 3; num25++)
						{
							if (num24 >= bestScores[num25 + 1])
							{
								bestScores[num25] = num24;
								bestSizes[num25] = sampleSize[num21];
								ref Vector2 reference8 = ref bestPos[num25];
								reference8 = samplePos[num21];
								break;
							}
						}
					}
					if (num22 < num19)
					{
						val19 = samplePos[num21];
						num19 = num22;
						if (num22 == 0f)
						{
							num20 = 100;
							break;
						}
					}
				}
				num13 = 0;
				for (int num26 = 0; num26 < 3; num26++)
				{
					Vector2 val21 = bestPos[num26];
					float num27 = bestSizes[num26];
					bestScores[num26] = float.PositiveInfinity;
					float num28 = num27 * 0.6f * 0.5f;
					ref Vector2 reference9 = ref samplePos[num13];
					reference9 = val21 + new Vector2(num28, num28);
					ref Vector2 reference10 = ref samplePos[num13 + 1];
					reference10 = val21 + new Vector2(0f - num28, num28);
					ref Vector2 reference11 = ref samplePos[num13 + 2];
					reference11 = val21 + new Vector2(0f - num28, 0f - num28);
					ref Vector2 reference12 = ref samplePos[num13 + 3];
					reference12 = val21 + new Vector2(num28, 0f - num28);
					sampleSize[num13 + 3] = (sampleSize[num13 + 2] = (sampleSize[num13 + 1] = (sampleSize[num13] = num27 * (num27 * 0.6f))));
					num13 += 4;
				}
			}
			zero = val19;
		}
		if (DebugDraw)
		{
			DrawCross(zero + val);
		}
		newVelocity = To3D(Vector2.ClampMagnitude(zero, maxSpeed));
	}

	private static Color Rainbow(float v)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		Color result = new Color(v, 0f, 0f);
		if (result.r > 1f)
		{
			result.g = result.r - 1f;
			result.r = 1f;
		}
		if (result.g > 1f)
		{
			result.b = result.g - 1f;
			result.g = 1f;
		}
		return result;
	}

	private Vector2 Trace(VO[] vos, int voCount, Vector2 p, float cutoff, out float score)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		score = 0f;
		float stepScale = simulator.stepScale;
		float num = float.PositiveInfinity;
		Vector2 result = p;
		for (int i = 0; i < 50; i++)
		{
			float num2 = 1f - (float)i / 50f;
			num2 *= stepScale;
			Vector2 val = Vector2.zero;
			float num3 = 0f;
			for (int j = 0; j < voCount; j++)
			{
				Vector2 val2 = vos[j].Sample(p, out var num4);
				val += val2;
				if (num4 > num3)
				{
					num3 = num4;
				}
			}
			Vector2 val3 = new Vector2(desiredVelocity.x, desiredVelocity.z) - p;
			float val4 = val3.magnitude * DesiredVelocityWeight;
			val += val3 * DesiredVelocityScale;
			num3 = (score = Math.Max(num3, val4));
			if (score < num)
			{
				num = score;
			}
			result = p;
			if (score <= cutoff && i > 10)
			{
				break;
			}
			float sqrMagnitude = val.sqrMagnitude;
			if (sqrMagnitude > 0f)
			{
				val *= num3 / Mathf.Sqrt(sqrMagnitude);
			}
			val *= num2;
			Vector2 p2 = p;
			p += val;
			if (DebugDraw)
			{
				Debug.DrawLine(To3D(p2) + position, To3D(p) + position, Rainbow(0.1f / score) * new Color(1f, 1f, 1f, 0.2f));
			}
		}
		score = num;
		return result;
	}

	public static bool IntersectionFactor(Vector2 start1, Vector2 dir1, Vector2 start2, Vector2 dir2, out float factor)
	{
		float num = dir2.y * dir1.x - dir2.x * dir1.y;
		if (num == 0f)
		{
			factor = 0f;
			return false;
		}
		float num2 = dir2.x * (start1.y - start2.y) - dir2.y * (start1.x - start2.x);
		factor = num2 / num;
		return true;
	}
}
