using System;
using System.Collections;
using DG.Tweening;
using Grumpyface;
using UnityEngine;
using UnityEngine.Serialization;

[CreateAssetMenu(menuName = "Save the Light/Abilities/Player Characters/Connie/Connie-Garnet Team Attack")]
public class ConnieGarnet_TeamAttackAbility : BaseAbility, IFusionAbility
{
	[Serializable]
	private class AbilityData
	{
		public float initialDistFromEnemy;

		public float bgFadeInTime;

		public float bgFadeOutTime;

		public float garnetMinJumpPower;

		public float garnetMinDistanceForJump;

		public float garnetJumpSpeed;

		public float connieJumpUpTime;

		public float connieSlamJumpUpTime;

		public float connieSlamJumpDownTime;

		public float connieJumpAttackOutroDelay;

		[Header("Animations")]
		public CharacterAnimationNamePair connieIntro = default;

		public CharacterAnimationNamePair connieJumpAttack = default;

		public CharacterAnimationNamePair connieJumpAttackOutro = default;

		public CharacterAnimationNamePair garnetIntro = default;

		public CharacterAnimationNamePair garnetJumpForward = default;

		public CharacterAnimationNamePair garnetLand = default;

		[Header("Sound Effects")]
		public DelayedAudioEvent voClip = default;

		[Header("Camera Settings")]
		public float introZoomAmount;

		public float connieAttackCameraInfluence;

		public float garnetAttackCameraInfluence;

		public BattleCameraSetup cameraSetup;

		[Header("Attack Data")]
		public AttackData garnetAttack1;

		[FormerlySerializedAs("garnetAttack2")]
		public AttackData garnetDashAttack;

		public AttackData garnetUppercut;

		public AttackData connieAttack1;

		public MultiHitAttackData connieMultislash;

		public AttackData connieDiveSlash;

		[Header("Prefabs")]
		public GameObject bgEffectPrefab;

		public GameObject projectorReceiverPrefab;
	}

	[Serializable]
	public struct AttackData
	{
		public DamageInfo damageInfo;

		public CharacterAnimationNamePair animation;

		public DelayedAudioEvent soundEffect;

		public BonusStarData bonusStarData;

		public float teammateCameraInfluence;
	}

	[Serializable]
	public struct MultiHitAttackData
	{
		public DamageInfo damageInfo;

		public CharacterAnimationNamePair startAnimation;

		public CharacterAnimationNamePair startLoopAnimation;

		public CharacterAnimationNamePair[] animations;

		public CharacterAnimationNamePair endAnimation;

		public float attackDuration;

		public float attackSpeed;

		public DelayedAudioEvent soundEffect;

		public BonusStarData bonusStarData;

		public float teammateCameraInfluence;
	}

	private enum Mode
	{
		GarnetAttack1,
		ConnieAttack1,
		GarnetAttack2,
		ConnieMultislash,
		GarnetUppercut,
		ConnieSlam
	}

	[SerializeField]
	private AbilityData abilityData;

	[NonSerialized]
	private BaseCharacter connie;

	[NonSerialized]
	private BaseCharacter garnet;

	[NonSerialized]
	private ITargetable enemyTarget;

	[NonSerialized]
	private BaseCharacter enemyTargetBaseCharacter;

	[NonSerialized]
	private AbstractBattleBG abstractBG;

	[NonSerialized]
	private GameObject projectorReceiver;

	[NonSerialized]
	private ConnieGarnetTeamAttackBG teamAttackBG;

	[NonSerialized]
	private IEnumerator receiverFollowCoroutine;

	[NonSerialized]
	private IEnumerator enforceLowestYCoroutine;

	[NonSerialized]
	private float prevTimeScale;

	[NonSerialized]
	private float lowestYPosition;

	[NonSerialized]
	private Mode mode;

	[NonSerialized]
	private bool isConnieAttack1Setup;

	[NonSerialized]
	private bool isGarnetAttack2Setup;

	[NonSerialized]
	private bool isConnieMultiSlashSetup;

	[NonSerialized]
	private bool isGarnetUppercutSetup;

	[NonSerialized]
	private bool isConnieSlamSetup;

	[NonSerialized]
	private GameObject dummyTarget;

	[NonSerialized]
	private Vector3 originalEnemyPos;

	[NonSerialized]
	private int originalEnemyLayer;

	[NonSerialized]
	private Vector3 projectorReceiverOffset = Vector3.zero;

	[NonSerialized]
	private GameObject poofEffect;

	[NonSerialized]
	private BaseCharacter currentAnimEventCaster;

	[NonSerialized]
	private AttackData currentAttackData;

	[NonSerialized]
	private string targetAnimEventInfo = "hit";

	[NonSerialized]
	private bool allowTargetDeath;

	[NonSerialized]
	private StarBonusCheck currentBonusCheck;

	public CharacterName[] members => new CharacterName[2]
	{
		CharacterName.Connie,
		CharacterName.Garnet
	};

	public ConnieGarnet_TeamAttackAbility()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
	}

	protected override void OnInit()
	{
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		base.OnInit();
		PlayerCharacter playerCharacter = null;
		for (int i = 0; i < GameController.Instance.Players.Count; i++)
		{
			playerCharacter = (PlayerCharacter)GameController.Instance.Players[i];
			if (playerCharacter.characterName == CharacterName.Connie && playerCharacter.IsAlive)
			{
				connie = playerCharacter;
			}
			else if (playerCharacter.characterName == CharacterName.Garnet && playerCharacter.IsAlive)
			{
				garnet = playerCharacter;
			}
		}
		abstractBG = ObjectPool.GetObject<AbstractBattleBG>(abilityData.bgEffectPrefab, default(Vector3), true);
		((Component)abstractBG).gameObject.SetActive(false);
		teamAttackBG = ((Component)abstractBG).GetComponent<ConnieGarnetTeamAttackBG>();
		projectorReceiver = ObjectPool.GetObject(abilityData.projectorReceiverPrefab);
		projectorReceiver.gameObject.SetActive(false);
		allowTargetDeath = false;
	}

	public override IEnumerator Play()
	{
		bool connieIntroFirst = object.ReferenceEquals(caster, connie);
		if (targets[0] is StrawberryKnight_EyeHolder)
		{
			enemyTarget = targets[0];
			enemyTargetBaseCharacter = enemyTarget.gameObject.GetComponentInParent<StrawberryKnight>();
			((StrawberryKnight)enemyTargetBaseCharacter).FadeOutMace(1f);
		}
		else
		{
			enemyTarget = targets[0];
			enemyTargetBaseCharacter = enemyTarget as BaseCharacter;
		}
		lowestYPosition = ((Component)connie).transform.position.y;
		enemyTargetBaseCharacter.ignoreKnockbackReturnToBattlefield = true;
		enemyTargetBaseCharacter.useAlternateGroundCheck = true;
		enemyTargetBaseCharacter.lowestYPos = lowestYPosition;
		enemyTargetBaseCharacter.forceUseKnockback = true;
		originalEnemyPos = ((Component)enemyTargetBaseCharacter).transform.position;
		connie.ignoreGravity = true;
		garnet.ignoreGravity = true;
		connie.SetInput(0f, 0f, newJump: false, connie.baseMovementSpeed);
		garnet.SetInput(0f, 0f, newJump: false, garnet.baseMovementSpeed);
		enforceLowestYCoroutine = EnforceLowestYPos();
		((MonoBehaviour)caster).StartCoroutine(enforceLowestYCoroutine);
		EventMessenger.Instance.Raise(new CameraZoomEvent(1.5f));
		if (connieIntroFirst)
		{
			yield return ((MonoBehaviour)caster).StartCoroutine(ConnieIntroSequence());
			yield return ((MonoBehaviour)caster).StartCoroutine(GarnetIntroSequence());
		}
		else
		{
			yield return ((MonoBehaviour)caster).StartCoroutine(GarnetIntroSequence());
			yield return ((MonoBehaviour)caster).StartCoroutine(ConnieIntroSequence());
		}
		if ((Object)(object)enemyTargetBaseCharacter != (Object)null)
		{
			enemyTargetBaseCharacter.FaceTarget(((Component)garnet).transform);
		}
		abstractBG.AddCameraCullingMask("SpecialFX");
		GameCamera.instance.battleCamera.overrideFollowTarget = enemyTarget.transform;
		GameCamera.instance.battleCamera.overrideCameraOverride = abilityData.cameraSetup;
		EventMessenger.Instance.Raise(new CameraZoomEvent(abilityData.introZoomAmount));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)connie).transform, abilityData.connieAttackCameraInfluence)));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)garnet).transform, abilityData.garnetAttackCameraInfluence)));
		Vector3 connieOriginalPosition = ((Component)connie).transform.position;
		Vector3 garnetOriginalPosition = ((Component)garnet).transform.position;
		Vector3 connieOriginalFacingDir = connie.directionVector;
		Vector3 garnetOriginalFacingDir = garnet.directionVector;
		Vector3 targetGarnetPos = Vector3.zero;
		Vector3 pos1 = enemyTarget.FrontPosition;
		Vector3 pos2 = enemyTarget.BackPosition;
		Vector3 val = pos1 - ((Component)garnet).transform.position;
		float dist1 = val.sqrMagnitude;
		Vector3 val2 = pos2 - ((Component)garnet).transform.position;
		float dist2 = val2.sqrMagnitude;
		targetGarnetPos = ((!(dist1 < dist2)) ? pos2 : pos1);
		Vector3 val3 = targetGarnetPos - enemyTarget.transform.position;
		Vector3 enemyDir = val3.normalized;
		Vector3 targetConniePos = targetGarnetPos + enemyDir * 2f;
		if ((Object)(object)enemyTargetBaseCharacter != (Object)null)
		{
			enemyTargetBaseCharacter.FaceTarget(targetGarnetPos);
			teamAttackBG.SetFacingDir((enemyTargetBaseCharacter.horizontalDir == Direction.Right) ? Direction.Left : Direction.Right);
		}
		garnet.RichAI2D.MoveToPosition(targetGarnetPos);
		connie.RichAI2D.MoveToPosition(targetConniePos);
		yield return new WaitUntilAIReachedTargets(connie.RichAI2D, garnet.RichAI2D);
		int ignoreAllCollisionLayer = LayerMask.NameToLayer("IgnoreAllCollision");
		((Component)connie).gameObject.layer = ignoreAllCollisionLayer;
		((Component)garnet).gameObject.layer = ignoreAllCollisionLayer;
		connie.ignoreAntiBumpFactor = true;
		connie.VelocityVector = Vector3.zero;
		garnet.ignoreAntiBumpFactor = true;
		garnet.VelocityVector = Vector3.zero;
		originalEnemyLayer = enemyTarget.gameObject.layer;
		enemyTarget.gameObject.layer = ignoreAllCollisionLayer;
		connie.FaceTarget(enemyTarget.transform);
		garnet.FaceTarget(enemyTarget.transform);
		garnet.SetDirections(((Component)garnet).transform.right);
		if ((Object)(object)abilityData.voClip.audioEvent != (Object)null)
		{
			abilityData.voClip.Play();
		}
		((Component)abstractBG).gameObject.SetActive(true);
		if (enemyTarget is SquareidotShip)
		{
			projectorReceiverOffset = new Vector3(0f, -0.956f, 0f);
		}
		projectorReceiver.SetActive(true);
		receiverFollowCoroutine = ProjectorReceiverFollowTarget();
		((MonoBehaviour)caster).StartCoroutine(receiverFollowCoroutine);
		EventMessenger.Instance.Raise(new AbstractBackgroundEvent(abstractBackgroundActive: true, attackingOccurring: true));
		ParticleSystem[] particleSystems = ((Component)abstractBG).GetComponentsInChildren<ParticleSystem>();
		Color[] rendererStartAlpha = new Color[particleSystems.Length];
		int colorID = Shader.PropertyToID("_Color");
		foreach (ParticleSystem val4 in particleSystems)
		{
			Renderer component = ((Component)val4).GetComponent<Renderer>();
			Color color = component.material.GetColor(colorID);
			component.material.SetColor(colorID, Color.clear);
			TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOColor(component.material, color, abilityData.bgFadeInTime), (Ease)1);
		}
		tk2dSprite bgSprite = ((Component)abstractBG).GetComponentInChildren<tk2dSprite>(true);
		bgSprite.color = new Color(1f, 1f, 1f, 0f);
		TweenSettingsExtensions.SetEase<Tweener>(bgSprite.DOFade(1f, abilityData.bgFadeInTime), (Ease)1);
		abstractBG.AddTargets(garnet, connie, enemyTarget);
		prevTimeScale = Time.timeScale;
		yield return (object)new WaitForSeconds(0.2f);
		isConnieAttack1Setup = false;
		isGarnetAttack2Setup = false;
		isConnieMultiSlashSetup = false;
		isGarnetUppercutSetup = false;
		isConnieSlamSetup = false;
		mode = Mode.GarnetAttack1;
		((MonoBehaviour)caster).StartCoroutine(ConnieAttack1Setup());
		yield return ((MonoBehaviour)caster).StartCoroutine(GarnetAttack1());
		mode = Mode.ConnieAttack1;
		((MonoBehaviour)caster).StartCoroutine(GarnetAttack2Setup());
		yield return ((MonoBehaviour)caster).StartCoroutine(ConnieAttack1());
		mode = Mode.GarnetAttack2;
		((MonoBehaviour)caster).StartCoroutine(ConnieMultiSlashAttackSetup());
		yield return ((MonoBehaviour)caster).StartCoroutine(GarnetAttack2());
		mode = Mode.ConnieMultislash;
		((MonoBehaviour)caster).StartCoroutine(GarnetUppercutSetup());
		yield return ((MonoBehaviour)caster).StartCoroutine(ConnieMultiSlashAttack());
		mode = Mode.GarnetUppercut;
		((MonoBehaviour)caster).StartCoroutine(ConnieSlamSetup());
		yield return ((MonoBehaviour)caster).StartCoroutine(GarnetUppercutAttack());
		mode = Mode.ConnieSlam;
		yield return ((MonoBehaviour)caster).StartCoroutine(ConnieSlamAttack());
		Vector3 connieRelativePos = ((Component)connie).transform.position - ((Component)enemyTargetBaseCharacter).transform.position;
		Vector3 garnetRelativePos = ((Component)garnet).transform.position - ((Component)enemyTargetBaseCharacter).transform.position;
		Vector3 cameraRelativePos = GameCamera.instance.container.position - ((Component)enemyTargetBaseCharacter).transform.position;
		bool isBoss = enemyTarget is ForestBoss || enemyTarget is StrawberryKnight || enemyTarget is SquareidotShip || enemyTarget is LightWarrior || enemyTarget is Hessonite || enemyTarget is StrawberryKnight_EyeHolder;
		((Component)enemyTargetBaseCharacter).transform.position = ((!isBoss) ? GameController.Instance.currentBattlefield.GetClosestPoint(((Component)enemyTargetBaseCharacter).transform.position) : originalEnemyPos);
		((Component)connie).transform.position = ((Component)enemyTargetBaseCharacter).transform.position + connieRelativePos;
		((Component)garnet).transform.position = ((Component)enemyTargetBaseCharacter).transform.position + garnetRelativePos;
		GameCamera.instance.container.position = ((Component)enemyTargetBaseCharacter).transform.position + cameraRelativePos;
		if (isBoss)
		{
			enemyTargetBaseCharacter.battlePosition = enemyTargetBaseCharacter.battleStartPosition;
		}
		if (enemyTarget.IsDead)
		{
			dummyTarget = new GameObject("Connie Garnet Team Attack Dummy Target");
			dummyTarget.transform.position = ((Component)enemyTargetBaseCharacter).transform.position;
			GameCamera.instance.battleCamera.overrideFollowTarget = dummyTarget.transform;
		}
		yield return (object)new WaitForSeconds(abilityData.connieJumpAttackOutroDelay);
		connie.PlayAnimFromFrame(abilityData.connieJumpAttackOutro, 3, clearQueue: true);
		yield return (object)new WaitForSeconds(0.746f);
		foreach (ParticleSystem val5 in particleSystems)
		{
			Renderer psRenderer = ((Component)val5).GetComponent<Renderer>();
			Color originalColor = psRenderer.material.GetColor(colorID);
			TweenSettingsExtensions.OnComplete<Tweener>(TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOColor(psRenderer.material, Color.clear, abilityData.bgFadeOutTime), (Ease)1), (TweenCallback)(() =>
			{
				//IL_0017: Unknown result type (might be due to invalid IL or missing references)
				psRenderer.material.SetColor(colorID, originalColor);
			}));
		}
		Tweener bgFadeTween = TweenSettingsExtensions.OnComplete<Tweener>(TweenSettingsExtensions.SetEase<Tweener>(bgSprite.DOFade(0f, abilityData.bgFadeOutTime), (Ease)1), (TweenCallback)(() =>
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			bgSprite.color = Color.white;
			abstractBG.ReturnAllActiveTargets();
			((Component)abstractBG).gameObject.SetActive(false);
			((Component)connie).gameObject.layer = LayerMask.NameToLayer("Player");
			((Component)garnet).gameObject.layer = LayerMask.NameToLayer("Player");
			enemyTarget.gameObject.layer = originalEnemyLayer;
		}));
		GameCamera.instance.battleCamera.overrideFollowTarget = null;
		GameCamera.instance.battleCamera.overrideCameraOverride = null;
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new CameraZoomEvent(1.1f));
		int bossTitleCardLayer = LayerMask.NameToLayer("BossTitleCard");
		((Component)connie).gameObject.layer = bossTitleCardLayer;
		((Component)garnet).gameObject.layer = bossTitleCardLayer;
		enemyTarget.gameObject.layer = bossTitleCardLayer;
		connie.ignoreGravity = false;
		connie.ignoreAntiBumpFactor = false;
		garnet.ignoreGravity = false;
		garnet.ignoreAntiBumpFactor = false;
		garnet.RichAI2D.MoveToPosition(garnetOriginalPosition);
		connie.RichAI2D.MoveToPosition(connieOriginalPosition);
		yield return new WaitUntilAIReachedTargets(connie.RichAI2D, garnet.RichAI2D);
		connie.directionVector = connieOriginalFacingDir;
		garnet.directionVector = garnetOriginalFacingDir;
		if ((Object)(object)dummyTarget != (Object)null)
		{
			Object.Destroy((Object)(object)dummyTarget);
		}
		dummyTarget = null;
		yield return (object)new WaitWhile((Func<bool>)(() => TweenExtensions.IsPlaying((Tween)(object)bgFadeTween)));
	}

	private IEnumerator ConnieIntroSequence()
	{
		GameCamera.instance.battleCamera.overrideFollowTarget = ((Component)connie).transform;
		yield return (object)new WaitWhile((Func<bool>)(() => GameCamera.instance.battleCamera.isMoving));
		connie.PlayAnim(abilityData.connieIntro);
		connie.AddAnimToQueue(connie.GetIdleAnimation());
		yield return (object)new WaitUntil((Func<bool>)(() => connie.currentAnimation != abilityData.connieIntro));
	}

	private IEnumerator GarnetIntroSequence()
	{
		GameCamera.instance.battleCamera.overrideFollowTarget = ((Component)garnet).transform;
		yield return (object)new WaitWhile((Func<bool>)(() => GameCamera.instance.battleCamera.isMoving));
		garnet.PlayAnim(abilityData.garnetIntro);
		garnet.AddAnimToQueue(garnet.GetIdleAnimation());
		yield return (object)new WaitUntil((Func<bool>)(() => garnet.currentAnimation != abilityData.garnetIntro));
	}

	private IEnumerator GarnetAttack1()
	{
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)connie).transform, abilityData.garnetAttack1.teammateCameraInfluence)));
		garnet.PlayAnim(abilityData.garnetAttack1.animation, clearQueue: true);
		abilityData.garnetAttack1.soundEffect.Play();
		currentAnimEventCaster = garnet;
		currentAttackData = abilityData.garnetAttack1;
		tk2dSpriteAnimatorPlus animatorTk2d = garnet.animatorTk2d;
		animatorTk2d.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Combine(animatorTk2d.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEvent));
		int hitFrame = garnet.animatorTk2d.CurrentClip.GetFrameWithEventInfo("hit");
		float hitDelay = garnet.animatorTk2d.CurrentClip.GetFrameTime(hitFrame) - garnet.animatorTk2d.ClipTimeSeconds;
		StarBonusCheck bonusCheck = (currentBonusCheck = StartBonusCheck(Time.time + hitDelay, abilityData.garnetAttack1.bonusStarData, null, followTargets: true));
		for (int i = 0; i < bonusCheck.bonusStars.Count; i++)
		{
			UIBonusStar uIBonusStar = bonusCheck.bonusStars[i];
			((Component)uIBonusStar).gameObject.SetLayerRecursively(LayerMask.NameToLayer("SpecialFX"));
		}
		TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOMove(((Component)garnet).transform, GetClosestSidePosition(enemyTarget, enemyTarget.transform.position, ((Component)garnet).transform.position), hitDelay, false), (Ease)18);
		while (garnet.animatorTk2d.Playing)
		{
			if (garnet.animatorTk2d.CurrentFrame >= hitFrame)
			{
				if (bonusCheck.isBonusSuccess && bonusCheck.isBonusPerfectSuccess)
				{
					EventMessenger.Instance.Raise(new PerfectAttackEvent(bonusStarMeterOnPerfect));
					prevTimeScale = Time.timeScale;
					Time.timeScale = 0f;
					yield return new WaitForSecondsIndependentUnpaused(abilityData.garnetAttack1.bonusStarData.bonusPerfectFreezeDuration);
					Time.timeScale = prevTimeScale;
				}
				break;
			}
			yield return null;
		}
		tk2dSpriteAnimatorPlus animatorTk2d2 = garnet.animatorTk2d;
		animatorTk2d2.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Remove(animatorTk2d2.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEvent));
	}

	private IEnumerator ConnieAttack1Setup()
	{
		connie.FaceTarget(enemyTarget.transform);
		Vector3 impactDirection = ((garnet.horizontalDir != Direction.Right) ? (-GameCamera.instance.container.right) : GameCamera.instance.container.right);
		BaseCharacter source = garnet;
		ImpactResultType impactType = abilityData.garnetAttack1.damageInfo.impactType;
		float impactForce = abilityData.garnetAttack1.damageInfo.impactForce;
		Vector3 position = default;
		Vector3 predictedEnemyPos = GetPredictedKnockedbackPosition(knockbackImpact: new ImpactResult(source, impactType, impactDirection, impactForce, position), startPosition: SnapPositionToGround(enemyTarget.transform.position), speedFactor: enemyTargetBaseCharacter.movementSpeedFactor, knockbackData: enemyTargetBaseCharacter.characterKnockbackData, lowestYPos: lowestYPosition, percentAlongKnockback: 1f);
		connie.PlayAnim(connie.GetRunAnimation());
		Vector3 targetMovePosition = GetClosestSidePosition(enemyTarget, predictedEnemyPos, ((Component)connie).transform.position);
		float minDist = 0.05f;
		float minDistSqr = minDist * minDist;
		float curDist = Vector3.Distance(enemyTarget.transform.position, ((Component)connie).transform.position);
		while (curDist > minDist)
		{
			position = targetMovePosition - ((Component)connie).transform.position;
			Vector3 velocity = Vector3.ClampMagnitude(position.normalized * connie.curMovementSpeed * Time.deltaTime * 1.1f, Vector3.Distance(targetMovePosition, ((Component)connie).transform.position));
			connie.Controller.Move(velocity);
			yield return null;
			curDist = Vector3.Distance(targetMovePosition, ((Component)connie).transform.position);
			if (curDist > minDist && !connie.IsAnimPlaying(connie.GetRunAnimation()))
			{
				connie.PlayAnim(connie.GetRunAnimation());
			}
			else if (curDist <= minDist)
			{
				connie.PlayAnim(connie.GetIdleAnimation());
			}
		}
		isConnieAttack1Setup = true;
	}

	private IEnumerator ConnieAttack1()
	{
		while (!isConnieAttack1Setup)
		{
			yield return null;
		}
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)garnet).transform, abilityData.connieAttack1.teammateCameraInfluence)));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)connie).transform, abilityData.connieAttackCameraInfluence)));
		connie.PlayAnim(abilityData.connieAttack1.animation, clearQueue: true);
		connie.AddAnimToQueue(connie.GetIdleAnimation());
		abilityData.connieAttack1.soundEffect.Play();
		currentAnimEventCaster = connie;
		currentAttackData = abilityData.connieAttack1;
		tk2dSpriteAnimatorPlus animatorTk2d = connie.animatorTk2d;
		animatorTk2d.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Combine(animatorTk2d.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEvent));
		int hitFrame = connie.animatorTk2d.CurrentClip.GetFrameWithEventInfo("hit");
		float hitDelay = connie.animatorTk2d.CurrentClip.GetFrameTime(hitFrame) - connie.animatorTk2d.ClipTimeSeconds;
		StarBonusCheck bonusCheck = (currentBonusCheck = StartBonusCheck(Time.time + hitDelay, abilityData.connieAttack1.bonusStarData, null, followTargets: true));
		for (int i = 0; i < bonusCheck.bonusStars.Count; i++)
		{
			UIBonusStar uIBonusStar = bonusCheck.bonusStars[i];
			((Component)uIBonusStar).gameObject.SetLayerRecursively(LayerMask.NameToLayer("SpecialFX"));
		}
		Debug.Log((object)"Connie Attack 1A");
		while (connie.animatorTk2d.Playing)
		{
			if (connie.animatorTk2d.CurrentFrame >= hitFrame)
			{
				if (bonusCheck.isBonusSuccess && bonusCheck.isBonusPerfectSuccess)
				{
					EventMessenger.Instance.Raise(new PerfectAttackEvent(bonusStarMeterOnPerfect));
					prevTimeScale = Time.timeScale;
					Time.timeScale = 0f;
					yield return new WaitForSecondsIndependentUnpaused(abilityData.connieAttack1.bonusStarData.bonusPerfectFreezeDuration);
					Time.timeScale = prevTimeScale;
				}
				Debug.Log((object)"Connie Attack 1B");
				break;
			}
			yield return null;
		}
		Debug.Log((object)"Connie Attack 1C");
		tk2dSpriteAnimatorPlus animatorTk2d2 = connie.animatorTk2d;
		animatorTk2d2.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Remove(animatorTk2d2.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEvent));
	}

	private IEnumerator GarnetAttack2Setup()
	{
		yield return null;
		isGarnetAttack2Setup = true;
		Debug.Log((object)"Garnet Attack Setup Done");
	}

	private IEnumerator GarnetAttack2()
	{
		Debug.Log((object)"Garnet Attack 2A");
		while (!isGarnetAttack2Setup)
		{
			yield return null;
		}
		Debug.Log((object)"Garnet Attack 2B");
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)connie).transform, abilityData.garnetDashAttack.teammateCameraInfluence)));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)garnet).transform, abilityData.garnetAttackCameraInfluence)));
		garnet.PlayAnim(abilityData.garnetDashAttack.animation, clearQueue: true);
		abilityData.garnetDashAttack.soundEffect.Play();
		currentAnimEventCaster = garnet;
		currentAttackData = abilityData.garnetDashAttack;
		tk2dSpriteAnimatorPlus animatorTk2d = garnet.animatorTk2d;
		animatorTk2d.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Combine(animatorTk2d.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEvent));
		targetAnimEventInfo = "dashHit";
		int dashFrame = garnet.animatorTk2d.CurrentClip.GetFrameWithEventInfo("dash");
		int hitFrame = garnet.animatorTk2d.CurrentClip.GetFrameWithEventInfo("dashHit");
		float dashTime = garnet.animatorTk2d.CurrentClip.GetFrameTime(hitFrame) - garnet.animatorTk2d.CurrentClip.GetFrameTime(dashFrame);
		float hitDelay = garnet.animatorTk2d.CurrentClip.GetFrameTime(hitFrame) - garnet.animatorTk2d.ClipTimeSeconds;
		StarBonusCheck bonusCheck = (currentBonusCheck = StartBonusCheck(Time.time + hitDelay, abilityData.garnetDashAttack.bonusStarData, null, followTargets: true));
		for (int i = 0; i < bonusCheck.bonusStars.Count; i++)
		{
			UIBonusStar uIBonusStar = bonusCheck.bonusStars[i];
			((Component)uIBonusStar).gameObject.SetLayerRecursively(LayerMask.NameToLayer("SpecialFX"));
		}
		Tweener dashTween = null;
		bool hasDashed = false;
		while (garnet.animatorTk2d.Playing)
		{
			if (!hasDashed && garnet.animatorTk2d.CurrentFrame >= dashFrame)
			{
				dashTween = TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOMove(((Component)garnet).transform, GetClosestSidePosition(enemyTarget, enemyTarget.transform.position, ((Component)garnet).transform.position), dashTime, false), (Ease)1);
				TweenExtensions.ForceInit((Tween)(object)dashTween);
				hasDashed = true;
			}
			if (garnet.animatorTk2d.CurrentFrame >= hitFrame)
			{
				if (bonusCheck.isBonusSuccess && bonusCheck.isBonusPerfectSuccess)
				{
					EventMessenger.Instance.Raise(new PerfectAttackEvent(bonusStarMeterOnPerfect));
					prevTimeScale = Time.timeScale;
					Time.timeScale = 0f;
					yield return new WaitForSecondsIndependentUnpaused(abilityData.garnetDashAttack.bonusStarData.bonusPerfectFreezeDuration);
					Time.timeScale = prevTimeScale;
				}
				break;
			}
			yield return null;
		}
		tk2dSpriteAnimatorPlus animatorTk2d2 = garnet.animatorTk2d;
		animatorTk2d2.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Remove(animatorTk2d2.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEvent));
		Debug.Log((object)"Garnet Dash Punch, FINISHED");
	}

	private IEnumerator ConnieMultiSlashAttackSetup()
	{
		Vector3 impactDirection = ((connie.horizontalDir != Direction.Right) ? (-GameCamera.instance.container.right) : GameCamera.instance.container.right);
		BaseCharacter source = connie;
		ImpactResultType impactType = abilityData.connieAttack1.damageInfo.impactType;
		Vector3 direction = impactDirection;
		float impactForce = abilityData.connieAttack1.damageInfo.impactForce;
		Vector3 position = default;
		Vector3 predictedEnemyPos1 = GetPredictedKnockedbackPosition(knockbackImpact: new ImpactResult(source, impactType, direction, impactForce, position), startPosition: SnapPositionToGround(enemyTarget.transform.position), speedFactor: enemyTargetBaseCharacter.movementSpeedFactor, knockbackData: enemyTargetBaseCharacter.characterKnockbackData, lowestYPos: lowestYPosition, percentAlongKnockback: 1f);
		impactDirection = ((garnet.horizontalDir != Direction.Right) ? (-GameCamera.instance.container.right) : GameCamera.instance.container.right);
		BaseCharacter source2 = garnet;
		ImpactResultType impactType2 = abilityData.garnetDashAttack.damageInfo.impactType;
		Vector3 direction2 = impactDirection;
		float impactForce2 = abilityData.garnetDashAttack.damageInfo.impactForce;
		position = default;
		Vector3 targetMovePos = GetClosestSidePosition(startPosition: GetPredictedKnockedbackPosition(knockbackImpact: new ImpactResult(source2, impactType2, direction2, impactForce2, position), startPosition: SnapPositionToGround(predictedEnemyPos1), speedFactor: enemyTargetBaseCharacter.movementSpeedFactor, knockbackData: enemyTargetBaseCharacter.characterKnockbackData, lowestYPos: lowestYPosition, percentAlongKnockback: 1f), target: enemyTarget, fromPosition: ((Component)connie).transform.position);
		connie.FaceTarget(enemyTarget.transform);
		connie.PlayAnim(connie.GetRunAnimation());
		float minDist = 0.05f;
		while (Vector3.Distance(targetMovePos, ((Component)connie).transform.position) > minDist)
		{
			position = targetMovePos - ((Component)connie).transform.position;
			Vector3 velocity = Vector3.ClampMagnitude(position.normalized * connie.curMovementSpeed * Time.deltaTime, Vector3.Distance(targetMovePos, ((Component)connie).transform.position));
			connie.Controller.Move(velocity);
			yield return null;
		}
		connie.PlayAnim(connie.GetIdleAnimation());
		isConnieMultiSlashSetup = true;
		Debug.Log((object)"MultiSlash is SET UP");
	}

	private IEnumerator ConnieMultiSlashAttack()
	{
		Debug.Log((object)"MultiSlash Attack A");
		while (!isConnieMultiSlashSetup)
		{
			yield return null;
		}
		Debug.Log((object)"MultiSlash Attack B");
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)garnet).transform, abilityData.connieMultislash.teammateCameraInfluence)));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)connie).transform, abilityData.connieAttackCameraInfluence)));
		connie.PlayAnim(abilityData.connieMultislash.startAnimation, clearQueue: true);
		connie.AddAnimToQueue(abilityData.connieMultislash.startLoopAnimation);
		abilityData.connieMultislash.soundEffect.Play();
		int hitFrame = connie.animatorTk2d.CurrentClip.GetFrameWithEventInfo("dashHit");
		float hitDelay = connie.animatorTk2d.CurrentClip.GetFrameTime(hitFrame) - connie.animatorTk2d.ClipTimeSeconds;
		StarBonusCheck bonusCheck = (currentBonusCheck = StartBonusCheck(Time.time + hitDelay, abilityData.connieMultislash.bonusStarData, null, followTargets: true));
		for (int i = 0; i < bonusCheck.bonusStars.Count; i++)
		{
			UIBonusStar uIBonusStar = bonusCheck.bonusStars[i];
			((Component)uIBonusStar).gameObject.SetLayerRecursively(LayerMask.NameToLayer("SpecialFX"));
		}
		bool isBonusChecked = false;
		while (connie.IsAnimPlaying(abilityData.connieMultislash.startAnimation))
		{
			if (!isBonusChecked && connie.animatorTk2d.CurrentFrame >= hitFrame)
			{
				isBonusChecked = true;
				if (bonusCheck.isBonusSuccess && bonusCheck.isBonusPerfectSuccess)
				{
					EventMessenger.Instance.Raise(new PerfectAttackEvent(bonusStarMeterOnPerfect));
					prevTimeScale = Time.timeScale;
					Time.timeScale = 0f;
					yield return new WaitForSecondsIndependentUnpaused(abilityData.connieAttack1.bonusStarData.bonusPerfectFreezeDuration);
					Time.timeScale = prevTimeScale;
				}
				break;
			}
			yield return null;
		}
		int animIndex = 0;
		float timer = abilityData.connieMultislash.attackSpeed;
		float attackDurationTimer = abilityData.connieMultislash.attackDuration;
		connie.PlayAnim(abilityData.connieMultislash.animations[animIndex], clearQueue: true);
		EventMessenger.Instance.Raise(new VibrationEvent(new VibrationManager.Vibration(0.7f, abilityData.connieMultislash.attackDuration)));
		while (true)
		{
			timer -= Time.deltaTime;
			attackDurationTimer -= Time.deltaTime;
			if (timer <= 0f)
			{
				animIndex = ((animIndex + 1 < abilityData.connieMultislash.animations.Length) ? (animIndex + 1) : 0);
				connie.PlayAnim(abilityData.connieMultislash.animations[animIndex]);
				if (enemyTargetBaseCharacter.CurrentState.Equals(CharacterState.KnockedBack))
				{
					enemyTargetBaseCharacter.ChangeState(CharacterState.BattleWaiting, true);
				}
				DamageResult damageResult = BattleHelper.CalculateDamage(connie, enemyTarget.damageReceiver, abilityData.connieMultislash.damageInfo, allowDeath: false, this);
				if (damageResult.impactResult != null)
				{
					damageResult.impactResult.direction = ((connie.horizontalDir != Direction.Right) ? (-GameCamera.instance.container.right) : GameCamera.instance.container.right);
				}
				BattleHelper.DoDamage(damageResult);
				EventMessenger.Instance.Raise(new ScreenShakeEvent(abilityData.connieMultislash.damageInfo.effects.screenShake));
				timer = abilityData.connieMultislash.attackSpeed;
			}
			if (attackDurationTimer <= 0f)
			{
				break;
			}
			yield return null;
		}
		DamageResult knockbackDamageResult = BattleHelper.CalculateDamage(connie, enemyTarget.damageReceiver, abilityData.connieMultislash.damageInfo, allowDeath: false, this);
		ImpactResult impactResult = new ImpactResult(direction: (connie.horizontalDir != Direction.Right) ? (-GameCamera.instance.container.right) : GameCamera.instance.container.right, source: connie, type: abilityData.connieMultislash.damageInfo.impactType, force: abilityData.connieMultislash.damageInfo.impactForce);
		enemyTargetBaseCharacter.ChangeState(CharacterState.KnockedBack, true, impactResult, knockbackDamageResult);
		connie.PlayAnim(abilityData.connieMultislash.endAnimation, clearQueue: true);
		yield return (object)new WaitForSeconds(0.5f);
		connie.PlayAnim(connie.GetIdleAnimation());
	}

	private IEnumerator GarnetUppercutSetup()
	{
		while (!isConnieMultiSlashSetup)
		{
			yield return null;
		}
		yield return null;
		while (connie.IsAnimPlaying(abilityData.connieMultislash.startAnimation))
		{
			yield return null;
		}
		Vector3 targetPos = GetClosestSidePosition(startPosition: GetPredictedKnockedbackPosition(knockbackImpact: new ImpactResult(direction: (connie.horizontalDir != Direction.Right) ? (-GameCamera.instance.container.right) : GameCamera.instance.container.right, source: connie, type: abilityData.connieMultislash.damageInfo.impactType, force: abilityData.connieMultislash.damageInfo.impactForce), startPosition: SnapPositionToGround(enemyTarget.transform.position), speedFactor: enemyTargetBaseCharacter.movementSpeedFactor, knockbackData: enemyTargetBaseCharacter.characterKnockbackData, lowestYPos: lowestYPosition, percentAlongKnockback: 1f), target: enemyTarget, fromPosition: ((Component)garnet).transform.position);
		float distance = Vector3.Distance(((Component)garnet).transform.PositionXZ(), new Vector3(targetPos.x, 0f, targetPos.z));
		float tweenTime = distance / abilityData.garnetJumpSpeed;
		yield return (object)new WaitForSeconds(abilityData.connieMultislash.attackDuration - tweenTime);
		yield return (object)new WaitForSeconds(0.25f);
		garnet.PlayAnim(abilityData.garnetJumpForward);
		garnet.characterSounds.jumpSound.Play(((Component)garnet).transform.position);
		yield return TweenExtensions.WaitForCompletion((Tween)(object)TweenExtensions.Play<Sequence>(TweenSettingsExtensions.SetEase<Sequence>(ShortcutExtensions.DOJump(((Component)garnet).transform, targetPos, abilityData.garnetMinJumpPower * (distance / abilityData.garnetMinDistanceForJump), 1, tweenTime, false), (Ease)1)));
		garnet.PlayAnim(abilityData.garnetLand);
		isGarnetUppercutSetup = true;
	}

	private IEnumerator GarnetUppercutAttack()
	{
		while (!isGarnetUppercutSetup)
		{
			yield return null;
		}
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)connie).transform, abilityData.garnetUppercut.teammateCameraInfluence)));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)garnet).transform, abilityData.garnetAttackCameraInfluence)));
		Debug.Log((object)"Play Attack 5");
		garnet.PlayAnim(abilityData.garnetUppercut.animation, clearQueue: true);
		abilityData.garnetUppercut.soundEffect.Play();
		currentAnimEventCaster = garnet;
		currentAttackData = abilityData.garnetUppercut;
		targetAnimEventInfo = "hit";
		tk2dSpriteAnimatorPlus animatorTk2d = garnet.animatorTk2d;
		animatorTk2d.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Combine(animatorTk2d.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEvent));
		int hitFrame = garnet.animatorTk2d.CurrentClip.GetFrameWithEventInfo("hit");
		float hitDelay = garnet.animatorTk2d.CurrentClip.GetFrameTime(hitFrame) - garnet.animatorTk2d.ClipTimeSeconds;
		StarBonusCheck bonusCheck = (currentBonusCheck = StartBonusCheck(Time.time + hitDelay, abilityData.garnetAttack1.bonusStarData, null, followTargets: true));
		for (int i = 0; i < bonusCheck.bonusStars.Count; i++)
		{
			UIBonusStar uIBonusStar = bonusCheck.bonusStars[i];
			((Component)uIBonusStar).gameObject.SetLayerRecursively(LayerMask.NameToLayer("SpecialFX"));
		}
		while (garnet.animatorTk2d.Playing)
		{
			if (garnet.animatorTk2d.CurrentFrame >= hitFrame)
			{
				if (bonusCheck.isBonusSuccess && bonusCheck.isBonusPerfectSuccess)
				{
					EventMessenger.Instance.Raise(new PerfectAttackEvent(bonusStarMeterOnPerfect));
					prevTimeScale = Time.timeScale;
					Time.timeScale = 0f;
					yield return new WaitForSecondsIndependentUnpaused(abilityData.garnetAttack1.bonusStarData.bonusPerfectFreezeDuration);
					Time.timeScale = prevTimeScale;
				}
				break;
			}
			yield return null;
		}
		Debug.Log((object)"Garnet finished playing punch animation");
		tk2dSpriteAnimatorPlus animatorTk2d2 = garnet.animatorTk2d;
		animatorTk2d2.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Remove(animatorTk2d2.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEvent));
	}

	private IEnumerator ConnieSlamSetup()
	{
		yield return null;
		isConnieSlamSetup = true;
	}

	private IEnumerator ConnieSlamAttack()
	{
		while (!isConnieSlamSetup)
		{
			yield return null;
		}
		EventMessenger.Instance.Raise(new RemoveCameraInfluenceEvent(((Component)garnet).transform));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)connie).transform, abilityData.connieAttackCameraInfluence)));
		connie.PlayAnim(connie.animationNames.jumpRun);
		Vector3 targetPos = Vector3.zero;
		tk2dSpriteAnimationFrame animFrame = garnet.animatorTk2d.CurrentClip.GetTk2dAnimationFrameWithEventInfo("jumpFrame");
		tk2dSpriteDefinition spriteDef = animFrame.spriteCollection.spriteDefinitions[animFrame.spriteId];
		tk2dSpriteDefinition.AttachPoint[] attachPoints = spriteDef.attachPoints;
		foreach (tk2dSpriteDefinition.AttachPoint attachPoint in attachPoints)
		{
			if (attachPoint.name == "jumpPoint")
			{
				targetPos = ((Component)garnet.animatorTk2d).transform.TransformPoint(Vector3.Scale(attachPoint.position, garnet.animatorTk2d.Sprite.scale));
			}
		}
		float upTime = 0f;
		float downTime = 0f;
		float highestY = ((!(targetPos.y >= ((Component)connie).transform.position.y)) ? ((Component)connie).transform.position.y : targetPos.y);
		float upDist = Mathf.Abs(highestY + 1.25f - ((Component)connie).transform.position.y);
		float downDist = Mathf.Abs(highestY + 1.25f - targetPos.y);
		float totalDist = upDist + downDist;
		upTime = upDist / totalDist;
		downTime = downDist / totalDist;
		Sequence jumpTween = DOTween.Sequence();
		TweenSettingsExtensions.Append(jumpTween, (Tween)(object)TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOMoveY(((Component)connie).transform, highestY + 1.25f, abilityData.connieJumpUpTime * upTime, false), (Ease)18));
		TweenSettingsExtensions.Append(jumpTween, (Tween)(object)TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOMoveY(((Component)connie).transform, targetPos.y, abilityData.connieJumpUpTime * downTime, false), (Ease)17));
		TweenSettingsExtensions.Insert(jumpTween, 0f, (Tween)(object)TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOMoveX(((Component)connie).transform, targetPos.x, abilityData.connieJumpUpTime, false), (Ease)1));
		TweenSettingsExtensions.Insert(jumpTween, 0f, (Tween)(object)TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOMoveZ(((Component)connie).transform, targetPos.z, abilityData.connieJumpUpTime, false), (Ease)1));
		yield return TweenExtensions.WaitForCompletion((Tween)(object)jumpTween);
		EventMessenger.Instance.Raise(new CameraZoomEvent(1.25f));
		ScreenFlashData screenFlash = new ScreenFlashData
		{
			duration = 0.3f,
			easeFunc = (Ease)1,
			initialColor = Color.white
		};
		EventMessenger.Instance.Raise(new ScreenFlashEvent(screenFlash));
		connie.PlayAnim(abilityData.connieJumpAttack, clearQueue: true);
		poofEffect = ObjectPool.GetObject("steven_jumpLand_particleSystem", targetPos);
		poofEffect.layer = LayerMask.NameToLayer("SpecialFX");
		targetPos = GetClosestSidePosition(enemyTarget, enemyTarget.transform.position, ((Component)connie).transform.position);
		upTime = 0f;
		downTime = 0f;
		highestY = ((!(targetPos.y >= ((Component)connie).transform.position.y)) ? ((Component)connie).transform.position.y : targetPos.y);
		upDist = Mathf.Abs(highestY + 1.25f - ((Component)connie).transform.position.y);
		downDist = Mathf.Abs(highestY + 1.25f - targetPos.y);
		totalDist = upDist + downDist;
		upTime = upDist / totalDist;
		downTime = downDist / totalDist;
		float totalTime = abilityData.connieSlamJumpUpTime + abilityData.connieSlamJumpDownTime;
		jumpTween = DOTween.Sequence();
		TweenSettingsExtensions.Append(jumpTween, (Tween)(object)TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOMoveY(((Component)connie).transform, highestY + 2.5f, abilityData.connieSlamJumpUpTime, false), (Ease)12));
		TweenSettingsExtensions.Append(jumpTween, (Tween)(object)TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOMoveY(((Component)connie).transform, targetPos.y, abilityData.connieSlamJumpDownTime, false), (Ease)11));
		TweenSettingsExtensions.Insert(jumpTween, 0f, (Tween)(object)TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOMoveX(((Component)connie).transform, targetPos.x, totalTime, false), (Ease)1));
		TweenSettingsExtensions.Insert(jumpTween, 0f, (Tween)(object)TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOMoveZ(((Component)connie).transform, targetPos.z, totalTime, false), (Ease)1));
		StarBonusCheck bonusCheck = (currentBonusCheck = StartBonusCheck(Time.time + totalTime, abilityData.connieDiveSlash.bonusStarData, null, followTargets: true));
		for (int j = 0; j < bonusCheck.bonusStars.Count; j++)
		{
			UIBonusStar uIBonusStar = bonusCheck.bonusStars[j];
			((Component)uIBonusStar).gameObject.SetLayerRecursively(LayerMask.NameToLayer("SpecialFX"));
		}
		yield return TweenExtensions.WaitForCompletion((Tween)(object)jumpTween);
		connie.PlayAnim(abilityData.connieDiveSlash.animation, clearQueue: true);
		abilityData.connieDiveSlash.soundEffect.Play();
		currentAnimEventCaster = connie;
		currentAttackData = abilityData.connieDiveSlash;
		targetAnimEventInfo = "hit";
		allowTargetDeath = true;
		tk2dSpriteAnimatorPlus animatorTk2d = connie.animatorTk2d;
		animatorTk2d.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Combine(animatorTk2d.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEvent));
		int hitFrame = connie.animatorTk2d.CurrentClip.GetFrameWithEventInfo("hit");
		while (connie.animatorTk2d.Playing)
		{
			if (connie.animatorTk2d.CurrentFrame >= hitFrame)
			{
				if (bonusCheck.isBonusSuccess && bonusCheck.isBonusPerfectSuccess)
				{
					EventMessenger.Instance.Raise(new PerfectAttackEvent(bonusStarMeterOnPerfect));
					prevTimeScale = Time.timeScale;
					Time.timeScale = 0f;
					yield return new WaitForSecondsIndependentUnpaused(abilityData.connieAttack1.bonusStarData.bonusPerfectFreezeDuration);
					Time.timeScale = prevTimeScale;
				}
				break;
			}
			yield return null;
		}
		tk2dSpriteAnimatorPlus animatorTk2d2 = connie.animatorTk2d;
		animatorTk2d2.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Remove(animatorTk2d2.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEvent));
	}

	protected void HandleAnimationEvent(tk2dSpriteAnimator animator, tk2dSpriteAnimationClip clip, int frameNum)
	{
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		tk2dSpriteAnimationFrame frame = clip.GetFrame(frameNum);
		if (frame.eventInfo == targetAnimEventInfo)
		{
			DamageResult damageResult = BattleHelper.CalculateDamage(currentAnimEventCaster, enemyTarget.damageReceiver, currentAttackData.damageInfo, allowTargetDeath, this);
			if (damageResult.impactResult != null)
			{
				damageResult.impactResult.direction = ((currentAnimEventCaster.horizontalDir != Direction.Right) ? (-GameCamera.instance.container.right) : GameCamera.instance.container.right);
			}
			BattleHelper.DoDamage(damageResult);
			EventMessenger.Instance.Raise(new ScreenShakeEvent(currentAttackData.damageInfo.effects.screenShake));
		}
	}

	private IEnumerator EnforceLowestYPos()
	{
		Vector3 pos = Vector3.zero;
		Vector3 velocity = Vector3.zero;
		while (true)
		{
			yield return null;
			if (((Component)enemyTargetBaseCharacter).transform.position.y < lowestYPosition)
			{
				pos.Set(((Component)enemyTargetBaseCharacter).transform.position.x, lowestYPosition, ((Component)enemyTargetBaseCharacter).transform.position.z);
				((Component)enemyTargetBaseCharacter).transform.position = pos;
				Vector3 velocityVector = enemyTargetBaseCharacter.VelocityVector;
				velocityVector.Set(enemyTargetBaseCharacter.CurVelocity.x, 0f, enemyTargetBaseCharacter.CurVelocity.z);
			}
			if (((Component)connie).transform.position.y < lowestYPosition)
			{
				pos.Set(((Component)connie).transform.position.x, lowestYPosition, ((Component)connie).transform.position.z);
				((Component)connie).transform.position = pos;
				Vector3 velocityVector2 = connie.VelocityVector;
				velocityVector2.Set(connie.CurVelocity.x, 0f, connie.CurVelocity.z);
			}
			if (((Component)garnet).transform.position.y < lowestYPosition)
			{
				pos.Set(((Component)garnet).transform.position.x, lowestYPosition, ((Component)garnet).transform.position.z);
				((Component)garnet).transform.position = pos;
				Vector3 velocityVector3 = garnet.VelocityVector;
				velocityVector3.Set(garnet.CurVelocity.x, 0f, garnet.CurVelocity.z);
			}
		}
	}

	private IEnumerator ProjectorReceiverFollowTarget()
	{
		Transform enemyTransform = enemyTarget.transform;
		LayerMask layerMask = LayerMask.op_Implicit(LayerMask.GetMask(new string[2] { "Ground", "Ground2" }));
		Vector3 yOffset = new Vector3(0f, 0.2f, 0f);
		Vector3 finalPos = Vector3.zero;
		Ray ray = default;
		ray.direction = Vector3.down;
		RaycastHit rayHit = default;
		while (true)
		{
			Vector3 enemyPos = enemyTransform.position + yOffset;
			ray.origin = enemyPos;
			if (Physics.Raycast(ray, ref rayHit, 10f, LayerMask.op_Implicit(layerMask), (QueryTriggerInteraction)1))
			{
				finalPos = rayHit.point;
			}
			else
			{
				finalPos.Set(enemyTransform.position.x, lowestYPosition, enemyTransform.position.z);
			}
			projectorReceiver.transform.position = finalPos + projectorReceiverOffset;
			yield return null;
		}
	}

	private Vector3 GetPredictedKnockedbackPosition(Vector3 startPosition, float speedFactor, BaseCharacter.KnockbackData knockbackData, ImpactResult knockbackImpact, float lowestYPos, float percentAlongKnockback)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		percentAlongKnockback = Mathf.Clamp01(percentAlongKnockback);
		int numBounces = knockbackData.numBounces;
		float gravity = knockbackData.gravity;
		float num = knockbackData.speed * knockbackImpact.force;
		float num2 = knockbackData.jumpHeight * knockbackImpact.force;
		Vector2 val = new Vector2(knockbackImpact.direction.x, knockbackImpact.direction.z);
		float unscaledDeltaTime = Time.unscaledDeltaTime;
		int num3 = numBounces;
		float num4 = num2;
		float num5 = num;
		Vector3 val2 = startPosition;
		Vector3 val3 = new Vector3(0f, num4, 0f);
		val2 += val3 * unscaledDeltaTime;
		val3.y -= gravity * unscaledDeltaTime;
		int num6 = 1000;
		int i;
		for (i = 0; i < num6; i++)
		{
			val3.x = val.x * num5 * speedFactor;
			val3.y -= gravity * unscaledDeltaTime;
			val3.z = val.y * num5 * speedFactor;
			val2 += val3 * unscaledDeltaTime;
			if (val2.y < lowestYPos)
			{
				if (num3 <= 0)
				{
					break;
				}
				num3--;
				num4 *= knockbackData.bounceHeightReduction;
				num5 *= knockbackData.bounceMovementReduction;
				val3.y = num4;
			}
		}
		if (i >= num6)
		{
			Debug.LogError((object)("Predicted position exceeded max iterations, iterations: " + i));
		}
		val2.y = lowestYPos;
		Vector3 val4 = val2 - startPosition;
		return startPosition + val4.normalized * (Vector3.Distance(val2, startPosition) * percentAlongKnockback);
	}

	private Vector3 GetClosestSidePosition(ITargetable target, Vector3 startPosition, Vector3 fromPosition)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = target.FrontPosition - target.transform.position;
		Vector3 val2 = target.BackPosition - target.transform.position;
		Vector3 val3 = startPosition + val;
		Vector3 val4 = startPosition + val2;
		val4.y = (val3.y = lowestYPosition);
		Vector3 val5 = val3 - fromPosition;
		float sqrMagnitude = val5.sqrMagnitude;
		Vector3 val6 = val4 - fromPosition;
		float sqrMagnitude2 = val6.sqrMagnitude;
		return (!(sqrMagnitude < sqrMagnitude2)) ? val4 : val3;
	}

	public override IEnumerator Cancel()
	{
		yield return null;
	}

	protected override void OnCleanUp()
	{
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		base.OnCleanUp();
		connie.ignoreGravity = false;
		connie.ignoreAntiBumpFactor = false;
		garnet.ignoreGravity = false;
		garnet.ignoreAntiBumpFactor = false;
		int layer = LayerMask.NameToLayer("Player");
		((Component)connie).gameObject.layer = layer;
		((Component)garnet).gameObject.layer = layer;
		enemyTarget.gameObject.layer = originalEnemyLayer;
		enemyTargetBaseCharacter.ignoreKnockbackReturnToBattlefield = false;
		enemyTargetBaseCharacter.forceUseKnockback = false;
		if (receiverFollowCoroutine != null)
		{
			((MonoBehaviour)caster).StopCoroutine(receiverFollowCoroutine);
		}
		if (enforceLowestYCoroutine != null)
		{
			((MonoBehaviour)caster).StopCoroutine(enforceLowestYCoroutine);
		}
		receiverFollowCoroutine = null;
		enforceLowestYCoroutine = null;
		if ((Object)(object)dummyTarget != (Object)null)
		{
			Object.Destroy((Object)(object)dummyTarget);
		}
		dummyTarget = null;
		for (int i = 0; i < starBonusChecks.Count; i++)
		{
			StarBonusCheck starBonusCheck = starBonusChecks[i];
			for (int j = 0; j < starBonusCheck.bonusStars.Count; j++)
			{
				UIBonusStar uIBonusStar = starBonusCheck.bonusStars[j];
				((Component)uIBonusStar).gameObject.SetLayerRecursively(LayerMask.NameToLayer("Default"));
			}
		}
		if (enemyTargetBaseCharacter is StrawberryKnight)
		{
			((StrawberryKnight)enemyTargetBaseCharacter).FadeInMace(0.2f);
		}
		teamAttackBG = null;
		ObjectPool.PoolObject(((Component)abstractBG).gameObject);
		ObjectPool.PoolObject(projectorReceiver.gameObject);
		projectorReceiverOffset = Vector3.zero;
		if ((Object)(object)poofEffect != (Object)null)
		{
			poofEffect.layer = LayerMask.NameToLayer("Default");
		}
		poofEffect = null;
		EventMessenger.Instance.Raise(new AbstractBackgroundEvent(abstractBackgroundActive: false, attackingOccurring: true));
	}

	public override void ResetForReUse()
	{
		if ((Object)(object)garnet != (Object)null)
		{
			if ((Object)(object)garnet.animatorTk2d != (Object)null)
			{
				tk2dSpriteAnimatorPlus animatorTk2d = garnet.animatorTk2d;
				animatorTk2d.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Remove(animatorTk2d.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEvent));
			}
			garnet = null;
		}
		if ((Object)(object)connie != (Object)null)
		{
			if ((Object)(object)connie.animatorTk2d != (Object)null)
			{
				tk2dSpriteAnimatorPlus animatorTk2d2 = connie.animatorTk2d;
				animatorTk2d2.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Remove(animatorTk2d2.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEvent));
			}
			connie = null;
		}
		enemyTarget = null;
		enemyTargetBaseCharacter = null;
		abstractBG = null;
		projectorReceiver = null;
		teamAttackBG = null;
		receiverFollowCoroutine = null;
		enforceLowestYCoroutine = null;
		dummyTarget = null;
		poofEffect = null;
		currentAnimEventCaster = null;
		currentBonusCheck = null;
		EventMessenger.Instance.Raise(new StopScreenShakeEvent());
		base.ResetForReUse();
	}

	public bool CanFuse()
	{
		return true;
	}

	private Vector3 SnapPositionToGround(Vector3 pos)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val = default;
		if (Physics.Raycast(pos + Vector3.up, Vector3.down, ref val, 15f, LayerMask.GetMask(new string[2] { "Ground", "Ground2" })))
		{
			pos = val.point;
			pos.y = Mathf.Max(pos.y, lowestYPosition);
		}
		else
		{
			pos.y = lowestYPosition;
		}
		return pos;
	}
}
