using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpalPC : PlayerCharacter, IFusion
{
	protected override DamageInfo actionDamageInfo => new DamageInfo();

	public CharacterName[] fusedCharacters => new CharacterName[2]
	{
		CharacterName.Amethyst,
		CharacterName.Pearl
	};

	public override StatusEffectName[] InnateImmunities => new StatusEffectName[2]
	{
		StatusEffectName.Frozen,
		StatusEffectName.Stun
	};

	protected override void Awake()
	{
		base.Awake();
		characterName = CharacterName.Opal;
		AddTransitionsToState(CharacterState.DeathComplete, new Enum[1] { CharacterState.BattleWaiting });
	}

	protected override void EnterDeath(Enum previous, object[] args)
	{
		InterruptReturningToBattlefield();
		((MonoBehaviour)this).StartCoroutine(PlayUnfuseDeath());
	}

	protected override void UpdateDeath()
	{
	}

	private IEnumerator PlayUnfuseDeath()
	{
		BaseAbility unfuseAbility = GetAbility<UnfuseAbility>();
		unfuseAbility.Init(this, new List<ITargetable> { this });
		AbilityEventController.instance.AddLoadedAbilityAsset(unfuseAbility);
		yield return ((MonoBehaviour)this).StartCoroutine(unfuseAbility.Play());
		unfuseAbility.CleanUp();
		ChangeState(CharacterState.DeathComplete, false);
	}
}
