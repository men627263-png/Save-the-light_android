using System;
using System.Collections;
using Grumpyface;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Abilities/Bosses/Light Warrior/Rainbow Laser")]
public class LightWarrior_RainbowLaserAbility : BaseAbility
{
	[Serializable]
	private class AbilityData
	{
		[Header("Prefabs")]
		public GameObject backgroundPrefab;

		[Header("Object References")]
		public BattleCameraSetup introCameraSetup;

		public BattleCameraSetup shootCameraSetup;

		[Header("Animations")]
		public CharacterAnimationNamePair introAnim = default;

		public CharacterAnimationNamePair loopAnim = default;

		public CharacterAnimationNamePair outroAnim = default;

		[Header("Tweakables")]
		public DamageInfo damage;

		public float duration = 4f;

		[Header("Visual/Force Feedback")]
		[Range(0f, 1f)]
		public float zoomOutAt = 0.75f;

		[Tooltip("The duration in this ScreenShakeData object will be ignored. It is overridden by the above duration.")]
		public ScreenShakeData shootShake;

		[Range(0f, 1f)]
		public float shootVibrationStrength;

		public ScreenShakeData finalShake;

		public VibrationManager.Vibration finalVibration;

		[Header("Sounds")]
		public DelayedAudioEvent mainSound = default;
	}

	[SerializeField]
	private AbilityData abilityData;

	[NonSerialized]
	private LightWarrior lightWarrior;

	[NonSerialized]
	private BattleCamera battleCamera;

	[NonSerialized]
	private AbstractBattleBG background;

	protected override void OnInit()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		base.OnInit();
		lightWarrior = (LightWarrior)caster;
		battleCamera = GameController.Instance.BattleCamera;
		background = ObjectPool.GetObject<AbstractBattleBG>(abilityData.backgroundPrefab, default(Vector3), false);
	}

	public override IEnumerator Play()
	{
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new CameraZoomEvent(1f));
		battleCamera.overrideCameraOverride = abilityData.introCameraSetup;
		battleCamera.overrideFollowTarget = ((Component)lightWarrior).transform;
		((Component)background).gameObject.SetActive(true);
		background.AddTarget((ITargetable)lightWarrior);
		background.AddTargets(targets);
		lightWarrior.PlayAnim(abilityData.introAnim, clearQueue: true);
		lightWarrior.AddAnimToQueue(abilityData.loopAnim);
		abilityData.mainSound.Play(((Component)lightWarrior).transform.position);
		((Component)lightWarrior.characterProperties.extrasAnimator).gameObject.SetActive(true);
		lightWarrior.characterProperties.extrasAnimator.Play(abilityData.introAnim, clearQueue: true);
		lightWarrior.characterProperties.extrasAnimator.AddToQueue(abilityData.loopAnim);
		lightWarrior.animator.Update(0f);
		AnimatorStateInfo currentAnimatorStateInfo = lightWarrior.animator.GetCurrentAnimatorStateInfo(0);
		float delay = currentAnimatorStateInfo.length * abilityData.zoomOutAt;
		yield return (object)new WaitForSeconds(delay);
		battleCamera.overrideCameraOverride = abilityData.shootCameraSetup;
		battleCamera.overrideFollowTarget = null;
		yield return (object)new WaitWhile((Func<bool>)(() => lightWarrior.IsAnimPlaying(abilityData.introAnim)));
		ScreenShakeData shakeData = abilityData.shootShake;
		shakeData.duration = abilityData.duration;
		EventMessenger.Instance.Raise(new ScreenShakeEvent(shakeData));
		EventMessenger.Instance.Raise(new VibrationEvent(new VibrationManager.Vibration(abilityData.shootVibrationStrength, abilityData.duration)));
		float halfDuration = abilityData.duration * 0.5f;
		yield return (object)new WaitForSeconds(halfDuration);
		BattleHelper.DoDamage(caster, targets, abilityData.damage, allowDeath: true, this);
		yield return (object)new WaitForSeconds(halfDuration);
		battleCamera.overrideCameraOverride = null;
		background.ReturnAllActiveTargets();
		ObjectPool.PoolObject(((Component)background).gameObject);
		background = null;
		lightWarrior.PlayAnim(abilityData.outroAnim, clearQueue: true);
		lightWarrior.AddAnimToQueue(lightWarrior.GetIdleAnimation());
		lightWarrior.characterProperties.extrasAnimator.Play(abilityData.outroAnim);
		EventMessenger.Instance.Raise(new ScreenShakeEvent(abilityData.finalShake));
		EventMessenger.Instance.Raise(new VibrationEvent(abilityData.finalVibration));
		yield return (object)new WaitWhile((Func<bool>)(() => lightWarrior.IsAnimPlaying(abilityData.outroAnim)));
		((Component)lightWarrior.characterProperties.extrasAnimator).gameObject.SetActive(false);
	}

	public override IEnumerator Cancel()
	{
		yield break;
	}

	protected override void OnCleanUp()
	{
		base.OnCleanUp();
		if ((Object)(object)background != (Object)null)
		{
			background.ReturnAllActiveTargets();
			ObjectPool.PoolObject(((Component)background).gameObject);
			background = null;
		}
		lightWarrior = null;
		battleCamera = null;
	}

	public override void ResetForReUse()
	{
		EventMessenger.Instance.Raise(new RemoveVibrationEvent(abilityData.finalVibration));
		EventMessenger.Instance.Raise(new StopScreenShakeEvent());
		lightWarrior = null;
		battleCamera = null;
		background = null;
		base.ResetForReUse();
	}
}
