using System.Collections.Generic;
using UnityEngine;

public class SecretArea : MonoBehaviour
{
	public string guid;

	protected void SecretAreaFound()
	{
		if (PlayerGameState.Instance.HasFoundSecretArea(guid) || string.IsNullOrEmpty(guid))
		{
			return;
		}
		PlayerGameState.Instance.FoundSecretArea(guid);
		float value = Random.value;
		if (!(value <= GameResources.instance.gameSettings.chanceToPlaySecretVO))
		{
			return;
		}
		List<PlayerCharacter> list = GameController.Instance.party.FindAll((PlayerCharacter x) => x.followingPartyLeader || x.isPartyLeader);
		if (list.Count > 0)
		{
			PlayerCharacter playerCharacter = list[Random.Range(0, list.Count)];
			if ((Object)(object)playerCharacter.secretFoundVOClip != (Object)null)
			{
				playerCharacter.secretFoundVOClip.Play();
			}
		}
	}

	protected virtual void OnTriggerEnter(Collider collider)
	{
		if (!((Object)(object)GameController.Instance == (Object)null) && !((Object)(object)GameController.Instance.partyLeader == (Object)null) && ((object)((Component)collider).gameObject).Equals((object?)((Component)GameController.Instance.partyLeader).gameObject))
		{
			SecretAreaFound();
		}
	}
}
