using System;
using UnityEngine;

public class EntranceArea : StopArea
{
	public Vector3[] startPositions;

	public Vector3 leaderStartPosition;

	public Vector3 leaderEndPosition;

	private bool[] startPositionsUsed;

	private bool hasStartedMove;

	protected override void Awake()
	{
		base.Awake();
		startPositionsUsed = new bool[startPositions.Length];
	}

	protected override void OnTriggerEnter(Collider other)
	{
		if (!hasStartedMove)
		{
			base.OnTriggerEnter(other);
		}
	}

	protected override void OnTriggerStay(Collider other)
	{
		if (!hasStartedMove && !((Object)(object)GameController.Instance == (Object)null) && !((Object)(object)GameController.Instance.partyLeader == (Object)null))
		{
			base.OnTriggerStay(other);
			if (((object)((Component)other).gameObject).Equals((object?)((Component)GameController.Instance.partyLeader).gameObject))
			{
				MoveAllCharacters();
			}
		}
	}

	private void MoveAllCharacters()
	{
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		if (hasStartedMove)
		{
			return;
		}
		hasStartedMove = true;
		for (int i = 0; i < startPositionsUsed.Length; i++)
		{
			startPositionsUsed[i] = false;
		}
		for (int j = 0; j < GameController.Instance.party.Count; j++)
		{
			PlayerCharacter playerCharacter = GameController.Instance.party[j];
			if (!((Object)(object)playerCharacter != (Object)(object)GameController.Instance.partyLeader))
			{
				continue;
			}
			int num = 0;
			float num2 = 99999f;
			for (int k = 0; k < startPositions.Length; k++)
			{
				Vector3 val = ((Component)this).transform.position + ((Component)this).transform.rotation * startPositions[k];
				if (Vector3.Distance(((Component)playerCharacter).transform.position, val) <= num2 && !startPositionsUsed[k])
				{
					num = k;
					startPositionsUsed[k] = true;
					num2 = Vector3.Distance(((Component)playerCharacter).transform.position, ((Component)this).transform.position + ((Component)this).transform.rotation * startPositions[num]);
					break;
				}
			}
			((Component)playerCharacter).transform.position = ((Component)this).transform.position + ((Component)this).transform.rotation * startPositions[num];
		}
		((Component)GameController.Instance.partyLeader).transform.position = ((Component)this).transform.position + ((Component)this).transform.rotation * leaderStartPosition;
		GameController.Instance.partyLeader.disableJump = true;
		GameController.Instance.partyLeader.disableAction = true;
		GameController.Instance.partyLeader.disableMovement = true;
		GameController.Instance.partyLeader.RichAI2D.MoveToPosition(((Component)this).transform.position + ((Component)this).transform.rotation * leaderEndPosition, 5f);
		RichAI2D richAI2D = GameController.Instance.partyLeader.RichAI2D;
		richAI2D.targetReached = (Action)Delegate.Combine(richAI2D.targetReached, new Action(PartyLeaderReachedPosition));
	}

	private void PartyLeaderReachedPosition()
	{
		RichAI2D richAI2D = GameController.Instance.partyLeader.RichAI2D;
		richAI2D.targetReached = (Action)Delegate.Remove(richAI2D.targetReached, new Action(PartyLeaderReachedPosition));
		GameController.Instance.partyLeader.disableJump = false;
		GameController.Instance.partyLeader.disableAction = false;
		GameController.Instance.partyLeader.disableMovement = false;
	}

	private void OnDrawGizmos()
	{
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		if (characterPositions != null)
		{
			for (int i = 0; i < characterPositions.Length; i++)
			{
				Vector3 val = characterPositions[i];
				Gizmos.color = Color.yellow;
				Gizmos.DrawSphere(((Component)this).transform.position + ((Component)this).transform.rotation * val, 0.2f);
				Gizmos.color = Color.white;
			}
		}
		if (startPositions != null)
		{
			for (int j = 0; j < startPositions.Length; j++)
			{
				Vector3 val2 = startPositions[j];
				Gizmos.color = Color.red;
				Gizmos.DrawSphere(((Component)this).transform.position + ((Component)this).transform.rotation * val2, 0.2f);
				Gizmos.color = Color.white;
			}
		}
		Gizmos.color = Color.red;
		Gizmos.DrawSphere(((Component)this).transform.position + ((Component)this).transform.rotation * leaderStartPosition, 0.2f);
		Gizmos.color = Color.white;
		Gizmos.color = Color.red;
		Gizmos.DrawSphere(((Component)this).transform.position + ((Component)this).transform.rotation * leaderEndPosition, 0.2f);
		Gizmos.color = Color.white;
	}
}
