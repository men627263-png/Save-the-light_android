public enum UIBonusStarType
{
	Offensive,
	Defensive
}
