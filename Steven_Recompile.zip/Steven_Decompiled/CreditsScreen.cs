using System.Collections;
using System.Collections.Generic;
using Rewired;
using TMPro;
using UnityEngine;

public class CreditsScreen : MonoBehaviour
{
	public static CreditsScreen instance;

	public Transform animGroup;

	public Transform creditsGroup;

	public TMP_FontAsset font;

	public Material headerFontMaterial;

	public Material nameFontMaterial;

	public Material titleFontMaterial;

	public float headerSpacingBefore = 30f;

	public float headerSpacingAfter = 20f;

	public float headerFontSize = 200f;

	public float nameSpacing = 10f;

	public float nameFontSize = 150f;

	public float titleSpacingBefore = 20f;

	public float titleSpacingAfter = 30f;

	public float titleFontSize = 200f;

	public float scrollSpeed = 1f;

	public Transform cameraUpperCenter;

	public Transform cameraLowerCenter;

	public Transform lastItem;

	public float creditItemObjectScale = 1f;

	public List<CreditItem> credits = new List<CreditItem>();

	public bool titleScreenCredits { get; set; }

	public Player player { get; set; }

	private void Awake()
	{
		instance = this;
		player = ReInput.players.GetPlayer(0);
	}

	private void OnDestroy()
	{
		instance = null;
		player = null;
	}

	private void OnEnable()
	{
		ResetScroller();
	}

	private void OnDisable()
	{
	}

	private void Update()
	{
		if (titleScreenCredits && player.GetButtonDown("MenuUICancel"))
		{
			LoadGameController.Instance.HideCreditsScene();
		}
	}

	public void ResetScroller()
	{
		((MonoBehaviour)this).StopCoroutine("Scroll");
		((MonoBehaviour)this).StartCoroutine("Scroll");
	}

	private IEnumerator Scroll()
	{
		while (true)
		{
			creditsGroup.localPosition = new Vector3(0f, creditsGroup.localPosition.y + scrollSpeed, 0f);
			if (lastItem.position.y > cameraUpperCenter.position.y + 15f)
			{
				break;
			}
			yield return (object)new WaitForEndOfFrame();
		}
		if (titleScreenCredits)
		{
			LoadGameController.Instance.HideCreditsScene();
			yield break;
		}
		GameController.showTitleScreen = true;
		UILoadingScreen.Instance.LoadScene("HouseInterior", 1f, 0f);
	}

	public void Rebuild()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Expected Obj, but got Unknown
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Expected Obj, but got Unknown
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_048b: Unknown result type (might be due to invalid IL or missing references)
		List<GameObject> list = new List<GameObject>();
		foreach (Transform item in creditsGroup)
		{
			Transform val = item;
			if (!((Object)((Component)val).gameObject).name.ToLower().Contains("sprite") && !((Object)((Component)val).gameObject).name.ToLower().Contains("buildnumber"))
			{
				list.Add(((Component)val).gameObject);
			}
		}
		list.ForEach((GameObject child) =>
		{
			Object.DestroyImmediate((Object)(object)child);
		});
		float num = 0f;
		CreditType creditType = CreditType.Space;
		for (int num2 = 0; num2 < credits.Count; num2++)
		{
			GameObject val2 = new GameObject(string.Concat(credits[num2].type, " ", credits[num2].key));
			val2.transform.parent = creditsGroup;
			val2.layer = LayerMask.NameToLayer("UI");
			if (credits[num2].type != CreditType.Space)
			{
				LocalizedText localizedText = val2.AddComponent<LocalizedText>();
				localizedText.key = credits[num2].key;
				localizedText.sheet = "CREDITS";
				localizedText.sheetIndex = 4;
				if (credits[num2].type != CreditType.Name)
				{
					localizedText.overrideTextAutoSizing = true;
					localizedText.textMeshSettingsOverride = new OverrideTextMeshSettings[2];
					localizedText.textMeshSettingsOverride[0].language = LanguageCode.JA;
					localizedText.textMeshSettingsOverride[0].overrideDilate = true;
					localizedText.textMeshSettingsOverride[0].faceDilate = 0.12f;
					localizedText.textMeshSettingsOverride[1].language = LanguageCode.KO;
					localizedText.textMeshSettingsOverride[1].overrideDilate = true;
					localizedText.textMeshSettingsOverride[1].faceDilate = 0.12f;
				}
			}
			if (credits[num2].type == CreditType.Header)
			{
				num -= headerSpacingBefore;
			}
			if (credits[num2].type == CreditType.Title)
			{
				num -= titleSpacingBefore;
			}
			val2.transform.localPosition = new Vector3(0f, num, 0f);
			val2.transform.localScale = new Vector3(creditItemObjectScale, creditItemObjectScale, creditItemObjectScale);
			TextMeshProUGUI textMeshProUGUI = val2.AddComponent<TextMeshProUGUI>();
			textMeshProUGUI.font = font;
			textMeshProUGUI.alignment = TextAlignmentOptions.Midline;
			if (credits[num2].type == CreditType.Header)
			{
				textMeshProUGUI.text = Languages.Get(credits[num2].key, "CREDITS");
				num -= headerSpacingAfter;
				textMeshProUGUI.fontSharedMaterial = headerFontMaterial;
				textMeshProUGUI.fontSize = headerFontSize;
			}
			if (credits[num2].type == CreditType.Name)
			{
				textMeshProUGUI.text = Languages.Get(credits[num2].key, "CREDITS");
				num -= nameSpacing;
				textMeshProUGUI.fontSharedMaterial = nameFontMaterial;
				textMeshProUGUI.fontSize = nameFontSize;
			}
			if (credits[num2].type == CreditType.Title)
			{
				textMeshProUGUI.text = Languages.Get(credits[num2].key, "CREDITS");
				num -= titleSpacingAfter;
				textMeshProUGUI.fontSharedMaterial = titleFontMaterial;
				textMeshProUGUI.fontSize = titleFontSize;
				textMeshProUGUI.enableAutoSizing = true;
				textMeshProUGUI.fontSizeMin = 20f;
				textMeshProUGUI.fontSizeMax = titleFontSize;
			}
			if (credits[num2].type == CreditType.Space)
			{
				num -= credits[num2].spaceAmount;
			}
			if (credits[num2].changeFontMaterial && (Object)(object)credits[num2].fontMaterial != (Object)null)
			{
				textMeshProUGUI.fontSharedMaterial = credits[num2].fontMaterial;
			}
			((Component)textMeshProUGUI).GetComponent<RectTransform>().sizeDelta = new Vector2(1024f, 100f);
			textMeshProUGUI.enableWordWrapping = true;
			if (num2 == credits.Count - 1)
			{
				lastItem = val2.transform;
			}
		}
	}
}
