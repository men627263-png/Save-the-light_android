public class StarPointsRemovedEvent : GameEvent
{
	public int originalAmount { get; private set; }

	public int actualAmount { get; private set; }

	public StarPointsRemovedEvent(int originalAmount, int actualAmount)
	{
		this.originalAmount = originalAmount;
		this.actualAmount = actualAmount;
	}
}
