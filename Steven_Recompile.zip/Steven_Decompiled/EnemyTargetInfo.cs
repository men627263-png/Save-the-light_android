using System.Collections.Generic;

public class EnemyTargetInfo
{
	public BaseCharacter enemyCharacter;

	public List<ITargetable> targets;

	public EnemyTargetInfo(BaseCharacter newEnemy)
	{
		enemyCharacter = newEnemy;
		targets = new List<ITargetable>();
	}

	public EnemyTargetInfo(BaseCharacter newEnemy, List<ITargetable> newTargets)
	{
		enemyCharacter = newEnemy;
		targets = ((newTargets != null) ? newTargets : new List<ITargetable>());
	}
}
