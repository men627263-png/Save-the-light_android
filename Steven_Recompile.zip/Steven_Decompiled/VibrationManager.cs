using System;
using System.Collections.Generic;
using Rewired;
using UnityEngine;

[DisallowMultipleComponent]
public class VibrationManager : MonoBehaviour
{
	[Serializable]
	public class Vibration
	{
		[Range(0f, 1f)]
		public float strength = 0.25f;

		public float duration = 0.25f;

		public bool useUnscaledTime;

		public bool isContinuous;

		public string id;

		internal float lifetime { get; set; }

		public Vibration(float strength, float duration, bool useUnscaledTime = false, bool isContinuous = false, string id = null)
		{
			this.strength = strength;
			this.duration = duration;
			this.useUnscaledTime = useUnscaledTime;
			this.isContinuous = isContinuous;
			this.id = id;
		}
	}

	public bool showDebug;

	public int debugFontSize = 24;

	public Color debugFontColor = Color.white;

	public Color debugFontBackColor = Color.black;

	private bool disableVibration;

	private List<Vibration> activeVibrations = new List<Vibration>();

	private Vibration vibration;

	private Joystick joystick;

	private bool isGamePaused;

	private bool applicationDidQuit;

	private float prevTimeScale;

	private Player _player;

	private static VibrationManager _instance;

	private Player player
	{
		get
		{
			if (_player == null)
			{
				_player = ReInput.players.GetPlayer(0);
			}
			return _player;
		}
	}

	public static VibrationManager Instance
	{
		get
		{
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			if ((Object)(object)_instance == (Object)null)
			{
				_instance = new GameObject("VibrationManager").AddComponent<VibrationManager>();
			}
			return _instance;
		}
	}

	public VibrationManager()
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Awake()
	{
		if ((Object)(object)_instance != (Object)null && (Object)(object)_instance != (Object)(object)this)
		{
			Debug.LogError((object)"An instance of the VibrationManager already exists, so destroying this instance");
			Object.Destroy((Object)(object)this);
			return;
		}
		if ((Object)(object)((Component)this).transform.root != (Object)(object)((Component)this).transform)
		{
			Debug.LogWarning((object)"Ideally the Vibration Manager should be on a top-most GameObject in the hierarchy");
		}
		_instance = this;
		Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
	}

	private void OnEnable()
	{
		EventMessenger.Instance.AddListener<VibrationEvent>(HandleVibrationEvent);
		EventMessenger.Instance.AddListener<RemoveVibrationEvent>(HandleRemoveVibrationEvent);
		EventMessenger.Instance.AddListener<PauseEvent>(HandlePauseEvent);
		prevTimeScale = Time.timeScale;
	}

	private void OnDisable()
	{
		if (!applicationDidQuit)
		{
			EventMessenger.Instance.RemoveListener<VibrationEvent>(HandleVibrationEvent);
			EventMessenger.Instance.RemoveListener<RemoveVibrationEvent>(HandleRemoveVibrationEvent);
			EventMessenger.Instance.RemoveListener<PauseEvent>(HandlePauseEvent);
			activeVibrations.Clear();
			RefreshVibration();
		}
	}

	private void OnApplicationQuit()
	{
		applicationDidQuit = true;
	}

	private void Update()
	{
		bool flag = false;
		int num = activeVibrations.Count - 1;
		for (int num2 = num; num2 >= 0; num2--)
		{
			vibration = activeVibrations[num2];
			if (!vibration.isContinuous)
			{
				vibration.lifetime -= ((!vibration.useUnscaledTime) ? Time.deltaTime : Time.unscaledDeltaTime);
				if (vibration.lifetime <= 0f)
				{
					activeVibrations.RemoveAt(num2);
					flag = true;
				}
			}
		}
		if ((Time.timeScale == 0f && prevTimeScale > 0f) || (Time.timeScale > 0f && prevTimeScale == 0f))
		{
			flag = true;
		}
		prevTimeScale = Time.timeScale;
		if (flag)
		{
			RefreshVibration();
		}
	}

	private void OnGUI()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Expected Obj, but got Unknown
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Expected Obj, but got Unknown
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Expected Obj, but got Unknown
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Expected Obj, but got Unknown
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Expected Obj, but got Unknown
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		if (showDebug)
		{
			Color color = GUI.color;
			GUIStyle val = new GUIStyle(GUI.skin.label);
			val.fontSize = debugFontSize;
			string empty = string.Empty;
			empty = "Vibrations Enabled: " + ((!disableVibration) ? "Yes" : "No");
			GUI.color = debugFontBackColor;
			GUI.Label(new Rect(12f, 12f, 1000f, (float)(debugFontSize + 10)), new GUIContent(empty), val);
			GUI.color = debugFontColor;
			GUI.Label(new Rect(10f, 10f, 1000f, (float)(debugFontSize + 10)), new GUIContent(empty), val);
			vibration = GetActiveVibration();
			empty = ((vibration == null) ? string.Format("No active vibrations", new object[0]) : $"There are {activeVibrations.Count} active vibration(s). Current strength: {vibration.strength}   Time Remaining: {vibration.lifetime}");
			GUI.color = debugFontBackColor;
			GUI.Label(new Rect(12f, 42f, 1000f, (float)(debugFontSize + 10)), new GUIContent(empty), val);
			GUI.color = debugFontColor;
			GUI.Label(new Rect(10f, 40f, 1000f, (float)(debugFontSize + 10)), new GUIContent(empty), val);
			GUI.color = color;
		}
	}

	public void Init()
	{
	}

	private void AddVibration(Vibration vibration)
	{
		if (!disableVibration && (vibration.isContinuous || !(vibration.duration <= 0f)) && !(vibration.strength <= 0f))
		{
			vibration.lifetime = vibration.duration;
			if (!activeVibrations.Contains(vibration))
			{
				activeVibrations.Add(vibration);
			}
			activeVibrations.Sort(VibrationSort);
			RefreshVibration();
		}
	}

	private void AddVibration(float strength, float duration, bool useUnscaledTime = false, bool isContinuous = false)
	{
		if ((isContinuous || !(duration <= 0f)) && !(strength <= 0f))
		{
			AddVibration(new Vibration(strength, duration, useUnscaledTime, isContinuous));
		}
	}

	private void RemoveVibration(Vibration vibration)
	{
		int num = activeVibrations.IndexOf(vibration);
		if (num > -1)
		{
			activeVibrations.RemoveAt(num);
			RefreshVibration();
		}
	}

	private void RemoveVibration(string id)
	{
		if (string.IsNullOrEmpty(id))
		{
			return;
		}
		int num = activeVibrations.Count - 1;
		for (int num2 = num; num2 >= 0; num2--)
		{
			if (activeVibrations[num2].id.Equals(id))
			{
				activeVibrations.RemoveAt(num2);
			}
		}
		RefreshVibration();
	}

	public void DisableVibrations(bool shouldDisable)
	{
		disableVibration = shouldDisable;
		if (disableVibration)
		{
			activeVibrations.Clear();
		}
		RefreshVibration();
	}

	private void RefreshVibration()
	{
		if (player == null)
		{
			return;
		}
		int joystickCount = player.controllers.joystickCount;
		vibration = GetActiveVibration();
		if (vibration != null)
		{
			float num = Mathf.Clamp01(vibration.strength);
			for (int i = 0; i < joystickCount; i++)
			{
				joystick = player.controllers.Joysticks[i];
				if (joystick.supportsVibration)
				{
					if (joystick.vibrationMotorCount > 0)
					{
						joystick.SetVibration(0, num);
					}
					if (joystick.vibrationMotorCount > 1)
					{
						joystick.SetVibration(1, num);
					}
				}
			}
			return;
		}
		for (int j = 0; j < joystickCount; j++)
		{
			joystick = player.controllers.Joysticks[j];
			if (joystick.supportsVibration && joystick.vibrationMotorCount > 0)
			{
				joystick.StopVibration();
			}
		}
	}

	private Vibration GetActiveVibration()
	{
		int num = activeVibrations.Count - 1;
		for (int num2 = num; num2 >= 0; num2--)
		{
			if (activeVibrations[num2].useUnscaledTime || (!isGamePaused && Time.timeScale > 0f))
			{
				return activeVibrations[num2];
			}
		}
		return null;
	}

	private int VibrationSort(Vibration vibration1, Vibration vibration2)
	{
		return vibration1.strength.CompareTo(vibration2.strength);
	}

	private void HandleVibrationEvent(VibrationEvent evt)
	{
		AddVibration(evt.vibration);
	}

	private void HandleRemoveVibrationEvent(RemoveVibrationEvent evt)
	{
		if (evt.vibration != null)
		{
			RemoveVibration(evt.vibration);
		}
		else
		{
			RemoveVibration(evt.id);
		}
	}

	private void HandlePauseEvent(PauseEvent evt)
	{
		isGamePaused = evt.isPaused;
		RefreshVibration();
	}
}
