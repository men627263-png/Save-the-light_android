using UnityEngine;

public class DetachedPuzzlePiece : MonoBehaviour
{
	public tk2dSprite bgSprite;

	public tk2dSprite[] glowSprites;

	public bool Equals(DetachedPuzzlePiece puzzlePiece)
	{
		return bgSprite.spriteId == puzzlePiece.bgSprite.spriteId;
	}
}
