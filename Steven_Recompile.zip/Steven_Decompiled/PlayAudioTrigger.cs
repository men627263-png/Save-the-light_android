using UnityEngine;

public class PlayAudioTrigger : MonoBehaviour
{
	public DelayedAudioEvent audioEvent;

	public bool playOnce;

	private bool played;

	private void OnTriggerEnter(Collider other)
	{
		if (!((Object)(object)GameController.Instance == (Object)null) && !((Object)(object)GameController.Instance.partyLeader == (Object)null) && ((object)((Component)other).gameObject).Equals((object?)((Component)GameController.Instance.partyLeader).gameObject) && ((playOnce && !played) || !playOnce))
		{
			played = true;
			audioEvent.Play();
		}
	}
}
