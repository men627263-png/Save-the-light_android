using System;
using System.Collections.Generic;
using Grumpyface;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[CreateAssetMenu(menuName = "Save the Light/Target Systems/Single Radial")]
public class SingleRadialTargetSystem : BattleTargetSystem
{
	public UITargetArrow targetArrowButtonPrefab;

	public UITargetArrow blinkingArrowPrefab;

	public GroundTarget groundTargetPrefab;

	public float radius;

	[NonSerialized]
	private List<GameObject> targetArrows = new List<GameObject>();

	[NonSerialized]
	private List<UITargetArrow> targetArrowsRef = new List<UITargetArrow>();

	[NonSerialized]
	private Dictionary<ITargetable, UITargetArrow> blinkingArrows = new Dictionary<ITargetable, UITargetArrow>();

	[NonSerialized]
	private GroundTarget groundTarget;

	[NonSerialized]
	private GameObject lastSelectedUIObj;

	[NonSerialized]
	private Collider[] hitResults = new Collider[10];

	[NonSerialized]
	private ITargetable mainTarget;

	[NonSerialized]
	private List<ITargetable> inRangeTargets = new List<ITargetable>();

	[NonSerialized]
	private int layerMask;

	[NonSerialized]
	private float curRadius;

	public override ITargetable lastSelected => null;

	public sealed override bool canExit => true;

	protected override void OnDisable()
	{
		base.OnDisable();
		if (targetArrows != null)
		{
			targetArrows.Clear();
		}
		else
		{
			targetArrows = new List<GameObject>();
		}
		if (targetArrowsRef != null)
		{
			targetArrowsRef.Clear();
		}
		else
		{
			targetArrowsRef = new List<UITargetArrow>();
		}
		if (blinkingArrows != null)
		{
			blinkingArrows.Clear();
		}
		else
		{
			blinkingArrows = new Dictionary<ITargetable, UITargetArrow>();
		}
		if (inRangeTargets != null)
		{
			inRangeTargets.Clear();
		}
		else
		{
			inRangeTargets = new List<ITargetable>();
		}
		groundTarget = null;
		lastSelectedUIObj = null;
		mainTarget = null;
	}

	protected override void OnStartTargeting(BaseCharacter caster, AbilityTargetType targetType, bool canTargetNonCharacters, ITargetable initialTarget = null)
	{
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		inRangeTargets.Clear();
		targetArrows.Clear();
		targetArrowsRef.Clear();
		blinkingArrows.Clear();
		int num = 1 << LayerMask.NameToLayer("Player");
		int num2 = 1 << LayerMask.NameToLayer("Enemy");
		layerMask = 0;
		switch (targetType)
		{
		case AbilityTargetType.All:
		case AbilityTargetType.SingleAll:
			layerMask = num | num2;
			break;
		case AbilityTargetType.SingleFriendly:
		case AbilityTargetType.AllFriendly:
		case AbilityTargetType.AllFriendlyPlusSelf:
		case AbilityTargetType.SingleFriendlyPlusSelf:
			layerMask = ((!(((Component)caster).tag == "Player")) ? num2 : num);
			break;
		case AbilityTargetType.SingleEnemy:
		case AbilityTargetType.AllEnemies:
			layerMask = ((!(((Component)caster).tag == "Player")) ? num : num2);
			break;
		}
		curRadius = GetRadius(caster);
		groundTarget = ObjectPool.GetObject<GroundTarget>(((Component)groundTargetPrefab).gameObject, default(Vector3), true);
		groundTarget.projector.orthographicSize = curRadius;
		((Behaviour)groundTarget.projector).enabled = false;
		UITargetArrow uITargetArrow = null;
		ITargetable targetable = null;
		UITargetArrow uITargetArrow2 = null;
		int count = validTargets.Count;
		for (int i = 0; i < count; i++)
		{
			targetable = validTargets[i];
			if (!targetable.IsDead || targetType == AbilityTargetType.SingleDeadFriendlyPlusSelf)
			{
				Color white = Color.white;
				uITargetArrow = ObjectPool.GetObject<UITargetArrow>(((Component)targetArrowButtonPrefab).gameObject, default(Vector3), true);
				GameUI.instance.AddElementToLayer(uITargetArrow.rectTransform, GameUI.instance.characterLayer);
				uITargetArrow.Init(targetable, controller.uiCanvas, white);
				((Component)uITargetArrow).gameObject.SetActive(true);
				targetArrows.Add(((Component)uITargetArrow).gameObject);
				targetArrowsRef.Add(uITargetArrow);
				if (uITargetArrow.target == initialTarget && (!initialTarget.IsDead || targetType == AbilityTargetType.SingleDeadFriendlyPlusSelf))
				{
					uITargetArrow2 = uITargetArrow;
				}
				uITargetArrow = ObjectPool.GetObject<UITargetArrow>(((Component)blinkingArrowPrefab).gameObject, default(Vector3), true);
				GameUI.instance.AddElementToLayer(uITargetArrow.rectTransform, GameUI.instance.characterLayer);
				uITargetArrow.Init(targetable, controller.uiCanvas, white);
				((Component)((Component)uITargetArrow).GetComponentInChildren<Graphic>(true)).gameObject.AddComponent<BlinkGraphic>();
				((Component)uITargetArrow).gameObject.SetActive(false);
				blinkingArrows.Add(targetable, uITargetArrow);
				EventMessenger.Instance.Raise(new HealthBarDisplayerShowEvent(targetable));
			}
		}
		EventSystem.current.SetSelectedGameObject((!((Object)(object)uITargetArrow2 != (Object)null)) ? targetArrows[0] : ((Component)uITargetArrow2).gameObject);
		EventMessenger.Instance.AddListener<UITargetArrowEvent>(HandleUITargetArrowEvent);
		lastSelectedUIObj = null;
	}

	protected override void OnUpdateTargeting()
	{
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)EventSystem.current == (Object)(object)controller.gameEventSystem) || !((Object)(object)lastSelectedUIObj != (Object)(object)EventSystem.current.currentSelectedGameObject))
		{
			return;
		}
		if ((Object)(object)lastSelectedUIObj != (Object)null)
		{
			EventMessenger.Instance.Raise(new RemoveCameraInfluenceEvent(targetArrowsRef[targetArrows.IndexOf(lastSelectedUIObj)].target.transform));
			for (int i = 0; i < inRangeTargets.Count; i++)
			{
				((Component)blinkingArrows[inRangeTargets[i]]).gameObject.SetActive(false);
			}
			inRangeTargets.Clear();
		}
		lastSelectedUIObj = EventSystem.current.currentSelectedGameObject;
		if ((Object)(object)lastSelectedUIObj != (Object)null)
		{
			EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(targetArrowsRef[targetArrows.IndexOf(lastSelectedUIObj)].target.transform, 0.75f)));
			mainTarget = lastSelectedUIObj.GetComponent<UITargetArrow>().target;
			((Component)groundTarget).transform.position = mainTarget.transform.position + new Vector3(0f, 4f, 0f);
			((Behaviour)groundTarget.projector).enabled = true;
			int num = Physics.OverlapCapsuleNonAlloc(mainTarget.transform.position + new Vector3(0f, -10f, 0f), mainTarget.transform.position + new Vector3(0f, 10f, 0f), curRadius, hitResults, layerMask);
			if (num <= 0)
			{
				return;
			}
			ITargetable targetable = null;
			for (int j = 0; j < num; j++)
			{
				targetable = ((Component)hitResults[j]).GetComponent<ITargetable>();
				if (targetable != mainTarget && targetable.IsAlive && validTargets.Contains(targetable) && Vector3.Distance(mainTarget.transform.PositionXZ(), targetable.transform.PositionXZ()) <= curRadius)
				{
					((Component)blinkingArrows[targetable]).gameObject.SetActive(true);
					inRangeTargets.Add(targetable);
				}
			}
		}
		else
		{
			((Behaviour)groundTarget.projector).enabled = false;
		}
	}

	protected override void OnEndTargeting()
	{
		EventMessenger.Instance.RemoveListener<UITargetArrowEvent>(HandleUITargetArrowEvent);
		EventSystem.current.SetSelectedGameObject((GameObject)null);
		ITargetable targetable = null;
		while (targetArrowsRef.Count > 0)
		{
			targetable = targetArrowsRef[targetArrowsRef.Count - 1].target;
			EventMessenger.Instance.Raise(new HealthBarDisplayerHideEvent(targetable));
			ObjectPool.PoolObject(((Component)blinkingArrows[targetable]).gameObject);
			ObjectPool.PoolObject(((Component)targetArrowsRef.Pop()).gameObject);
		}
		blinkingArrows.Clear();
		targetArrows.Clear();
		ObjectPool.PoolObject(((Component)groundTarget).gameObject);
		groundTarget = null;
	}

	private void HandleUITargetArrowEvent(UITargetArrowEvent evt)
	{
		OnTargetsSelected(new List<ITargetable> { mainTarget }.Concat(inRangeTargets));
	}

	public float GetRadius(BaseCharacter caster)
	{
		float num = radius;
		if (caster is GarnetPC && caster.HasPerkUnlocked(4))
		{
			num *= 1.15f;
		}
		return num;
	}

	public override void ResetForReUse()
	{
		EventMessenger.Instance.RemoveListener<UITargetArrowEvent>(HandleUITargetArrowEvent);
		targetArrows.Clear();
		targetArrowsRef.Clear();
		blinkingArrows.Clear();
		groundTarget = null;
		lastSelectedUIObj = null;
		hitResults = new Collider[10];
		mainTarget = null;
		inRangeTargets.Clear();
		base.ResetForReUse();
	}
}
