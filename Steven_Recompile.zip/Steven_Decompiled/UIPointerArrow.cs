using UnityEngine;

public class UIPointerArrow : MonoBehaviour
{
	public static UIPointerArrow instance;

	private Canvas uiCanvas;

	private void Awake()
	{
		instance = this;
	}

	private void OnDestroy()
	{
		instance = null;
	}

	private void Start()
	{
		uiCanvas = ((Component)this).GetComponentInParent<Canvas>();
	}

	public void PointTo(Vector2 targetPos)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).gameObject.SetActive(true);
		((Component)this).transform.localPosition = Vector2.op_Implicit(targetPos);
	}

	public void Hide()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).gameObject.SetActive(false);
		((Component)this).transform.localRotation = Quaternion.Euler(Vector3.zero);
	}
}
