using UnityEngine;

[ExecuteInEditMode]
public class CameraPathTiltList : CameraPathPointList
{
	public enum Interpolation
	{
		None,
		Linear,
		SmoothStep
	}

	public Interpolation interpolation = Interpolation.SmoothStep;

	public bool listEnabled = true;

	public float autoSensitivity = 1f;

	public new CameraPathTilt this[int index] => (CameraPathTilt)base[index];

	private void OnEnable()
	{
		((Object)this).hideFlags = (HideFlags)2;
	}

	public override void Init(CameraPath _cameraPath)
	{
		if (!initialised)
		{
			pointTypeName = "Tilt";
			base.Init(_cameraPath);
			cameraPath.PathPointAddedEvent += AddTilt;
			initialised = true;
		}
	}

	public override void CleanUp()
	{
		base.CleanUp();
		cameraPath.PathPointAddedEvent -= AddTilt;
		initialised = false;
	}

	public void AddTilt(CameraPathControlPoint atPoint)
	{
		CameraPathTilt cameraPathTilt = ((Component)this).gameObject.AddComponent<CameraPathTilt>();
		cameraPathTilt.tilt = 0f;
		((Object)cameraPathTilt).hideFlags = (HideFlags)2;
		AddPoint(cameraPathTilt, atPoint);
		RecalculatePoints();
	}

	public CameraPathTilt AddTilt(CameraPathControlPoint curvePointA, CameraPathControlPoint curvePointB, float curvePercetage, float tilt)
	{
		CameraPathTilt cameraPathTilt = ((Component)this).gameObject.AddComponent<CameraPathTilt>();
		cameraPathTilt.tilt = tilt;
		((Object)cameraPathTilt).hideFlags = (HideFlags)2;
		AddPoint(cameraPathTilt, curvePointA, curvePointB, curvePercetage);
		RecalculatePoints();
		return cameraPathTilt;
	}

	public float GetTilt(float percentage)
	{
		if (realNumberOfPoints < 2)
		{
			if (realNumberOfPoints == 1)
			{
				return this[0].tilt;
			}
			return 0f;
		}
		percentage = Mathf.Clamp(percentage, 0f, 1f);
		switch (interpolation)
		{
		case Interpolation.SmoothStep:
			return SmoothStepInterpolation(percentage);
		case Interpolation.Linear:
			return LinearInterpolation(percentage);
		case Interpolation.None:
		{
			CameraPathTilt cameraPathTilt = (CameraPathTilt)GetPoint(GetNextPointIndex(percentage));
			return cameraPathTilt.tilt;
		}
		default:
			return LinearInterpolation(percentage);
		}
	}

	public void AutoSetTilts()
	{
		for (int i = 0; i < realNumberOfPoints; i++)
		{
			AutoSetTilt(this[i]);
		}
	}

	public void AutoSetTilt(CameraPathTilt point)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		float percent = point.percent;
		Vector3 pathPosition = cameraPath.GetPathPosition(percent - 0.1f);
		Vector3 pathPosition2 = cameraPath.GetPathPosition(percent);
		Vector3 pathPosition3 = cameraPath.GetPathPosition(percent + 0.1f);
		Vector3 val = pathPosition2 - pathPosition;
		Vector3 val2 = pathPosition3 - pathPosition2;
		Quaternion val3 = Quaternion.LookRotation(-cameraPath.GetPathDirection(point.percent));
		Vector3 val4 = val2 - val;
		Vector3 val5 = val3 * val4.normalized;
		float num = Vector2.Angle(Vector2.up, new Vector2(val5.x, val5.y));
		float num2 = Mathf.Min(Mathf.Abs(val5.x) + Mathf.Abs(val5.y) / Mathf.Abs(val5.z), 1f);
		point.tilt = (0f - num) * autoSensitivity * num2;
	}

	private float LinearInterpolation(float percentage)
	{
		int lastPointIndex = GetLastPointIndex(percentage);
		CameraPathTilt cameraPathTilt = (CameraPathTilt)GetPoint(lastPointIndex);
		CameraPathTilt cameraPathTilt2 = (CameraPathTilt)GetPoint(lastPointIndex + 1);
		float percent = cameraPathTilt.percent;
		float num = cameraPathTilt2.percent;
		if (percent > num)
		{
			num++;
		}
		float num2 = num - percent;
		float num3 = percentage - percent;
		float num4 = num3 / num2;
		return Mathf.LerpAngle(cameraPathTilt.tilt, cameraPathTilt2.tilt, num4);
	}

	private float SmoothStepInterpolation(float percentage)
	{
		int lastPointIndex = GetLastPointIndex(percentage);
		CameraPathTilt cameraPathTilt = (CameraPathTilt)GetPoint(lastPointIndex);
		CameraPathTilt cameraPathTilt2 = (CameraPathTilt)GetPoint(lastPointIndex + 1);
		float percent = cameraPathTilt.percent;
		float num = cameraPathTilt2.percent;
		if (percent > num)
		{
			num++;
		}
		float num2 = num - percent;
		float num3 = percentage - percent;
		float val = num3 / num2;
		return Mathf.LerpAngle(cameraPathTilt.tilt, cameraPathTilt2.tilt, CPMath.SmoothStep(val));
	}
}
