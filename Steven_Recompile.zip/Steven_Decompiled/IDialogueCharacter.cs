using UnityEngine;

public interface IDialogueCharacter
{
	string actorName { get; }

	GameObject actorObject { get; }

	Vector3 dialoguePosition { get; }

	tk2dSpriteAnimatorPlus actorAnimator { get; }

	CharacterAnimator actorCharacterAnimator { get; }

	RichAI2D actorRichAI2D { get; }
}
