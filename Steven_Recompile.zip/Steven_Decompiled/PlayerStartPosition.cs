using UnityEngine;

public class PlayerStartPosition : MonoBehaviour
{
	[SerializeField]
	[HideInInspector]
	private int levelUid = -1;

	public int LevelUid => levelUid;
}
