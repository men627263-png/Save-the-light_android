public enum BadgeEffectTimeType
{
	OneTime,
	OverTimeInBattle,
	OverTimeOutOfBattle
}
