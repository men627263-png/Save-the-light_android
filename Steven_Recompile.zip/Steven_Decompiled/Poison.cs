using Grumpyface;
using UnityEngine;

public class Poison : StatusEffect
{
	private int damagePerTick;

	private float secondsPerTick;

	private float duration;

	private bool tickImmediately;

	private float timer;

	private float tickTimer;

	private CharacterTint tint;

	private GameObject particle;

	public override StatusEffectName effectName => StatusEffectName.Poison;

	public override StatusEffectType type => StatusEffectType.Debuff;

	public override bool isPersistent => true;

	public override bool isSavable => true;

	public override bool isResettable => false;

	public override bool isStackable => false;

	public override bool isOwnerValid => true;

	public Poison(ITargetable owner, int damagePerTick, float secondsPerTick, float duration, bool tickImmediately)
		: base(owner)
	{
		this.damagePerTick = damagePerTick;
		this.secondsPerTick = secondsPerTick;
		this.duration = duration;
		this.tickImmediately = tickImmediately;
	}

	protected override void InitEffect()
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		timer = duration;
		tickTimer = ((!tickImmediately) ? secondsPerTick : 0f);
		particle = ObjectPool.GetObject(GameResources.instance.gameSettings.poisonParticlePrefab);
		if ((Object)(object)particle != (Object)null)
		{
			particle.transform.position = owner.CenterTopPosition;
			particle.transform.SetParent(owner.transform, true);
		}
		tint = new CharacterTint(CharacterTint.Type.Static, GameResources.instance.gameSettings.poisonTintColor);
		if ((Object)(object)owner.TargetableTinter != (Object)null)
		{
			owner.TargetableTinter.AddTint(tint);
		}
	}

	protected override void UpdateEffect()
	{
		tickTimer -= Time.deltaTime;
		if (tickTimer <= 0f)
		{
			BattleHelper.DoDamage(null, owner.damageReceiver, new DamageInfo(DamageInfo.ValueType.FlatAmount, damagePerTick, CombatType.None), allowDeath: true);
			tickTimer += secondsPerTick;
		}
		timer -= Time.deltaTime;
		if (timer <= 0f)
		{
			Remove();
		}
	}

	protected override void ResetEffect()
	{
	}

	protected override void RemoveEffect()
	{
		if ((Object)(object)particle != (Object)null)
		{
			ObjectPool.PoolObject(particle);
			particle = null;
		}
		if ((Object)(object)owner.TargetableTinter != (Object)null)
		{
			owner.TargetableTinter.RemoveTint(tint);
		}
	}

	protected override void CleanUp()
	{
		owner = null;
		tint = null;
	}

	protected override void InitSaveData(StatusEffectSaveData saveData)
	{
		saveData.startingData.intValue1 = damagePerTick;
		saveData.startingData.floatValue1 = duration;
		saveData.startingData.floatValue2 = secondsPerTick;
		saveData.startingData.boolValue1 = tickImmediately;
		saveData.data.intValue1 = damagePerTick;
		saveData.data.floatValue1 = timer;
		saveData.data.floatValue2 = tickTimer;
		saveData.data.boolValue1 = false;
	}

	public sealed override void LoadSaveData(StatusEffectData data)
	{
		timer = data.floatValue1;
		tickTimer = data.floatValue2;
	}
}
