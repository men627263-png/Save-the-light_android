using UnityEngine;
using UnityEngine.UI;

public class VideoController : MonoBehaviour
{
	[SerializeField]
	private string[] moviePaths;

	[SerializeField]
	private RawImage uiRawImage;

	[SerializeField]
	private UIAutoSaveScreen autoSaveScreen;

	private bool waitingToLoadGameData;

	private bool loadingComplete;

	private bool savingComplete;
}
