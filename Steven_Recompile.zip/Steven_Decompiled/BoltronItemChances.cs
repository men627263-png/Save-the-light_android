using System;

[Serializable]
public struct BoltronItemChances
{
	public string itemName;

	public int itemUID;

	public int itemChanceWeight;
}
