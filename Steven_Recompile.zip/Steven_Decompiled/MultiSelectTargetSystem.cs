using System;
using System.Collections.Generic;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Grumpyface;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

[CreateAssetMenu(menuName = "Save the Light/Target Systems/Multi Select")]
public class MultiSelectTargetSystem : BattleTargetSystem
{
	public UITargetArrow targetArrowPrefab;

	public DelayedAudioEvent targetSelectSound;

	public TextMeshProUGUI selectionsRemainingTextPrefab;

	public int maxNumSelections = 2;

	[NonSerialized]
	protected List<GameObject> targetArrows = new List<GameObject>();

	[NonSerialized]
	protected List<UITargetArrow> targetArrowsRef = new List<UITargetArrow>();

	[NonSerialized]
	protected GameObject lastSelectedUIObj;

	[NonSerialized]
	protected TextMeshProUGUI selectionsRemainingText;

	[NonSerialized]
	private List<ITargetable> selectedTargets = new List<ITargetable>();

	[NonSerialized]
	private int numSelectionsRemaining;

	private int NumSelectionsRemaining
	{
		get
		{
			return numSelectionsRemaining;
		}
		set
		{
			numSelectionsRemaining = value;
			selectionsRemainingText.text = "Selections Remaining\n" + numSelectionsRemaining;
		}
	}

	public override ITargetable lastSelected => (!((Object)(object)lastSelectedUIObj != (Object)null)) ? null : lastSelectedUIObj.GetComponent<UITargetArrow>().target;

	public sealed override bool canExit => selectedTargets.Count == 0;

	protected override void OnDisable()
	{
		base.OnDisable();
		if (targetArrows != null)
		{
			targetArrows.Clear();
		}
		else
		{
			targetArrows = new List<GameObject>();
		}
		if (targetArrowsRef != null)
		{
			targetArrowsRef.Clear();
		}
		else
		{
			targetArrowsRef = new List<UITargetArrow>();
		}
		if (selectedTargets != null)
		{
			selectedTargets.Clear();
		}
		else
		{
			selectedTargets = new List<ITargetable>();
		}
		lastSelectedUIObj = null;
	}

	protected sealed override void OnStartTargeting(BaseCharacter caster, AbilityTargetType targetType, bool canTargetNonCharacters, ITargetable initialTarget = null)
	{
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		UITargetArrow uITargetArrow = null;
		ITargetable targetable = null;
		UITargetArrow uITargetArrow2 = null;
		targetArrows.Clear();
		targetArrowsRef.Clear();
		selectedTargets.Clear();
		int count = validTargets.Count;
		for (int i = 0; i < count; i++)
		{
			targetable = validTargets[i];
			if (!targetable.IsDead || targetType == AbilityTargetType.SingleDeadFriendlyPlusSelf)
			{
				Color white = Color.white;
				uITargetArrow = ObjectPool.GetObject<UITargetArrow>(((Component)targetArrowPrefab).gameObject, default(Vector3), true);
				GameUI.instance.AddElementToLayer(uITargetArrow.rectTransform, GameUI.instance.characterLayer);
				uITargetArrow.Init(targetable, controller.uiCanvas, white);
				((Component)uITargetArrow).gameObject.SetActive(true);
				targetArrows.Add(((Component)uITargetArrow).gameObject);
				targetArrowsRef.Add(uITargetArrow);
				if (uITargetArrow.target == initialTarget && (!initialTarget.IsDead || targetType == AbilityTargetType.SingleDeadFriendlyPlusSelf))
				{
					uITargetArrow2 = uITargetArrow;
				}
				EventMessenger.Instance.Raise(new HealthBarDisplayerShowEvent(targetable));
			}
		}
		selectionsRemainingText = ObjectPool.GetObject<TextMeshProUGUI>(((Component)selectionsRemainingTextPrefab).gameObject, default(Vector3), true);
		selectionsRemainingText.transform.parent = ((Component)GameController.Instance.uiCanvas).transform;
		selectionsRemainingText.rectTransform.anchoredPosition3D = new Vector3(0f, -230f);
		NumSelectionsRemaining = Mathf.Min(targetArrows.Count, maxNumSelections);
		EventSystem.current.SetSelectedGameObject((!((Object)(object)uITargetArrow2 != (Object)null)) ? targetArrows[0] : ((Component)uITargetArrow2).gameObject);
		EventMessenger.Instance.AddListener<UITargetArrowEvent>(HandleUITargetArrowEvent);
		lastSelectedUIObj = null;
	}

	protected sealed override void OnUpdateTargeting()
	{
		if (player.GetButtonDown("UICancel") && selectedTargets.Count > 0)
		{
			ITargetable previousTarget = selectedTargets.Pop();
			NumSelectionsRemaining++;
			DOTween.Kill((object)("redTintFlash" + selectedTargets.Count), false);
			EventSystem.current.SetSelectedGameObject(targetArrows[targetArrowsRef.FindIndex((UITargetArrow x) => x.target == previousTarget)]);
		}
		if ((Object)(object)EventSystem.current == (Object)(object)controller.gameEventSystem && (Object)(object)lastSelectedUIObj != (Object)(object)EventSystem.current.currentSelectedGameObject)
		{
			if ((Object)(object)lastSelectedUIObj != (Object)null)
			{
				EventMessenger.Instance.Raise(new RemoveCameraInfluenceEvent(targetArrowsRef[targetArrows.IndexOf(lastSelectedUIObj)].target.transform));
			}
			lastSelectedUIObj = EventSystem.current.currentSelectedGameObject;
			targetSelectSound.Play();
			EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(targetArrowsRef[targetArrows.IndexOf(lastSelectedUIObj)].target.transform, 0.75f)));
		}
	}

	protected sealed override void OnEndTargeting()
	{
		EventMessenger.Instance.RemoveListener<UITargetArrowEvent>(HandleUITargetArrowEvent);
		EventSystem.current.SetSelectedGameObject((GameObject)null);
		if ((Object)(object)lastSelectedUIObj != (Object)null)
		{
			EventMessenger.Instance.Raise(new RemoveCameraInfluenceEvent(targetArrowsRef[targetArrows.IndexOf(lastSelectedUIObj)].target.transform));
		}
		while (targetArrowsRef.Count > 0)
		{
			EventMessenger.Instance.Raise(new HealthBarDisplayerHideEvent(targetArrowsRef[targetArrowsRef.Count - 1].target));
			ObjectPool.PoolObject(((Component)targetArrowsRef.Pop()).gameObject);
			if (targetArrowsRef.Count < selectedTargets.Count)
			{
				DOTween.Kill((object)("redTintFlash" + targetArrowsRef.Count), false);
			}
		}
		targetArrows.Clear();
		ObjectPool.PoolObject(((Component)selectionsRemainingText).gameObject);
		selectionsRemainingText = null;
	}

	protected void HandleUITargetArrowEvent(UITargetArrowEvent evt)
	{
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Expected Obj, but got Unknown
		ITargetable targetCharacter = evt.arrow.target;
		int num = selectedTargets.IndexOf(targetCharacter);
		if (num > -1)
		{
			DOTween.Kill((object)("redTintFlash" + num), false);
			selectedTargets.RemoveAt(num);
			NumSelectionsRemaining++;
		}
		else
		{
			Color originalColor = targetCharacter.TintColor;
			Color val = ((!(targetCharacter is PlayerCharacter)) ? new Color(1f, 0f, 0f, 0.5f) : new Color(0f, 1f, 0f, 0.5f));
			TweenSettingsExtensions.OnKill<TweenerCore<Color, Color, ColorOptions>>(TweenSettingsExtensions.SetId<TweenerCore<Color, Color, ColorOptions>>(TweenSettingsExtensions.SetLoops<TweenerCore<Color, Color, ColorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Color, Color, ColorOptions>>(DOTween.To((DOGetter<Color>)(() =>
			{
				//IL_000b: Unknown result type (might be due to invalid IL or missing references)
				return targetCharacter.TintColor;
			}), (DOSetter<Color>)((Color x) =>
			{
				//IL_000b: Unknown result type (might be due to invalid IL or missing references)
				targetCharacter.TintColor = x;
			}), val, 0.1f), (Ease)1), -1, (LoopType)1), (object)("redTintFlash" + selectedTargets.Count)), (TweenCallback)(() =>
			{
				//IL_0017: Unknown result type (might be due to invalid IL or missing references)
				HandleOnFlashKilled(targetCharacter, originalColor);
			}));
			selectedTargets.Add(targetCharacter);
			NumSelectionsRemaining--;
		}
		if (NumSelectionsRemaining <= 0)
		{
			OnTargetsSelected(new List<ITargetable>(selectedTargets));
		}
	}

	private void HandleOnFlashKilled(ITargetable character, Color originalColor)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		character.TintColor = originalColor;
	}

	public override void ResetForReUse()
	{
		EventMessenger.Instance.RemoveListener<UITargetArrowEvent>(HandleUITargetArrowEvent);
		targetArrows.Clear();
		targetArrowsRef.Clear();
		lastSelectedUIObj = null;
		selectionsRemainingText = null;
		selectedTargets.Clear();
		base.ResetForReUse();
	}
}
