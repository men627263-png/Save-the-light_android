using System;
using UnityEngine;

[Serializable]
public class SurfaceData
{
	public SurfaceType surfaceType;

	public DelayedAudioEvent footstepSound;

	public Material footstepDecalMat;

	public GameObject specialEffectObj;

	public bool allowFootstepDecals = true;
}
