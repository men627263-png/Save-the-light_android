using System.Collections.Generic;
using UnityEngine;

public class AchievementsDatabase : ScriptableObject
{
	public List<STLAchievement> achievements;

	public STLAchievement GetAchievement(int id)
	{
		return achievements.Find((STLAchievement x) => x.id == id);
	}

	public STLAchievement GetAchievement(string stringID)
	{
		return achievements.Find((STLAchievement x) => x.achievementName.key == stringID);
	}
}
