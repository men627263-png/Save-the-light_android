using System;

[Serializable]
public class ShopItem
{
	public string guid;

	public bool isUnique;

	public bool gameEventRequired;

	public int gameEventUID;

	public GamePlayEventState gameEventState = GamePlayEventState.Complete;

	public int itemUID;

	public int itemCount = 1;

	public int itemBundleDiscount;

	public bool backupItemAvailable;

	public int backupItemType;

	public int backupItemUID;

	public int backupItemCount = 1;

	public int backupItemBundleDiscount;

	public bool foldout = true;
}
