using System;
using System.Collections.Generic;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Grumpyface;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Target Systems/Growing Radial")]
public class GrowingRadialTargetSystem : BattleTargetSystem
{
	public GroundTarget groundTargetPrefab;

	public GroundTarget innerProjectionPrefab;

	public GroundTarget outerProjectionPrefab;

	public float startRadius;

	public float endRadius;

	public float growTime = 1f;

	public Ease growEase = (Ease)8;

	public float fadeTime = 0.5f;

	public int holdFramesAtMax = 2;

	public DelayedAudioEvent targettingSound;

	[NonSerialized]
	private BaseCharacter caster;

	[NonSerialized]
	private GroundTarget groundTarget;

	[NonSerialized]
	private GroundTarget innerProjection;

	[NonSerialized]
	private GroundTarget outerProjection;

	[NonSerialized]
	private Tweener groundTargetTween;

	[NonSerialized]
	private Collider[] hitResults = new Collider[10];

	[NonSerialized]
	private int layerMask;

	[NonSerialized]
	private bool inputDelay;

	[NonSerialized]
	private bool targetStopped;

	[NonSerialized]
	private int holdFrameCount;

	[NonSerialized]
	private bool didCommit;

	private float _lastRadius;

	public override ITargetable lastSelected => null;

	public sealed override bool canExit => !didCommit;

	public float LastRadius => _lastRadius;

	public GrowingRadialTargetSystem()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
	}

	protected override void OnDisable()
	{
		base.OnDisable();
		caster = null;
		groundTarget = null;
		groundTargetTween = null;
	}

	protected override void OnStartTargeting(BaseCharacter caster, AbilityTargetType targetType, bool canTargetNonCharacters, ITargetable initialTarget = null)
	{
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		this.caster = caster;
		didCommit = false;
		int num = 1 << LayerMask.NameToLayer("Player");
		int num2 = 1 << LayerMask.NameToLayer("Enemy");
		layerMask = 0;
		switch (targetType)
		{
		case AbilityTargetType.All:
		case AbilityTargetType.SingleAll:
			layerMask = num | num2;
			break;
		case AbilityTargetType.SingleFriendly:
		case AbilityTargetType.AllFriendly:
		case AbilityTargetType.AllFriendlyPlusSelf:
		case AbilityTargetType.SingleFriendlyPlusSelf:
			layerMask = ((!(((Component)caster).tag == "Player")) ? num2 : num);
			break;
		case AbilityTargetType.SingleEnemy:
		case AbilityTargetType.AllEnemies:
			layerMask = ((!(((Component)caster).tag == "Player")) ? num : num2);
			break;
		}
		groundTarget = ObjectPool.GetObject<GroundTarget>(((Component)groundTargetPrefab).gameObject, default(Vector3), true);
		groundTarget.projector.orthographicSize = startRadius;
		((Component)groundTarget).transform.position = ((Component)caster).transform.position + new Vector3(0f, 4f, 0f);
		if ((Object)(object)innerProjectionPrefab != (Object)null)
		{
			innerProjection = ObjectPool.GetObject<GroundTarget>(((Component)innerProjectionPrefab).gameObject, default(Vector3), true);
			innerProjection.projector.orthographicSize = startRadius;
			((Component)innerProjection).transform.position = ((Component)caster).transform.position + new Vector3(0f, 4f, 0f);
		}
		if ((Object)(object)outerProjectionPrefab != (Object)null)
		{
			outerProjection = ObjectPool.GetObject<GroundTarget>(((Component)outerProjectionPrefab).gameObject, default(Vector3), true);
			outerProjection.projector.orthographicSize = endRadius;
			((Component)outerProjection).transform.position = ((Component)caster).transform.position + new Vector3(0f, 4f, 0f);
		}
		groundTargetTween = (Tweener)(object)TweenSettingsExtensions.SetAutoKill<TweenerCore<float, float, FloatOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<float, float, FloatOptions>>(DOTween.To((DOGetter<float>)(() => groundTarget.projector.orthographicSize), (DOSetter<float>)((float x) =>
		{
			groundTarget.projector.orthographicSize = x;
		}), endRadius, growTime), (Ease)8), false);
		holdFrameCount = holdFramesAtMax;
		inputDelay = true;
		targetStopped = false;
		if ((Object)(object)targettingSound.audioEvent != (Object)null)
		{
			targettingSound.Play();
		}
	}

	protected override void OnUpdateTargeting()
	{
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Expected Obj, but got Unknown
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		if (targetStopped)
		{
			return;
		}
		if (!inputDelay && player.GetButtonDown("UISubmit"))
		{
			didCommit = true;
			_lastRadius = groundTarget.projector.orthographicSize;
			bool flag = TweenExtensions.IsComplete((Tween)(object)groundTargetTween);
			TweenExtensions.Kill((Tween)(object)groundTargetTween, false);
			groundTargetTween = null;
			List<ITargetable> inRangeTargets = new List<ITargetable>();
			int num = Physics.OverlapCapsuleNonAlloc(((Component)caster).transform.position + new Vector3(0f, -10f, 0f), ((Component)caster).transform.position + new Vector3(0f, 10f, 0f), _lastRadius, hitResults, layerMask);
			if (num > 0)
			{
				ITargetable targetable = null;
				for (int i = 0; i < num; i++)
				{
					targetable = ((Component)hitResults[i]).GetComponent<ITargetable>();
					if (targetable != null && !object.ReferenceEquals(targetable, caster) && targetable.IsAlive && validTargets.Contains(targetable) && Vector3.Distance(caster.positionXZ, targetable.transform.PositionXZ()) <= _lastRadius)
					{
						inRangeTargets.Add(targetable);
					}
				}
			}
			if (flag)
			{
				TweenSettingsExtensions.SetLoops<Tweener>(ShortcutExtensions.DOColor(outerProjection.materialInst, new Color(1f, 18f / 255f, 180f / 255f), 0.1f), 10, (LoopType)1);
			}
			TweenSettingsExtensions.OnComplete<Tweener>(TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOFade(groundTarget.materialInst, 0f, fadeTime), (Ease)2), (TweenCallback)(() =>
			{
				OnTargetsSelected(inRangeTargets);
			}));
			targetStopped = true;
			return;
		}
		inputDelay = false;
		if (TweenExtensions.IsComplete((Tween)(object)groundTargetTween))
		{
			holdFrameCount--;
			if (holdFrameCount <= 0)
			{
				TweenExtensions.Restart((Tween)(object)groundTargetTween, true);
				holdFrameCount = holdFramesAtMax;
			}
		}
	}

	protected override void OnEndTargeting()
	{
		if (groundTargetTween != null)
		{
			TweenExtensions.Kill((Tween)(object)groundTargetTween, false);
			groundTargetTween = null;
		}
		ObjectPool.PoolObject(((Component)groundTarget).gameObject);
		groundTarget = null;
		if ((Object)(object)innerProjection != (Object)null)
		{
			ObjectPool.PoolObject(((Component)innerProjection).gameObject);
			innerProjection = null;
		}
		if ((Object)(object)outerProjection != (Object)null)
		{
			ObjectPool.PoolObject(((Component)outerProjection).gameObject);
			outerProjection = null;
		}
	}

	public override void ResetForReUse()
	{
		caster = null;
		groundTarget = null;
		innerProjection = null;
		outerProjection = null;
		groundTargetTween = null;
		hitResults = new Collider[10];
		base.ResetForReUse();
	}
}
