using System;
using System.Collections.Generic;
using Grumpyface;
using UnityEngine;

public abstract class LilWizShockwave : MonoBehaviour, IPoolable
{
	[Serializable]
	public struct ShockwaveData
	{
		public float minDistance;

		public float maxDistance;

		public float minValue;

		public float maxValue;
	}

	[SerializeField]
	private MeshRenderer outerMesh;

	[SerializeField]
	private Animator animator;

	[SerializeField]
	private AnimatorEventListener animatorEventListener;

	[SerializeField]
	private float animatorSpeed;

	protected BaseCharacter source;

	protected List<ITargetable> possibleTargets;

	protected ShockwaveData shockwaveData;

	protected BaseAbility ability;

	private bool isPaused;

	private void OnEnable()
	{
		animatorEventListener.EventTriggered += HandleEventTriggered;
	}

	private void OnDisable()
	{
		animatorEventListener.EventTriggered -= HandleEventTriggered;
	}

	private void Update()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		if (isPaused)
		{
			return;
		}
		Bounds bounds = ((Renderer)outerMesh).bounds;
		float x = bounds.extents.x;
		int num = possibleTargets.Count - 1;
		ITargetable targetable = null;
		for (int num2 = num; num2 >= 0; num2--)
		{
			targetable = possibleTargets[num2];
			if (!targetable.IsDead)
			{
				float num3 = Vector3.Distance(((Component)this).transform.position, targetable.transform.position);
				if (num3 <= x)
				{
					possibleTargets.RemoveAt(num2);
					OnTargetReached(targetable, Mathf.Clamp01((num3 - shockwaveData.minDistance) / (shockwaveData.maxDistance - shockwaveData.minDistance)));
				}
			}
		}
	}

	public void Init(BaseCharacter source, List<ITargetable> possibleTargets, ShockwaveData shockwaveData, BaseAbility ability)
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		this.source = source;
		this.possibleTargets = new List<ITargetable>(possibleTargets);
		this.shockwaveData = shockwaveData;
		this.ability = ability;
		((Component)this).transform.position = ((Component)source).transform.position;
		((Component)this).transform.localScale = Vector3.one * (shockwaveData.maxDistance / 10f);
		animator.speed = animatorSpeed;
		EventMessenger.Instance.AddListener<BattleWaitingEvent>(HandleBattleWaitingEvent);
		isPaused = (GameControllerState)(object)GameController.Instance.CurrentState != GameControllerState.Battle_Waiting;
		EventMessenger.Instance.AddListener<BattleFinishedEvent>(HandleBattleFinishedEvent);
		EventMessenger.Instance.AddListener<EnemyDiedEvent>(HandleEnemyDiedEvent);
		EventMessenger.Instance.AddListener<AddEnemyToBattleEvent>(HandleAddEnemyToBattleEvent);
	}

	private void HandleBattleWaitingEvent(BattleWaitingEvent evt)
	{
		isPaused = !evt.didEnter;
		if ((Object)(object)animator != (Object)null)
		{
			animator.speed = ((!isPaused) ? animatorSpeed : 0f);
		}
	}

	private void HandleBattleFinishedEvent(BattleFinishedEvent evt)
	{
		EventMessenger.Instance.RemoveListener<BattleFinishedEvent>(HandleBattleFinishedEvent);
		ObjectPool.PoolObject(((Component)this).gameObject);
	}

	private void HandleEnemyDiedEvent(EnemyDiedEvent evt)
	{
		if (possibleTargets.Contains(evt.deadEnemy))
		{
			possibleTargets.Remove(evt.deadEnemy);
		}
	}

	private void HandleAddEnemyToBattleEvent(AddEnemyToBattleEvent evt)
	{
		if (ability.targetType == AbilityTargetType.AllEnemies)
		{
			possibleTargets.Add(evt.enemy);
		}
	}

	private void HandleEventTriggered(AnimationEvent evt)
	{
		if (evt.stringParameter == "complete")
		{
			ObjectPool.PoolObject(((Component)this).gameObject);
		}
	}

	protected abstract void OnTargetReached(ITargetable target, float progress);

	public void ResetObject()
	{
		EventMessenger.Instance.RemoveListener<BattleWaitingEvent>(HandleBattleWaitingEvent);
		EventMessenger.Instance.RemoveListener<BattleFinishedEvent>(HandleBattleFinishedEvent);
		EventMessenger.Instance.RemoveListener<EnemyDiedEvent>(HandleEnemyDiedEvent);
		EventMessenger.Instance.RemoveListener<AddEnemyToBattleEvent>(HandleAddEnemyToBattleEvent);
		source = null;
		possibleTargets = null;
		ability = null;
	}
}
