using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Grumpyface;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Abilities/Bosses/Light Warrior/Ice Ball")]
public class LightWarrior_IceBallAbility : BaseAbility
{
	[Serializable]
	private class AbilityData
	{
		[Header("Prefabs")]
		public GameObject iceBallPrefab;

		[Header("Animations")]
		public CharacterAnimationNamePair chargeIntroAnim = default;

		public CharacterAnimationNamePair chargeLoopAnim = default;

		public CharacterAnimationNamePair chargeOutroAnim = default;

		public CharacterAnimationNamePair deflect1Anim = default;

		public CharacterAnimationNamePair deflect2Anim = default;

		public CharacterAnimationNamePair hitAnim = default;

		[Header("Tweakables")]
		public float ballSmoothTime = 0.1f;

		public float ballChargeDuration = 1f;

		public float ballSpeedStart = 8f;

		public float ballSpeedIncreaseOnDeflect = 3f;

		[MinMaxRange(1, 20)]
		public RangedInt numDeflectionsToHit = new RangedInt(3, 4);

		public DamageInfo targetDamage;

		public DamageInfo selfDamage;

		[Header("Sounds")]
		public DelayedAudioEvent shootSound = default;

		public DelayedAudioEvent deflectSound = default;

		public DelayedAudioEvent hitSound = default;

		[Header("Visual/Force Feedback")]
		public VibrationManager.Vibration deflectVibration = new VibrationManager.Vibration(0.2f, 0.2f);

		public ScreenShakeData deflectShake = default;

		public float ballCameraInfluenceAmount = 0.1f;

		public Vector3 laughCameraInfluenceAmount = new Vector3(1f, 0.5f, 1f);

		public float laughCameraZoom = 1.35f;

		public AbilityData()
		{
			//IL_0102: Unknown result type (might be due to invalid IL or missing references)
			//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		}
	}

	[SerializeField]
	private BonusStarData bonusStarData;

	[SerializeField]
	private AbilityData abilityData;

	[NonSerialized]
	private LightWarrior lightWarrior;

	[NonSerialized]
	private SquareidotShip_IceBall iceBall;

	[NonSerialized]
	private Vector3 iceBallVelocity;

	[NonSerialized]
	private BaseCharacter target;

	[NonSerialized]
	private BaseCharacter finalTarget;

	[NonSerialized]
	private bool followHand;

	[NonSerialized]
	private bool ballSequenceFinished;

	protected override void OnInit()
	{
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		base.OnInit();
		lightWarrior = (LightWarrior)caster;
		lightWarrior.animatorEventListener.EventTriggered += HandleEventTriggered;
		target = (BaseCharacter)targets[0];
		finalTarget = null;
		followHand = false;
		ballSequenceFinished = false;
		iceBallVelocity = Vector3.zero;
	}

	public override IEnumerator Play()
	{
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)caster).transform, 1.5f)));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(lightWarrior.characterProperties.ballSpawnPosition, abilityData.ballCameraInfluenceAmount)));
		EventMessenger.Instance.Raise(new CameraZoomEvent(1.3f));
		lightWarrior.PlayAnim(abilityData.chargeIntroAnim, clearQueue: true);
		lightWarrior.AddAnimToQueue(abilityData.chargeLoopAnim);
		yield return (object)new WaitWhile((Func<bool>)(() => (Object)(object)iceBall == (Object)null));
		abilityData.shootSound.Play(((Component)caster).transform.position);
		yield return TweenExtensions.WaitForCompletion((Tween)(object)TweenSettingsExtensions.SetEase<TweenerCore<float, float, FloatOptions>>(DOTween.To((DOGetter<float>)(() => iceBall.scale), (DOSetter<float>)((float x) =>
		{
			iceBall.scale = x;
		}), 1f, abilityData.ballChargeDuration), (Ease)1));
		lightWarrior.PlayAnim(abilityData.chargeOutroAnim);
		lightWarrior.AddAnimToQueue(lightWarrior.GetIdleAnimation());
		yield return (object)new WaitUntil((Func<bool>)(() => ballSequenceFinished));
	}

	public override IEnumerator Cancel()
	{
		yield break;
	}

	protected override void OnUpdate()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		base.OnUpdate();
		if ((Object)(object)iceBall != (Object)null && followHand)
		{
			((Component)iceBall).transform.position = Vector3.SmoothDamp(((Component)iceBall).transform.position, lightWarrior.characterProperties.ballSpawnPosition.position, ref iceBallVelocity, abilityData.ballSmoothTime);
		}
	}

	protected sealed override void OnCleanUp()
	{
		base.OnCleanUp();
		if ((Object)(object)iceBall != (Object)null)
		{
			ObjectPool.PoolObject(((Component)iceBall).gameObject);
			iceBall = null;
		}
		lightWarrior.animatorEventListener.EventTriggered -= HandleEventTriggered;
		lightWarrior = null;
	}

	public override void ResetForReUse()
	{
		if ((Object)(object)lightWarrior != (Object)null)
		{
			lightWarrior.animatorEventListener.EventTriggered -= HandleEventTriggered;
			lightWarrior = null;
		}
		iceBall = null;
		target = null;
		finalTarget = null;
		base.ResetForReUse();
	}

	private void HandleEventTriggered(AnimationEvent evt)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		switch (evt.stringParameter)
		{
		case "spawnBall":
			iceBall = ObjectPool.GetObject<SquareidotShip_IceBall>(abilityData.iceBallPrefab, default(Vector3), true);
			((Component)iceBall).transform.position = lightWarrior.characterProperties.ballSpawnPosition.position;
			iceBall.scale = 0f;
			followHand = true;
			EventMessenger.Instance.Raise(new RemoveCameraInfluenceEvent(lightWarrior.characterProperties.ballSpawnPosition));
			EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)iceBall).transform, abilityData.ballCameraInfluenceAmount)));
			break;
		case "launchBall":
			EventMessenger.Instance.Raise(new RemoveCameraInfluenceEvent(((Component)caster).transform));
			EventMessenger.Instance.Raise(new CameraZoomEvent(1f));
			((MonoBehaviour)caster).StartCoroutine(BallSequence());
			break;
		}
	}

	private IEnumerator BallSequence()
	{
		followHand = false;
		float ballSpeed = abilityData.ballSpeedStart;
		int deflectCount = 0;
		int maxDeflectCount = Random.Range(abilityData.numDeflectionsToHit.minValue, abilityData.numDeflectionsToHit.maxValue + 1);
		finalTarget = null;
		Tweener ballTween = null;
		while ((Object)(object)finalTarget == (Object)null)
		{
			if (ballTween != null)
			{
				TweenExtensions.Kill((Tween)(object)ballTween, false);
			}
			if (targets.Count > 1)
			{
				target = (BaseCharacter)targets[Random.Range(0, targets.Count)];
			}
			ballTween = TweenSettingsExtensions.SetEase<Tweener>(TweenSettingsExtensions.SetSpeedBased<Tweener>(ShortcutExtensions.DOMove(((Component)iceBall).transform, target.CenterPosition, ballSpeed, false)), (Ease)1);
			TweenExtensions.ForceInit((Tween)(object)ballTween);
			StarBonusCheck starBonus = StartBonusCheck(Time.time + TweenExtensions.Duration((Tween)(object)ballTween, true), bonusStarData, new List<ITargetable> { target });
			yield return TweenExtensions.WaitForCompletion((Tween)(object)ballTween);
			LastFrameBonusCheck(starBonus);
			if (starBonus.isBonusSuccess)
			{
				deflectCount++;
				if (starBonus.StarBonusType == AbilityStarBonusType.Perfect)
				{
					target.characterSounds.perfectBlockSound.Play(((Component)target).transform.position);
				}
				else
				{
					target.characterSounds.blockSound.Play(((Component)target).transform.position);
				}
				target.PlayAnimFromFrame(target.animationNames.block, 0, clearQueue: true);
				target.AddAnimToQueue(target.GetIdleAnimation());
				EventMessenger.Instance.Raise(new VibrationEvent(abilityData.deflectVibration));
				EventMessenger.Instance.Raise(new ScreenShakeEvent(abilityData.deflectShake));
				abilityData.deflectSound.Play(((Component)iceBall).transform.position);
				if (deflectCount < maxDeflectCount)
				{
					CharacterAnimationNamePair deflectAnim = ((!(Random.value <= 0.5f)) ? abilityData.deflect2Anim : abilityData.deflect1Anim);
					Transform deflectPosition = ((!(deflectAnim == abilityData.deflect1Anim)) ? lightWarrior.characterProperties.deflectBallPosition2 : lightWarrior.characterProperties.deflectBallPosition1);
					ballTween = TweenSettingsExtensions.SetEase<Tweener>(TweenSettingsExtensions.SetSpeedBased<Tweener>(ShortcutExtensions.DOMove(((Component)iceBall).transform, deflectPosition.position, ballSpeed, false)), (Ease)1);
					TweenExtensions.ForceInit((Tween)(object)ballTween);
					AnimationClip clip = lightWarrior.animator.GetClip(deflectAnim.frontName);
					AnimationEvent deflectEvent = null;
					for (int i = 0; i < clip.events.Length; i++)
					{
						if (clip.events[i].stringParameter.Equals("deflect"))
						{
							deflectEvent = clip.events[i];
							break;
						}
					}
					float playTime = Time.time + TweenExtensions.Duration((Tween)(object)ballTween, true) - deflectEvent.time;
					float deflectTime = playTime + deflectEvent.time;
					if (playTime > Time.time)
					{
						yield return (object)new WaitUntil((Func<bool>)(() => Time.time >= playTime));
						lightWarrior.PlayAnimFrom(deflectAnim, 0f, clearQueue: true);
						lightWarrior.AddAnimToQueue(lightWarrior.GetIdleAnimation());
					}
					else
					{
						float num = deflectEvent.time + (playTime - Time.time);
						lightWarrior.animator.speed = deflectEvent.time / num;
						lightWarrior.PlayAnimFrom(deflectAnim, 0f, clearQueue: true);
						lightWarrior.AddAnimToQueue(lightWarrior.GetIdleAnimation());
					}
					yield return (object)new WaitUntil((Func<bool>)(() => Time.time >= deflectTime));
					abilityData.deflectSound.Play(((Component)iceBall).transform.position);
					lightWarrior.animator.speed = 1f;
					ballSpeed += abilityData.ballSpeedIncreaseOnDeflect;
					continue;
				}
				finalTarget = caster;
				CharacterAnimationNamePair deflectAnim2 = ((!(Random.value <= 0.5f)) ? abilityData.deflect2Anim : abilityData.deflect1Anim);
				Transform deflectPosition2 = ((!(deflectAnim2 == abilityData.deflect1Anim)) ? lightWarrior.characterProperties.deflectBallPosition2 : lightWarrior.characterProperties.deflectBallPosition1);
				float distanceToTarget = Vector3.Distance(((Component)iceBall).transform.position, lightWarrior.CenterPosition);
				float distanceToDeflectPosition = Vector3.Distance(((Component)iceBall).transform.position, deflectPosition2.position);
				float distanceRatio = distanceToDeflectPosition / distanceToTarget;
				ballTween = TweenSettingsExtensions.SetEase<Tweener>(TweenSettingsExtensions.SetSpeedBased<Tweener>(ShortcutExtensions.DOMove(((Component)iceBall).transform, lightWarrior.CenterPosition, ballSpeed, false)), (Ease)1);
				TweenExtensions.ForceInit((Tween)(object)ballTween);
				AnimationClip clip2 = lightWarrior.animator.GetClip(deflectAnim2.frontName);
				AnimationEvent deflectEvent2 = null;
				for (int num2 = 0; num2 < clip2.events.Length; num2++)
				{
					if (clip2.events[num2].stringParameter.Equals("deflect"))
					{
						deflectEvent2 = clip2.events[num2];
						break;
					}
				}
				float playTime2 = Time.time + TweenExtensions.Duration((Tween)(object)ballTween, true) * distanceRatio - deflectEvent2.time;
				yield return (object)new WaitUntil((Func<bool>)(() => Time.time >= playTime2));
				lightWarrior.PlayAnimFrom(deflectAnim2, 0f, clearQueue: true);
				lightWarrior.AddAnimToQueue(lightWarrior.GetIdleAnimation());
				yield return TweenExtensions.WaitForCompletion((Tween)(object)ballTween);
			}
			else
			{
				finalTarget = target;
			}
		}
		EventMessenger.Instance.Raise(new RemoveCameraInfluenceEvent(((Component)iceBall).transform));
		ObjectPool.PoolObject(((Component)iceBall).gameObject);
		iceBall = null;
		abilityData.hitSound.Play(((Component)finalTarget).transform.position);
		if ((Object)(object)finalTarget == (Object)(object)target)
		{
			BattleHelper.DoDamage(caster, finalTarget.damageReceiver, abilityData.targetDamage, allowDeath: true, this);
			yield return (object)new WaitForSeconds(0.5f);
		}
		else
		{
			BattleHelper.DoDamage(caster, lightWarrior.damageReceiver, abilityData.selfDamage, allowDeath: true, this);
			lightWarrior.PlayAnim(abilityData.hitAnim, clearQueue: true);
			if (lightWarrior.isAlive)
			{
				lightWarrior.AddAnimToQueue(lightWarrior.GetIdleAnimation());
				EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)lightWarrior).transform, abilityData.laughCameraInfluenceAmount)));
				EventMessenger.Instance.Raise(new CameraZoomEvent(abilityData.laughCameraZoom));
				yield return (object)new WaitWhile((Func<bool>)(() => lightWarrior.IsAnimPlaying(abilityData.hitAnim)));
			}
		}
		ballSequenceFinished = true;
	}
}
