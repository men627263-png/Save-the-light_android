using UnityEngine;

public class PlayMakerRPCProxy : MonoBehaviour
{
	public PlayMakerFSM[] fsms;

	public void Reset()
	{
		fsms = ((Component)this).GetComponents<PlayMakerFSM>();
	}

	public void ForwardEvent(string eventName)
	{
		PlayMakerFSM[] array = fsms;
		foreach (PlayMakerFSM val in array)
		{
			val.SendEvent(eventName);
		}
	}
}
