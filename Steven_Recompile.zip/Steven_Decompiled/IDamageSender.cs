using System;
using UnityEngine;

public interface IDamageSender
{
	GameObject gameObject { get; }

	int AttackValue { get; }

	int LuckValue { get; }

	event Action<DamageResult> OutgoingDamage;

	event Action<DamageResult> DamageDealt;

	void OnOutgoingDamage(DamageResult damageResult);

	void OnDamageDealt(DamageResult damageResult);
}
