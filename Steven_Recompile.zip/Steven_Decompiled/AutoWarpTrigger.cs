using System;
using System.Collections;
using Rewired;
using UnityEngine;

public class AutoWarpTrigger : MonoBehaviour
{
	public int levelUID;

	public string levelWarpPadName = string.Empty;

	public int completesEventUID = -1;

	public GameObject warpPad;

	private bool startedWarp;

	private RichAI2D richAI2d;

	private void OnTriggerEnter(Collider other)
	{
		if (!((Object)(object)GameController.Instance == (Object)null) && !((Object)(object)GameController.Instance.partyLeader == (Object)null) && !startedWarp && ((object)((Component)other).gameObject).Equals((object?)((Component)GameController.Instance.partyLeader).gameObject))
		{
			GamePlayLevelDefinition level = GameController.Instance.gameplayDatabase.GetLevel(levelUID);
			if (GameController.Instance.AllowedToLoadScene(level.sceneName))
			{
				warpPad.GetComponent<WarpPad>().preventDisplayingOptions = true;
				startedWarp = false;
				Player player = GameController.Instance.player;
				GameController.Instance.SetMapsEnabled(state: false, "Game");
				GameController.Instance.SetMapsEnabled(state: false, "GameUI");
				GameController.Instance.SetMapsEnabled(state: false, "GameWarpPad");
				((MonoBehaviour)this).StartCoroutine(StartMovement());
			}
		}
	}

	private IEnumerator StartMovement()
	{
		richAI2d = GameController.Instance.partyLeader.RichAI2D;
		if ((Object)(object)richAI2d != (Object)null)
		{
			while (!GameController.Instance.partyLeader.isGrounded)
			{
				yield return null;
			}
			richAI2d.MoveToPosition(warpPad.transform.position, 5f);
			RichAI2D richAI2D = richAI2d;
			richAI2D.targetReached = (Action)Delegate.Combine(richAI2D.targetReached, new Action(TargetReached));
		}
		yield return null;
	}

	private void TargetReached()
	{
		RichAI2D richAI2D = richAI2d;
		richAI2D.targetReached = (Action)Delegate.Remove(richAI2D.targetReached, new Action(TargetReached));
		((MonoBehaviour)this).StartCoroutine("LoadSceneRoutine");
	}

	private IEnumerator LoadSceneRoutine()
	{
		GameController.Instance.SetMapsEnabled(state: false, "Game");
		while (true)
		{
			bool anyMoving = false;
			for (int i = 0; i < GameController.Instance.party.Count; i++)
			{
				if (GameController.Instance.party[i].RichAI2D.IsMovingAlongPath)
				{
					anyMoving = true;
				}
			}
			if (!anyMoving)
			{
				break;
			}
			yield return null;
		}
		EventMessenger.Instance.Raise(new StartWarpEvent(levelWarpPadName));
		GamePlayLevelDefinition levelDef = GameController.Instance.gameplayDatabase.GetLevel(levelUID);
		yield return (object)new WaitForSeconds(1f);
		GameController.Instance.LoadScene(levelDef.sceneName, null, fromWarpPad: true, levelWarpPadName);
		if (completesEventUID > -1)
		{
			PlayerGameState.Instance.TriggerGamePlayEvent(completesEventUID, GamePlayEventState.Complete);
		}
	}
}
