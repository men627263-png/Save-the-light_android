using System;
using System.Collections;
using System.Collections.Generic;
using HutongGames.PlayMaker;
using Pathfinding;
using UnityEngine;

public class LightDoor : MonoBehaviour
{
	[Serializable]
	public class LightDoorSetting
	{
		public KeyType keyType;

		public string loopAnimation;

		public string openAnimation;
	}

	public string guid = string.Empty;

	public KeyType keyType;

	public StageInteractable stageInteractable;

	public Animator animator;

	public AnimatorEventListener eventListener;

	public Collider collider;

	public NavmeshCut navMeshCut;

	public CameraZone activateCameraZone;

	public float exitCameraZonDelay = 2f;

	public PlayMakerFSM fsm;

	public FsmEvent fsmEvent;

	public List<LightDoorSetting> lightDoorSettings;

	private string loopAnimation;

	private string openAnimation;

	private StopArea _stopArea;

	private bool didShowCinemaBars;

	private bool preventingBackpackUse;

	private StopArea stopArea
	{
		get
		{
			if ((Object)(object)_stopArea == (Object)null)
			{
				_stopArea = ((Component)this).GetComponent<StopArea>();
			}
			return _stopArea;
		}
	}

	private void Awake()
	{
		if ((Object)(object)stageInteractable != (Object)null)
		{
			stageInteractable.Interact += CheckUnlockDoor;
		}
		LightDoorSetting lightDoorSetting = lightDoorSettings.Find((LightDoorSetting x) => x.keyType == keyType);
		if (lightDoorSetting != null)
		{
			loopAnimation = lightDoorSetting.loopAnimation;
			openAnimation = lightDoorSetting.openAnimation;
			animator.Play(loopAnimation);
		}
		PlayerGameState.Instance.PlayerDataChanged += HandlePlayerDataChanged;
		HandlePlayerDataChanged();
	}

	private void Start()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		Collider val = collider;
		BoxCollider val2 = (BoxCollider)(object)((val is BoxCollider) ? val : null);
		if ((Object)(object)val2 != (Object)null)
		{
			navMeshCut.rectangleSize = new Vector2(val2.size.x, val2.size.z);
			navMeshCut.height = val2.size.y;
			navMeshCut.center = val2.center;
			navMeshCut.ForceUpdate();
		}
	}

	private void HandlePlayerDataChanged()
	{
		if (PlayerGameState.Instance.IsLightDoorUnlocked(guid))
		{
			UnlockDoor(animate: false);
		}
	}

	private void OnDestroy()
	{
		if ((Object)(object)stageInteractable != (Object)null)
		{
			stageInteractable.Interact -= CheckUnlockDoor;
		}
		PlayerGameState.Instance.PlayerDataChanged -= HandlePlayerDataChanged;
	}

	public void UnlockDoor(bool animate = true)
	{
		preventingBackpackUse = GameController.Instance.preventBackpackUse;
		if (animate)
		{
			((MonoBehaviour)this).StartCoroutine(StartUnlockDoorAnimation());
		}
		else
		{
			animator.Play(openAnimation, 0, 1f);
			collider.enabled = false;
			((Behaviour)navMeshCut).enabled = false;
			didShowCinemaBars = false;
		}
		if ((Object)(object)stageInteractable != (Object)null)
		{
			((Component)stageInteractable).gameObject.SetActive(false);
		}
	}

	private IEnumerator StartUnlockDoorAnimation()
	{
		GameController.Instance.partyLeader.ignoreInput = true;
		if ((Object)(object)stopArea != (Object)null)
		{
			stopArea.TriggerStopArea();
		}
		UICinemaBars.Instance.ShowCinemaBars();
		didShowCinemaBars = true;
		yield return (object)new WaitForSeconds(1.5f);
		animator.Play(openAnimation);
		eventListener.EventTriggered += HandleAnimatorEvent;
		GameController.Instance.preventBackpackUse = true;
		if ((Object)(object)activateCameraZone != (Object)null)
		{
			activateCameraZone.DoEnter(((Component)GameController.Instance.partyLeader).transform);
		}
		yield return null;
	}

	private void HandleAnimatorEvent(AnimationEvent animEvent)
	{
		if (animEvent.stringParameter == "PlayAudio")
		{
			PrefabManager.instance.lightDoorUnlockedSound.Play();
		}
		if (animEvent.stringParameter == "Open")
		{
			eventListener.EventTriggered -= HandleAnimatorEvent;
			collider.enabled = false;
			((Behaviour)navMeshCut).enabled = false;
			((MonoBehaviour)this).StartCoroutine("ExitCameraZone");
			if ((Object)(object)stopArea != (Object)null)
			{
				stopArea.DisableStopArea();
			}
			if (didShowCinemaBars)
			{
				UICinemaBars.Instance.HideCinemaBars();
			}
			GameController.Instance.preventBackpackUse = preventingBackpackUse;
			didShowCinemaBars = false;
			GameController.Instance.partyLeader.ignoreInput = false;
		}
	}

	private IEnumerator ExitCameraZone()
	{
		yield return (object)new WaitForSeconds(exitCameraZonDelay);
		if ((Object)(object)activateCameraZone != (Object)null)
		{
			activateCameraZone.DoExit(((Component)GameController.Instance.partyLeader).transform);
		}
	}

	public void CheckUnlockDoor()
	{
		if (!PlayerGameState.Instance.IsLightDoorUnlocked(guid) && PlayerGameState.Instance.HasKeyType(keyType))
		{
			PlayerGameState.Instance.UseKey(keyType, save: false);
			PlayerGameState.Instance.UnlockLightDoor(guid);
			UIStageInteractbleButton.Instance.Hide();
			UICurrency.Instance.HideKeys();
			UnlockDoor();
			if ((Object)(object)fsm != (Object)null && fsmEvent != null)
			{
				fsm.SendEvent(fsmEvent.Name);
			}
		}
	}
}
