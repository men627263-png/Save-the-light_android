using System.Collections;
using PixelCrushers.DialogueSystem;
using Rewired;
using UnityEngine;

public class DialogueTrigger : MonoBehaviour
{
	public DialogueDatabase database;

	public DialogueTriggerType trigger;

	public string conversation = string.Empty;

	public int conversationUID = -1;

	public int eventUID = -1;

	public float delayTime;

	public float delayStartTime;

	public bool onlyOnce;

	public bool disableObject;

	public bool requiresItem;

	public bool requiresCharacter;

	public bool requiresNotHavingCharacter;

	public bool requiresEvent;

	public bool requiresConvoPlayed;

	public bool activateZoom;

	public bool activatesCameraZone;

	public CameraZone cameraZoneActivated;

	public string conversationRequired = string.Empty;

	public int conversationUIDRequired = -1;

	public int characterUIDRequired;

	public int characterUIDToNotHave;

	public int eventUIDRequired;

	private bool startedConvo;

	public bool allowMovement;

	public bool allowReactivation;

	private Player _player;

	private Player player
	{
		get
		{
			if (_player == null)
			{
				_player = ReInput.players.GetPlayer(0);
			}
			return _player;
		}
	}

	private IEnumerator Start()
	{
		if (trigger == DialogueTriggerType.OnEventComplete)
		{
			PlayerGameState.Instance.GamePlayEventCompleted += HandleGamePlayEventCompleted;
		}
		if (trigger == DialogueTriggerType.OnEventTriggered)
		{
			PlayerGameState.Instance.GamePlayEventTriggered += HandleGamePlayEventTriggered;
		}
		PlayerGameState.Instance.PlayerDataChanged += HandlePlayerDataChanged;
		HandlePlayerDataChanged();
		yield return (object)new WaitForSeconds(1f);
		if (trigger == DialogueTriggerType.OnStart)
		{
			StartDialogue();
		}
	}

	private void OnDestroy()
	{
		if (trigger == DialogueTriggerType.OnEventComplete)
		{
			PlayerGameState.Instance.GamePlayEventCompleted -= HandleGamePlayEventCompleted;
		}
		if (trigger == DialogueTriggerType.OnEventTriggered)
		{
			PlayerGameState.Instance.GamePlayEventTriggered -= HandleGamePlayEventTriggered;
		}
		PlayerGameState.Instance.PlayerDataChanged -= HandlePlayerDataChanged;
	}

	private void OnCollisionEnter(Collision other)
	{
		if (trigger == DialogueTriggerType.OnCollisionEnter)
		{
			CheckGameObject(((Component)other.collider).gameObject);
		}
	}

	private void OnCollisionExit(Collision other)
	{
		if (trigger == DialogueTriggerType.OnCollisionExit)
		{
			CheckGameObject(((Component)other.collider).gameObject);
		}
	}

	private void OnTriggerEnter(Collider other)
	{
		if (trigger == DialogueTriggerType.OnTriggerEnter)
		{
			CheckGameObject(((Component)other).gameObject);
		}
	}

	private void OnTriggerExit(Collider other)
	{
		if (trigger == DialogueTriggerType.OnTriggerExit)
		{
			CheckGameObject(((Component)other).gameObject);
		}
	}

	private void CheckGameObject(GameObject go)
	{
		if ((Object)(object)GameController.Instance != (Object)null && (Object)(object)GameController.Instance.partyLeader != (Object)null && (Object)(object)go == (Object)(object)((Component)GameController.Instance.partyLeader).gameObject)
		{
			StartDialogue();
		}
	}

	private void HandlePlayerDataChanged()
	{
		startedConvo = onlyOnce && PlayerGameState.Instance.HasConversationPlayed(conversationUID);
		if (startedConvo && disableObject)
		{
			((Component)this).gameObject.SetActive(false);
		}
	}

	private void HandleGamePlayEventCompleted(int eventUIDCompleted)
	{
		if (eventUID == eventUIDCompleted)
		{
			StartDialogue();
		}
	}

	private void HandleGamePlayEventTriggered(int eventUIDTriggered)
	{
		if (eventUID == eventUIDTriggered)
		{
			StartDialogue();
		}
	}

	public void StartDialogue()
	{
		if (CanStartDialogue())
		{
			startedConvo = true;
			((MonoBehaviour)GameController.Instance).StartCoroutine(StartDialogueRoutine());
		}
	}

	private bool CanStartDialogue()
	{
		bool result = true;
		if (!((Component)this).gameObject.activeSelf || !((Behaviour)this).enabled)
		{
			return false;
		}
		if (startedConvo)
		{
			return false;
		}
		if (requiresConvoPlayed && !PlayerGameState.Instance.HasConversationPlayed(conversationUIDRequired))
		{
			return false;
		}
		if (requiresCharacter && !PlayerGameState.Instance.HasCharacterInActiveParty(characterUIDRequired))
		{
			return false;
		}
		if (requiresNotHavingCharacter && PlayerGameState.Instance.HasCharacterInActiveParty(characterUIDToNotHave))
		{
			return false;
		}
		return result;
	}

	private IEnumerator StartDialogueRoutine()
	{
		yield return (object)new WaitForEndOfFrame();
		if (!((Object)(object)database != (Object)null) || string.IsNullOrEmpty(conversation))
		{
			yield break;
		}
		yield return (object)new WaitForSeconds(delayStartTime);
		yield return new WaitForDialogue();
		yield return (object)new WaitForEndOfFrame();
		yield return (object)new WaitForSeconds(delayTime);
		while (GameController.Instance.showingCharacterScreen)
		{
			yield return null;
		}
		if (allowMovement)
		{
			DialogueManager.StartConversation(conversation);
			DialogueSystemListener.Instance.OnConversationEndEvent += HandleOnConversationEndEvent;
			yield return (object)new WaitForEndOfFrame();
			DialogueSystemListener.Instance.SetMovementAllowed(allow: true);
			yield break;
		}
		GameController.Instance.partyLeader.ignoreInput = true;
		yield return (object)new WaitForEndOfFrame();
		GameController.Instance.partyLeader.Controller.SimpleMove(Vector3.zero);
		GameController.Instance.partyLeader.SetInput(0f, 0f, newJump: false, GameController.Instance.partyLeader.baseMovementSpeed);
		while (!GameController.Instance.partyLeader.isGrounded)
		{
			yield return (object)new WaitForEndOfFrame();
		}
		yield return (object)new WaitForEndOfFrame();
		GameController.Instance.partyLeader.ignoreInput = false;
		UIGameMap.Instance.HideOptions();
		DialogueManager.StartConversation(conversation);
		DialogueSystemListener.Instance.OnConversationEndEvent += HandleOnConversationEndEvent;
		if (activateZoom)
		{
			EventMessenger.Instance.Raise(new CameraZoomEventOOB(GameResources.instance.gameSettings.zoomFactorOnNPCDialogue));
		}
		if (activatesCameraZone && (Object)(object)cameraZoneActivated != (Object)null)
		{
			cameraZoneActivated.DoEnter(((Component)GameController.Instance.partyLeader).transform);
		}
	}

	private void HandleOnConversationEndEvent(string conversationName)
	{
		if (conversationName.Equals(conversation))
		{
			PlayerGameState.Instance.ConversationPlayed(conversationUID);
			DialogueSystemListener.Instance.OnConversationEndEvent -= HandleOnConversationEndEvent;
			if (allowReactivation)
			{
				startedConvo = false;
			}
			else
			{
				((Behaviour)this).enabled = false;
			}
			if (activateZoom)
			{
				EventMessenger.Instance.Raise(new CameraZoomEventOOB(1f));
			}
			if (activatesCameraZone && (Object)(object)cameraZoneActivated != (Object)null)
			{
				cameraZoneActivated.DoExit(((Component)GameController.Instance.partyLeader).transform);
			}
			if (disableObject)
			{
				((Component)this).gameObject.SetActive(false);
			}
		}
	}
}
