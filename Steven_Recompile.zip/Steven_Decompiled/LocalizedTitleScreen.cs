using SimpleSpritePacker;
using UnityEngine;
using UnityEngine.UI;

public class LocalizedTitleScreen : MonoBehaviour
{
	public Image[] images;

	public LocalizedSpriteAtlas[] atlases;

	private void OnEnable()
	{
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		SPInstance sPInstance = null;
		for (int i = 0; i < atlases.Length; i++)
		{
			if (atlases[i].language == Languages.CurrentLanguage())
			{
				sPInstance = atlases[i].spriteAtlas;
			}
		}
		if ((Object)(object)sPInstance == (Object)null)
		{
			sPInstance = atlases[0].spriteAtlas;
		}
		for (int j = 0; j < images.Length; j++)
		{
			Image val = images[j];
			val.sprite = sPInstance.GetSpriteByName(((Object)val.sprite).name);
			RectTransform component = ((Component)val).GetComponent<RectTransform>();
			Rect rect = val.sprite.rect;
			float width = rect.width;
			Rect rect2 = val.sprite.rect;
			component.sizeDelta = new Vector2(width, rect2.height);
		}
	}
}
