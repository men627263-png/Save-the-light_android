using Grumpyface;
using UnityEngine;

public class Immunity : StatusEffect
{
	public enum ImmunityType
	{
		StatusEffectType,
		StatusEffectName
	}

	private ImmunityType immunityType;

	private int enumIndex;

	private float duration;

	private float chanceToBeImmune;

	private float timer;

	private GameObject particle;

	public override StatusEffectName effectName => StatusEffectName.Immunity;

	public override StatusEffectType type => StatusEffectType.Buff;

	public override bool isPersistent => true;

	public override bool isSavable => true;

	public override bool isResettable => true;

	public override bool isStackable => false;

	public override bool isOwnerValid => true;

	public Immunity(ITargetable owner, ImmunityType immunityType, int enumIndex, float duration, float chanceToBeImmune)
		: base(owner)
	{
		this.immunityType = immunityType;
		this.enumIndex = enumIndex;
		this.duration = duration;
		this.chanceToBeImmune = chanceToBeImmune;
	}

	protected override void InitEffect()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		timer = duration;
		owner.StatusEffectManager.StatusEffectAdded += HandleStatusEffectAdded;
		particle = ObjectPool.GetObject(GameResources.instance.gameSettings.immunityParticlePrefab);
		if ((Object)(object)particle != (Object)null)
		{
			particle.transform.position = owner.CenterTopPosition;
			particle.transform.SetParent(owner.transform, true);
		}
	}

	protected override void UpdateEffect()
	{
		if (duration >= 0f)
		{
			timer -= Time.deltaTime;
			if (timer <= 0f)
			{
				Remove();
			}
		}
	}

	protected override void ResetEffect()
	{
		timer = duration;
	}

	protected override void RemoveEffect()
	{
		owner.StatusEffectManager.StatusEffectAdded -= HandleStatusEffectAdded;
		if ((Object)(object)particle != (Object)null)
		{
			ObjectPool.PoolObject(particle);
			particle = null;
		}
	}

	protected override void CleanUp()
	{
		owner = null;
	}

	protected override void InitSaveData(StatusEffectSaveData saveData)
	{
		saveData.startingData.floatValue1 = duration;
		saveData.startingData.intValue1 = (int)immunityType;
		saveData.startingData.intValue2 = enumIndex;
		saveData.startingData.floatValue2 = chanceToBeImmune;
		saveData.data.floatValue1 = timer;
		saveData.data.intValue1 = (int)immunityType;
		saveData.data.intValue2 = enumIndex;
	}

	public override void LoadSaveData(StatusEffectData data)
	{
		timer = data.floatValue1;
		immunityType = (ImmunityType)data.intValue1;
		enumIndex = data.intValue2;
	}

	private void HandleStatusEffectAdded(StatusEffect effect)
	{
		if (immunityType == ImmunityType.StatusEffectType)
		{
			float value = Random.value;
			if (effect.type == (StatusEffectType)enumIndex && value <= chanceToBeImmune)
			{
				effect.Remove();
			}
			else if (value > chanceToBeImmune)
			{
				Debug.Log((object)("Failed Immunity Roll (" + value + ") for " + (StatusEffectType)enumIndex));
			}
		}
		else
		{
			float value2 = Random.value;
			if (effect.effectName == (StatusEffectName)enumIndex && value2 <= chanceToBeImmune)
			{
				effect.Remove();
			}
			else if (value2 > chanceToBeImmune)
			{
				Debug.Log((object)("Failed Immunity Roll (" + value2 + ") for " + (StatusEffectName)enumIndex));
			}
		}
	}
}
