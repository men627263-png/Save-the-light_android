using UnityEngine;

public class MoveSpeed : StatusEffect
{
	private BaseCharacter character;

	private float speedMultiplier;

	private float duration;

	private float timerDuration;

	private CharacterStatModifier statModifier;

	public override StatusEffectName effectName => StatusEffectName.MoveSpeed;

	public override StatusEffectType type => StatusEffectType.Buff;

	public override bool isStackable => false;

	public override bool isPersistent => true;

	public override bool isSavable => true;

	public override bool isResettable => true;

	public override bool isOwnerValid => owner is BaseCharacter;

	public MoveSpeed(ITargetable owner, float speedMultiplier, float duration)
		: base(owner)
	{
		this.speedMultiplier = speedMultiplier;
		this.duration = duration;
	}

	protected override void InitEffect()
	{
		character = (BaseCharacter)owner;
		timerDuration = duration;
		statModifier = new CharacterStatModifier(CharacterStatModifier.Types.BaseValueAdd, CharacterStatType.MovementSpeed, Mathf.RoundToInt(speedMultiplier * 100f), string.Empty);
		character.Stats.AddStatModifier(statModifier);
	}

	protected override void ResetEffect()
	{
		timerDuration = duration;
	}

	protected override void UpdateEffect()
	{
		timerDuration -= Time.deltaTime;
		if (timerDuration <= 0f)
		{
			Remove();
		}
	}

	protected override void RemoveEffect()
	{
		character.Stats.RemoveStatModifier(statModifier);
	}

	protected override void CleanUp()
	{
		character = null;
		statModifier = null;
	}

	protected override void InitSaveData(StatusEffectSaveData saveData)
	{
		saveData.startingData.floatValue1 = speedMultiplier;
		saveData.startingData.floatValue2 = duration;
		saveData.data.floatValue1 = speedMultiplier;
		saveData.data.floatValue2 = timerDuration;
	}

	public sealed override void LoadSaveData(StatusEffectData data)
	{
		speedMultiplier = data.floatValue1;
		timerDuration = data.floatValue2;
	}
}
