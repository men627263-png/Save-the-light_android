using UnityEngine;

public class WaterSplash : MonoBehaviour
{
	[SerializeField]
	private tk2dSpriteAnimator[] animators;

	[SerializeField]
	private DelayedAudioEvent sound;

	[SerializeField]
	private float fps;

	private void OnEnable()
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < animators.Length; i++)
		{
			animators[i].Play();
			animators[i].ClipFps = fps;
		}
		sound.Play(((Component)this).transform.position);
	}

	private void OnDisable()
	{
		for (int i = 0; i < animators.Length; i++)
		{
			animators[i].SetFrame(0);
		}
	}
}
