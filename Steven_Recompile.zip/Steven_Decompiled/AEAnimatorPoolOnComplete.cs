using Grumpyface;
using UnityEngine;

public class AEAnimatorPoolOnComplete : MonoBehaviour
{
	[SerializeField]
	private AEAnimator animator;

	private void Awake()
	{
		if ((Object)(object)animator != (Object)null)
		{
			animator.AnimationComplete += HandleAnimationComplete;
		}
	}

	private void OnDestroy()
	{
		if ((Object)(object)animator != (Object)null)
		{
			animator.AnimationComplete -= HandleAnimationComplete;
		}
	}

	private void HandleAnimationComplete(AEAnimator obj)
	{
		ObjectPool.PoolObject(((Component)this).gameObject);
	}
}
