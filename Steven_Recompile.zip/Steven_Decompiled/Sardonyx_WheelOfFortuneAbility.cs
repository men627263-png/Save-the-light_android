using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Grumpyface;
using UnityEngine;

public class Sardonyx_WheelOfFortuneAbility : BaseAbility
{
	[Serializable]
	public class AbilityData
	{
		public SardonyxWheelOfFortune wheelPrefab;

		public CharacterAnimationNamePair introAnim = default;

		[Header("Sound Effects")]
		public DelayedAudioEvent introSFX = default;
	}

	public AbilityData abilityData;

	public TreasureChest treasureChestPrefab;

	public RandomLootDropperProperties randomLootProperties;

	[NonSerialized]
	private SardonyxWheelOfFortune wheel;

	protected override void OnInit()
	{
		if ((Object)(object)wheel == (Object)null)
		{
			wheel = Object.Instantiate<SardonyxWheelOfFortune>(abilityData.wheelPrefab);
		}
		((Component)wheel).gameObject.SetActive(false);
	}

	public override IEnumerator Play()
	{
		if (!string.IsNullOrEmpty(abilityData.introAnim.FrontName))
		{
			caster.PlayAnim(abilityData.introAnim);
			caster.AddAnimToQueue(caster.GetIdleAnimation());
		}
		abilityData.introSFX.Play();
		while (caster.currentAnimation == abilityData.introAnim)
		{
			yield return null;
		}
		((Component)wheel).gameObject.SetActive(true);
		wheel.Init();
		EventMessenger.Instance.Raise(new AbstractBackgroundEvent(abstractBackgroundActive: true));
		ToggleUI(0.4f, (Ease)26);
		yield return wheel.WaitUntilWheelSequenceFinished();
		EventMessenger.Instance.Raise(new AbstractBackgroundEvent(abstractBackgroundActive: false));
		List<ITargetable> players = targets.FindAll((ITargetable x) => x is PlayerCharacter);
		List<ITargetable> enemies = targets.FindAll((ITargetable x) => x is BaseEnemy);
		bool unfuse = false;
		TreasureChest newChest = null;
		bool uiToggledEarly = false;
		switch (wheel.finalWheelReward.rewardType)
		{
		case SardonyxWheelOfFortune.WheelRewardType.EnemyStatDebuff:
		{
			for (int num2 = 0; num2 < enemies.Count; num2++)
			{
				BaseEnemy baseEnemy = (BaseEnemy)enemies[num2];
				wheel.finalWheelReward.rewardData.intValue1 = (int)wheel.finalWheelReward.statusEffectStatType;
				baseEnemy.StatusEffectManager.AddStatusEffect(StatusEffectName.CharacterStatBuff, wheel.finalWheelReward.rewardData);
			}
			break;
		}
		case SardonyxWheelOfFortune.WheelRewardType.PartyStatBuff:
		{
			for (int num3 = 0; num3 < players.Count; num3++)
			{
				PlayerCharacter playerCharacter = (PlayerCharacter)players[num3];
				wheel.finalWheelReward.rewardData.intValue1 = (int)wheel.finalWheelReward.statusEffectStatType;
				playerCharacter.StatusEffectManager.AddStatusEffect(StatusEffectName.CharacterStatBuff, wheel.finalWheelReward.rewardData);
			}
			break;
		}
		case SardonyxWheelOfFortune.WheelRewardType.EnemyChilly:
		{
			for (int num4 = 0; num4 < enemies.Count; num4++)
			{
				BaseEnemy baseEnemy2 = (BaseEnemy)enemies[num4];
				baseEnemy2.StatusEffectManager.AddStatusEffect(StatusEffectName.Chilly, wheel.finalWheelReward.rewardData);
			}
			break;
		}
		case SardonyxWheelOfFortune.WheelRewardType.Heal:
		{
			ToggleUI(0.2f, (Ease)26);
			uiToggledEarly = true;
			yield return (object)new WaitForSeconds(0.2f);
			for (int num5 = 0; num5 < players.Count; num5++)
			{
				PlayerCharacter playerCharacter2 = (PlayerCharacter)players[num5];
				playerCharacter2.DoHeal(new HealResult((IHealSender)caster, playerCharacter2, wheel.finalWheelReward.rewardData.intValue1));
			}
			break;
		}
		case SardonyxWheelOfFortune.WheelRewardType.StarPoints:
			ToggleUI(0.2f, (Ease)26);
			uiToggledEarly = true;
			yield return (object)new WaitForSeconds(0.2f);
			EventMessenger.Instance.Raise(new AddStarPointsEvent(wheel.finalWheelReward.rewardData.intValue1));
			break;
		case SardonyxWheelOfFortune.WheelRewardType.Treasure:
		{
			newChest = ObjectPool.GetObject<TreasureChest>("TreasureChest", default(Vector3), true);
			Bounds battlefieldBounds = GameController.Instance.currentBattlefield.battlefieldBounds;
			Vector3[] positions = new Vector3[4]
			{
				battlefieldBounds.center + new Vector3(battlefieldBounds.extents.x, 0f),
				battlefieldBounds.center - new Vector3(battlefieldBounds.extents.x, 0f),
				battlefieldBounds.center + new Vector3(0f, 0f, battlefieldBounds.extents.z),
				battlefieldBounds.center - new Vector3(0f, 0f, battlefieldBounds.extents.z)
			};
			Vector3 farthestPos = Vector3.zero;
			float highestSqrDist = -1f;
			for (int num = 0; num < positions.Length; num++)
			{
				Vector3 val = positions[num] - GameCamera.instance.container.position;
				float sqrMagnitude = val.sqrMagnitude;
				if (sqrMagnitude > highestSqrDist)
				{
					highestSqrDist = sqrMagnitude;
					farthestPos = positions[num];
				}
			}
			((Component)newChest).transform.position = farthestPos;
			((Component)newChest).transform.LookAt(battlefieldBounds.center);
			Transform transform = ((Component)newChest).transform;
			Quaternion rotation = ((Component)newChest).transform.rotation;
			transform.rotation = Quaternion.Euler(0f, rotation.eulerAngles.y + 180f, 0f);
			newChest.InitAsSpawnedChest(randomLootProperties.GenerateLootProperties(), autoOpen: true);
			break;
		}
		case SardonyxWheelOfFortune.WheelRewardType.Unfuse:
			unfuse = true;
			break;
		}
		if (!unfuse && (Object)(object)newChest == (Object)null)
		{
			yield return (object)new WaitForSeconds(0.5f);
		}
		else if (unfuse)
		{
			yield return ((MonoBehaviour)caster).StartCoroutine(((SardonyxPC)caster).Unfuse());
		}
		else if ((Object)(object)newChest != (Object)null)
		{
			GameCamera.instance.battleCamera.ignoreTallFusionOffset = true;
			EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
			EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)newChest).transform, 0.5f)));
			EventMessenger.Instance.Raise(new CameraZoomEvent(GameResources.instance.gameSettings.defaultZoomOnPlayerTurn));
			bool continueSequence = false;
			Action handleFinishedLoot = () =>
			{
				continueSequence = true;
			};
			newChest.lootDropper.FinishedDroppingLoot += handleFinishedLoot;
			while (!continueSequence)
			{
				yield return null;
			}
			newChest.lootDropper.FinishedDroppingLoot -= handleFinishedLoot;
			newChest.Despawn();
			GameCamera.instance.battleCamera.ignoreTallFusionOffset = false;
			yield return (object)new WaitForSeconds(2f);
		}
		if (!uiToggledEarly)
		{
			float toggleDuration = 0.2f;
			ToggleUI(toggleDuration, (Ease)26);
			yield return (object)new WaitForSeconds(toggleDuration);
		}
	}

	public override IEnumerator Cancel()
	{
		yield return null;
	}

	public override void ResetForReUse()
	{
		wheel = null;
		base.ResetForReUse();
	}

	private void ToggleUI(float time, Ease ease = (Ease)26)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Expected Obj, but got Unknown
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Expected Obj, but got Unknown
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected Obj, but got Unknown
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions46.DOAnchorPosY((RectTransform)((Component)GameController.Instance.battlePortraits).transform, 0f - ((RectTransform)((Component)GameController.Instance.battlePortraits).transform).anchoredPosition.y, time, false), ease);
		if ((Object)(object)UIStarMeter.instance != (Object)null)
		{
			TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions46.DOAnchorPosY((RectTransform)((Component)UIStarMeter.instance).transform, 0f - ((RectTransform)((Component)UIStarMeter.instance).transform).anchoredPosition.y, time, false), ease);
		}
		TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions46.DOAnchorPosY((RectTransform)((Component)GameController.Instance.cheeseburgerBackpack).transform, 0f - ((RectTransform)((Component)GameController.Instance.cheeseburgerBackpack).transform).anchoredPosition.y, time, false), ease);
	}
}
