using UnityEngine;

public class HealingAuraShockwave : Shockwave
{
	public bool ignoreSourceCharacter;

	protected override void OnTargetReached(ITargetable target, float progress)
	{
		if ((!object.ReferenceEquals(source, target) || !ignoreSourceCharacter) && target.IsAlive)
		{
			if (target.damageReceiver.CurrentHealthValue < target.damageReceiver.MaxHealthValue)
			{
				float healAmount = Mathf.Lerp(shockwaveData.maxValue, shockwaveData.minValue, progress);
				HealResult healResult = BattleHelper.CalculateHeal((IHealSender)source, target.damageReceiver, healAmount, canBeLucky: false, canOverheal: false);
				BattleHelper.DoHeal(healResult);
			}
			else
			{
				EventMessenger.Instance.Raise(new DisplayBattleTextEvent(Languages.Get("FULL", "MENUS, GUI"), target.transform));
			}
		}
	}
}
