using System;
using System.Collections;
using System.Collections.Generic;
using Grumpyface;
using Rewired;
using UnityEngine;

public abstract class BaseAbility : ScriptableObject
{
	[HideInInspector]
	public AbilityType abilityType;

	[HideInInspector]
	public AbilityUseType useType;

	[HideInInspector]
	public float castTime;

	[HideInInspector]
	public bool isCastInterruptible;

	[HideInInspector]
	public AbilityTargetType targetType;

	[HideInInspector]
	[Tooltip("Whether or not this ability can target non BaseCharacter targets")]
	public bool canTargetNonCharacters;

	[HideInInspector]
	[Tooltip("Wether or not this ability requires at least 1 target in order to execute. If set to FALSE, this ability will always execute no matter how many targets are selected by the below target system")]
	public bool targetsRequired = true;

	[HideInInspector]
	public BattleTargetSystem targetSystem;

	[HideInInspector]
	public string iconSpriteName;

	[HideInInspector]
	public AbilityCost[] costs;

	[HideInInspector]
	public AbilityVisibilityRequirement[] visibilityRequirements;

	[HideInInspector]
	public CombatType attackRangeType;

	[Range(0.01f, 1f)]
	public float bonusStarMeterOnPerfect = 0.1f;

	public int relationshipPoints;

	[HideInInspector]
	public bool hidden;

	protected BaseCharacter caster;

	protected List<ITargetable> targets;

	protected List<StarBonusCheck> starBonusChecks = new List<StarBonusCheck>();

	protected Player player;

	private float prevTime;

	private float curTime;

	private StarBonusCheck lastBonusCheck;

	protected int _uid = -1;

	public int uid
	{
		get
		{
			return _uid;
		}
		set
		{
			_uid = value;
		}
	}

	protected bool isBonusCanceled => lastBonusCheck != null && lastBonusCheck.isBonusCanceled;

	protected bool isBonusSuccess => lastBonusCheck != null && lastBonusCheck.isBonusSuccess;

	protected bool isBonusPerfectSuccess => lastBonusCheck != null && lastBonusCheck.isBonusPerfectSuccess;

	public bool isDisabled => AbilityEventController.instance.isAbilityDisabled(this);

	public bool preventPerfect => AbilityEventController.instance.doNotAllowStarBonusPerfect;

	public bool preventFreezeDuration => AbilityEventController.instance.isAbilityFreezeDurationDisabled(this);

	public void Init(BaseCharacter caster, List<ITargetable> targets)
	{
		this.caster = caster;
		this.targets = targets;
		if ((Object)(object)caster.animatorTk2d != (Object)null)
		{
			tk2dSpriteAnimatorPlus animatorTk2d = caster.animatorTk2d;
			animatorTk2d.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Combine(animatorTk2d.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEventTriggered));
		}
		player = ReInput.players.GetPlayer(0);
		OnInit();
	}

	public IEnumerator UpdateLoop()
	{
		while (true)
		{
			yield return null;
			OnUpdate();
		}
	}

	public void CleanUp()
	{
		OnCleanUp();
		if ((Object)(object)caster.animatorTk2d != (Object)null)
		{
			tk2dSpriteAnimatorPlus animatorTk2d = caster.animatorTk2d;
			animatorTk2d.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Remove(animatorTk2d.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEventTriggered));
		}
		caster = null;
		targets = null;
		ResetBonusVariables();
		RemoveBonusStars();
		starBonusChecks.Clear();
		player = null;
		lastBonusCheck = null;
	}

	public virtual void ResetForReUse()
	{
		if ((Object)(object)caster != (Object)null)
		{
			((MonoBehaviour)caster).StopAllCoroutines();
			if ((Object)(object)caster.animatorTk2d != (Object)null)
			{
				tk2dSpriteAnimatorPlus animatorTk2d = caster.animatorTk2d;
				animatorTk2d.AnimationEventTriggered = (Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>)Delegate.Remove(animatorTk2d.AnimationEventTriggered, new Action<tk2dSpriteAnimator, tk2dSpriteAnimationClip, int>(HandleAnimationEventTriggered));
			}
		}
		caster = null;
		targets = null;
		ResetBonusVariables();
		RemoveBonusStars();
		starBonusChecks.Clear();
		player = null;
		lastBonusCheck = null;
	}

	public virtual AbilityCost GetCost(AbilityCostType type, BaseCharacter caster = null)
	{
		int num = costs.Length;
		for (int i = 0; i < num; i++)
		{
			if (costs[i].type == type)
			{
				return costs[i];
			}
		}
		return null;
	}

	public void SetCost(AbilityCostType type, int newCost)
	{
		int num = costs.Length;
		for (int i = 0; i < num; i++)
		{
			if (costs[i].type == type)
			{
				costs[i].intValue = newCost;
			}
		}
	}

	private void HandleAnimationEventTriggered(tk2dSpriteAnimator animator, tk2dSpriteAnimationClip clip, int frame)
	{
		OnCasterAnimationEvent(clip, clip.GetFrame(frame));
	}

	protected StarBonusCheck StartBonusCheck(float hitTime, BonusStarData bonusStarData, List<ITargetable> bonusStarTargets = null, bool followTargets = false)
	{
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		if (bonusStarTargets == null)
		{
			bonusStarTargets = targets;
		}
		StarBonusCheck starBonusCheck = new StarBonusCheck((!((Component)caster).tag.Equals("Player")) ? UIBonusStarType.Defensive : UIBonusStarType.Offensive, hitTime);
		if (starBonusCheck.bonusStarType == UIBonusStarType.Defensive)
		{
			starBonusCheck.bonusStartTime = hitTime + bonusStarData.bonusStartOffset;
			starBonusCheck.bonusEndTime = hitTime;
			starBonusCheck.bonusPerfectStartTime = hitTime + bonusStarData.bonusPerfectStartOffset;
			starBonusCheck.bonusPerfectEndTime = hitTime;
			starBonusCheck.bonusCancelStartTime = starBonusCheck.bonusStartTime + bonusStarData.bonusCancelStartOffset;
		}
		else
		{
			starBonusCheck.bonusStartTime = hitTime + bonusStarData.bonusStartOffset;
			starBonusCheck.bonusEndTime = starBonusCheck.bonusStartTime + bonusStarData.bonusDuration;
			starBonusCheck.bonusPerfectStartTime = hitTime + bonusStarData.bonusPerfectStartOffset;
			starBonusCheck.bonusPerfectEndTime = starBonusCheck.bonusPerfectStartTime + bonusStarData.bonusPerfectDuration;
			starBonusCheck.bonusCancelStartTime = starBonusCheck.bonusStartTime + bonusStarData.bonusCancelStartOffset;
		}
		if (starBonusCheck.bonusStarType == UIBonusStarType.Defensive)
		{
			bool flag = false;
			for (int i = 0; i < bonusStarTargets.Count; i++)
			{
				if (bonusStarTargets[i].CanBlock)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				return starBonusCheck;
			}
		}
		UIBonusStar uIBonusStar = null;
		for (int j = 0; j < bonusStarTargets.Count; j++)
		{
			if (starBonusCheck.bonusStarType == UIBonusStarType.Offensive || bonusStarTargets[j].CanBlock)
			{
				uIBonusStar = ObjectPool.GetObject<UIBonusStar>("UIBonusStar", bonusStarTargets[j].transform.position, false);
				uIBonusStar.Init(starBonusCheck.bonusStarType, bonusStarTargets[j], followTargets);
				uIBonusStar.animator.speed = 0.183f / starBonusCheck.Duration;
				starBonusCheck.bonusStars.Add(uIBonusStar);
			}
		}
		starBonusCheck.checkForBonus = true;
		if (Time.time >= starBonusCheck.bonusStartTime && Time.time < starBonusCheck.bonusEndTime)
		{
			bool isPerfect = Time.time >= starBonusCheck.bonusPerfectStartTime && Time.time < starBonusCheck.bonusPerfectEndTime;
			for (int k = 0; k < starBonusCheck.bonusStars.Count; k++)
			{
				((Component)starBonusCheck.bonusStars[k]).gameObject.SetActive(true);
				starBonusCheck.bonusStars[k].animator.Play("intro", 0, (Time.time - starBonusCheck.bonusStartTime) / starBonusCheck.Duration);
				starBonusCheck.bonusStars[k].animator.Update(0f);
				starBonusCheck.bonusStars[k].isPerfect = isPerfect;
			}
		}
		starBonusChecks.Add(starBonusCheck);
		starBonusChecks.Sort(SortBonusChecks);
		return starBonusCheck;
	}

	protected void UpdateBonusCheck(StarBonusCheck bonusCheck, BonusStarData bonusStarData, float hitTime)
	{
		if (!starBonusChecks.Contains(bonusCheck))
		{
			return;
		}
		bonusCheck.bonusStartTime = hitTime + bonusStarData.bonusStartOffset;
		bonusCheck.bonusEndTime = hitTime;
		bonusCheck.bonusPerfectStartTime = hitTime + bonusStarData.bonusPerfectStartOffset;
		bonusCheck.bonusPerfectEndTime = hitTime;
		bonusCheck.bonusCancelStartTime = bonusCheck.bonusStartTime + bonusStarData.bonusCancelStartOffset;
		if (Time.time >= bonusCheck.bonusStartTime && Time.time < bonusCheck.bonusEndTime)
		{
			bool isPerfect = Time.time >= bonusCheck.bonusPerfectStartTime && Time.time < bonusCheck.bonusPerfectEndTime;
			for (int i = 0; i < bonusCheck.bonusStars.Count; i++)
			{
				((Component)bonusCheck.bonusStars[i]).gameObject.SetActive(true);
				bonusCheck.bonusStars[i].animator.Play("intro", 0, (Time.time - bonusCheck.bonusStartTime) / bonusCheck.Duration);
				bonusCheck.bonusStars[i].animator.Update(0f);
				bonusCheck.bonusStars[i].isPerfect = isPerfect;
			}
		}
		starBonusChecks.Sort(SortBonusChecks);
	}

	private int SortBonusChecks(StarBonusCheck bonusCheck1, StarBonusCheck bonusCheck2)
	{
		return bonusCheck1.hitTime.CompareTo(bonusCheck2.hitTime);
	}

	protected void DoBonusCheck(StarBonusCheck bonusCheck, bool checkInput)
	{
		if (bonusCheck.isBonusCanceled || bonusCheck.isBonusSuccess)
		{
			return;
		}
		if (curTime >= bonusCheck.bonusCancelStartTime && curTime < bonusCheck.bonusStartTime)
		{
			if (checkInput && player.GetButtonDown("UISubmit"))
			{
				bonusCheck.isBonusCanceled = true;
				bonusCheck.checkForBonus = false;
				lastBonusCheck = bonusCheck;
				EventMessenger.Instance.Raise(new BonusStarEvent(AbilityStarBonusType.CancelEarly, bonusCheck.bonusStars, bonusCheck.bonusStarType));
			}
		}
		else if (curTime >= bonusCheck.bonusStartTime && curTime < bonusCheck.bonusEndTime)
		{
			if (prevTime < bonusCheck.bonusStartTime)
			{
				for (int i = 0; i < bonusCheck.bonusStars.Count; i++)
				{
					((Component)bonusCheck.bonusStars[i]).gameObject.SetActive(true);
				}
				EventMessenger.Instance.Raise(new BonusStarEvent(AbilityStarBonusType.NormalStart, bonusCheck.bonusStars, bonusCheck.bonusStarType));
			}
			if (curTime >= bonusCheck.bonusPerfectStartTime && curTime < bonusCheck.bonusPerfectEndTime)
			{
				if (prevTime < bonusCheck.bonusPerfectStartTime)
				{
					for (int j = 0; j < bonusCheck.bonusStars.Count; j++)
					{
						bonusCheck.bonusStars[j].isPerfect = !preventPerfect;
					}
					EventMessenger.Instance.Raise(new BonusStarEvent(AbilityStarBonusType.PerfectStart, bonusCheck.bonusStars, bonusCheck.bonusStarType));
				}
				if (checkInput && player.GetButtonDown("UISubmit"))
				{
					bonusCheck.isBonusSuccess = true;
					bonusCheck.isBonusPerfectSuccess = !preventPerfect;
					bonusCheck.checkForBonus = false;
					lastBonusCheck = bonusCheck;
					for (int k = 0; k < bonusCheck.bonusStars.Count; k++)
					{
						bonusCheck.bonusStars[k].PlaySuccess();
					}
					EventMessenger.Instance.Raise(new BonusStarEvent(preventPerfect ? AbilityStarBonusType.Normal : AbilityStarBonusType.Perfect, bonusCheck.bonusStars, bonusCheck.bonusStarType));
				}
				return;
			}
			if (prevTime < bonusCheck.bonusPerfectEndTime)
			{
				for (int l = 0; l < bonusCheck.bonusStars.Count; l++)
				{
					bonusCheck.bonusStars[l].isPerfect = false;
				}
			}
			if (checkInput && player.GetButtonDown("UISubmit"))
			{
				bonusCheck.isBonusSuccess = true;
				bonusCheck.checkForBonus = false;
				lastBonusCheck = bonusCheck;
				for (int m = 0; m < bonusCheck.bonusStars.Count; m++)
				{
					bonusCheck.bonusStars[m].PlaySuccess();
				}
				EventMessenger.Instance.Raise(new BonusStarEvent(AbilityStarBonusType.Normal, bonusCheck.bonusStars, bonusCheck.bonusStarType));
			}
		}
		else if (curTime >= bonusCheck.bonusEndTime && curTime < bonusCheck.bonusEndTime + 0.3f && !bonusCheck.isBonusSuccess && !bonusCheck.isBonusCanceled)
		{
			if (prevTime < bonusCheck.bonusEndTime)
			{
				for (int n = 0; n < bonusCheck.bonusStars.Count; n++)
				{
					((Component)bonusCheck.bonusStars[n]).gameObject.SetActive(false);
				}
			}
			if (checkInput && player.GetButtonDown("UISubmit"))
			{
				bonusCheck.isBonusCanceled = true;
				bonusCheck.checkForBonus = false;
				lastBonusCheck = bonusCheck;
				EventMessenger.Instance.Raise(new BonusStarEvent(AbilityStarBonusType.CancelLate, bonusCheck.bonusStars, bonusCheck.bonusStarType));
			}
		}
		else if (curTime >= bonusCheck.bonusEndTime + 0.3f && !bonusCheck.isBonusSuccess && !bonusCheck.isBonusCanceled)
		{
			bonusCheck.checkForBonus = false;
			lastBonusCheck = bonusCheck;
			EventMessenger.Instance.Raise(new BonusStarEvent(AbilityStarBonusType.None, bonusCheck.bonusStars, bonusCheck.bonusStarType));
		}
	}

	protected void LastFrameBonusCheck(StarBonusCheck bonusCheck)
	{
		if (bonusCheck.checkForBonus && !bonusCheck.isBonusCanceled && !bonusCheck.isBonusSuccess && player.GetButtonDown("UISubmit"))
		{
			bonusCheck.isBonusSuccess = true;
			bonusCheck.isBonusPerfectSuccess = bonusCheck.bonusStarType == UIBonusStarType.Defensive;
			bonusCheck.checkForBonus = false;
			lastBonusCheck = bonusCheck;
			for (int i = 0; i < bonusCheck.bonusStars.Count; i++)
			{
				bonusCheck.bonusStars[i].PlaySuccess();
			}
			EventMessenger.Instance.Raise(new BonusStarEvent(AbilityStarBonusType.Perfect, bonusCheck.bonusStars, bonusCheck.bonusStarType));
		}
	}

	protected void LastFrameBonusCheck()
	{
		if (starBonusChecks.Count > 0)
		{
			LastFrameBonusCheck(starBonusChecks[0]);
		}
	}

	protected void ResetBonusVariables()
	{
		int count = starBonusChecks.Count;
		for (int i = 0; i < count; i++)
		{
			starBonusChecks[i].checkForBonus = false;
			starBonusChecks[i].isBonusCanceled = false;
			starBonusChecks[i].isBonusSuccess = false;
			starBonusChecks[i].isBonusPerfectSuccess = false;
		}
	}

	protected void RemoveBonusStars()
	{
		UIBonusStar uIBonusStar = null;
		int count = starBonusChecks.Count;
		for (int i = 0; i < count; i++)
		{
			while (starBonusChecks[i].bonusStars.Count > 0)
			{
				uIBonusStar = starBonusChecks[i].bonusStars.Pop();
				if ((Object)(object)uIBonusStar != (Object)null)
				{
					ObjectPool.PoolObject(((Component)uIBonusStar).gameObject);
				}
			}
		}
	}

	protected void RemoveBonusStars(StarBonusCheck bonusCheck)
	{
		if (starBonusChecks.Contains(bonusCheck))
		{
			while (bonusCheck.bonusStars.Count > 0)
			{
				ObjectPool.PoolObject(((Component)bonusCheck.bonusStars.Pop()).gameObject);
			}
		}
	}

	protected virtual void OnInit()
	{
	}

	protected virtual void OnUpdate()
	{
		curTime = Time.time;
		bool checkInput = true;
		StarBonusCheck starBonusCheck = null;
		int count = starBonusChecks.Count;
		for (int i = 0; i < count; i++)
		{
			starBonusCheck = starBonusChecks[i];
			if (!starBonusCheck.checkForBonus)
			{
				continue;
			}
			if (starBonusCheck.bonusStarType == UIBonusStarType.Defensive)
			{
				for (int num = starBonusCheck.bonusStars.Count - 1; num >= 0; num--)
				{
					if (!starBonusCheck.bonusStars[num].target.CanBlock)
					{
						ObjectPool.PoolObject(((Component)starBonusCheck.bonusStars[num]).gameObject);
						starBonusCheck.bonusStars.RemoveAt(num);
					}
				}
				if (starBonusCheck.bonusStars.Count == 0)
				{
					starBonusCheck.checkForBonus = false;
					starBonusCheck.isBonusCanceled = true;
					if (curTime >= starBonusCheck.bonusEndTime)
					{
						EventMessenger.Instance.Raise(new BonusStarEvent(AbilityStarBonusType.None, starBonusCheck.bonusStars, starBonusCheck.bonusStarType));
					}
					continue;
				}
			}
			DoBonusCheck(starBonusCheck, checkInput);
			checkInput = false;
		}
		prevTime = curTime;
	}

	protected virtual void OnCleanUp()
	{
	}

	protected virtual void OnCasterAnimationEvent(tk2dSpriteAnimationClip clip, tk2dSpriteAnimationFrame frame)
	{
	}

	public abstract IEnumerator Play();

	public abstract IEnumerator Cancel();

	public virtual void Activate()
	{
	}

	public virtual void Deactivate()
	{
	}
}
