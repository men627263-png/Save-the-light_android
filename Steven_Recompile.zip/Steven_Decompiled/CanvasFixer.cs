using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class CanvasFixer : MonoBehaviour
{
	private CanvasScaler scaler;

	private IEnumerator Start()
	{
		scaler = ((Component)this).GetComponent<CanvasScaler>();
		WaitForSeconds wait = new WaitForSeconds(2f);
		float expectedRatio = 1.7777778f;
		yield return wait;
		while (true)
		{
			float actualRatio = (float)Screen.width / (float)Screen.height;
			if (actualRatio > expectedRatio)
			{
				scaler.matchWidthOrHeight = 1f;
			}
			else if (actualRatio < expectedRatio)
			{
				scaler.matchWidthOrHeight = 0f;
			}
			yield return wait;
		}
	}
}
