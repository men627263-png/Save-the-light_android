using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

public class SaveDataManager : MonoBehaviour
{
	public static string fileNameLocal = "STLGameData.sav";

	private static string backupFileNameLocal = "STLGameData.bak";

	private bool _isInitialized;

	private bool ignoreSave;

	private STLGameData queuedSaveData;

	private static SaveDataManager _instance;

	public bool IsInitialized => _isInitialized;

	public bool IgnoreSave => ignoreSave;

	private static string localPath => Application.persistentDataPath + "/" + fileNameLocal;

	private static string backupPath => Application.persistentDataPath + "/" + backupFileNameLocal;

	public bool IsBusy
	{
		get
		{
			if (!_isInitialized)
			{
				Debug.LogError((object)"SaveDataManager has not been initialized, so ignoring this");
				return false;
			}
			return false;
		}
	}

	public static SaveDataManager Instance
	{
		get
		{
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			if ((Object)(object)_instance == (Object)null)
			{
				_instance = new GameObject("SaveDataManager").AddComponent<SaveDataManager>();
			}
			return _instance;
		}
	}

	public event Action SavingStarted;

	public event Action SavingComplete;

	public event Action LoadingStarted;

	public event Action LoadingComplete;

	public event Action LoadingFailed;

	public event Action DeletingStarted;

	public event Action DeletingComplete;

	public event Action GameDataSaved;

	public event Action<STLGameData> GameDataLoaded;

	public event Action<bool> SaveDataFound;

	private void Awake()
	{
		if ((Object)(object)_instance != (Object)null && (Object)(object)_instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
			return;
		}
		_instance = this;
		Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
	}

	private void Start()
	{
	}

	private void Update()
	{
	}

	public void Init(bool ignoreSave = false)
	{
		if (!_isInitialized)
		{
			Init_Default();
			this.ignoreSave = ignoreSave;
			_isInitialized = true;
			OnScreenLog.Add("SaveDataManager Initialized");
		}
	}

	public void SaveGameData(STLGameData gameData)
	{
		if (!_isInitialized)
		{
			Debug.LogError((object)"SaveDataManager has not been initialized, so ignoring this SAVE request");
		}
		else if (ignoreSave)
		{
			Debug.Log((object)"Ignoring Save");
			OnScreenLog.Add("Ignoring Save");
		}
		else if (IsBusy)
		{
			Debug.Log((object)"SaveDataManager is busy. Ignoring SAVE request");
			OnScreenLog.Add("SaveDataManager is busy. Ignoring SAVE request");
			queuedSaveData = gameData;
		}
		else
		{
			Save_Default(gameData);
		}
	}

	public void LoadGameData()
	{
		if (!_isInitialized)
		{
			Debug.LogError((object)"SaveDataManager has not been initialized, so ignoring this LOAD request");
		}
		else if (IsBusy)
		{
			OnScreenLog.Add("SaveDataManager is busy. Ignoring LOAD request");
		}
		else
		{
			Load_Default();
		}
	}

	public void DeleteGameData()
	{
		if (!_isInitialized)
		{
			Debug.LogError((object)"SaveDataManager has not been initialized, so ignoring this DELETE request");
		}
		else if (IsBusy)
		{
			OnScreenLog.Add("SaveDataManager is busy. Ignoring DELETE request");
		}
		else
		{
			Delete_Default();
		}
	}

	public void LoadGameDataFromResources(string filePath)
	{
		if (!_isInitialized)
		{
			Debug.LogError((object)"SaveDataManager has not been initialized, so ignoring this LOAD request");
			return;
		}
		if (IsBusy)
		{
			OnScreenLog.Add("SaveDataManager is busy. Ignoring LOAD request");
			return;
		}
		Debug.Log((object)("Attempting to load game data from Resources at path: " + filePath));
		Object val = Resources.Load(filePath);
		TextAsset val2 = (TextAsset)(object)((val is TextAsset) ? val : null);
		Stream stream = new MemoryStream(val2.bytes);
		BinaryFormatter binaryFormatter = new BinaryFormatter();
		binaryFormatter.Binder = new VersionDeserializationBinder();
		object obj = binaryFormatter.Deserialize(stream);
		stream.Close();
		STLGameData sTLGameData = (STLGameData)obj;
		if (sTLGameData != null)
		{
			OnGameDataLoaded(sTLGameData);
		}
		OnLoadingComplete();
	}

	public bool HasSaveData()
	{
		if (!_isInitialized)
		{
			Debug.LogError((object)"SaveDataManager has not been initialized, so ignoring this method call");
			return false;
		}
		return HasSaveData_Default();
	}

	public void SetIgnoreSave(bool updatedIgnoreSave)
	{
		ignoreSave = updatedIgnoreSave;
	}

	private void Init_Default()
	{
	}

	private void Save_Default(STLGameData gameData)
	{
		OnSavingStarted();
		SerializeObjectToFile(gameData, localPath);
		OnGameDataSaved();
		OnSavingComplete();
	}

	private void Load_Default()
	{
		if (File.Exists(localPath))
		{
			Debug.Log((object)("Attempting to load game data from location: " + localPath));
			OnLoadingStarted();
			STLGameData sTLGameData = (STLGameData)DeserializeObjectFromFile(localPath);
			if (sTLGameData != null)
			{
				OnGameDataLoaded(sTLGameData);
				OnLoadingComplete();
			}
			else
			{
				Debug.Log((object)"Save File exists but is corrupted. Creating new save data.");
				Save_Default(new STLGameData());
				Load_Default();
			}
		}
		else
		{
			Debug.Log((object)("File doesn't exist at location: " + localPath));
			Save_Default(new STLGameData());
			Load_Default();
		}
	}

	private void Delete_Default()
	{
	}

	private bool HasSaveData_Default()
	{
		return File.Exists(localPath);
	}

	public static void SerializeObjectToFile(object serializableObject, string filePath, bool skipBackup = true)
	{
		FileStream fileStream = null;
		try
		{
			fileStream = File.Open(filePath, FileMode.Create, FileAccess.Write);
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			binaryFormatter.Binder = new VersionDeserializationBinder();
			binaryFormatter.Serialize(fileStream, serializableObject);
			fileStream.Close();
		}
		catch
		{
			fileStream?.Close();
		}
	}

	private static object DeserializeObjectFromFile(string filePath)
	{
		if (File.Exists(filePath))
		{
			FileStream fileStream = null;
			try
			{
				fileStream = File.Open(filePath, FileMode.Open);
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				binaryFormatter.Binder = new VersionDeserializationBinder();
				object result = binaryFormatter.Deserialize(fileStream);
				fileStream.Close();
				return result;
			}
			catch (Exception)
			{
				fileStream?.Close();
				return null;
			}
		}
		return null;
	}

	protected void OnSavingStarted()
	{
		OnScreenLog.Add("Saving Started");
		if (SavingStarted != null)
		{
			SavingStarted();
		}
	}

	protected void OnSavingComplete()
	{
		OnScreenLog.Add("Saving Complete");
		if (SavingComplete != null)
		{
			SavingComplete();
		}
		if (queuedSaveData != null)
		{
			SaveGameData(queuedSaveData);
			queuedSaveData = null;
		}
	}

	protected void OnLoadingStarted()
	{
		OnScreenLog.Add("Loading Started");
		if (LoadingStarted != null)
		{
			LoadingStarted();
		}
	}

	protected void OnLoadingComplete()
	{
		OnScreenLog.Add("Loading Complete");
		if (LoadingComplete != null)
		{
			LoadingComplete();
		}
	}

	protected void OnLoadingFailed()
	{
		OnScreenLog.Add("Loading Failed");
		if (LoadingFailed != null)
		{
			LoadingFailed();
		}
	}

	protected void OnDeletingStarted()
	{
		if (DeletingStarted != null)
		{
			DeletingStarted();
		}
	}

	protected void OnDeletingComplete()
	{
		if (DeletingComplete != null)
		{
			DeletingComplete();
		}
	}

	protected void OnGameDataSaved()
	{
		if (GameDataSaved != null)
		{
			GameDataSaved();
		}
	}

	protected void OnGameDataLoaded(STLGameData gameData)
	{
		if (GameDataLoaded != null)
		{
			GameDataLoaded(gameData);
		}
	}

	protected void OnSaveDataFound(bool saveDataFound)
	{
		if (SaveDataFound != null)
		{
			SaveDataFound(saveDataFound);
		}
	}

	public static STLGameData LoadSTLGameDataForFilePath(string filePath)
	{
		STLGameData result = null;
		if (File.Exists(filePath))
		{
			return (STLGameData)DeserializeObjectFromFile(filePath);
		}
		return result;
	}

	public static void SaveSTLGameDataFile(STLGameData gameData, string filePath)
	{
		SerializeObjectToFile(gameData, filePath);
	}
}
