using UnityEngine;

public class NonPlayerCharacter : BaseCharacter
{
	public Vector3 dialogueOffset = Vector3.zero;

	public override Vector3 dialoguePosition
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			return ((Component)this).transform.position + dialogueOffset;
		}
	}

	public NonPlayerCharacter()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
	}

	protected override void OnEnable()
	{
		base.OnEnable();
		GameController.Instance.AddDialogueCharacter(this);
		richAI2D.preciseSlowdown = true;
		richAI2D.slowdownTime = 0.1f;
		richAI2D.endReachedDistance = 0.1f;
	}

	protected override void OnDisable()
	{
		base.OnDisable();
		if ((Object)(object)GameController.Instance != (Object)null)
		{
			GameController.Instance.RemoveDialogueCharacter(this);
		}
	}

	private void OnDrawGizmosSelected()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		Gizmos.color = Color.red;
		Gizmos.DrawSphere(dialoguePosition, 0.15f);
		Gizmos.color = Color.white;
	}
}
