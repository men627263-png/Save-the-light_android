using System;
using System.Collections.Generic;
using UnityEngine;

public class DepthColorEffectController : MonoBehaviour
{
	[Serializable]
	private class TransformRenderer
	{
		public Transform transform;

		public Renderer renderer;

		public TransformRenderer(Transform transformNew, Renderer rendererNew)
		{
			transform = transformNew;
			renderer = rendererNew;
		}
	}

	public Color fadeColor;

	public float minDist = 8f;

	public float maxDist = 30f;

	private TransformRenderer[] bushes;

	private MaterialPropertyBlock matBlock;

	private int overlayColorID;

	private Transform mainCameraTransform;

	private Color gray = Color.gray;

	private int count;

	public DepthColorEffectController()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Start()
	{
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Expected Obj, but got Unknown
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		mainCameraTransform = ((Component)Camera.main).transform;
		List<tk2dSprite> list = new List<tk2dSprite>(Object.FindObjectsOfType<tk2dSprite>());
		list.RemoveAll((tk2dSprite bush) => ((Object)((Component)bush).gameObject).name != "Bush" && !((Object)((Component)bush).gameObject).name.Contains("Bush ("));
		count = list.Count;
		bushes = new TransformRenderer[count];
		for (int num = 0; num < count; num++)
		{
			tk2dSprite tk2dSprite2 = list[num];
			bushes[num] = new TransformRenderer(((Component)tk2dSprite2).transform, ((Component)tk2dSprite2).GetComponent<Renderer>());
		}
		overlayColorID = Shader.PropertyToID("_OverlayColor");
		matBlock = new MaterialPropertyBlock();
		matBlock.SetColor(overlayColorID, Color.gray);
	}

	private void LateUpdate()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < count; i++)
		{
			TransformRenderer transformRenderer = bushes[i];
			float num = Mathf.Abs(transformRenderer.transform.position.z - mainCameraTransform.position.z);
			matBlock.SetColor(overlayColorID, Color.Lerp(gray, fadeColor, Mathf.Clamp01((num - minDist) / (maxDist - minDist))));
			transformRenderer.renderer.SetPropertyBlock(matBlock);
		}
	}
}
