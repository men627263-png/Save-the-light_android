using UnityEngine;

[RequireComponent(typeof(tk2dBaseSprite))]
public class ForceAnimatedSpriteShader : MonoBehaviour
{
	public Shader shader;

	private tk2dBaseSprite sprite;

	private Renderer spriteRenderer;

	private void Awake()
	{
		sprite = ((Component)this).GetComponent<tk2dBaseSprite>();
		spriteRenderer = ((Component)sprite).GetComponent<Renderer>();
	}

	private void OnEnable()
	{
		sprite.SpriteChanged += HandleCharacterSpriteChanged;
		HandleCharacterSpriteChanged(sprite);
	}

	private void OnDisable()
	{
		sprite.SpriteChanged -= HandleCharacterSpriteChanged;
	}

	private void HandleCharacterSpriteChanged(tk2dBaseSprite obj)
	{
		spriteRenderer.material.shader = shader;
	}
}
