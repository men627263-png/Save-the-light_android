using System;
using UnityEngine;

[Serializable]
public class ItemDefinition : ScriptableObject
{
	[SerializeField]
	private int _uid = -1;

	[SerializeField]
	private bool _isActive;

	[SerializeField]
	private string _itemName = string.Empty;

	[SerializeField]
	private string _itemNameKey = string.Empty;

	[SerializeField]
	private string _itemDescriptionHeader = string.Empty;

	[SerializeField]
	private string _itemDescriptionHeaderKey = string.Empty;

	[SerializeField]
	private string _itemDescription = string.Empty;

	[SerializeField]
	private string _itemDescriptionKey = string.Empty;

	[SerializeField]
	private string _itemShopDescription = string.Empty;

	[SerializeField]
	private string _itemShopDescriptionKey = string.Empty;

	[SerializeField]
	private string _iconSprite = string.Empty;

	[SerializeField]
	private int _iconSpriteId = -1;

	[SerializeField]
	private int _stackLimit = -1;

	[SerializeField]
	private int _price;

	[SerializeField]
	private float _castTime;

	[SerializeField]
	private string _spriteName = string.Empty;

	[SerializeField]
	private Sprite _guiSprite;

	[SerializeField]
	private Sprite _guiSprite2;

	[SerializeField]
	private Sprite _guiSprite3;

	[SerializeField]
	protected Vector3 _guiSpriteLocalScale = Vector3.one;

	[SerializeField]
	protected Vector3 _guiSpriteLocalPosition = Vector3.zero;

	[SerializeField]
	private GameObject _prefabObject;

	[SerializeField]
	private Color _debugSpriteColor = Color.white;

	[SerializeField]
	private Color _shopOutlineColor = Color.white;

	[SerializeField]
	private Color _shopDescriptionBGColor = Color.white;

	[SerializeField]
	private Color _shopBGColor = Color.white;

	[SerializeField]
	private Sprite _shopBGSprite;

	[SerializeField]
	protected Vector3 _shopTopOffset = Vector3.zero;

	[SerializeField]
	private bool _preventFirstTimeZoom;

	[SerializeField]
	protected BackpackItemType _backpackItemType;

	[SerializeField]
	private BattleTargetSystem _overrideTargetSystem;

	public int uid
	{
		get
		{
			return _uid;
		}
		set
		{
			_uid = value;
		}
	}

	public bool isActive => _isActive;

	public string itemName => _itemName;

	public string itemNameKey => _itemNameKey;

	public string itemDescriptionHeader => _itemDescriptionHeader;

	public string itemDescriptionHeaderKey => _itemDescriptionHeaderKey;

	public string itemDescription => _itemDescription;

	public string itemDescriptionKey => _itemDescriptionKey;

	public string itemShopDescription => _itemShopDescription;

	public string itemShopDescriptionKey => _itemShopDescriptionKey;

	public string iconSprite => _iconSprite;

	public int iconSpriteId => _iconSpriteId;

	public int stackLimit => _stackLimit;

	public int price => _price;

	public float castTime => _castTime;

	public string spriteName => _spriteName;

	public Sprite guiSprite
	{
		get
		{
			return _guiSprite;
		}
		set
		{
			_guiSprite = value;
		}
	}

	public Sprite guiSprite2
	{
		get
		{
			return _guiSprite2;
		}
		set
		{
			_guiSprite2 = value;
		}
	}

	public Sprite guiSprite3
	{
		get
		{
			return _guiSprite3;
		}
		set
		{
			_guiSprite3 = value;
		}
	}

	public Vector3 guiSpriteLocalScale
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return _guiSpriteLocalScale;
		}
	}

	public Vector3 guiSpriteLocalPosition
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return _guiSpriteLocalPosition;
		}
	}

	public GameObject prefabObject => _prefabObject;

	public Color debugSpriteColor
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return _debugSpriteColor;
		}
	}

	public Color shopOutlineColor
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return _shopOutlineColor;
		}
	}

	public Color shopDescriptionBGColor
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return _shopDescriptionBGColor;
		}
	}

	public Color shopBGColor
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return _shopBGColor;
		}
	}

	public Sprite shopBGSprite => _shopBGSprite;

	public Vector3 shopTopOffset
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return _shopTopOffset;
		}
	}

	public bool preventFirstTimeZoom => _preventFirstTimeZoom;

	public BackpackItemType backpackItemType
	{
		get
		{
			return _backpackItemType;
		}
		set
		{
			_backpackItemType = value;
		}
	}

	public BattleTargetSystem overrideTargetSystem
	{
		get
		{
			return _overrideTargetSystem;
		}
		set
		{
			_overrideTargetSystem = value;
		}
	}

	public ItemDefinition()
	{
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
	}
}
