using System;
using System.Collections;
using DG.Tweening;
using Grumpyface;
using UnityEngine;
using UnityEngine.SceneManagement;

[CreateAssetMenu(menuName = "Save the Light/Abilities/Player Characters/Greg/Greg-Connie Team Attack")]
public class GregConnie_TeamAttack : BaseAbility, IFusionAbility
{
	[Serializable]
	private class AbilityData
	{
		[Header("Prefabs")]
		public GameObject pillarEffectPrefab;

		public GameObject specialCameraPrefab;

		[Header("Animations")]
		public CharacterAnimationNamePair[] gregGuitarAnims;

		public CharacterAnimationNamePair connieIdleAnim = default;

		public CharacterAnimationNamePair connieExcitedAnim = default;

		[Header("Audio")]
		public RandomAudioEvent gregVOClip;

		public RandomAudioEvent connieVOClip;

		public DelayedAudioEvent beamSFX = default;

		[Header("Camera Settings")]
		public float gregCameraInfluence;

		public float connieCameraInfluence;

		public float zoomInAmount;

		public float zoomInAmountStrawberryBoss;

		[Space]
		public float distFromConnie;

		public float effectDuration;

		public float attackMultiplier;

		public float defenseMultiplier;

		public float luckMultiplier;

		[Header("Timing Variables")]
		public float backgroundFadeInTime;

		public float delayBeforeGregVO;

		public float delayBeforePillarEffect;

		public float delayBeforeBuffsAdded;

		public float delayBetweenBuffs;

		public float delayBeforeIdleAnims;

		public float outroDelay;

		public float backgroundFadeOutTime;
	}

	[SerializeField]
	private AbilityData abilityData;

	[NonSerialized]
	private tk2dCamera specialCamera;

	[NonSerialized]
	private GameObject pillarEffect;

	[NonSerialized]
	private int loopCount;

	public CharacterName[] members => new CharacterName[2]
	{
		CharacterName.Greg,
		CharacterName.Connie
	};

	protected override void OnInit()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		base.OnInit();
		loopCount = 0;
		specialCamera = ObjectPool.GetObject<tk2dCamera>(abilityData.specialCameraPrefab, default(Vector3), true);
		specialCamera.ScreenCamera.depth = Camera.main.depth + 1f;
		((Component)specialCamera).transform.parent = ((Component)Camera.main).transform;
		((Component)specialCamera).transform.localPosition = Vector3.zero;
		((Component)specialCamera).transform.localRotation = Quaternion.identity;
		((Component)specialCamera).transform.localScale = Vector3.one;
		((Component)specialCamera).GetComponent<MatchParentCameraZoomFactor>().UpdateParent();
		pillarEffect = ObjectPool.GetObject(abilityData.pillarEffectPrefab);
		pillarEffect.SetActive(false);
	}

	public override IEnumerator Play()
	{
		PlayerCharacter greg = null;
		PlayerCharacter connie = null;
		PlayerCharacter member = null;
		for (int i = 0; i < GameController.Instance.Players.Count; i++)
		{
			member = (PlayerCharacter)GameController.Instance.Players[i];
			if (member.characterName == CharacterName.Connie && member.IsAlive)
			{
				connie = member;
			}
			else if (member.characterName == CharacterName.Greg && member.IsAlive)
			{
				greg = member;
			}
		}
		Vector3 connieOriginalFacingDir = connie.directionVector;
		Vector3 gregOriginalFacingDir = greg.directionVector;
		tk2dBaseSprite bgSprite = ((Component)specialCamera).GetComponentInChildren<tk2dBaseSprite>();
		bgSprite.color = Color.clear;
		GameObject dummyTarget = new GameObject("Dummy Camera Target");
		dummyTarget.transform.position = (((Component)greg).transform.position + ((Component)connie).transform.position) / 2f;
		GameCamera.instance.battleCamera.overrideFollowTarget = dummyTarget.transform;
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)greg).transform, abilityData.gregCameraInfluence)));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)connie).transform, abilityData.connieCameraInfluence)));
		Scene activeScene = SceneManager.GetActiveScene();
		float finalZoom = ((!(activeScene.name == "Strawberry_Boss")) ? abilityData.zoomInAmount : abilityData.zoomInAmountStrawberryBoss);
		EventMessenger.Instance.Raise(new CameraZoomEvent(finalZoom));
		EventMessenger.Instance.Raise(new AbstractBackgroundEvent(abstractBackgroundActive: true));
		greg.FaceTarget(((Component)connie).transform);
		greg.PlayAnim(greg.GetIdleAnimation());
		connie.FaceTarget(((Component)greg).transform);
		connie.PlayAnim(connie.GetIdleAnimation());
		TweenSettingsExtensions.SetEase<Tweener>(bgSprite.DOFade(0.7f, abilityData.backgroundFadeInTime), (Ease)1);
		int originalGregLayer = ((Component)greg.animatorTk2d).gameObject.layer;
		int originalConnieLayer = ((Component)connie.animatorTk2d).gameObject.layer;
		int bossLayer = LayerMask.NameToLayer("BossTitleCard");
		((Component)greg.animatorTk2d).gameObject.layer = bossLayer;
		((Component)connie.animatorTk2d).gameObject.layer = bossLayer;
		yield return (object)new WaitForSeconds(0.2f);
		greg.PlayAnim(abilityData.gregGuitarAnims[Random.Range(0, abilityData.gregGuitarAnims.Length)]);
		yield return (object)new WaitForSeconds(abilityData.delayBeforeGregVO);
		if ((Object)(object)abilityData.gregVOClip != (Object)null)
		{
			abilityData.gregVOClip.Play();
		}
		yield return (object)new WaitForSeconds(abilityData.delayBeforePillarEffect);
		pillarEffect.SetActive(true);
		pillarEffect.transform.position = ((Component)connie).transform.position + ((Component)connie).transform.forward * 0.05f;
		abilityData.beamSFX.Play();
		connie.PlayAnim(abilityData.connieExcitedAnim);
		if ((Object)(object)abilityData.connieVOClip != (Object)null)
		{
			abilityData.connieVOClip.Play();
		}
		yield return (object)new WaitForSeconds(abilityData.delayBeforeBuffsAdded);
		StatusEffectData attackBuffData = new StatusEffectData
		{
			intValue1 = 1,
			floatValue2 = abilityData.attackMultiplier,
			floatValue1 = abilityData.effectDuration
		};
		connie.StatusEffectManager.AddStatusEffect(StatusEffectName.CharacterStatBuff, attackBuffData);
		CharacterStatBuffFX buffFX = ((Component)connie).GetComponentInChildren<CharacterStatBuffFX>();
		((Component)buffFX).gameObject.SetLayerRecursively(bossLayer);
		yield return (object)new WaitForSeconds(abilityData.delayBetweenBuffs);
		StatusEffectData defBuffData = new StatusEffectData(attackBuffData)
		{
			intValue1 = 2,
			floatValue2 = abilityData.defenseMultiplier
		};
		connie.StatusEffectManager.AddStatusEffect(StatusEffectName.CharacterStatBuff, defBuffData);
		yield return (object)new WaitForSeconds(abilityData.delayBetweenBuffs);
		StatusEffectData luckBuffData = new StatusEffectData(attackBuffData)
		{
			intValue1 = 4,
			floatValue2 = abilityData.luckMultiplier
		};
		connie.StatusEffectManager.AddStatusEffect(StatusEffectName.CharacterStatBuff, luckBuffData);
		yield return (object)new WaitForSeconds(abilityData.delayBeforeIdleAnims);
		greg.PlayAnim(greg.GetIdleAnimation());
		connie.PlayAnim(connie.GetIdleAnimation());
		pillarEffect.GetComponentInChildren<Animator>().Play("ConnieAmethystTeamAttackBG_OutroAnimation");
		yield return (object)new WaitForSeconds(abilityData.outroDelay);
		float zoomAmount = 1f;
		EventMessenger.Instance.Raise(new CameraZoomEvent(zoomAmount));
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		GameCamera.instance.battleCamera.overrideFollowTarget = null;
		Object.Destroy((Object)(object)dummyTarget);
		ShortcutExtensions.DOKill((Component)(object)bgSprite, false);
		Tweener fadeOutTween = TweenSettingsExtensions.OnComplete<Tweener>(TweenSettingsExtensions.SetEase<Tweener>(bgSprite.DOFade(0f, abilityData.backgroundFadeOutTime), (Ease)1), (TweenCallback)(() =>
		{
			((Component)greg.animatorTk2d).gameObject.layer = originalGregLayer;
			((Component)connie.animatorTk2d).gameObject.layer = originalConnieLayer;
			((Component)buffFX).gameObject.SetLayerRecursively(LayerMask.NameToLayer("Default"));
		}));
		connie.directionVector = connieOriginalFacingDir;
		greg.directionVector = gregOriginalFacingDir;
		yield return (object)new WaitWhile((Func<bool>)(() => TweenExtensions.IsPlaying((Tween)(object)fadeOutTween)));
	}

	public override IEnumerator Cancel()
	{
		yield return null;
	}

	protected override void OnCleanUp()
	{
		base.OnCleanUp();
		if ((Object)(object)specialCamera != (Object)null)
		{
			ObjectPool.PoolObject(((Component)specialCamera).gameObject);
			specialCamera = null;
		}
		if ((Object)(object)pillarEffect != (Object)null)
		{
			ObjectPool.PoolObject(pillarEffect.gameObject);
			pillarEffect = null;
		}
		EventMessenger.Instance.Raise(new AbstractBackgroundEvent(abstractBackgroundActive: false));
	}

	public override void ResetForReUse()
	{
		specialCamera = null;
		pillarEffect = null;
		base.ResetForReUse();
	}

	public bool CanFuse()
	{
		return true;
	}
}
