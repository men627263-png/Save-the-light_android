using System;
using System.Collections;
using Grumpyface;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Abilities/Team Attacks/Peridot-Amethyst")]
public class PeridotAmethyst_TeamAttackAbility : BaseAbility, IFusionAbility
{
	[Serializable]
	private class AbilityData
	{
		[Header("Debug")]
		public bool buildCameraHold;

		public bool shockCameraHold;

		public bool explodeCameraHold;

		[Header("Object References")]
		public BattleCameraSetup buildCameraSetup;

		public BattleCameraSetup shockCameraSetup;

		public BattleCameraSetup explodeCameraSetup;

		[Header("Prefabs")]
		public GameObject backgroundPrefab;

		public GameObject buildFXPrefab;

		public GameObject shockWhipPrefab;

		public GameObject shockwavePrefab;

		[Header("Animations")]
		public CharacterAnimationNamePair peridotBuildAnim = default;

		public CharacterAnimationNamePair peridotFinishedAnim = default;

		public CharacterAnimationNamePair peridotLaughAnim = default;

		public CharacterAnimationNamePair amethystWhipIntroAnim = default;

		public CharacterAnimationNamePair amethystShockWhipAnim = default;

		[Header("Tweakables")]
		[Tooltip("Distance from the TV where Amethyst will stand when shocking it")]
		public float amethystDistance = 2f;

		public float buildDuration = 3f;

		public CharacterTint whiteTine = new CharacterTint(CharacterTint.Type.Static, Color.white);

		public CharacterTint blackTint = new CharacterTint(CharacterTint.Type.Static, Color.black);

		public float tintDelay = 0.05f;

		public float buildUpShakeDuration = 3f;

		public float buildUpShakeUpdateDelay = 0.25f;

		public Vector3 buildUpShakeStartStrength = new Vector3(0.2f, 0.2f);

		public Vector3 buildUpShakeEndStrength = new Vector3(0.6f, 0.6f);

		public Shockwave.ShockwaveData shockwaveData = new Shockwave.ShockwaveData(1f, 6f, 0f, 0f);

		public ScreenShakeData shockwaveShake = default;

		[Header("Sounds")]
		public DelayedAudioEvent peridotLaughVO = default;

		public DelayedAudioEvent finishedBuildingVO = default;

		public DelayedAudioEvent shockStartSound = default;

		public DelayedAudioEvent shockSound = default;

		public DelayedAudioEvent shockEndSound = default;

		public AbilityData()
		{
			//IL_0063: Unknown result type (might be due to invalid IL or missing references)
			//IL_0074: Unknown result type (might be due to invalid IL or missing references)
			//IL_00af: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		}
	}

	[SerializeField]
	private AbilityData abilityData;

	[NonSerialized]
	private BaseCharacter peridot;

	[NonSerialized]
	private AmethystPC amethyst;

	[NonSerialized]
	private PeridotContraptionBlueprint blueprint;

	[NonSerialized]
	private AmethystShockWhipFX shockWhip;

	[NonSerialized]
	private AbstractBattleBG background;

	[NonSerialized]
	private CharacterTint curTint;

	[NonSerialized]
	private Coroutine blinkCoroutine;

	public CharacterName[] members => new CharacterName[2]
	{
		CharacterName.Amethyst,
		CharacterName.Peridot
	};

	protected override void OnInit()
	{
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		base.OnInit();
		PlayerCharacter playerCharacter = null;
		for (int i = 0; i < GameController.Instance.Players.Count; i++)
		{
			playerCharacter = (PlayerCharacter)GameController.Instance.Players[i];
			if (playerCharacter.characterName == CharacterName.Amethyst && playerCharacter.isAlive)
			{
				amethyst = (AmethystPC)playerCharacter;
			}
			else if (playerCharacter.characterName == CharacterName.Peridot && playerCharacter.isAlive)
			{
				peridot = playerCharacter;
			}
		}
		blueprint = ((PeridotContraptionTargetSystem)targetSystem).contraptionBlueprint;
		shockWhip = ObjectPool.GetObject<AmethystShockWhipFX>(abilityData.shockWhipPrefab, ((Component)amethyst).transform.position, false);
		((Component)shockWhip).transform.SetParent(amethyst.characterProperties.shockWhipStartPos, true);
		((Component)shockWhip).transform.localRotation = Quaternion.identity;
		((Component)shockWhip).transform.localScale = Vector3.one;
		background = ObjectPool.GetObject<AbstractBattleBG>(abilityData.backgroundPrefab, default(Vector3), false);
	}

	public override IEnumerator Play()
	{
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new CameraZoomEvent(1.1f));
		Vector3 amethystOriginalDirection = amethyst.directionVector;
		Vector3 peridotOriginalDirection = peridot.directionVector;
		((Component)background).gameObject.SetActive(true);
		background.AddTargets(peridot, amethyst);
		for (int i = 0; i < GameController.Instance.Enemies.Count; i++)
		{
			background.AddTarget((ITargetable)GameController.Instance.Enemies[i]);
		}
		background.AddTarget(((Component)shockWhip).gameObject);
		Transform buildPosition = targets[0].transform;
		GameCamera.instance.battleCamera.overrideFollowTarget = buildPosition;
		GameCamera.instance.battleCamera.overrideCameraOverride = abilityData.buildCameraSetup;
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)amethyst).transform, 0.75f)));
		EventMessenger.Instance.Raise(new AbstractBackgroundEvent(abstractBackgroundActive: true));
		Battlefield battlefield = GameController.Instance.currentBattlefield;
		Vector3 forward = ((Component)battlefield).transform.forward;
		Vector3 leftPosition = buildPosition.position + ((Component)battlefield).transform.right * (0f - abilityData.amethystDistance) + -forward * 0.5f;
		Vector3 rightPosition = buildPosition.position + ((Component)battlefield).transform.right * abilityData.amethystDistance + -forward * 0.5f;
		((MonoBehaviour)peridot).StartCoroutine(MoveCharacterToPosition(peridot, buildPosition.position + -forward * 1f, peridot.baseMovementSpeed, abilityData.peridotBuildAnim, buildPosition));
		if (Vector3.Distance(((Component)amethyst).transform.position, leftPosition) < Vector3.Distance(((Component)amethyst).transform.position, rightPosition))
		{
			((MonoBehaviour)amethyst).StartCoroutine(MoveCharacterToPosition(amethyst, leftPosition, amethyst.baseMovementSpeed, abilityData.amethystWhipIntroAnim, buildPosition));
		}
		else
		{
			((MonoBehaviour)amethyst).StartCoroutine(MoveCharacterToPosition(amethyst, rightPosition, amethyst.baseMovementSpeed, abilityData.amethystWhipIntroAnim, buildPosition));
		}
		yield return new WaitUntilAIReachedTarget(peridot.RichAI2D);
		PeridotBuildFX buildFX = ObjectPool.GetObject<PeridotBuildFX>(abilityData.buildFXPrefab, default(Vector3), true);
		((Component)buildFX).transform.position = buildPosition.position;
		background.AddTarget(((Component)buildFX).gameObject);
		yield return (object)new WaitForSeconds(abilityData.buildDuration);
		buildFX.TurnOff();
		buildFX = null;
		PeridotContraption contraption = ObjectPool.GetObject<PeridotContraption>(blueprint.contraptionPrefab, buildPosition.position, false);
		((Component)contraption).transform.forward = forward;
		contraption.Init((PeridotPC)peridot, blueprint, buildPosition);
		((Component)contraption).gameObject.SetActive(true);
		if (contraption is ITargetable)
		{
			EventMessenger.Instance.Raise(new AddPlayerToBattleEvent((ITargetable)contraption));
		}
		((PeridotPC)peridot).AddContraption(contraption);
		PeridotTV tv = (PeridotTV)contraption;
		background.AddTarget((ITargetable)tv);
		abilityData.finishedBuildingVO.Play(buildPosition.position);
		Vector3 newPosition = buildPosition.position + amethyst.horizontalDirectionVector * 1.5f + -forward * 1.5f;
		((MonoBehaviour)peridot).StartCoroutine(MoveCharacterToPosition(peridot, newPosition, peridot.baseMovementSpeed, abilityData.peridotFinishedAnim, buildPosition, lookAway: true));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)amethyst).transform, 1.5f)));
		GameCamera.instance.battleCamera.overrideCameraOverride = abilityData.shockCameraSetup;
		int startFrame = 7;
		amethyst.PlayAnimFromFrame(abilityData.amethystShockWhipAnim, startFrame, clearQueue: true);
		AudioSource shockStartSource = abilityData.shockStartSound.Play();
		int showFrame = amethyst.animatorTk2d.CurrentClip.GetFrameWithEventInfo("show");
		yield return (object)new WaitWhile((Func<bool>)(() => amethyst.animatorTk2d.CurrentFrame < showFrame));
		shockWhip.startJointFollow.target = amethyst.characterProperties.shockWhipStartPos;
		shockWhip.endJointFollow.target = ((Component)tv).transform;
		shockWhip.endJointFollow.offset = tv.CenterPosition - ((Component)tv).transform.position;
		((Component)shockWhip).gameObject.SetActive(true);
		int pullFrame = amethyst.animatorTk2d.CurrentClip.GetFrameWithEventInfo("pull");
		yield return (object)new WaitWhile((Func<bool>)(() => amethyst.animatorTk2d.CurrentFrame < pullFrame));
		abilityData.shockSound.Play();
		EventMessenger.Instance.Raise(new RemoveCameraInfluenceEvent(((Component)amethyst).transform));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)tv).transform, 1.25f)));
		peridot.FaceTarget(buildPosition);
		peridot.PlayAnim(abilityData.peridotLaughAnim, clearQueue: true);
		if ((Object)(object)abilityData.peridotLaughVO.audioEvent != (Object)null)
		{
			abilityData.peridotLaughVO.Play();
		}
		shockWhip.animator.Play("loop");
		blinkCoroutine = ((MonoBehaviour)tv).StartCoroutine(BlinkEffect(tv));
		Transform shockFX = ObjectPool.GetObject("stunned_fx_electricity", ((Component)tv).transform.position).transform;
		shockFX.localScale = new Vector3(tv.EffectScale, tv.EffectScale, tv.EffectScale);
		shockFX.SetParent(((Component)tv).transform, true);
		shockFX.localRotation = Quaternion.identity;
		Transform val = shockFX;
		val.localPosition += -shockFX.forward * 0.7f;
		background.AddTarget(((Component)shockFX).gameObject);
		yield return (object)new WaitForSeconds(0.75f);
		EventMessenger.Instance.Raise(new RemoveCameraInfluenceEvent(((Component)tv).transform));
		GameCamera.instance.battleCamera.overrideFollowTarget = ((Component)tv).transform;
		GameCamera.instance.battleCamera.overrideCameraOverride = abilityData.explodeCameraSetup;
		yield return ((MonoBehaviour)tv).StartCoroutine(ShakeEffect(abilityData.buildUpShakeDuration, abilityData.buildUpShakeUpdateDelay, abilityData.buildUpShakeStartStrength, abilityData.buildUpShakeEndStrength));
		abilityData.shockEndSound.Play();
		amethyst.PlayAnim(amethyst.GetIdleAnimation(), clearQueue: true);
		if ((Object)(object)shockWhip != (Object)null)
		{
			background.ReturnTarget(((Component)shockWhip).gameObject);
			ObjectPool.PoolObject(((Component)shockWhip).gameObject);
			shockWhip = null;
		}
		if ((Object)(object)shockFX != (Object)null)
		{
			background.ReturnTarget(((Component)shockFX).gameObject);
			ObjectPool.PoolObject(((Component)shockFX).gameObject);
			shockFX = null;
		}
		((MonoBehaviour)tv).StopCoroutine(blinkCoroutine);
		if ((Object)(object)tv.TargetableTinter != (Object)null)
		{
			tv.TargetableTinter.RemoveTint(curTint);
		}
		blinkCoroutine = null;
		Shockwave shockwave = ObjectPool.GetObject<Shockwave>(abilityData.shockwavePrefab, default(Vector3), false);
		shockwave.Init(peridot, abilityData.shockwaveData);
		((Component)shockwave).transform.position = ((Component)tv).transform.position;
		((Component)shockwave).gameObject.SetActive(true);
		background.AddTarget(((Component)shockwave).gameObject);
		EventMessenger.Instance.Raise(new ScreenShakeEvent(abilityData.shockwaveShake));
		yield return (object)new WaitWhile((Func<bool>)(() => ((Component)shockwave).gameObject.activeSelf));
		background.ReturnAllActiveTargets();
		ObjectPool.PoolObject(((Component)background).gameObject);
		background = null;
		EventMessenger.Instance.Raise(new AbstractBackgroundEvent(abstractBackgroundActive: false));
		GameCamera.instance.battleCamera.overrideFollowTarget = null;
		GameCamera.instance.battleCamera.overrideCameraOverride = null;
		((MonoBehaviour)amethyst).StartCoroutine(MoveCharacterToPosition(amethyst, amethyst.battlePosition, amethyst.baseMovementSpeed, amethystOriginalDirection));
		((MonoBehaviour)peridot).StartCoroutine(MoveCharacterToPosition(peridot, peridot.battlePosition, peridot.baseMovementSpeed, peridotOriginalDirection));
		yield return new WaitUntilAIReachedTargets(amethyst.RichAI2D, peridot.RichAI2D);
	}

	public override IEnumerator Cancel()
	{
		yield break;
	}

	protected override void OnCleanUp()
	{
		base.OnCleanUp();
		if ((Object)(object)shockWhip != (Object)null)
		{
			ObjectPool.PoolObject(((Component)shockWhip).gameObject);
		}
		if ((Object)(object)background != (Object)null)
		{
			ObjectPool.PoolObject(((Component)background).gameObject);
			EventMessenger.Instance.Raise(new AbstractBackgroundEvent(abstractBackgroundActive: false));
		}
		peridot = null;
		amethyst = null;
		blueprint = null;
	}

	public override void ResetForReUse()
	{
		if ((Object)(object)amethyst != (Object)null)
		{
			((MonoBehaviour)amethyst).StopAllCoroutines();
			amethyst = null;
		}
		if ((Object)(object)peridot != (Object)null)
		{
			((MonoBehaviour)peridot).StopAllCoroutines();
			peridot = null;
		}
		blueprint = null;
		shockWhip = null;
		background = null;
		curTint = null;
		blinkCoroutine = null;
		EventMessenger.Instance.Raise(new StopScreenShakeEvent());
		base.ResetForReUse();
	}

	private IEnumerator MoveCharacterToPosition(BaseCharacter character, Vector3 position, float speed, CharacterAnimationNamePair animOnComplete = default(CharacterAnimationNamePair), Transform lookAtOnComplete = null, bool lookAway = false)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		character.RichAI2D.MoveToPosition(position, speed);
		yield return new WaitUntilAIReachedTarget(character.RichAI2D);
		if (!animOnComplete.isNullOrEmpty)
		{
			character.PlayAnim(animOnComplete, clearQueue: true);
		}
		if ((Object)(object)lookAtOnComplete != (Object)null)
		{
			if (lookAway)
			{
				character.FaceAwayFromTarget(lookAtOnComplete);
			}
			else
			{
				character.FaceTarget(lookAtOnComplete);
			}
		}
	}

	private IEnumerator MoveCharacterToPosition(BaseCharacter character, Vector3 position, float speed, Vector3 faceDirOnComplete)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		character.RichAI2D.MoveToPosition(position, speed);
		yield return new WaitUntilAIReachedTarget(character.RichAI2D);
		character.directionVector = faceDirOnComplete;
	}

	private IEnumerator BlinkEffect(PeridotTV tv)
	{
		curTint = abilityData.blackTint;
		while (true)
		{
			if ((Object)(object)tv.TargetableTinter != (Object)null)
			{
				tv.TargetableTinter.AddTint(curTint);
			}
			yield return (object)new WaitForSeconds(abilityData.tintDelay);
			if ((Object)(object)tv.TargetableTinter != (Object)null)
			{
				tv.TargetableTinter.RemoveTint(curTint);
			}
			curTint = ((curTint != abilityData.blackTint) ? abilityData.blackTint : abilityData.whiteTine);
		}
	}

	private IEnumerator ShakeEffect(float duration, float updateDelay, Vector3 start, Vector3 end)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		float timeRemaining = duration;
		float delay = updateDelay;
		while (timeRemaining > 0f)
		{
			yield return null;
			timeRemaining -= Time.deltaTime;
			if (timeRemaining <= 0f)
			{
				break;
			}
			delay -= Time.deltaTime;
			if (delay <= 0f)
			{
				delay += updateDelay;
				Vector3 strength = Vector3.Lerp(start, end, (duration - timeRemaining) / duration);
				EventMessenger.Instance.Raise(new ScreenShakeEvent(new ScreenShakeData(10f, strength, 40, 90f, snapping: false, dontFadeOut: true)));
			}
		}
	}

	public bool CanFuse()
	{
		return true;
	}
}
