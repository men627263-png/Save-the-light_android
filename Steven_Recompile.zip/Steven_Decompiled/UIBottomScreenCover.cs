using System;
using DG.Tweening;
using DG.Tweening.Core;
using UnityEngine;
using UnityEngine.UI;

public class UIBottomScreenCover : MonoBehaviour
{
	public static UIBottomScreenCover Instance;

	private Image image;

	private Color imageColor = new Color(0f, 0f, 0f, 1f);

	private Tweener spinTween;

	public event Action FadeInComplete;

	public event Action FadeOutComplete;

	public UIBottomScreenCover()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Awake()
	{
		Instance = this;
		image = ((Component)this).GetComponent<Image>();
	}

	private void OnDestroy()
	{
		Instance = null;
		FadeOutComplete = null;
		FadeInComplete = null;
	}

	public void InitFadeOut()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)image != (Object)null)
		{
			((Graphic)image).color = imageColor;
		}
	}

	public void FadeOut(float time, float delay)
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Expected Obj, but got Unknown
		if (!((Object)(object)image != (Object)null))
		{
			return;
		}
		TweenSettingsExtensions.OnComplete<Tweener>(TweenSettingsExtensions.SetDelay<Tweener>(DOTween.ToAlpha((DOGetter<Color>)(() =>
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return ((Graphic)image).color;
		}), (DOSetter<Color>)((Color x) =>
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			((Graphic)image).color = x;
		}), 0f, time), delay), (TweenCallback)(() =>
		{
			if (FadeOutComplete != null)
			{
				FadeOutComplete();
			}
		}));
	}

	public void FadeIn(float time, float delay, float alpha)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Expected Obj, but got Unknown
		((Graphic)image).color = new Color(imageColor.r, imageColor.g, imageColor.b, 0f);
		TweenSettingsExtensions.OnComplete<Tweener>(TweenSettingsExtensions.SetUpdate<Tweener>(TweenSettingsExtensions.SetDelay<Tweener>(DOTween.ToAlpha((DOGetter<Color>)(() =>
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return ((Graphic)image).color;
		}), (DOSetter<Color>)((Color x) =>
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			((Graphic)image).color = x;
		}), alpha, time), delay), true), (TweenCallback)HandleFadeInComplete);
	}

	private void HandleFadeInComplete()
	{
		if (FadeInComplete != null)
		{
			FadeInComplete();
		}
	}

	public void UpdateColor(Color newColor)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		imageColor = newColor;
	}
}
