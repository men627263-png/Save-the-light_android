using System.Collections;
using Grumpyface;
using UnityEngine;

public class Shock : StatusEffect
{
	private static CharacterTint WHITE_TINT = new CharacterTint(CharacterTint.Type.Static, Color.white);

	private static CharacterTint BLACK_TINT = new CharacterTint(CharacterTint.Type.Static, Color.black);

	private static float tintDelay = 0.1f;

	private BaseCharacter character;

	private float duration;

	private bool removeOnDamage;

	private float timer;

	private Transform shockFX;

	private CharacterTint curTint;

	private Coroutine blinkCoroutine;

	public sealed override StatusEffectType type => StatusEffectType.Debuff;

	public sealed override StatusEffectName effectName => StatusEffectName.Shock;

	public sealed override bool isResettable => true;

	public sealed override bool isStackable => false;

	public sealed override bool isPersistent => false;

	public override bool isSavable => false;

	public override bool isOwnerValid => owner is BaseCharacter;

	public Shock(ITargetable owner, float duration, bool removeOnDamage = true)
		: base(owner)
	{
		this.duration = duration;
		this.removeOnDamage = removeOnDamage;
	}

	protected sealed override void InitEffect()
	{
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		character = (BaseCharacter)owner;
		timer = duration;
		if (removeOnDamage)
		{
			character.DamageReceived += HandleDamageReceived;
		}
		character.InterruptCasting(force: true);
		character.InterruptChanneling(force: true);
		character.DisableBattleWaitingSubState();
		if (character is ShieldEnemy)
		{
			((ShieldEnemy)character).SetActiveState(ShieldEnemy.ShieldEnemyState.None);
		}
		blinkCoroutine = ((MonoBehaviour)character).StartCoroutine(BlinkEffect());
		shockFX = ObjectPool.GetObject("stunned_fx_electricity", ((Component)character).transform.position).transform;
		shockFX.localScale = new Vector3(character.EffectScale, character.EffectScale, character.EffectScale);
		shockFX.SetParent(((Component)character).transform, true);
		shockFX.localRotation = Quaternion.identity;
		if (!character.CurrentState.Equals(CharacterState.KnockedBack))
		{
			character.ReturnToBattleWaiting();
			character.PlayAnim(character.GetIdleAnimation(), clearQueue: true);
		}
	}

	protected sealed override void UpdateEffect()
	{
		if (timer >= 0f)
		{
			timer -= Time.deltaTime;
			if (timer <= 0f)
			{
				Remove();
			}
		}
	}

	protected sealed override void ResetEffect()
	{
		timer = duration;
	}

	protected sealed override void RemoveEffect()
	{
		if (blinkCoroutine != null)
		{
			((MonoBehaviour)character).StopCoroutine(blinkCoroutine);
			if ((Object)(object)character.TargetableTinter != (Object)null)
			{
				character.TargetableTinter.RemoveTint(curTint);
			}
			blinkCoroutine = null;
		}
	}

	protected sealed override void CleanUp()
	{
		if ((Object)(object)shockFX != (Object)null)
		{
			ObjectPool.PoolObject(((Component)shockFX).gameObject);
			shockFX = null;
		}
		character.DamageReceived -= HandleDamageReceived;
		character = null;
		curTint = null;
	}

	protected sealed override void InitSaveData(StatusEffectSaveData saveData)
	{
		saveData.startingData.floatValue1 = duration;
		saveData.data.floatValue1 = timer;
	}

	public sealed override void LoadSaveData(StatusEffectData data)
	{
		timer = data.floatValue1;
	}

	private void HandleDamageReceived(DamageResult obj)
	{
		if (obj.totalDamage > 0)
		{
			Remove();
		}
	}

	private IEnumerator BlinkEffect()
	{
		curTint = BLACK_TINT;
		while (true)
		{
			if ((Object)(object)character.TargetableTinter != (Object)null)
			{
				character.TargetableTinter.AddTint(curTint);
			}
			yield return (object)new WaitForSeconds(tintDelay);
			if ((Object)(object)character.TargetableTinter != (Object)null)
			{
				character.TargetableTinter.RemoveTint(curTint);
			}
			curTint = ((curTint != BLACK_TINT) ? BLACK_TINT : WHITE_TINT);
		}
	}

	static Shock()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
	}
}
