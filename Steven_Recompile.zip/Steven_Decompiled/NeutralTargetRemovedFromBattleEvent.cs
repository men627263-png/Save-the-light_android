public class NeutralTargetRemovedFromBattleEvent : GameEvent
{
	public ITargetable target { get; private set; }

	public NeutralTargetRemovedFromBattleEvent(ITargetable target)
	{
		this.target = target;
	}
}
