using UnityEngine;

public class LevelTableEnemy : ScriptableObject
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
