public enum DialogueFacing
{
	None,
	FaceLeft,
	FaceRight,
	FaceFlip,
	FaceCharacter,
	PlayAnim
}
