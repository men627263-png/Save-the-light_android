using System;
using System.Collections;
using UnityEngine;

public class KudosAbility : BaseAbility
{
	[Serializable]
	public class AbilityData
	{
		public int relationshipPointsGained;

		public float effectDelay;

		public float endDelay;

		[Range(0f, 1f)]
		public float characterSpecificVOProbability;

		public DelayedAudioEvent selectSound = default;
	}

	[SerializeField]
	private AbilityData abilityData;

	public override IEnumerator Play()
	{
		PlayerCharacter target = (PlayerCharacter)targets[0];
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)caster).transform, 1.5f)));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)target).transform, 1.5f)));
		EventMessenger.Instance.Raise(new CameraZoomEvent(1.2f));
		yield return (object)new WaitForSeconds(abilityData.effectDelay);
		abilityData.selectSound.Play();
		RelationshipPointsManager.Instance.AddRelationshipPoints(caster, target, abilityData.relationshipPointsGained);
		caster.PlayAnim(caster.animationNames.victory, clearQueue: true);
		caster.AddAnimToQueue(caster.GetIdleAnimation());
		target.PlayAnim(target.animationNames.victory, clearQueue: true);
		target.AddAnimToQueue(target.GetIdleAnimation());
		((!(Random.value <= abilityData.characterSpecificVOProbability)) ? ((PlayerCharacter)caster).GetKudosVOClip() : ((PlayerCharacter)caster).GetKudosVOClip(target.characterName))?.audioEvent.Play(((Component)(PlayerCharacter)caster).transform.position);
		yield return (object)new WaitForSeconds(abilityData.endDelay);
	}

	public override IEnumerator Cancel()
	{
		yield return null;
	}
}
