using System.Collections;
using UnityEngine;

public class Shop : StopArea
{
	public ShopItemTrigger[] shopItems;

	public bool allowActivation = true;

	public bool hideShopItemShadow;

	[Header("ONION SHOP PROPERTIES")]
	public bool isOnionShop;

	public tk2dSpriteAnimatorPlus onionAnimator;

	public Animator onionRugAnimator;

	public AnimatorEventListener animatorEventListener;

	private bool activatedShop;

	protected override void Awake()
	{
		base.Awake();
		if ((Object)(object)animatorEventListener != (Object)null)
		{
			animatorEventListener.EventTriggered += HandleEventTriggered;
		}
		UIShopItemBox.Instance.PurchasedItem += OnPurchasedItem;
	}

	private void Start()
	{
		EventMessenger.Instance.AddListener<InstigateBattleEvent>(HandleInstigateBattleEvent);
	}

	protected override void OnDestroy()
	{
		base.OnDestroy();
		if ((Object)(object)animatorEventListener != (Object)null)
		{
			animatorEventListener.EventTriggered -= HandleEventTriggered;
		}
		UIShopItemBox.Instance.PurchasedItem -= OnPurchasedItem;
		EventMessenger.Instance.RemoveListener<InstigateBattleEvent>(HandleInstigateBattleEvent);
	}

	private void OnEnable()
	{
		disabled = false;
	}

	private void HandleEventTriggered(AnimationEvent obj)
	{
		if (obj.stringParameter == "ShowItem1" && shopItems.Length > 0)
		{
			((Component)shopItems[0]).gameObject.SetActive(true);
			if ((Object)(object)shopItems[0].item != (Object)null)
			{
				shopItems[0].PlayRevealAnimation();
			}
		}
		if (obj.stringParameter == "ShowItem2" && shopItems.Length > 1)
		{
			((Component)shopItems[1]).gameObject.SetActive(true);
			if ((Object)(object)shopItems[1].item != (Object)null)
			{
				shopItems[1].PlayRevealAnimation();
			}
		}
		if (obj.stringParameter == "ShowItem3" && shopItems.Length > 2)
		{
			((Component)shopItems[2]).gameObject.SetActive(true);
			if ((Object)(object)shopItems[2].item != (Object)null)
			{
				shopItems[2].PlayRevealAnimation();
			}
		}
	}

	private void OnPurchasedItem(int itemUID)
	{
		if (isOnionShop)
		{
			onionAnimator.Play((!((double)Random.Range(0f, 1f) < 0.5)) ? "onion_thumbsUp" : "onion_clap");
			onionAnimator.AddToQueue("onion_idle");
		}
	}

	public void AllowShopActivation()
	{
		allowActivation = true;
		activatedShop = true;
		((MonoBehaviour)this).StartCoroutine("ActivateShop");
	}

	private IEnumerator ActivateShop()
	{
		if (isOnionShop)
		{
			onionAnimator.Play("onion_kick");
			onionAnimator.AddToQueue("onion_gesture");
			onionAnimator.AddToQueue("onion_idle");
			yield return (object)new WaitForSeconds(0.5f);
			onionRugAnimator.SetTrigger("Open");
		}
		yield return (object)new WaitForSeconds(2f);
	}

	protected override void OnTriggerEnter(Collider other)
	{
		base.OnTriggerEnter(other);
		if ((Object)(object)GameController.Instance != (Object)null && ((object)((Component)other).gameObject).Equals((object?)((Component)GameController.Instance.partyLeader).gameObject) && !activatedShop && allowActivation)
		{
			activatedShop = true;
			((MonoBehaviour)this).StartCoroutine("ActivateShop");
		}
	}

	private void HandleInstigateBattleEvent(InstigateBattleEvent evt)
	{
		if ((Object)(object)currentPlayer != (Object)null)
		{
			ExitStopArea();
		}
	}
}
