using System;
using UnityEngine;

[Serializable]
public struct GradientProperties
{
	public Color topColor;

	public Color midColor;

	public Color botColor;

	public float topColorPos;

	public float midColorPos;

	public float botColorPos;

	public float gradientOffset;

	public float gradientAngle;

	public float midColorWeight;
}
