using UnityEngine;

public class BaseCharacterNew : MonoBehaviour
{
	[SerializeField]
	private CharacterMovement characterMovement;

	[SerializeField]
	private PlayerCharacterInput playerInput;

	[SerializeField]
	private float jumpHeight;

	private void Update()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		characterMovement.SetInput(playerInput.moveInput);
		if (playerInput.jumpInput)
		{
			Vector3 targetVelocity = characterMovement.targetVelocity;
			targetVelocity.y = jumpHeight;
			characterMovement.targetVelocity = targetVelocity;
			characterMovement.isGrounded = false;
		}
	}
}
