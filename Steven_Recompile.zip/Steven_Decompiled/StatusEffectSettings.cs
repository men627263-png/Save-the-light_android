using System;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Status Effect Settings")]
public class StatusEffectSettings : ScriptableObject
{
	[SerializeField]
	private StatusEffectData[] _allStatusEffectData;

	[SerializeField]
	private StatusEffectData[] _allCharacterStatBuffData;

	[NonSerialized]
	private Dictionary<StatusEffectName, StatusEffectData> _dataDictionary;

	[NonSerialized]
	private Dictionary<CharacterStatType, StatusEffectData[]> _characterStatBuffDataDictionary;

	private Dictionary<StatusEffectName, StatusEffectData> dataDictionary
	{
		get
		{
			if (_dataDictionary == null)
			{
				_dataDictionary = new Dictionary<StatusEffectName, StatusEffectData>();
				StatusEffectName[] array = (StatusEffectName[])Enum.GetValues(typeof(StatusEffectName));
				for (int i = 0; i < array.Length; i++)
				{
					if (i >= _allStatusEffectData.Length)
					{
						_dataDictionary.Add(array[i], new StatusEffectData());
					}
					else
					{
						_dataDictionary.Add(array[i], _allStatusEffectData[i]);
					}
				}
			}
			return _dataDictionary;
		}
	}

	private Dictionary<CharacterStatType, StatusEffectData[]> characterStatBuffDataDictionary
	{
		get
		{
			if (_characterStatBuffDataDictionary == null)
			{
				_characterStatBuffDataDictionary = new Dictionary<CharacterStatType, StatusEffectData[]>();
				CharacterStatType[] array = (CharacterStatType[])Enum.GetValues(typeof(CharacterStatType));
				for (int i = 0; i < array.Length; i++)
				{
					if (i >= _allCharacterStatBuffData.Length / 2)
					{
						_characterStatBuffDataDictionary.Add(array[i], new StatusEffectData[2]
						{
							new StatusEffectData(),
							new StatusEffectData()
						});
					}
					else
					{
						_characterStatBuffDataDictionary.Add(array[i], new StatusEffectData[2]);
						_characterStatBuffDataDictionary[array[i]][0] = _allCharacterStatBuffData[i * 2];
						_characterStatBuffDataDictionary[array[i]][1] = _allCharacterStatBuffData[i * 2 + 1];
					}
				}
			}
			return _characterStatBuffDataDictionary;
		}
	}

	public StatusEffectData GetData(StatusEffectName statusEffect)
	{
		StatusEffectData value = null;
		dataDictionary.TryGetValue(statusEffect, out value);
		return value;
	}

	public StatusEffectData GetCharacterStatBuffData(CharacterStatType type, bool isBuff)
	{
		StatusEffectData[] value = null;
		characterStatBuffDataDictionary.TryGetValue(type, out value);
		if (value != null)
		{
			return value[(!isBuff) ? 1u : 0u];
		}
		return null;
	}

	public StatusEffectData GetCharacterStatBuffData(CharacterStatType type, float multiplierBonus)
	{
		return GetCharacterStatBuffData(type, Mathf.Sign(multiplierBonus) > 0f);
	}
}
