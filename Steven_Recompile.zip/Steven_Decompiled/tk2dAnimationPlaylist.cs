using System;
using UnityEngine;

[RequireComponent(typeof(tk2dSpriteAnimator))]
public class tk2dAnimationPlaylist : MonoBehaviour
{
	[Serializable]
	public class Entry
	{
		public string clipName;

		public int numLoops;
	}

	[SerializeField]
	private tk2dSpriteAnimator _animator;

	[SerializeField]
	[Tooltip("FPS to use for all clips. Set to 0 to use all clips' default FPS")]
	private float _overrideFPS;

	[SerializeField]
	[Tooltip("If TRUE, the playlist will start playing from the beginning upon this object being enabled")]
	private bool _autoPlay = true;

	[SerializeField]
	[Tooltip("Whether or not to use unscaledDeltaTime when updating the animation every frame")]
	private bool _useUnscaledTime;

	[SerializeField]
	private Entry[] _entries;

	private int curEntryIndex;

	private Entry curEntry;

	private float curClipDuration;

	private int playCounter;

	public tk2dSpriteAnimator animator => _animator;

	public float overrideFPS
	{
		get
		{
			return _overrideFPS;
		}
		set
		{
			_overrideFPS = value;
		}
	}

	public bool autoPlay
	{
		get
		{
			return _autoPlay;
		}
		set
		{
			_autoPlay = value;
		}
	}

	public bool useUnscaledTime
	{
		get
		{
			return _useUnscaledTime;
		}
		set
		{
			_useUnscaledTime = value;
		}
	}

	public event Action Completed;

	public event Action<tk2dAnimationPlaylist> CompletedPlaylist;

	private void Reset()
	{
		_animator = ((Component)this).GetComponent<tk2dSpriteAnimator>();
	}

	private void Awake()
	{
		if ((Object)(object)_animator == (Object)null)
		{
			_animator = ((Component)this).GetComponent<tk2dSpriteAnimator>();
		}
		_animator.playAutomatically = false;
		_animator.Stop();
	}

	private void OnEnable()
	{
		if (autoPlay)
		{
			((Behaviour)_animator).enabled = false;
			curEntryIndex = -1;
			NextEntry();
		}
	}

	private void OnDisable()
	{
		if (_animator.Playing)
		{
			_animator.Stop();
		}
		((Behaviour)_animator).enabled = true;
	}

	private void LateUpdate()
	{
		if (curEntry == null)
		{
			return;
		}
		int currentFrame = _animator.CurrentFrame;
		_animator.UpdateAnimation((!_useUnscaledTime) ? Time.deltaTime : Time.unscaledDeltaTime);
		if (_animator.CurrentClip.wrapMode == tk2dSpriteAnimationClip.WrapMode.Once)
		{
			if (_animator.CurrentFrame >= _animator.CurrentClip.frames.Length)
			{
				playCounter++;
				if (playCounter == curEntry.numLoops)
				{
					NextEntry(_animator.ClipTimeSeconds % curClipDuration);
					return;
				}
				_animator.PlayFrom(_animator.ClipTimeSeconds % curClipDuration);
				_animator.ClipFps = _overrideFPS;
			}
		}
		else if (_animator.CurrentFrame < currentFrame)
		{
			playCounter++;
			if (playCounter == curEntry.numLoops)
			{
				NextEntry(_animator.ClipTimeSeconds % curClipDuration);
			}
		}
	}

	private void NextEntry(float overflow = 0f)
	{
		curEntryIndex++;
		if (curEntryIndex < _entries.Length)
		{
			curEntry = _entries[curEntryIndex];
			_animator.PlayFrom(curEntry.clipName, overflow);
			_animator.ClipFps = _overrideFPS;
			curClipDuration = (float)_animator.CurrentClip.frames.Length / _animator.ClipFps;
			playCounter = 0;
		}
		else
		{
			_animator.Stop();
			curEntry = null;
			OnCompleted();
			OnCompletedPlaylist();
		}
	}

	protected void OnCompleted()
	{
		if (Completed != null)
		{
			Completed();
		}
	}

	protected void OnCompletedPlaylist()
	{
		if (CompletedPlaylist != null)
		{
			CompletedPlaylist(this);
		}
	}
}
