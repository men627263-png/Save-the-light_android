using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.Demos;

[AddComponentMenu("")]
[RequireComponent(typeof(RectTransform))]
public sealed class UIPointer : UIBehaviour
{
	[Tooltip("Should the hardware pointer be hidden?")]
	[SerializeField]
	private bool _hideHardwarePointer = true;

	[Tooltip("Sets the pointer to the last sibling in the parent hierarchy. Do not enable this on multiple UIPointers under the same parent transform or they will constantly fight each other for dominance.")]
	[SerializeField]
	private bool _autoSort = true;

	[NonSerialized]
	private RectTransform _canvasRectTransform;

	public bool autoSort
	{
		get
		{
			return _autoSort;
		}
		set
		{
			if (value != _autoSort)
			{
				_autoSort = value;
				if (value)
				{
					((Component)this).transform.SetAsLastSibling();
				}
			}
		}
	}

	protected override void Awake()
	{
		((UIBehaviour)this).Awake();
		Graphic[] componentsInChildren = ((Component)this).GetComponentsInChildren<Graphic>();
		Graphic[] array = componentsInChildren;
		foreach (Graphic val in array)
		{
			val.raycastTarget = false;
		}
		if (_hideHardwarePointer)
		{
			Cursor.visible = false;
		}
		if (_autoSort)
		{
			((Component)this).transform.SetAsLastSibling();
		}
		GetDependencies();
	}

	private void Update()
	{
		if (_autoSort && ((Component)this).transform.GetSiblingIndex() < ((Component)this).transform.parent.childCount - 1)
		{
			((Component)this).transform.SetAsLastSibling();
		}
	}

	protected override void OnTransformParentChanged()
	{
		((UIBehaviour)this).OnTransformParentChanged();
		GetDependencies();
	}

	protected override void OnCanvasGroupChanged()
	{
		((UIBehaviour)this).OnCanvasGroupChanged();
		GetDependencies();
	}

	public void OnScreenPositionChanged(Vector2 screenPosition)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)_canvasRectTransform == (Object)null))
		{
			Rect rect = _canvasRectTransform.rect;
			Vector2 anchoredPosition = Vector2.op_Implicit(Camera.main.ScreenToViewportPoint(Vector2.op_Implicit(screenPosition)));
			anchoredPosition.x = anchoredPosition.x * rect.width - _canvasRectTransform.pivot.x * rect.width;
			anchoredPosition.y = anchoredPosition.y * rect.height - _canvasRectTransform.pivot.y * rect.height;
			Transform transform = ((Component)this).transform;
			((RectTransform)((transform is RectTransform) ? transform : null)).anchoredPosition = anchoredPosition;
		}
	}

	private void GetDependencies()
	{
		Canvas componentInChildren = ((Component)((Component)this).transform.root).GetComponentInChildren<Canvas>();
		_canvasRectTransform = ((!((Object)(object)componentInChildren != (Object)null)) ? null : ((Component)componentInChildren).GetComponent<RectTransform>());
	}
}
