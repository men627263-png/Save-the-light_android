using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Rewired.Demos;

[AddComponentMenu("")]
public class SimpleControlRemapping : MonoBehaviour
{
	private class Row
	{
		public InputAction action;

		public AxisRange actionRange;

		public Button button;

		public Text text;
	}

	private const string category = "Default";

	private const string layout = "Default";

	private InputMapper inputMapper = new InputMapper();

	public GameObject buttonPrefab;

	public GameObject textPrefab;

	public RectTransform fieldGroupTransform;

	public RectTransform actionGroupTransform;

	public Text controllerNameUIText;

	public Text statusUIText;

	private ControllerType selectedControllerType;

	private int selectedControllerId;

	private List<Row> rows = new List<Row>();

	private Player player => ReInput.players.GetPlayer(0);

	private ControllerMap controllerMap
	{
		get
		{
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			if (controller == null)
			{
				return null;
			}
			return player.controllers.maps.GetMap(controller.type, controller.id, "Default", "Default");
		}
	}

	private Controller controller
	{
		get
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			return player.controllers.GetController(selectedControllerType, selectedControllerId);
		}
	}

	public SimpleControlRemapping()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected Obj, but got Unknown
	}

	private void OnEnable()
	{
		if (ReInput.isReady)
		{
			inputMapper.options.timeout = 5f;
			inputMapper.options.ignoreMouseXAxis = true;
			inputMapper.options.ignoreMouseYAxis = true;
			ReInput.ControllerConnectedEvent += OnControllerChanged;
			ReInput.ControllerDisconnectedEvent += OnControllerChanged;
			inputMapper.InputMappedEvent += OnInputMapped;
			inputMapper.StoppedEvent += OnStopped;
			InitializeUI();
		}
	}

	private void OnDisable()
	{
		inputMapper.Stop();
		inputMapper.RemoveAllEventListeners();
		ReInput.ControllerConnectedEvent -= OnControllerChanged;
		ReInput.ControllerDisconnectedEvent -= OnControllerChanged;
	}

	private void RedrawUI()
	{
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Expected Obj, but got Unknown
		if (controller == null)
		{
			ClearUI();
			return;
		}
		controllerNameUIText.text = controller.name;
		for (int i = 0; i < rows.Count; i++)
		{
			Row row = rows[i];
			InputAction action = rows[i].action;
			string text = string.Empty;
			int actionElementMapId = -1;
			foreach (ActionElementMap item in controllerMap.ElementMapsWithAction(action.id))
			{
				if (item.ShowInField(row.actionRange))
				{
					text = item.elementIdentifierName;
					actionElementMapId = item.id;
					break;
				}
			}
			row.text.text = text;
			((UnityEventBase)row.button.onClick).RemoveAllListeners();
			int index = i;
			((UnityEvent)row.button.onClick).AddListener((UnityAction)(() =>
			{
				OnInputFieldClicked(index, actionElementMapId);
			}));
		}
	}

	private void ClearUI()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		if ((int)selectedControllerType == 2)
		{
			controllerNameUIText.text = "No joysticks attached";
		}
		else
		{
			controllerNameUIText.text = string.Empty;
		}
		for (int i = 0; i < rows.Count; i++)
		{
			rows[i].text.text = string.Empty;
		}
	}

	private void InitializeUI()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Expected Obj, but got Unknown
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Expected Obj, but got Unknown
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Invalid comparison between Unknown and I4
		foreach (Transform item in (Transform)actionGroupTransform)
		{
			Transform val = item;
			Object.Destroy((Object)(object)((Component)val).gameObject);
		}
		foreach (Transform item2 in (Transform)fieldGroupTransform)
		{
			Transform val2 = item2;
			Object.Destroy((Object)(object)((Component)val2).gameObject);
		}
		foreach (InputAction action in ReInput.mapping.Actions)
		{
			if ((int)action.type == 0)
			{
				CreateUIRow(action, (AxisRange)0, action.descriptiveName);
				CreateUIRow(action, (AxisRange)1, string.IsNullOrEmpty(action.positiveDescriptiveName) ? (action.descriptiveName + " +") : action.positiveDescriptiveName);
				CreateUIRow(action, (AxisRange)2, string.IsNullOrEmpty(action.negativeDescriptiveName) ? (action.descriptiveName + " -") : action.negativeDescriptiveName);
			}
			else if ((int)action.type == 1)
			{
				CreateUIRow(action, (AxisRange)1, action.descriptiveName);
			}
		}
		RedrawUI();
	}

	private void CreateUIRow(InputAction action, AxisRange actionRange, string label)
	{
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = Object.Instantiate<GameObject>(textPrefab);
		val.transform.SetParent((Transform)(object)actionGroupTransform);
		val.transform.SetAsLastSibling();
		val.GetComponent<Text>().text = label;
		GameObject val2 = Object.Instantiate<GameObject>(buttonPrefab);
		val2.transform.SetParent((Transform)(object)fieldGroupTransform);
		val2.transform.SetAsLastSibling();
		rows.Add(new Row
		{
			action = action,
			actionRange = actionRange,
			button = val2.GetComponent<Button>(),
			text = val2.GetComponentInChildren<Text>()
		});
	}

	private void SetSelectedController(ControllerType controllerType)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Invalid comparison between Unknown and I4
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		if (controllerType != selectedControllerType)
		{
			selectedControllerType = controllerType;
			flag = true;
		}
		int num = selectedControllerId;
		if ((int)selectedControllerType == 2)
		{
			if (player.controllers.joystickCount > 0)
			{
				selectedControllerId = ((Controller)player.controllers.Joysticks[0]).id;
			}
			else
			{
				selectedControllerId = -1;
			}
		}
		else
		{
			selectedControllerId = 0;
		}
		if (selectedControllerId != num)
		{
			flag = true;
		}
		if (flag)
		{
			inputMapper.Stop();
			RedrawUI();
		}
	}

	public void OnControllerSelected(int controllerType)
	{
		SetSelectedController((ControllerType)controllerType);
	}

	private void OnInputFieldClicked(int index, int actionElementMapToReplaceId)
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Expected Obj, but got Unknown
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (index >= 0 && index < rows.Count && controller != null)
		{
			InputMapper val = inputMapper;
			Context val2 = new Context();
			val2.actionId = rows[index].action.id;
			val2.controllerMap = controllerMap;
			val2.actionRange = rows[index].actionRange;
			val2.actionElementMapToReplace = controllerMap.GetElementMap(actionElementMapToReplaceId);
			val.Start(val2);
			statusUIText.text = "Listening...";
		}
	}

	private void OnControllerChanged(ControllerStatusChangedEventArgs args)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		SetSelectedController(selectedControllerType);
	}

	private void OnInputMapped(InputMappedEventData data)
	{
		RedrawUI();
	}

	private void OnStopped(StoppedEventData data)
	{
		statusUIText.text = string.Empty;
	}
}
