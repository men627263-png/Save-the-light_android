using UnityEngine;

namespace Rewired.Demos;

[AddComponentMenu("")]
[RequireComponent(typeof(CharacterController))]
public class CustomControllerDemo_Player : MonoBehaviour
{
	public int playerId;

	public float speed = 1f;

	public float bulletSpeed = 20f;

	public GameObject bulletPrefab;

	private Player _player;

	private CharacterController cc;

	private Player player
	{
		get
		{
			if (_player == null)
			{
				_player = ReInput.players.GetPlayer(playerId);
			}
			return _player;
		}
	}

	private void Awake()
	{
		cc = ((Component)this).GetComponent<CharacterController>();
	}

	private void Update()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		if (ReInput.isReady)
		{
			Vector2 val = new Vector2(player.GetAxis("Move Horizontal"), player.GetAxis("Move Vertical"));
			cc.Move(Vector2.op_Implicit(val * speed * Time.deltaTime));
			if (player.GetButtonDown("Fire"))
			{
				Vector3 val2 = Vector3.Scale(new Vector3(1f, 0f, 0f), ((Component)this).transform.right);
				GameObject val3 = Object.Instantiate<GameObject>(bulletPrefab, ((Component)this).transform.position + val2, Quaternion.identity);
				val3.GetComponent<Rigidbody>().velocity = new Vector3(bulletSpeed * ((Component)this).transform.right.x, 0f, 0f);
			}
			if (player.GetButtonDown("Change Color"))
			{
				Renderer component = ((Component)this).GetComponent<Renderer>();
				Material material = component.material;
				material.color = new Color(Random.Range(0f, 1f), Random.Range(0f, 1f), Random.Range(0f, 1f), 1f);
				component.material = material;
			}
		}
	}
}
