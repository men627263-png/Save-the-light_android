using UnityEngine;

public class PeridotContraptionBattlefieldBounds : MonoBehaviour
{
	private Renderer mainRenderer;

	private float _alpha;

	public float alpha
	{
		get
		{
			return _alpha;
		}
		set
		{
			SetAlpha(value);
		}
	}

	private void Awake()
	{
		mainRenderer = ((Component)this).GetComponent<Renderer>();
	}

	public void SetAlpha(float newAlpha)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		_alpha = newAlpha;
		Color color = mainRenderer.material.color;
		color.a = _alpha;
		mainRenderer.material.color = color;
	}
}
