public class RemoveThreatEvent : GameEvent
{
	public ITargetable source { get; private set; }

	public int amount { get; private set; }

	public BaseCharacter character { get; private set; }

	public RemoveThreatEvent(ITargetable source, int amount, BaseCharacter character = null)
	{
		this.source = source;
		this.amount = amount;
		this.character = character;
	}
}
