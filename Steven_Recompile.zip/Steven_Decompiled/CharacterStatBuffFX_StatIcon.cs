using UnityEngine;

public class CharacterStatBuffFX_StatIcon : MonoBehaviour
{
	public Animator animator;

	public AnimatorEventListener animatorEventListener;

	public MeshRenderer iconMeshRenderer;

	public Transform scaleGroup;

	public ParticleSystem arrowsUpPS;

	public ParticleSystem arrowsDownPS;

	private void Awake()
	{
		((Component)arrowsUpPS).gameObject.SetActive(false);
		((Component)arrowsDownPS).gameObject.SetActive(false);
	}

	public void Show(bool isBuff)
	{
		((Component)this).gameObject.SetActive(true);
		((Component)arrowsDownPS).gameObject.SetActive(!isBuff);
		((Component)arrowsUpPS).gameObject.SetActive(isBuff);
		animator.Play("intro", 0, 0f);
	}

	public void Hide()
	{
		animator.Play("outro");
		((Component)arrowsUpPS).gameObject.SetActive(false);
		((Component)arrowsDownPS).gameObject.SetActive(false);
	}
}
