using System;
using System.Collections.Generic;
using UnityEngine;

public class CharacterStat
{
	private List<CharacterStatModifier> _modifiers;

	private int _statModValue;

	public int BaseValue { get; set; }

	public int Value => BaseValue + StatModifierValue;

	public int StatModifierValue => _statModValue;

	public event Action ValueChanged;

	public CharacterStat()
	{
		_modifiers = new List<CharacterStatModifier>();
	}

	public CharacterStat(int baseValue)
	{
		BaseValue = baseValue;
		_modifiers = new List<CharacterStatModifier>();
	}

	public void AddModifier(CharacterStatModifier modifier)
	{
		if (!_modifiers.Contains(modifier))
		{
			_modifiers.Add(modifier);
			UpdateModifiers();
		}
	}

	public void RemoveModifier(CharacterStatModifier modifier)
	{
		for (int num = _modifiers.Count - 1; num >= 0; num--)
		{
			if (_modifiers[num].Equals(modifier))
			{
				_modifiers.RemoveAt(num);
				UpdateModifiers();
				break;
			}
		}
	}

	public void RemoveModifier(string id)
	{
		if (string.IsNullOrEmpty(id))
		{
			return;
		}
		for (int num = _modifiers.Count - 1; num >= 0; num--)
		{
			if (_modifiers[num].ID.Equals(id))
			{
				_modifiers.RemoveAt(num);
			}
		}
		UpdateModifiers();
	}

	public void RemoveAllModifiers()
	{
		_modifiers.Clear();
		UpdateModifiers();
	}

	public void RemoveAllModifiersByType(CharacterStatType statType)
	{
		for (int num = _modifiers.Count - 1; num >= 0; num--)
		{
			if (_modifiers[num].StatType.Equals(statType))
			{
				_modifiers.RemoveAt(num);
			}
		}
		UpdateModifiers();
	}

	public bool HasModifier(string id)
	{
		if (string.IsNullOrEmpty(id))
		{
			return false;
		}
		for (int i = 0; i < _modifiers.Count; i++)
		{
			if (_modifiers[i].ID.Equals(id))
			{
				return true;
			}
		}
		return false;
	}

	private void UpdateModifiers()
	{
		_statModValue = 0;
		float num = 0f;
		float num2 = 0f;
		float num3 = 0f;
		float num4 = 0f;
		CharacterStatModifier characterStatModifier = null;
		for (int i = 0; i < _modifiers.Count; i++)
		{
			characterStatModifier = _modifiers[i];
			switch (characterStatModifier.Type)
			{
			case CharacterStatModifier.Types.BaseValuePercent:
				num += characterStatModifier.Value;
				break;
			case CharacterStatModifier.Types.BaseValueAdd:
				num2 += characterStatModifier.Value;
				break;
			case CharacterStatModifier.Types.TotalValuePercent:
				num3 += characterStatModifier.Value;
				break;
			case CharacterStatModifier.Types.TotalValueAdd:
				num4 += characterStatModifier.Value;
				break;
			}
		}
		_statModValue = Mathf.RoundToInt((float)BaseValue * num + num2);
		_statModValue += Mathf.RoundToInt((float)Value * num3 + num4);
		OnValueChanged();
	}

	protected void OnValueChanged()
	{
		if (ValueChanged != null)
		{
			ValueChanged();
		}
	}
}
