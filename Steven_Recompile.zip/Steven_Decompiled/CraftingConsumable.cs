using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class CraftingConsumable : ItemDefinition, IBackpackItem
{
	[SerializeField]
	protected CraftingItemType _craftingItemType;

	[SerializeField]
	protected List<CraftingRequirement> _craftingRequirements;

	[SerializeField]
	protected int _weaponToCraft;

	[SerializeField]
	protected int _weaponUpgradeToCraft;

	[SerializeField]
	protected CharacterName _targetCharacter;

	[SerializeField]
	protected Sprite _schematicWeaponSprite;

	[SerializeField]
	protected Sprite _forgeSprite;

	public CraftingItemType craftingItemType
	{
		get
		{
			return _craftingItemType;
		}
		set
		{
			_craftingItemType = value;
		}
	}

	public List<CraftingRequirement> craftingRequirements
	{
		get
		{
			if (_craftingRequirements == null)
			{
				_craftingRequirements = new List<CraftingRequirement>();
			}
			return _craftingRequirements;
		}
		set
		{
			_craftingRequirements = value;
		}
	}

	public int weaponToCraft
	{
		get
		{
			return _weaponToCraft;
		}
		set
		{
			_weaponToCraft = value;
		}
	}

	public int weaponUpgradeToCraft
	{
		get
		{
			return _weaponUpgradeToCraft;
		}
		set
		{
			_weaponUpgradeToCraft = value;
		}
	}

	public CharacterName targetCharacter
	{
		get
		{
			return _targetCharacter;
		}
		set
		{
			_targetCharacter = value;
		}
	}

	public Sprite schematicWeaponSprite
	{
		get
		{
			return _schematicWeaponSprite;
		}
		set
		{
			_schematicWeaponSprite = value;
		}
	}

	public Sprite forgeSprite
	{
		get
		{
			return _forgeSprite;
		}
		set
		{
			_forgeSprite = value;
		}
	}
}
