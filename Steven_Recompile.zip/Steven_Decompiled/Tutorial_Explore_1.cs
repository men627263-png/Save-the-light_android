using System.Collections;
using UnityEngine;

public class Tutorial_Explore_1 : MonoBehaviour
{
	public int minBattlesToTrigger = 3;

	private bool startedTutorial;

	private float screenCoverFadeTime = 0.3f;

	private void OnEnable()
	{
		((MonoBehaviour)this).StartCoroutine("StartExploreTutorial1");
	}

	private void OnDisable()
	{
		((MonoBehaviour)this).StopCoroutine("StartExploreTutorial1");
		EventMessenger.Instance.RemoveListener<PauseEvent>(HandlePauseEvent);
	}

	private IEnumerator StartExploreTutorial1()
	{
		while (true && !startedTutorial)
		{
			if (GameController.Instance.CurrentState.Equals(GameControllerState.Exploration_Waiting))
			{
				GamePlayEventData gameplayEventData = PlayerGameState.Instance.GetGamePlayEventData(21);
				if (gameplayEventData != null && gameplayEventData.currentCount >= minBattlesToTrigger)
				{
					for (int i = 0; i < GameController.Instance.party.Count; i++)
					{
						PlayerCharacter character = GameController.Instance.party[i];
						if (character.currentHealthRatio < 1f && !startedTutorial)
						{
							yield return ((MonoBehaviour)this).StartCoroutine(StartCookieCatTutorial(character));
							PlayerGameState.Instance.TriggerGamePlayEvent(64, GamePlayEventState.Complete);
							yield break;
						}
					}
				}
			}
			yield return null;
		}
	}

	private IEnumerator StartCookieCatTutorial(PlayerCharacter character)
	{
		yield return (object)new WaitForEndOfFrame();
		yield return (object)new WaitForEndOfFrame();
		while (GameController.Instance.isFSMActive)
		{
			yield return null;
		}
		while (!TutorialController.instance.canRunTutorial)
		{
			yield return null;
		}
		startedTutorial = true;
		TutorialController.instance.isTutorialRunning = true;
		yield return new WaitForDialogue();
		GameController.Instance.SetMapsEnabled(state: false, "Game");
		EventMessenger.Instance.AddListener<PauseEvent>(HandlePauseEvent);
		UIBottomScreenCover.Instance.FadeIn(screenCoverFadeTime, 0f, 0.5f);
		UIScreenText.instance.DisplayText(Languages.Get("OUTSIDE_BATTLE_1", "TUTORIALS, PROMPTS").Replace("{0}", ControlsUtility.GetSpriteTagForGameButton(UIGamepadButtonType.FaceButtonTop)), UIScreenTextAnchor.TopCenter);
		UIPointerArrow.instance.PointTo(Vector2.op_Implicit(new Vector3(((Component)UICheeseburgerBackpack.instance).gameObject.transform.localPosition.x, -320f, ((Component)UICheeseburgerBackpack.instance).gameObject.transform.localPosition.z)));
		GameController.Instance.preventCharacterScreenUse = true;
		PlayerGameState.Instance.CollectItem(0, 1, save: false);
		UICheeseburgerBackpack.instance.ShowBackpack();
		UICheeseburgerBackpack.instance.SetBackpackEnabled(enabled: true);
		UICheeseburgerBackpack.instance.PreventBackpackUse(preventBackpackUse: false);
		yield return new WaitForPlayerInput("UIMenu");
		GameController.Instance.preventExploreBackOut = true;
		UIPointerArrow.instance.Hide();
		UIScreenText.instance.DisplayText(Languages.Get("OUTSIDE_BATTLE_2", "TUTORIALS, PROMPTS"), UIScreenTextAnchor.TopCenter);
		yield return new WaitForPlayerInput("UISubmit");
		UIScreenText.instance.Hide();
		UIBottomScreenCover.Instance.FadeOut(screenCoverFadeTime, 0f);
		yield return new WaitForGameState(GameControllerState.Exploration_Waiting);
		GameController.Instance.preventExploreBackOut = false;
		GameController.Instance.preventCharacterScreenUse = false;
		GameController.Instance.SetMapsEnabled(state: true, "Game");
		EventMessenger.Instance.RemoveListener<PauseEvent>(HandlePauseEvent);
		yield return null;
		TutorialController.instance.isTutorialRunning = false;
	}

	private void HandlePauseEvent(PauseEvent evt)
	{
		if (!evt.isPaused)
		{
			GameController.Instance.SetMapsEnabled(state: false, "Game");
		}
	}
}
