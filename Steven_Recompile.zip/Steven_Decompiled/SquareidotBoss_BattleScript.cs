using System;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Battle Scripts/Squareidot Boss")]
public class SquareidotBoss_BattleScript : BattleScript
{
	[Serializable]
	public class BattleStageInfo
	{
		public float healthThreshold;

		public SquareidotShipBrain battleBrain;

		public float landedDuration;

		public int landedDamageLimit;

		public BattleStageInfo()
		{
			healthThreshold = 1f;
			landedDuration = 5f;
			landedDamageLimit = 10;
			battleBrain = null;
		}
	}

	[SerializeField]
	private BattleStageInfo[] _stages;

	[NonSerialized]
	private SquareidotShip squareidotShip;

	[NonSerialized]
	private int activeStageIndex;

	[NonSerialized]
	private BattleStageInfo activeStage;

	[NonSerialized]
	private BattleStageInfo nextStage;

	public override void OnInit()
	{
		squareidotShip = Object.FindObjectOfType<SquareidotShip>();
		if (_stages == null || _stages.Length == 0)
		{
			_stages = new BattleStageInfo[1]
			{
				new BattleStageInfo()
			};
		}
		activeStageIndex = 0;
		activeStage = _stages[activeStageIndex];
		if (_stages.Length > 1)
		{
			nextStage = _stages[1];
		}
	}

	public override void Update()
	{
		while (nextStage != null && squareidotShip.currentHealthRatio <= nextStage.healthThreshold)
		{
			activeStage = nextStage;
			activeStageIndex++;
			if ((Object)(object)activeStage.battleBrain != (Object)null)
			{
				squareidotShip.activeBattleBrain = activeStage.battleBrain;
			}
			squareidotShip.characterProperties.landedDuration = activeStage.landedDuration;
			squareidotShip.characterProperties.landedDamageLimit = activeStage.landedDamageLimit;
			nextStage = ((activeStageIndex + 1 >= _stages.Length) ? null : _stages[activeStageIndex + 1]);
		}
	}

	public override void OnBattleStarted()
	{
		if ((Object)(object)activeStage.battleBrain != (Object)null)
		{
			squareidotShip.activeBattleBrain = activeStage.battleBrain;
		}
		squareidotShip.characterProperties.landedDuration = activeStage.landedDuration;
		squareidotShip.characterProperties.landedDamageLimit = activeStage.landedDamageLimit;
		EventMessenger.Instance.AddListener<StartLoadingSceneEvent>(HandleStartLoadingSceneEvent);
	}

	public override void OnBattleFinished()
	{
		EventMessenger.Instance.RemoveListener<StartLoadingSceneEvent>(HandleStartLoadingSceneEvent);
	}

	private void HandleStartLoadingSceneEvent(StartLoadingSceneEvent evt)
	{
		EventMessenger.Instance.RemoveListener<StartLoadingSceneEvent>(HandleStartLoadingSceneEvent);
	}
}
