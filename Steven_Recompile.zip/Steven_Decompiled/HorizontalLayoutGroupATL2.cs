using System;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class HorizontalLayoutGroupATL2 : HorizontalLayoutGroup
{
	public Action TweensFinished;

	public float moveSpeed = 250f;

	public float tweenTime = 0.5f;

	private bool justEnabled;

	private Dictionary<RectTransform, Tweener> rectTweens = new Dictionary<RectTransform, Tweener>();

	public bool allowAutoLayout { get; set; }

	protected override void OnEnable()
	{
		((LayoutGroup)this).OnEnable();
		justEnabled = true;
		allowAutoLayout = true;
	}

	public override void SetLayoutHorizontal()
	{
		if (allowAutoLayout)
		{
			SetChildrenAlongAxis_Custom(0, isVertical: false);
		}
	}

	private void SetChildrenAlongAxis_Custom(int axis, bool isVertical)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = ((LayoutGroup)this).rectTransform.rect;
		Vector2 size = rect.size;
		float num = size[axis];
		if (isVertical ^ (axis == 1))
		{
			float num2 = num - (float)((axis != 0) ? ((LayoutGroup)this).padding.vertical : ((LayoutGroup)this).padding.horizontal);
			for (int i = 0; i < ((LayoutGroup)this).rectChildren.Count; i++)
			{
				RectTransform val = ((LayoutGroup)this).rectChildren[i];
				float minSize = LayoutUtility.GetMinSize(val, axis);
				float preferredSize = LayoutUtility.GetPreferredSize(val, axis);
				float num3 = LayoutUtility.GetFlexibleSize(val, axis);
				if ((axis != 0) ? ((HorizontalOrVerticalLayoutGroup)this).childForceExpandHeight : ((HorizontalOrVerticalLayoutGroup)this).childForceExpandWidth)
				{
					num3 = Mathf.Max(num3, 1f);
				}
				float num4 = Mathf.Clamp(num2, minSize, (!(num3 > 0f)) ? preferredSize : num);
				float startOffset = ((LayoutGroup)this).GetStartOffset(axis, num4);
				((LayoutGroup)this).SetChildAlongAxis(val, axis, startOffset, num4);
			}
			return;
		}
		float num5 = ((axis != 0) ? ((LayoutGroup)this).padding.top : ((LayoutGroup)this).padding.left);
		if (((LayoutGroup)this).GetTotalFlexibleSize(axis) == 0f && ((LayoutGroup)this).GetTotalPreferredSize(axis) < num)
		{
			num5 = ((LayoutGroup)this).GetStartOffset(axis, ((LayoutGroup)this).GetTotalPreferredSize(axis) - (float)((axis != 0) ? ((LayoutGroup)this).padding.vertical : ((LayoutGroup)this).padding.horizontal));
		}
		float num6 = 0f;
		if (((LayoutGroup)this).GetTotalMinSize(axis) != ((LayoutGroup)this).GetTotalPreferredSize(axis))
		{
			num6 = Mathf.Clamp01((num - ((LayoutGroup)this).GetTotalMinSize(axis)) / (((LayoutGroup)this).GetTotalPreferredSize(axis) - ((LayoutGroup)this).GetTotalMinSize(axis)));
		}
		float num7 = 0f;
		if (num > ((LayoutGroup)this).GetTotalPreferredSize(axis) && ((LayoutGroup)this).GetTotalFlexibleSize(axis) > 0f)
		{
			num7 = (num - ((LayoutGroup)this).GetTotalPreferredSize(axis)) / ((LayoutGroup)this).GetTotalFlexibleSize(axis);
		}
		for (int j = 0; j < ((LayoutGroup)this).rectChildren.Count; j++)
		{
			RectTransform val2 = ((LayoutGroup)this).rectChildren[j];
			float minSize2 = LayoutUtility.GetMinSize(val2, axis);
			float preferredSize2 = LayoutUtility.GetPreferredSize(val2, axis);
			float num8 = LayoutUtility.GetFlexibleSize(val2, axis);
			if ((axis != 0) ? ((HorizontalOrVerticalLayoutGroup)this).childForceExpandHeight : ((HorizontalOrVerticalLayoutGroup)this).childForceExpandWidth)
			{
				num8 = Mathf.Max(num8, 1f);
			}
			float num9 = Mathf.Lerp(minSize2, preferredSize2, num6);
			num9 += num8 * num7;
			SetChildAlongAxis_Custom(val2, axis, num5, num9);
			num5 += num9 + ((HorizontalOrVerticalLayoutGroup)this).spacing;
		}
		justEnabled = false;
	}

	protected void SetChildAlongAxis_Custom(RectTransform rect, int axis, float pos, float size)
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Expected Obj, but got Unknown
		if ((Object)(object)rect == (Object)null)
		{
			return;
		}
		((LayoutGroup)this).m_Tracker.Add((Object)(object)this, rect, (DrivenTransformProperties)16134);
		if (Application.isPlaying && !justEnabled)
		{
			Vector3 position = ((Transform)rect).position;
			rect.SetInsetAndSizeFromParentEdge((Edge)((axis != 0) ? 2 : 0), pos, size);
			Vector3 position2 = ((Transform)rect).position;
			((Transform)rect).position = position;
			Tweener value = TweenSettingsExtensions.OnComplete<Tweener>(TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOMove((Transform)(object)rect, position2, tweenTime, false), (Ease)19), (TweenCallback)(() =>
			{
				rectTweens.Remove(rect);
				RectTweenFinished();
			}));
			if (!rectTweens.ContainsKey(rect))
			{
				rectTweens.Add(rect, value);
			}
		}
		else
		{
			rect.SetInsetAndSizeFromParentEdge((Edge)((axis != 0) ? 2 : 0), pos, size);
		}
	}

	private void RectTweenFinished()
	{
		if (rectTweens.Count == 0 && TweensFinished != null)
		{
			TweensFinished();
		}
	}
}
