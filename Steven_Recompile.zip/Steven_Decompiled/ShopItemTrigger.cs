using System.Collections;
using System.Collections.Generic;
using Grumpyface;
using UnityEngine;

public class ShopItemTrigger : MonoBehaviour
{
	public List<ShopItem> shopItems = new List<ShopItem>();

	public Vector3 itemPosition;

	public Vector3 extraShopItemBoxOffset = Vector3.zero;

	private static float lastTriggerStay;

	private int itemUID;

	private int itemCount;

	private int itemDiscount;

	private ShopItem chosenShopItem;

	private bool itemAvailable;

	public PlayerCharacter currentPlayer;

	private bool showingItem;

	private Shop _shopParent;

	private List<ItemPickup> items = new List<ItemPickup>();

	private Shop shopParent
	{
		get
		{
			if ((Object)(object)_shopParent == (Object)null)
			{
				_shopParent = ((Component)this).GetComponentInParent<Shop>();
			}
			return _shopParent;
		}
	}

	public ItemPickup item
	{
		get
		{
			if (items.Count > 0)
			{
				return items[0];
			}
			return null;
		}
	}

	public ShopItemTrigger()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Awake()
	{
		PlayerGameState.Instance.PlayerDataChanged += HandlePlayerDataChanged;
		GameController.Instance.PartyLeaderChanged += HandlePartyLeaderChanged;
		HandlePlayerDataChanged();
	}

	private IEnumerator Start()
	{
		yield return (object)new WaitForEndOfFrame();
		DialogueSystemListener.Instance.OnConversationStartEvent += HandleConversationStart;
		DialogueSystemListener.Instance.OnConversationEndEvent += HandleConversationEnd;
		EventMessenger.Instance.AddListener<InstigateBattleEvent>(HandleInstigateBattleEvent);
	}

	private void OnDestroy()
	{
		PlayerGameState.Instance.PlayerDataChanged -= HandlePlayerDataChanged;
		GameController.Instance.PartyLeaderChanged -= HandlePartyLeaderChanged;
		DialogueSystemListener.Instance.OnConversationStartEvent -= HandleConversationStart;
		DialogueSystemListener.Instance.OnConversationEndEvent -= HandleConversationEnd;
		EventMessenger.Instance.RemoveListener<InstigateBattleEvent>(HandleInstigateBattleEvent);
	}

	private void HandlePlayerDataChanged()
	{
		ChooseItem();
	}

	private void HandleConversationStart(string conversationName)
	{
		if (showingItem)
		{
			HideItem();
		}
	}

	private void HandleConversationEnd(string conversationName)
	{
	}

	private void Update()
	{
		if (showingItem && DialogueSystemListener.Instance.isDialoguePlaying)
		{
			HideItem();
		}
	}

	public void RecreateItem()
	{
		ChooseItem();
	}

	private void ChooseItem()
	{
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0284: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_0304: Unknown result type (might be due to invalid IL or missing references)
		//IL_0309: Unknown result type (might be due to invalid IL or missing references)
		int count = items.Count;
		for (int i = 0; i < count; i++)
		{
			if ((Object)(object)items[i] != (Object)null)
			{
				ObjectPool.PoolObject(((Component)items[i]).gameObject, instant: true);
			}
		}
		if (shopItems.Count <= 0)
		{
			return;
		}
		int num = -1;
		for (int j = 0; j < shopItems.Count; j++)
		{
			ShopItem shopItem = shopItems[j];
			bool flag = true;
			if (shopItem.gameEventRequired)
			{
				GamePlayEventData gamePlayEventData = PlayerGameState.Instance.GetGamePlayEventData(shopItem.gameEventUID);
				if (gamePlayEventData == null || (gamePlayEventData != null && !gamePlayEventData.currentState.Equals(shopItem.gameEventState)))
				{
					flag = false;
				}
			}
			if (shopItem.isUnique && PlayerGameState.Instance.HasPurchasedShopItem(shopItem.guid) && !shopItem.backupItemAvailable)
			{
				flag = false;
			}
			if (flag)
			{
				num = j;
			}
		}
		if (num <= -1)
		{
			return;
		}
		chosenShopItem = shopItems[num];
		if (chosenShopItem.isUnique && PlayerGameState.Instance.HasPurchasedShopItem(chosenShopItem.guid))
		{
			itemUID = chosenShopItem.backupItemUID;
			itemCount = chosenShopItem.backupItemCount;
			itemDiscount = chosenShopItem.backupItemBundleDiscount;
		}
		else
		{
			itemUID = chosenShopItem.itemUID;
			itemCount = chosenShopItem.itemCount;
			itemDiscount = chosenShopItem.itemBundleDiscount;
		}
		ItemDefinition itemDefinition = GameController.Instance.itemDatabase.GetItem(itemUID);
		Vector3 val = Vector3.zero;
		int num2 = ((GameResources.instance.gameSettings.shopItemSetupPositions == null) ? 1 : GameResources.instance.gameSettings.shopItemSetupPositions.Length);
		if ((Object)(object)itemDefinition != (Object)null && (Object)(object)itemDefinition.prefabObject != (Object)null)
		{
			for (int k = 0; k < itemCount; k++)
			{
				if (items.Count >= num2)
				{
					continue;
				}
				ItemPickup itemPickup = ObjectPool.GetObject<ItemPickup>(itemDefinition.prefabObject, default(Vector3), true);
				itemPickup.MakeShopItem(shopItem: true);
				((Component)itemPickup).transform.position = ((Component)this).transform.position + itemPosition;
				((Component)itemPickup).transform.parent = ((Component)this).transform;
				itemAvailable = true;
				if ((Object)(object)shopParent != (Object)null && shopParent.hideShopItemShadow)
				{
					Projector componentInChildren = ((Component)itemPickup).GetComponentInChildren<Projector>();
					if ((Object)(object)componentInChildren != (Object)null)
					{
						((Component)componentInChildren).gameObject.SetActive(false);
						((Behaviour)componentInChildren).enabled = false;
					}
				}
				if (num2 > 1)
				{
					val = GetSettingsItemOffset(k, itemCount);
				}
				((Component)itemPickup).transform.position = ((Component)itemPickup).transform.position + val;
				items.Add(itemPickup);
			}
			((Component)this).GetComponent<Collider>().enabled = true;
		}
		else
		{
			itemAvailable = false;
		}
	}

	private Vector3 GetSettingsItemOffset(int itemNumber, int setupLength)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		Vector3 zero = Vector3.zero;
		int num = GameResources.instance.gameSettings.shopItemSetupPositions.Length;
		for (int i = 0; i < num; i++)
		{
			if (i != setupLength - 1)
			{
				continue;
			}
			int num2 = GameResources.instance.gameSettings.shopItemSetupPositions[i].itemOffsets.Length;
			for (int j = 0; j < num2; j++)
			{
				if (itemNumber == j)
				{
					return GameResources.instance.gameSettings.shopItemSetupPositions[i].itemOffsets[j];
				}
			}
		}
		return zero;
	}

	private void OnTriggerStay(Collider other)
	{
		if (!((Object)(object)GameController.Instance == (Object)null) && !GameController.Instance.inBattle && !GameController.Instance.CurrentState.Equals(GameControllerState.Exploration_TransitioningToBattle) && Time.time - lastTriggerStay > 0.5f && !DialogueSystemListener.Instance.isDialoguePlaying)
		{
			lastTriggerStay = Time.time;
			if ((!showingItem || !UIShopItemBox.Instance.ShowingItem) && ((object)((Component)other).gameObject).Equals((object?)((Component)GameController.Instance.partyLeader).gameObject) && itemAvailable)
			{
				ShowItemBox();
				currentPlayer = GameController.Instance.partyLeader;
			}
		}
	}

	private void OnTriggerExit(Collider other)
	{
		if (!((Object)(object)GameController.Instance == (Object)null) && !GameController.Instance.inBattle && !GameController.Instance.CurrentState.Equals(GameControllerState.Exploration_TransitioningToBattle) && (Object)(object)currentPlayer != (Object)null && ((object)((Component)other).gameObject).Equals((object?)((Component)currentPlayer).gameObject))
		{
			HideItem();
			currentPlayer = null;
		}
	}

	private void HandlePartyLeaderChanged()
	{
		if ((Object)(object)currentPlayer != (Object)null && (Object)(object)GameController.Instance.partyLeader != (Object)(object)currentPlayer)
		{
			HideItem();
			currentPlayer = null;
		}
	}

	private void ShowItemBox()
	{
		if (!showingItem || (!UIShopItemBox.Instance.ShowingItem && (Object)(object)GameController.Instance.currentStageInteractable == (Object)null))
		{
			showingItem = true;
			if ((Object)(object)UIShopItemBox.Instance != (Object)null)
			{
				UIShopItemBox.Instance.ShowItem(this, GameController.Instance.itemDatabase.GetItem(itemUID), itemCount, (itemCount > 1) ? itemDiscount : 0);
			}
		}
	}

	private void HideItem()
	{
		if (showingItem)
		{
			showingItem = false;
			if ((Object)(object)UIShopItemBox.Instance != (Object)null)
			{
				UIShopItemBox.Instance.Hide(this);
			}
		}
	}

	public void PurchasedItem()
	{
		int count = items.Count;
		for (int i = 0; i < count; i++)
		{
			if ((Object)(object)items[i] != (Object)null)
			{
				((Component)items[i]).gameObject.SetActive(false);
			}
		}
		((Component)this).GetComponent<Collider>().enabled = false;
		if (chosenShopItem != null)
		{
			if (chosenShopItem.isUnique && !string.IsNullOrEmpty(chosenShopItem.guid))
			{
				PlayerGameState.Instance.PurchasedShopItem(chosenShopItem.guid);
			}
			if ((Object)(object)item != (Object)null)
			{
				GamePlayEventDefinition gamePlayEventDefinition = GameController.Instance.gameplayDatabase.GetEvent(item.eventUID);
				if ((Object)(object)gamePlayEventDefinition != (Object)null)
				{
					PlayMakerFSM.BroadcastEvent(gamePlayEventDefinition.eventName);
				}
			}
		}
		itemAvailable = false;
	}

	public void PlayRevealAnimation()
	{
		((MonoBehaviour)this).StartCoroutine("StartPlayRevealAnimation");
	}

	private IEnumerator StartPlayRevealAnimation()
	{
		int len = items.Count;
		for (int i = 0; i < len; i++)
		{
			if ((Object)(object)items[i] != (Object)null)
			{
				items[i].PlayRevealAnimation();
			}
			yield return (object)new WaitForSeconds(0.008f);
		}
		yield return null;
	}

	private void HandleInstigateBattleEvent(InstigateBattleEvent evt)
	{
		if ((Object)(object)currentPlayer != (Object)null)
		{
			HideItem();
		}
	}

	private void OnDrawGizmos()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		Gizmos.color = Color.red;
		Gizmos.DrawSphere(((Component)this).transform.position + itemPosition, 0.25f);
		Gizmos.color = Color.white;
	}
}
