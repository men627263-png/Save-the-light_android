public class CameraZoomEventOOB : GameEvent
{
	public float zoomFactor { get; private set; }

	public CameraZoomEventOOB(float zoomFactor)
	{
		this.zoomFactor = zoomFactor;
	}
}
