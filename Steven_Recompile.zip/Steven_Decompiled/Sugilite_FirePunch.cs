using System;
using System.Collections;
using DG.Tweening;
using Grumpyface;
using UnityEngine;
using UnityEngine.UI;

public class Sugilite_FirePunch : BaseAbility
{
	[Serializable]
	private class FillBarSettings
	{
		public float duration = 5f;

		[MinMaxRange(0, 1)]
		public RangedFloat sweetSpotPositionRange = new RangedFloat(0.6f, 1f);

		public float whiteFlashDelayStart = 0.5f;

		public float whiteFlashDelayEnd = 0.025f;

		public float fillPerPressStart = 0.13f;

		public float fillPerPressEnd = 0.12f;

		public float drainRateStart = 0.3f;

		public float drainRateEnd = 1f;

		public float deadZoneSize;

		public EasingFunction.Ease whiteFlashDelayEase = EasingFunction.Ease.Linear;

		public EasingFunction.Ease fillPerPressEase = EasingFunction.Ease.Linear;

		public EasingFunction.Ease drainEase = EasingFunction.Ease.Linear;
	}

	private class SpinData
	{
		public bool inSpinMode;

		public float revolutionDir;

		public float previousAngle;

		public float angleDistTravelled;
	}

	[Serializable]
	private class AbilityData
	{
		public FillBarSettings fillBarSettings;

		public float punchBaseAttackModifier;

		public float punchMaxAttackModifier;

		public float punchImpactForce;

		public float fireballSpeed;

		public StatusEffectInfo burnEffectInfo;

		[Range(1f, 15f)]
		[Tooltip("Creates an exponential curve between the base and max Attack Modifiers. A value of 1 is linear. Increase the value to increase the curve.")]
		public float powerCurveModifier;

		public float freezeTimeOnSweetSpotHit;

		[Header("Prefabs")]
		public GameObject fillBarPrefab;

		public GameObject fireballPrefab;

		[Header("Animations")]
		public CharacterAnimationNamePair introAnim = default;

		public CharacterAnimationNamePair attackAnim = default;

		[Header("Sound Effects")]
		public DelayedAudioEvent introSFX = default;

		public DelayedAudioEvent punchSFX = default;

		public DelayedAudioEvent fireballSFX = default;
	}

	[SerializeField]
	private AbilityData abilityData;

	[SerializeField]
	private ScreenShakeData screenShakeData;

	[NonSerialized]
	private AmethystPC amethyst;

	[NonSerialized]
	private Vector3 originalPosition;

	[NonSerialized]
	private Vector3 originalDirection;

	[NonSerialized]
	private ITargetable currentTarget;

	[NonSerialized]
	private UISpinDashFillBar fillBar;

	[NonSerialized]
	private float fillTimer;

	[NonSerialized]
	private UISpinDashFillBar.ResultType fillBarResultType;

	[NonSerialized]
	private SpinData spinData;

	[NonSerialized]
	private Vector2 axisInput;

	[NonSerialized]
	private GameObject fireball;

	protected override void OnInit()
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		base.OnInit();
		if (spinData == null)
		{
			spinData = new SpinData();
		}
		spinData.inSpinMode = false;
		spinData.revolutionDir = 0f;
		spinData.previousAngle = 0f;
		spinData.angleDistTravelled = 0f;
		fireball = ObjectPool.GetObject(abilityData.fireballPrefab);
		fireball.SetActive(false);
	}

	public override IEnumerator Play()
	{
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)caster).transform, 2f)));
		caster.FaceTarget(((Component)GameController.Instance.currentBattlefield).transform);
		caster.PlayAnim(abilityData.introAnim, clearQueue: true);
		abilityData.introSFX.Play();
		yield return (object)new WaitForSeconds(0.5f);
		fillBar = ObjectPool.GetObject<UISpinDashFillBar>(abilityData.fillBarPrefab, default(Vector3), true);
		fillBar.fillAmount = 0f;
		fillBar.deadZoneSize = abilityData.fillBarSettings.deadZoneSize;
		fillBar.sweetSpotPosition = Random.Range(abilityData.fillBarSettings.sweetSpotPositionRange.minValue, abilityData.fillBarSettings.sweetSpotPositionRange.maxValue);
		fillBar.uiFollowCharacter.Init(GameController.Instance.uiCanvas, caster, setParent: false);
		GameUI.instance.AddElementToLayerAsFirstSibling((RectTransform)((Component)fillBar).transform, GameUI.instance.gameUILayer, worldPositionStays: true);
		yield return (object)new WaitWhile((Func<bool>)(() => fillBar.MainAnimator.IsPlaying()));
		((Component)fillBar.ButtonAnimator).gameObject.SetActive(true);
		bool isStarted = false;
		bool isDone = false;
		EasingFunction.Function curFillPressEaseFunc = EasingFunction.GetEasingFunction(abilityData.fillBarSettings.fillPerPressEase);
		EasingFunction.Function curDrainEaseFunc = EasingFunction.GetEasingFunction(abilityData.fillBarSettings.drainEase);
		Coroutine borderFlashCoroutine = null;
		if (GameController.ConnectedGamepad == GamepadType.Keyboard)
		{
			fillBar.ButtonAnimator.Play("leftright_smash", 0, 0f);
		}
		else
		{
			fillBar.ButtonAnimator.Play("full_rotation", 0, 0f);
		}
		bool keyboard_LeftPressedLast = false;
		while (true)
		{
			if (isStarted)
			{
				fillTimer -= Time.deltaTime;
				if (fillTimer <= 0f)
				{
					break;
				}
				fillBar.fillAmount -= curDrainEaseFunc(abilityData.fillBarSettings.drainRateStart, abilityData.fillBarSettings.drainRateEnd, 1f - fillTimer / abilityData.fillBarSettings.duration) * Time.deltaTime;
			}
			if (!isDone)
			{
				if (GameController.ConnectedGamepad == GamepadType.Keyboard)
				{
					if (keyboard_LeftPressedLast)
					{
						if (GameController.Instance.player.GetAxis("Move Horizontal") > 0f)
						{
							keyboard_LeftPressedLast = false;
							spinData.inSpinMode = true;
							if (!isStarted)
							{
								isStarted = true;
								fillTimer = abilityData.fillBarSettings.duration;
								borderFlashCoroutine = ((MonoBehaviour)fillBar).StartCoroutine(BorderFlash());
							}
							fillBar.fillAmount += curFillPressEaseFunc(abilityData.fillBarSettings.fillPerPressStart, abilityData.fillBarSettings.fillPerPressEnd, 1f - fillTimer / abilityData.fillBarSettings.duration) * 180f * Time.deltaTime;
						}
					}
					else if (GameController.Instance.player.GetAxis("Move Horizontal") < 0f)
					{
						keyboard_LeftPressedLast = true;
						spinData.inSpinMode = true;
						if (!isStarted)
						{
							isStarted = true;
							fillTimer = abilityData.fillBarSettings.duration;
							borderFlashCoroutine = ((MonoBehaviour)fillBar).StartCoroutine(BorderFlash());
						}
						fillBar.fillAmount += curFillPressEaseFunc(abilityData.fillBarSettings.fillPerPressStart, abilityData.fillBarSettings.fillPerPressEnd, 1f - fillTimer / abilityData.fillBarSettings.duration) * 180f * Time.deltaTime;
					}
				}
				else
				{
					Vector2 axis2D = player.GetAxis2D("UIHorizontal", "UIVertical");
					Vector2 axis2D2 = player.GetAxis2D("UIHorizontalRS", "UIVerticalRS");
					if (axis2D.sqrMagnitude == 0f && axis2D2.sqrMagnitude > 0f)
					{
						axisInput = axis2D2;
					}
					else
					{
						axisInput = axis2D;
					}
					if (!spinData.inSpinMode)
					{
						if (axisInput.sqrMagnitude > 0.25f)
						{
							spinData.previousAngle = Mathf.Atan2(axisInput.y, axisInput.x) * 57.29578f;
							spinData.angleDistTravelled = 0f;
							spinData.inSpinMode = true;
							if (!isStarted)
							{
								isStarted = true;
								fillTimer = abilityData.fillBarSettings.duration;
								borderFlashCoroutine = ((MonoBehaviour)fillBar).StartCoroutine(BorderFlash());
							}
						}
					}
					else
					{
						float num = Mathf.Atan2(axisInput.y, axisInput.x) * 57.29578f;
						float num2 = Mathf.DeltaAngle(spinData.previousAngle, num);
						spinData.previousAngle = num;
						fillBar.fillAmount += curFillPressEaseFunc(abilityData.fillBarSettings.fillPerPressStart, abilityData.fillBarSettings.fillPerPressEnd, 1f - fillTimer / abilityData.fillBarSettings.duration) * Mathf.Abs(num2) * Time.deltaTime;
						if (axisInput.magnitude <= 0.5f)
						{
							spinData.inSpinMode = false;
						}
					}
				}
			}
			yield return null;
		}
		isStarted = false;
		isDone = true;
		((MonoBehaviour)fillBar).StopCoroutine(borderFlashCoroutine);
		borderFlashCoroutine = null;
		((Component)fillBar.ButtonAnimator).gameObject.SetActive(false);
		fillBarResultType = fillBar.resultType;
		if (fillBarResultType == UISpinDashFillBar.ResultType.SweetSpot)
		{
			((Graphic)fillBar.WhiteBorder).color = Color.white;
			fillBar.IconAnimator.Play("success");
			yield return (object)new WaitWhile((Func<bool>)(() => fillBar.IconAnimator.IsPlaying()));
		}
		else
		{
			yield return ((MonoBehaviour)fillBar).StartCoroutine(FlashRed());
		}
		fillBar.MainAnimator.Play("outro");
		fillBar.MainAnimator.Update(0f);
		yield return (object)new WaitWhile((Func<bool>)(() => fillBar.MainAnimator.IsPlaying()));
		caster.PlayAnim(abilityData.attackAnim);
		caster.AddAnimToQueue(caster.GetIdleAnimation());
		yield return caster.animatorTk2d.WaitForEvent("fire");
		abilityData.punchSFX.Play();
		float percentPower = Mathf.Pow(fillBar.fillAmount, abilityData.powerCurveModifier);
		float punchAttackMod = percentPower * (abilityData.punchMaxAttackModifier - abilityData.punchBaseAttackModifier) + abilityData.punchBaseAttackModifier;
		ScreenShakeData shakeData = screenShakeData;
		shakeData.strength = Vector3.Scale(shakeData.strength, Vector3.one + caster.horizontalDirectionVector);
		EventMessenger.Instance.Raise(new ScreenShakeEvent(shakeData));
		DamageInfo punchDamageInfo = new DamageInfo(DamageInfo.ValueType.AttackModifier, punchAttackMod, CombatType.Melee, ImpactResultType.Blunt, abilityData.punchImpactForce);
		for (int num3 = 0; num3 < targets.Count; num3++)
		{
			ITargetable targetable = targets[num3];
			BattleHelper.DoDamage(caster, targetable.damageReceiver, punchDamageInfo, allowDeath: true, this);
			caster.ProcessBadgeEffects(BadgeEffectCondition.OnAttack, this, new ITargetable[1] { targetable });
		}
		ObjectPool.PoolObject(((Component)fillBar).gameObject);
		fillBar = null;
		tk2dSpriteDefinition.AttachPoint[] allFireFrameAttachPoints = caster.animatorTk2d.Sprite.GetCurrentSpriteDef().attachPoints;
		tk2dSpriteDefinition.AttachPoint fireballAttachPoint = null;
		foreach (tk2dSpriteDefinition.AttachPoint attachPoint in allFireFrameAttachPoints)
		{
			if (attachPoint.name == "fireball")
			{
				fireballAttachPoint = attachPoint;
				break;
			}
		}
		if (fireballAttachPoint == null)
		{
			Debug.LogError((object)"SUGILITE_FIREPUNCH, Fireball Attach Point is NULL");
		}
		GameObject fistCamInfluenceTarget = new GameObject("Fireball Start Pos");
		Vector3 spriteScale = caster.animatorTk2d.Sprite.scale;
		Vector3 adjustedAttachPoint = ((Component)caster.animatorTk2d).transform.TransformPoint(Vector2.op_Implicit(new Vector2(fireballAttachPoint.position.x * (float)((caster.horizontalDir == Direction.Right) ? 1 : (-1)) * Mathf.Abs(caster.animatorTk2d.Sprite.scale.x), fireballAttachPoint.position.y * Mathf.Abs(caster.animatorTk2d.Sprite.scale.y))));
		fistCamInfluenceTarget.transform.position = adjustedAttachPoint;
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(fistCamInfluenceTarget.transform, 1f)));
		if (fillBarResultType == UISpinDashFillBar.ResultType.SweetSpot)
		{
			float prevTimeScale = Time.timeScale;
			Time.timeScale = 0f;
			yield return new WaitForSecondsIndependent(abilityData.freezeTimeOnSweetSpotHit);
			Time.timeScale = prevTimeScale;
			fireball.SetActive(true);
			fireball.transform.position = adjustedAttachPoint;
			Transform transform = fireball.transform;
			Vector3 position = transform.position;
			Vector3 val = ((Component)GameCamera.instance.camera).transform.position - fireball.transform.position;
			transform.position = position + val.normalized * 1f;
			fireball.transform.localScale = new Vector3((float)((caster.horizontalDir == Direction.Right) ? 1 : (-1)), 1f, 1f);
			((Component)fireball.GetComponentInChildren<tk2dBaseSprite>()).transform.rotation = ((Component)caster.animatorTk2d).transform.rotation;
			abilityData.fireballSFX.Play();
			Plane[] frustumPlanes = GeometryUtility.CalculateFrustumPlanes(GameCamera.instance.camera);
			Plane targetPlane = ((caster.horizontalDir != Direction.Right) ? frustumPlanes[0] : frustumPlanes[1]);
			float distToPlane = 0f;
			Ray fireballRay = new Ray(fireball.transform.position, caster.horizontalDirectionVector);
			targetPlane.Raycast(fireballRay, ref distToPlane);
			Vector3 fireballDest = fireballRay.GetPoint(distToPlane + 20f);
			Tweener fireballTween = TweenSettingsExtensions.SetSpeedBased<Tweener>(TweenSettingsExtensions.SetEase<Tweener>(ShortcutExtensions.DOMove(fireball.transform, fireballDest, abilityData.fireballSpeed, false), (Ease)1));
			for (int num5 = 0; num5 < targets.Count; num5++)
			{
				targets[num5].StatusEffectManager.AddStatusEffect(abilityData.burnEffectInfo);
			}
			yield return TweenExtensions.WaitForCompletion((Tween)(object)fireballTween);
			ObjectPool.PoolObject(fireball);
		}
		yield return (object)new WaitWhile((Func<bool>)(() => caster.IsAnimPlaying(abilityData.attackAnim)));
		EventMessenger.Instance.Raise(new RemoveCameraInfluenceEvent(fistCamInfluenceTarget.transform));
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)caster).transform, 1f)));
		Object.Destroy((Object)(object)fistCamInfluenceTarget);
	}

	public override IEnumerator Cancel()
	{
		yield return null;
	}

	public override void ResetForReUse()
	{
		if ((Object)(object)fillBar != (Object)null)
		{
			((MonoBehaviour)fillBar).StopAllCoroutines();
			fillBar = null;
		}
		EventMessenger.Instance.Raise(new StopScreenShakeEvent());
		amethyst = null;
		currentTarget = null;
		spinData = null;
		fireball = null;
		base.ResetForReUse();
	}

	private IEnumerator BorderFlash()
	{
		EasingFunction.Function curFlashEaseFunc = EasingFunction.GetEasingFunction(abilityData.fillBarSettings.whiteFlashDelayEase);
		while (true)
		{
			yield return (object)new WaitForSeconds(curFlashEaseFunc(abilityData.fillBarSettings.whiteFlashDelayStart, abilityData.fillBarSettings.whiteFlashDelayEnd, 1f - fillTimer / abilityData.fillBarSettings.duration));
			((Graphic)fillBar.WhiteBorder).color = Color.white;
			yield return (object)new WaitForSeconds(curFlashEaseFunc(abilityData.fillBarSettings.whiteFlashDelayStart, abilityData.fillBarSettings.whiteFlashDelayEnd, 1f - fillTimer / abilityData.fillBarSettings.duration));
			((Graphic)fillBar.WhiteBorder).color = new Color(1f, 1f, 1f, 0f);
		}
	}

	private IEnumerator FlashRed()
	{
		for (int blinks = 4; blinks > 0; blinks--)
		{
			yield return (object)new WaitForSeconds(0.1f);
			((Graphic)fillBar.WhiteBorder).color = Color.red;
			yield return (object)new WaitForSeconds(0.1f);
			((Graphic)fillBar.WhiteBorder).color = new Color(1f, 1f, 1f, 0f);
		}
	}
}
