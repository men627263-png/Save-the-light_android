using System.Collections;
using UnityEngine;

public class TreeSprout : MonoBehaviour
{
	public string guid;

	public Animator animator;

	public int currentStage = 1;

	public Collider[] jumpColliders;

	public Renderer renderer;

	public DelayedAudioEvent sproutSound1;

	public DelayedAudioEvent sproutSound2;

	public DelayedAudioEvent sproutSound3;

	public DelayedAudioEvent sproutSound4;

	public DelayedAudioEvent sproutSound5;

	private StageInteractable stageInteractable;

	public bool IsMaxed => currentStage >= 5;

	private Color sproutMaterialColor
	{
		get
		{
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			return renderer.material.GetColor("_TintColor");
		}
		set
		{
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			renderer.material.SetColor("_TintColor", value);
		}
	}

	private void Awake()
	{
		stageInteractable = ((Component)this).GetComponent<StageInteractable>();
		stageInteractable.Interact += AddDew;
	}

	private void OnDestroy()
	{
		stageInteractable.Interact -= AddDew;
	}

	private void Start()
	{
		currentStage = Mathf.Max(1, PlayerGameState.Instance.GetIntValue(guid));
		ShowCurrentStage(playSound: false);
	}

	private void TurnOnJumpColliders()
	{
		for (int i = 0; i < jumpColliders.Length; i++)
		{
			((Component)jumpColliders[i]).gameObject.SetActive(true);
		}
	}

	private void TurnOffJumpColliders()
	{
		for (int i = 0; i < jumpColliders.Length; i++)
		{
			((Component)jumpColliders[i]).gameObject.SetActive(false);
		}
	}

	private void ShowCurrentStage(bool playSound = true)
	{
		if (currentStage == 0)
		{
			TurnOffJumpColliders();
			animator.Play("Idle");
			return;
		}
		string text = "stage " + Mathf.Min(5, currentStage);
		animator.Play(text);
		if (playSound)
		{
			if (currentStage == 2)
			{
				sproutSound2.Play();
			}
			else if (currentStage == 3)
			{
				sproutSound3.Play();
			}
			else if (currentStage == 4)
			{
				sproutSound4.Play();
			}
			else if (currentStage == 5)
			{
				sproutSound5.Play();
			}
		}
		Glow();
		if (currentStage >= 5)
		{
			TurnOnJumpColliders();
		}
		else
		{
			TurnOffJumpColliders();
		}
	}

	public void Glow()
	{
		// ILSpy could not decompile this member: Error decompiling @060049AD TreeSprout.Glow: Value cannot be null. (Parameter 'source')
		// Please report the exception below,
		// along with the assembly it came from, at https://github.com/icsharpcode/ILSpy/issues/new
		// Error decompiling @060049AD TreeSprout.Glow
		// in assembly "/storage/emulated/0/Download/Assembly-CSharp.dll"
		//  ---> System.ArgumentNullException: Value cannot be null. (Parameter 'source')
		//    at System.Linq.ThrowHelper.ThrowArgumentNullException(ExceptionArgument argument) in offset 11
		//    at System.Linq.Enumerable.Take[TSource](IEnumerable`1 source, Int32 count) in offset 3
		//    at ICSharpCode.Decompiler.CSharp.ArgumentList.GetArgumentResolveResultsDirect(Int32 skipCount) in CallBuilder.cs:line 128
		//    at ICSharpCode.Decompiler.CSharp.Disambiguator.Probe() in Disambiguator.cs:line 493
		//    at ICSharpCode.Decompiler.CSharp.Disambiguator.Run() in Disambiguator.cs:line 438
		//    at ICSharpCode.Decompiler.CSharp.Disambiguator.ForMethodReference(ExpressionBuilder expressionBuilder, IMethod method, IType targetType, TranslatedExpression target, Boolean requireTarget, ExpectedTargetDetails expectedTargetDetails, Boolean isExtensionMethodReference, Boolean castTargetUpFront) in Disambiguator.cs:line 131
		//    at ICSharpCode.Decompiler.CSharp.CallBuilder.DisambiguateDelegateReference(IMethod method, IMethod invokeMethod, ExpectedTargetDetails expectedTargetDetails, ILInstruction thisArg) in CallBuilder.cs:line 1825
		//    at ICSharpCode.Decompiler.CSharp.CallBuilder.BuildDelegateReference(IMethod method, IMethod invokeMethod, ExpectedTargetDetails expectedTargetDetails, ILInstruction thisArg) in CallBuilder.cs:line 1755
		//    at ICSharpCode.Decompiler.CSharp.CallBuilder.BuildMethodReference(IMethod method, Boolean isVirtual) in CallBuilder.cs:line 1746
		//    at ICSharpCode.Decompiler.CSharp.ExpressionBuilder.VisitLdFtn(LdFtn inst, TranslationContext context) in ExpressionBuilder.cs:line 5084
		//    at ICSharpCode.Decompiler.IL.LdFtn.AcceptVisitor[C,T](ILVisitor`2 visitor, C context) in Instructions.cs:line 3198
		//    at ICSharpCode.Decompiler.CSharp.ExpressionBuilder.Translate(ILInstruction inst, IType typeHint) in ExpressionBuilder.cs:line 173
		//    at ICSharpCode.Decompiler.CSharp.CallBuilder.BuildArgumentList(ExpectedTargetDetails expectedTargetDetails, ResolveResult target, IMethod method, Int32 firstParamIndex, IReadOnlyList`1 callArguments, IReadOnlyList`1 argumentToParameterMap, Boolean writtenAsAssignment) in CallBuilder.cs:line 1084
		//    at ICSharpCode.Decompiler.CSharp.CallBuilder.HandleDelegateConstruction(CallInstruction inst) in CallBuilder.cs:line 1693
		//    at ICSharpCode.Decompiler.CSharp.CallBuilder.Build(CallInstruction inst, IType typeHint) in CallBuilder.cs:line 223
		//    at ICSharpCode.Decompiler.CSharp.ExpressionBuilder.VisitNewObj(NewObj inst, TranslationContext context) in ExpressionBuilder.cs:line 540
		//    at ICSharpCode.Decompiler.IL.NewObj.AcceptVisitor[C,T](ILVisitor`2 visitor, C context) in Instructions.cs:line 4612
		//    at ICSharpCode.Decompiler.CSharp.ExpressionBuilder.Translate(ILInstruction inst, IType typeHint) in ExpressionBuilder.cs:line 173
		//    at ICSharpCode.Decompiler.CSharp.CallBuilder.BuildArgumentList(ExpectedTargetDetails expectedTargetDetails, ResolveResult target, IMethod method, Int32 firstParamIndex, IReadOnlyList`1 callArguments, IReadOnlyList`1 argumentToParameterMap, Boolean writtenAsAssignment) in CallBuilder.cs:line 1084
		//    at ICSharpCode.Decompiler.CSharp.CallBuilder.Build(OpCode callOpCode, IMethod method, IReadOnlyList`1 callArguments, IReadOnlyList`1 argumentToParameterMap, IType constrainedTo) in CallBuilder.cs:line 464
		//    at ICSharpCode.Decompiler.CSharp.CallBuilder.Build(CallInstruction inst, IType typeHint) in CallBuilder.cs:line 258
		//    at ICSharpCode.Decompiler.CSharp.ExpressionBuilder.VisitCall(Call inst, TranslationContext context) in ExpressionBuilder.cs:line 2548
		//    at ICSharpCode.Decompiler.IL.Call.AcceptVisitor[C,T](ILVisitor`2 visitor, C context) in Instructions.cs:line 2213
		//    at ICSharpCode.Decompiler.CSharp.ExpressionBuilder.Translate(ILInstruction inst, IType typeHint) in ExpressionBuilder.cs:line 173
		//    at ICSharpCode.Decompiler.CSharp.CallBuilder.BuildArgumentList(ExpectedTargetDetails expectedTargetDetails, ResolveResult target, IMethod method, Int32 firstParamIndex, IReadOnlyList`1 callArguments, IReadOnlyList`1 argumentToParameterMap, Boolean writtenAsAssignment) in CallBuilder.cs:line 1084
		//    at ICSharpCode.Decompiler.CSharp.CallBuilder.Build(OpCode callOpCode, IMethod method, IReadOnlyList`1 callArguments, IReadOnlyList`1 argumentToParameterMap, IType constrainedTo) in CallBuilder.cs:line 464
		//    at ICSharpCode.Decompiler.CSharp.CallBuilder.Build(CallInstruction inst, IType typeHint) in CallBuilder.cs:line 258
		//    at ICSharpCode.Decompiler.CSharp.ExpressionBuilder.VisitCall(Call inst, TranslationContext context) in ExpressionBuilder.cs:line 2548
		//    at ICSharpCode.Decompiler.IL.Call.AcceptVisitor[C,T](ILVisitor`2 visitor, C context) in Instructions.cs:line 2213
		//    at ICSharpCode.Decompiler.CSharp.ExpressionBuilder.Translate(ILInstruction inst, IType typeHint) in ExpressionBuilder.cs:line 173
		//    at ICSharpCode.Decompiler.CSharp.StatementBuilder.Default(ILInstruction inst) in StatementBuilder.cs:line 93
		//    at ICSharpCode.Decompiler.IL.ILVisitor`1.VisitCall(Call inst) in Instructions.cs:line 7717
		//    at ICSharpCode.Decompiler.IL.Call.AcceptVisitor[T](ILVisitor`1 visitor) in Instructions.cs:line 2209
		//    at ICSharpCode.Decompiler.CSharp.StatementBuilder.Convert(ILInstruction inst) in StatementBuilder.cs:line 82
		//    at ICSharpCode.Decompiler.CSharp.StatementBuilder.ConvertBlockContainer(BlockStatement blockStatement, BlockContainer container, IEnumerable`1 blocks, Boolean isLoop) in StatementBuilder.cs:line 1581
		//    at ICSharpCode.Decompiler.CSharp.StatementBuilder.ConvertBlockContainer(BlockContainer container, Boolean isLoop) in StatementBuilder.cs:line 1468
		//    at ICSharpCode.Decompiler.CSharp.StatementBuilder.VisitBlockContainer(BlockContainer container) in StatementBuilder.cs:line 1354
		//    at ICSharpCode.Decompiler.IL.BlockContainer.AcceptVisitor[T](ILVisitor`1 visitor) in Instructions.cs:line 863
		//    at ICSharpCode.Decompiler.CSharp.StatementBuilder.Convert(ILInstruction inst) in StatementBuilder.cs:line 82
		//    at ICSharpCode.Decompiler.CSharp.StatementBuilder.ConvertAsBlock(ILInstruction inst) in StatementBuilder.cs:line 87
		//    at ICSharpCode.Decompiler.CSharp.CSharpDecompiler.DecompileBody(IMethod method, EntityDeclaration entityDecl, DecompileRun decompileRun, ITypeResolveContext decompilationContext, ExtensionInfo extensionInfo) in CSharpDecompiler.cs:line 2457
		// -- continuing with outer exception (ICSharpCode.Decompiler.DecompilerException) --
		// 
	}

	public void AddDew()
	{
		((MonoBehaviour)this).StartCoroutine("DelayAddDew");
	}

	private IEnumerator DelayAddDew()
	{
		currentStage = Mathf.Min(5, currentStage + 1);
		PlayerGameState.Instance.SetIntValue(guid, currentStage);
		yield return (object)new WaitForSeconds(1f);
		ShowCurrentStage();
	}
}
