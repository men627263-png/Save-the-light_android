using UnityEngine;

public abstract class CharacterDirection : MonoBehaviour
{
	private float prevCameraRotationY;

	[SerializeField]
	[HideInInspector]
	private Vector3 _directionVector = Vector3.right;

	protected Direction _horizontalDir = Direction.Right;

	protected Direction _verticalDir;

	private bool _isLocked;

	private Transform _mainCamera;

	public Vector3 directionVector
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return _directionVector;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_005a: Unknown result type (might be due to invalid IL or missing references)
			//IL_005f: Unknown result type (might be due to invalid IL or missing references)
			//IL_006d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0073: Unknown result type (might be due to invalid IL or missing references)
			//IL_0078: Unknown result type (might be due to invalid IL or missing references)
			//IL_007d: Unknown result type (might be due to invalid IL or missing references)
			_directionVector = value;
			_directionVector.y = 0f;
			_directionVector.Normalize();
			horizontalDir = ((!(Vector3.Angle(_directionVector, ((Component)this).transform.right) < 90f)) ? Direction.Left : Direction.Right);
			Vector3 val = Quaternion.Euler(0f, 0f - mainCamera.eulerAngles.y, 0f) * _directionVector;
			verticalDir = ((!(val.z <= 0.2f)) ? ((!(val.z >= 0.3f)) ? _verticalDir : Direction.Up) : Direction.Down);
		}
	}

	public virtual Direction horizontalDir
	{
		get
		{
			return _horizontalDir;
		}
		set
		{
			if (value == Direction.Left || value == Direction.Right)
			{
				_horizontalDir = value;
				if (!isLocked)
				{
					OnHorizontalDirectionChanged();
				}
			}
		}
	}

	public virtual Direction verticalDir
	{
		get
		{
			return _verticalDir;
		}
		set
		{
			if (value != _verticalDir && (value == Direction.Up || value == Direction.Down))
			{
				_verticalDir = value;
				if (!isLocked)
				{
					OnVerticalDirectionChanged();
				}
			}
		}
	}

	public bool isLocked
	{
		get
		{
			return _isLocked;
		}
		set
		{
			if (value != _isLocked)
			{
				_isLocked = value;
				if (!_isLocked)
				{
					OnHorizontalDirectionChanged();
					OnVerticalDirectionChanged();
				}
			}
		}
	}

	protected Transform mainCamera
	{
		get
		{
			if ((Object)(object)_mainCamera == (Object)null)
			{
				_mainCamera = ((Component)GameCamera.instance.camera).transform;
			}
			return _mainCamera;
		}
	}

	protected CharacterDirection()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Start()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)mainCamera != (Object)null)
		{
			prevCameraRotationY = mainCamera.eulerAngles.y;
		}
		directionVector = directionVector;
	}

	private void LateUpdate()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)mainCamera != (Object)null)
		{
			if (!Mathf.Approximately(mainCamera.eulerAngles.y, prevCameraRotationY))
			{
				horizontalDir = ((!(Vector3.Angle(_directionVector, ((Component)this).transform.right) < 90f)) ? Direction.Left : Direction.Right);
				Vector3 val = Quaternion.Euler(0f, 0f - mainCamera.eulerAngles.y, 0f) * _directionVector;
				verticalDir = ((!(val.z <= 0.2f)) ? ((!(val.z >= 0.3f)) ? _verticalDir : Direction.Up) : Direction.Down);
			}
			prevCameraRotationY = mainCamera.eulerAngles.y;
		}
	}

	public void FaceTarget(Vector3 position)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = new Vector3(position.x, 0f, position.z) - ((Component)this).transform.PositionXZ();
		directionVector = val.normalized;
	}

	public void FaceTarget(Transform transform)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)transform != (Object)null)
		{
			FaceTarget(transform.position);
		}
	}

	public void FaceTarget(BaseCharacter character)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)character != (Object)null)
		{
			FaceTarget(((Component)character).transform.position);
		}
	}

	public void FaceAwayFromTarget(Vector3 position)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = ((Component)this).transform.PositionXZ() - new Vector3(position.x, 0f, position.z);
		directionVector = val.normalized;
	}

	public void FaceAwayFromTarget(Transform transform)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)transform != (Object)null)
		{
			FaceAwayFromTarget(transform.position);
		}
	}

	public void FaceAwayFromTarget(BaseCharacter character)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)character != (Object)null)
		{
			FaceAwayFromTarget(((Component)character).transform.position);
		}
	}

	public bool IsFacingTarget(Vector3 position)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = new Vector3(position.x, 0f, position.z) - ((Component)this).transform.PositionXZ();
		Vector3 normalized = val.normalized;
		Direction direction = ((!(Vector3.Angle(normalized, ((Component)this).transform.right) < 90f)) ? Direction.Left : Direction.Right);
		return horizontalDir == direction;
	}

	public bool IsFacingTarget(Transform transform)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)transform != (Object)null)
		{
			return IsFacingTarget(transform.position);
		}
		return false;
	}

	public bool IsFacingTarget(BaseCharacter character)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)character != (Object)null)
		{
			return IsFacingTarget(((Component)character).transform.position);
		}
		return false;
	}

	protected abstract void OnHorizontalDirectionChanged();

	protected abstract void OnVerticalDirectionChanged();
}
