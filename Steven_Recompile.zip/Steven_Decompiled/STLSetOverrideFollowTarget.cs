using HutongGames.PlayMaker;
using UnityEngine;

[ActionCategory(/*Could not decode attribute arguments.*/)]
public class STLSetOverrideFollowTarget : FsmStateAction
{
	public FsmGameObject target;

	public override void Reset()
	{
		target = null;
	}

	public override void OnEnter()
	{
		if ((Object)(object)GameCamera.instance != (Object)null && (Object)(object)GameCamera.instance.battleCamera != (Object)null)
		{
			GameCamera.instance.battleCamera.overrideFollowTarget = ((!((Object)(object)target.Value != (Object)null)) ? null : target.Value.transform);
		}
		((FsmStateAction)this).Finish();
	}
}
