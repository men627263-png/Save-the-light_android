using System;
using System.Collections;
using Grumpyface;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Abilities/Player Characters/Peridot/Build Contraption")]
public class Peridot_BuildContraptionAbility : BaseAbility
{
	[Serializable]
	private class AbilityData
	{
		[Header("Sounds")]
		public DelayedAudioEvent finishedBuildingSound = default;

		public DelayedAudioEvent finishedBuildingVO = default;
	}

	[SerializeField]
	private AbilityData abilityData;

	[NonSerialized]
	private PeridotPC peridot;

	[NonSerialized]
	private Transform destination;

	[NonSerialized]
	private PeridotContraptionBlueprint blueprint;

	protected override void OnInit()
	{
		base.OnInit();
		peridot = (PeridotPC)caster;
		destination = targets[0].transform;
		blueprint = ((PeridotContraptionTargetSystem)targetSystem).contraptionBlueprint;
	}

	public override IEnumerator Play()
	{
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(destination, 1f)));
		EventMessenger.Instance.Raise(new CameraZoomEvent(1.3f));
		abilityData.finishedBuildingSound.Play(((Component)caster).transform.position);
		abilityData.finishedBuildingVO.Play(((Component)caster).transform.position);
		PeridotContraption contraption = ObjectPool.GetObject<PeridotContraption>(blueprint.contraptionPrefab, destination.position, false);
		Vector3 forward = ((Component)GameCamera.instance.camera).transform.forward;
		forward.y = 0f;
		forward.Normalize();
		((Component)contraption).transform.forward = forward;
		contraption.Init(peridot, blueprint, destination);
		((Component)contraption).gameObject.SetActive(true);
		if (contraption is ITargetable)
		{
			EventMessenger.Instance.Raise(new AddPlayerToBattleEvent((ITargetable)contraption));
		}
		peridot.AddContraption(contraption);
		caster.RichAI2D.MoveToPosition(caster.battlePosition, caster.baseMovementSpeed);
		yield return (object)new WaitWhile((Func<bool>)(() => caster.RichAI2D.WaitingForPathCalc));
		if (caster.RichAI2D.IsMovingAlongPath)
		{
			yield return new WaitUntilAIReachedTarget(caster.RichAI2D);
		}
		caster.FaceTarget(((Component)GameController.Instance.currentBattlefield).transform);
	}

	public override IEnumerator Cancel()
	{
		yield break;
	}

	protected override void OnCleanUp()
	{
		base.OnCleanUp();
		Object.Destroy((Object)(object)((Component)destination).gameObject);
		targets.Clear();
		peridot = null;
		destination = null;
		blueprint = null;
	}

	public override void ResetForReUse()
	{
		peridot = null;
		destination = null;
		blueprint = null;
		base.ResetForReUse();
	}
}
