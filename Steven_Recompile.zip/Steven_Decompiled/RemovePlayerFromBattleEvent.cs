public class RemovePlayerFromBattleEvent : GameEvent
{
	public ITargetable player { get; private set; }

	public bool allowPooling { get; private set; }

	public RemovePlayerFromBattleEvent(ITargetable player, bool allowPooling = true)
	{
		this.player = player;
		this.allowPooling = allowPooling;
	}
}
