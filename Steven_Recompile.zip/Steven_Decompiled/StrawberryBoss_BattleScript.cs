using System;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Battle Scripts/Strawberry Boss")]
public class StrawberryBoss_BattleScript : BattleScript
{
	[Serializable]
	public class BattleStageInfo
	{
		public float healthThreshold;

		public BattleBrain battleBrain;

		public int openCloseCount = 10;

		public float openCloseStartSpeed = 1f;

		public float openCloseSpeedIncrement = 0.1f;

		public float stepSpeed;

		public float stepDistance;

		public float midStepDelay;

		public float stepDelay;

		public float chainLength = 10f;

		public int headMaxHealth = 20;

		public int headDefense;

		public int handMaxHealth = 20;

		public int handDefense;

		public int beltMaxHealth = 20;

		public int beltDefense;

		public float eyeExposureDuration = 5f;

		public int eyeDamageLimit = 50;

		public BattleStageInfo()
		{
			healthThreshold = 1f;
			battleBrain = null;
			openCloseCount = 10;
			openCloseStartSpeed = 1f;
			openCloseSpeedIncrement = 0.1f;
			stepSpeed = 0.75f;
			stepDistance = 1.1f;
			midStepDelay = 0f;
			stepDelay = 5f;
			chainLength = 10f;
			headMaxHealth = 20;
			headDefense = 0;
			handMaxHealth = 20;
			handDefense = 0;
			beltMaxHealth = 20;
			beltDefense = 0;
			eyeExposureDuration = 5f;
			eyeDamageLimit = 50;
		}
	}

	[SerializeField]
	private BattleStageInfo[] _stages;

	[NonSerialized]
	private StrawberryKnight strawberryKnight;

	[NonSerialized]
	private int activeStageIndex;

	[NonSerialized]
	private BattleStageInfo activeStage;

	[NonSerialized]
	private BattleStageInfo nextStage;

	public override bool allowAlwaysUpdate => true;

	public override void OnInit()
	{
		strawberryKnight = Object.FindObjectOfType<StrawberryKnight>();
		if (_stages == null || _stages.Length == 0)
		{
			_stages = new BattleStageInfo[1]
			{
				new BattleStageInfo()
			};
		}
		activeStageIndex = 0;
		activeStage = _stages[activeStageIndex];
		if (_stages.Length > 1)
		{
			nextStage = _stages[1];
		}
	}

	public override void Update()
	{
		while (nextStage != null && strawberryKnight.currentHealthRatio <= nextStage.healthThreshold)
		{
			activeStage = nextStage;
			activeStageIndex++;
			SetStageValues(activeStage);
			nextStage = ((activeStageIndex + 1 >= _stages.Length) ? null : _stages[activeStageIndex + 1]);
		}
	}

	public override void OnBattleStarted()
	{
		SetStageValues(activeStage);
		strawberryKnight.characterProperties.head.SetMaxHealth(activeStage.headMaxHealth, updateCurrentHealth: true);
		strawberryKnight.characterProperties.hand.SetMaxHealth(activeStage.handMaxHealth, updateCurrentHealth: true);
		strawberryKnight.characterProperties.belt.SetMaxHealth(activeStage.beltMaxHealth, updateCurrentHealth: true);
		EventMessenger.Instance.AddListener<StartLoadingSceneEvent>(HandleStartLoadingSceneEvent);
	}

	public override void OnBattleFinished()
	{
		EventMessenger.Instance.RemoveListener<StartLoadingSceneEvent>(HandleStartLoadingSceneEvent);
	}

	private void HandleStartLoadingSceneEvent(StartLoadingSceneEvent evt)
	{
		EventMessenger.Instance.RemoveListener<StartLoadingSceneEvent>(HandleStartLoadingSceneEvent);
	}

	private void SetStageValues(BattleStageInfo stage)
	{
		if ((Object)(object)stage.battleBrain != (Object)null)
		{
			strawberryKnight.activeBattleBrain = stage.battleBrain;
		}
		strawberryKnight.characterProperties.openCloseCount = stage.openCloseCount;
		strawberryKnight.characterProperties.openCloseStartSpeed = stage.openCloseStartSpeed;
		strawberryKnight.characterProperties.openCloseSpeedIncrement = stage.openCloseSpeedIncrement;
		strawberryKnight.characterProperties.stepSpeed = stage.stepSpeed;
		strawberryKnight.characterProperties.stepDistance = stage.stepDistance;
		strawberryKnight.characterProperties.midStepDelay = stage.midStepDelay;
		strawberryKnight.characterProperties.stepDelay = stage.stepDelay;
		strawberryKnight.characterProperties.chainLength = stage.chainLength;
		strawberryKnight.characterProperties.head.SetMaxHealth(stage.headMaxHealth);
		strawberryKnight.characterProperties.head.SetDefense(stage.headDefense);
		strawberryKnight.characterProperties.hand.SetMaxHealth(stage.handMaxHealth);
		strawberryKnight.characterProperties.hand.SetDefense(stage.handDefense);
		strawberryKnight.characterProperties.belt.SetMaxHealth(stage.beltMaxHealth);
		strawberryKnight.characterProperties.belt.SetDefense(stage.beltDefense);
		strawberryKnight.characterProperties.eyeExposureDuration = stage.eyeExposureDuration;
		strawberryKnight.characterProperties.eyeDamageLimit = stage.eyeDamageLimit;
	}
}
