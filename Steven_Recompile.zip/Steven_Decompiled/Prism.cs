using UnityEngine;

public class Prism : MonoBehaviour
{
	private bool startedIntroChase;

	public void StartIntroChase()
	{
		startedIntroChase = true;
	}

	public void EndIntroChase()
	{
		startedIntroChase = false;
	}

	private void Update()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		if (startedIntroChase && ((Component)this).transform.position.z - ((Component)GameController.Instance.partyLeader).transform.position.z < 10f)
		{
			((Component)this).transform.position = new Vector3(((Component)this).transform.position.x, ((Component)this).transform.position.y, ((Component)GameController.Instance.partyLeader).transform.position.z + 10f);
		}
	}
}
