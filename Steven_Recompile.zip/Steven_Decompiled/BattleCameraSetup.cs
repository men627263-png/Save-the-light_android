using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Battle Camera Setup")]
public class BattleCameraSetup : ScriptableObject
{
	public float targetTiltAngle = 20f;

	public float offsetDistance = 17f;

	public float offsetHeight = 7f;

	public float targetZoomFactor = 1f;

	[Header("Damping")]
	[Range(0f, 1f)]
	public float dampTimeX = 0.15f;

	[Range(0f, 1f)]
	public float dampTimeY = 0.15f;

	[Range(0f, 1f)]
	public float dampTimeZ = 0.15f;

	[Range(0f, 1f)]
	public float rotationDampingX = 0.15f;

	[Range(0f, 1f)]
	public float rotationDampingY = 0.2f;

	[Header("Tall Fusion Offset Values")]
	public float tiltAngleFusionOffset;

	public float distanceFusionOffset = 6.1f;

	public float heightFusionOffset = 4.5f;
}
