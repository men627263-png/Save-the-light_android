using System;
using UnityEngine;

[Serializable]
public struct ScreenShakeData(float duration, Vector3 strength, int vibrato = 10, float randomness = 90f, bool snapping = false, bool dontFadeOut = false)
{
	public float duration = duration;

	public Vector3 strength = strength;

	public int vibrato = vibrato;

	public float randomness = randomness;

	public bool snapping = snapping;

	public bool dontFadeOut = dontFadeOut;
}
