using UnityEngine;

public class GenericTargetable : MonoBehaviour, ITargetable, ITinter
{
	private CharacterStats stats;

	protected StatusEffectManager statusEffectManager;

	protected TargetableTinter targetableTinter;

	public Vector3 BackPosition
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return ((Component)this).transform.position;
		}
	}

	public bool IsTargetable => true;

	public bool CanBlock => false;

	public virtual bool IsFlying => false;

	public Vector3 CenterPosition
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return ((Component)this).transform.position;
		}
	}

	public Vector3 CenterTopPosition
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return ((Component)this).transform.position;
		}
	}

	public IDamageReceiver damageReceiver => null;

	public Vector3 FrontPosition
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return ((Component)this).transform.position;
		}
	}

	public UIHealthBar HealthBar => null;

	public CharacterStats Stats
	{
		get
		{
			if (stats == null)
			{
				stats = new CharacterStats();
			}
			return stats;
		}
	}

	public HitBoxManager HitBoxManager => null;

	public StatusEffectManager StatusEffectManager
	{
		get
		{
			if ((Object)(object)statusEffectManager == (Object)null)
			{
				statusEffectManager = ((Component)this).GetComponent<StatusEffectManager>();
				if ((Object)(object)statusEffectManager == (Object)null)
				{
					statusEffectManager = ((Component)this).gameObject.AddComponent<StatusEffectManager>();
				}
				statusEffectManager.Init(this);
			}
			return statusEffectManager;
		}
	}

	public StatusEffectName[] InnateImmunities => new StatusEffectName[0];

	public TargetableTinter TargetableTinter
	{
		get
		{
			if ((Object)(object)targetableTinter == (Object)null)
			{
				targetableTinter = ((Component)this).GetComponent<TargetableTinter>();
			}
			return targetableTinter;
		}
	}

	public bool IsAlive => true;

	public bool IsDead => false;

	public float EffectScale => 1f;

	public Color TintColor
	{
		get
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			return Color.white;
		}
		set
		{
		}
	}

	public Renderer[] AllRenderers => new Renderer[0];

	public bool CanBeTargetedByAbility(BaseAbility ability)
	{
		return true;
	}

	public Vector3 GetClosestSidePosition(Vector3 fromPosition)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		return ((Component)this).transform.position;
	}

	public void Kill(IDamageSender source)
	{
	}
}
