using UnityEngine;

public class StrawberryKnight_Head : StrawberryKnight_EyeHolder
{
	[Space]
	[SerializeField]
	private Vector3 eyeRendererShatteredPos;

	public override bool IsFlying => true;

	public sealed override void Kill(IDamageSender source)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		base.Kill(source);
		((Component)eyeRenderer).transform.localPosition = eyeRendererShatteredPos;
	}

	public sealed override bool CanBeTargetedByAbility(BaseAbility ability)
	{
		return ability.attackRangeType != CombatType.Melee || ability is Sardonyx_HammerAbility;
	}
}
