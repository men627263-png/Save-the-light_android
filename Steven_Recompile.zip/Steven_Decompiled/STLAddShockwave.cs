using Grumpyface;
using HutongGames.PlayMaker;
using UnityEngine;

[ActionCategory(/*Could not decode attribute arguments.*/)]
public class STLAddShockwave : FsmStateAction
{
	public FsmGameObject prefab;

	public FsmVector3 destination;

	public BaseCharacter source;

	public FsmFloat minDistance;

	public FsmFloat maxDistance;

	public FsmFloat minValue;

	public FsmFloat maxValue;

	public override void Reset()
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		prefab = null;
		destination = FsmVector3.op_Implicit(default(Vector3));
		source = null;
		minDistance = FsmFloat.op_Implicit(0f);
		maxDistance = FsmFloat.op_Implicit(0f);
		minValue = FsmFloat.op_Implicit(0f);
		maxValue = FsmFloat.op_Implicit(0f);
	}

	public override void OnEnter()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)prefab.Value != (Object)null)
		{
			Shockwave shockwave = ObjectPool.GetObject<Shockwave>(prefab.Value, destination.Value, true);
			if ((Object)(object)shockwave != (Object)null)
			{
				shockwave.Init(source, new Shockwave.ShockwaveData(minDistance.Value, maxDistance.Value, minValue.Value, maxValue.Value));
			}
		}
		((FsmStateAction)this).Finish();
	}
}
