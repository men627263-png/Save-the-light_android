public interface IFusionAbility
{
	CharacterName[] members { get; }

	bool CanFuse();
}
