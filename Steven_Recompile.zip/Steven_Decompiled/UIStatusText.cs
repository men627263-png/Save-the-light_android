using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Grumpyface;
using SimpleSpritePacker;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIStatusText : MonoBehaviour, IPoolable
{
	public float moveDistance = 2f;

	public float moveTime = 1.5f;

	public Ease moveEase;

	public SPInstance atlas;

	public Image icon;

	private TextMeshProUGUI textMesh;

	private Transform followTarget;

	private Vector3 followTargetOffset;

	private Canvas uiCanvas;

	private Vector3 tweenedOffset;

	private float curMoveTime;

	private Ease curEase;

	public void Init(string message, Canvas uiCanvasNew, Transform followTargetNew, Vector3 followTargetOffsetNew, Color textColor, Color outlineColor, string spriteName = "", float moveTimeNew = -1f, Ease ease = (Ease)0)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Expected Obj, but got Unknown
		if ((Object)(object)textMesh == (Object)null)
		{
			textMesh = ((Component)this).GetComponentInChildren<TextMeshProUGUI>();
		}
		textMesh.text = message;
		((Graphic)textMesh).color = textColor;
		textMesh.outlineColor = Color32.op_Implicit(outlineColor);
		followTarget = followTargetNew;
		followTargetOffset = followTargetOffsetNew;
		uiCanvas = uiCanvasNew;
		curMoveTime = ((!(moveTimeNew < 0f)) ? moveTimeNew : moveTime);
		curEase = (((int)ease != 0) ? ease : moveEase);
		Sprite spriteByName = atlas.GetSpriteByName(spriteName);
		if ((Object)(object)spriteByName != (Object)null)
		{
			((Component)icon).gameObject.SetActive(true);
			icon.sprite = spriteByName;
		}
		else
		{
			((Component)icon).gameObject.SetActive(false);
		}
		((Component)this).transform.SetParent((Transform)(object)GameUI.instance.characterLayer, false);
		tweenedOffset = Vector3.zero;
		LateUpdate();
		TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(DOTween.To((DOGetter<Vector3>)(() =>
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return tweenedOffset;
		}), (DOSetter<Vector3>)((Vector3 newOffset) =>
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			tweenedOffset = newOffset;
		}), new Vector3(0f, moveDistance, 0f), curMoveTime), curEase);
		TweenSettingsExtensions.SetEase<Tweener>(DOTween.ToAlpha((DOGetter<Color>)(() =>
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return ((Graphic)textMesh).color;
		}), (DOSetter<Color>)((Color newColor) =>
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			((Graphic)textMesh).color = newColor;
		}), 0f, curMoveTime), curEase);
		TweenSettingsExtensions.OnComplete<Tweener>(TweenSettingsExtensions.SetEase<Tweener>(DOTween.ToAlpha((DOGetter<Color>)(() =>
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return ((Graphic)icon).color;
		}), (DOSetter<Color>)((Color newColor) =>
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			((Graphic)icon).color = newColor;
		}), 0f, curMoveTime), curEase), (TweenCallback)HandleTweenComplete);
	}

	private void LateUpdate()
	{
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)followTarget != (Object)null && (Object)(object)uiCanvas != (Object)null)
		{
			if (!followTarget.IsChildOf(((Component)uiCanvas).transform))
			{
				((Component)this).transform.localPosition = Vector2.op_Implicit(uiCanvas.WorldToCanvas(followTarget.position + followTargetOffset + tweenedOffset));
			}
			else
			{
				((Component)this).transform.position = followTarget.position + followTargetOffset + tweenedOffset;
			}
		}
	}

	private void HandleTweenComplete()
	{
		ObjectPool.PoolObject(((Component)this).gameObject);
	}

	public void ResetObject()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		((Graphic)icon).color = Color.white;
		((Component)this).transform.localScale = Vector3.one;
	}
}
