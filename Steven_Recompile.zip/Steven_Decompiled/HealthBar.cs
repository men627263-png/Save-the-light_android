using System;
using System.Collections;
using Grumpyface;
using UnityEngine;

public abstract class HealthBar : MonoBehaviour, IPoolable
{
	private IEnumerator showCoroutine;

	private IEnumerator hideCoroutine;

	protected ITargetable _targetable;

	protected Vector3 _offset;

	public event Action ShowComplete;

	public event Action HideComplete;

	private void OnDestroy()
	{
		if (_targetable != null)
		{
			_targetable.damageReceiver.DamageReceived -= HandleDamageReceived;
			_targetable.damageReceiver.HealReceived -= HandleHealReceived;
			_targetable = null;
		}
	}

	public void Init(ITargetable targetable, Vector3 offset)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		_offset = offset;
		if (targetable != _targetable)
		{
			if (_targetable != null)
			{
				_targetable.damageReceiver.DamageReceived -= HandleDamageReceived;
				_targetable.damageReceiver.HealReceived -= HandleHealReceived;
				_targetable.damageReceiver.HealthUpdated -= HandleHealthUpdated;
			}
			_targetable = targetable;
			if (_targetable != null)
			{
				_targetable.damageReceiver.DamageReceived += HandleDamageReceived;
				_targetable.damageReceiver.HealReceived += HandleHealReceived;
				_targetable.damageReceiver.HealthUpdated += HandleHealthUpdated;
			}
			OnInit();
			if (_targetable != null)
			{
				OnUpdated((float)_targetable.damageReceiver.CurrentHealthValue / (float)_targetable.damageReceiver.MaxHealthValue, didIncrease: true);
			}
		}
	}

	public void Show()
	{
		if (showCoroutine == null)
		{
			if (hideCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(hideCoroutine);
				hideCoroutine = null;
			}
			showCoroutine = PlayShow();
			((MonoBehaviour)this).StartCoroutine(showCoroutine);
		}
	}

	public void Hide()
	{
		if (hideCoroutine == null)
		{
			if (showCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(showCoroutine);
				showCoroutine = null;
			}
			hideCoroutine = PlayHide();
			((MonoBehaviour)this).StartCoroutine(hideCoroutine);
		}
	}

	private IEnumerator PlayShow()
	{
		yield return ((MonoBehaviour)this).StartCoroutine(ShowSequence());
		showCoroutine = null;
		if (ShowComplete != null)
		{
			ShowComplete();
		}
	}

	private IEnumerator PlayHide()
	{
		yield return ((MonoBehaviour)this).StartCoroutine(HideSequence());
		hideCoroutine = null;
		if (HideComplete != null)
		{
			HideComplete();
		}
	}

	private void HandleDamageReceived(DamageResult result)
	{
		OnUpdated((float)_targetable.damageReceiver.CurrentHealthValue / (float)_targetable.damageReceiver.MaxHealthValue);
	}

	private void HandleHealReceived(HealResult result)
	{
		OnUpdated((float)_targetable.damageReceiver.CurrentHealthValue / (float)_targetable.damageReceiver.MaxHealthValue, didIncrease: true);
	}

	private void HandleHealthUpdated(int delta)
	{
	}

	protected abstract void OnInit();

	protected abstract void OnUpdated(float percent, bool didIncrease = false);

	protected abstract IEnumerator ShowSequence();

	protected abstract IEnumerator HideSequence();

	public virtual void ResetObject()
	{
		if (_targetable != null)
		{
			_targetable.damageReceiver.DamageReceived -= HandleDamageReceived;
			_targetable.damageReceiver.HealReceived -= HandleHealReceived;
			_targetable.damageReceiver.HealthUpdated -= HandleHealthUpdated;
			_targetable = null;
		}
		showCoroutine = null;
		hideCoroutine = null;
	}
}
