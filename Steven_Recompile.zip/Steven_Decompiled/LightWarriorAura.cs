public class LightWarriorAura : Shockwave
{
	public float superDebuffDuration = 10f;

	protected override void OnTargetReached(ITargetable target, float progress)
	{
		if (!object.ReferenceEquals(target, source))
		{
			target.StatusEffectManager.AddStatusEffect(new SuperDebuff((BaseCharacter)target, superDebuffDuration));
			if (target is Hessonite)
			{
				((Hessonite)target).SetActiveState(Hessonite.State.Return);
			}
		}
	}
}
