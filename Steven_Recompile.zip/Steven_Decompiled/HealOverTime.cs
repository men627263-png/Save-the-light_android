using Grumpyface;
using UnityEngine;

public class HealOverTime : StatusEffect
{
	public enum HealType
	{
		None,
		Active,
		Passive
	}

	private static int nextID;

	private int healAmount;

	private float duration;

	private float tickRate;

	private bool tickImmediately;

	private float timerTick;

	private float timerDuration;

	private HealType _healType;

	private GameObject particle;

	public int id { get; private set; }

	public override StatusEffectName effectName => StatusEffectName.HealOverTime;

	public override StatusEffectType type => StatusEffectType.Buff;

	public override bool isStackable => true;

	public override bool isPersistent => true;

	public override bool isSavable => true;

	public override bool isResettable => false;

	public HealType healType => _healType;

	public override bool isOwnerValid => true;

	public HealOverTime(ITargetable owner, int healAmount, float tickRate, float duration, bool tickImmediately, HealType healType)
		: base(owner)
	{
		this.healAmount = healAmount;
		this.tickImmediately = tickImmediately;
		this.tickRate = tickRate;
		this.duration = duration;
		_healType = healType;
		id = nextID++;
	}

	protected override void InitEffect()
	{
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		timerTick = ((!tickImmediately) ? tickRate : 0f);
		timerDuration = duration;
		if (_healType == HealType.Active)
		{
			Transform val = owner.transform.Find(((Object)GameResources.instance.gameSettings.regenParticlePrefab).name);
			if ((Object)(object)val == (Object)null)
			{
				particle = ObjectPool.GetObject(GameResources.instance.gameSettings.regenParticlePrefab);
				particle.transform.localPosition = owner.CenterPosition;
				particle.transform.SetParent(owner.transform);
			}
			else
			{
				Debug.Log((object)"A HoT particle was found on the target, skipping putting a new one on");
			}
		}
	}

	protected override void ResetEffect()
	{
		timerTick = ((!tickImmediately) ? tickRate : 0f);
		timerDuration = duration;
	}

	protected override void UpdateEffect()
	{
		float deltaTime = Time.deltaTime;
		if (deltaTime == 0f)
		{
			return;
		}
		timerTick -= deltaTime;
		if (timerTick <= 0f)
		{
			timerTick += tickRate;
			if (owner.IsAlive)
			{
				float num = (float)owner.damageReceiver.CurrentHealthValue / (float)owner.damageReceiver.MaxHealthValue;
				if (_healType != HealType.Passive || num < 1f)
				{
					BattleHelper.DoHeal(null, owner.damageReceiver, new HealInfo(HealInfo.ValueType.FlatAmount, healAmount));
				}
				else if (_healType == HealType.Passive && num >= 1f)
				{
					Debug.Log((object)"Passive heal over time, tick skipped character is at full health");
				}
			}
		}
		if (duration >= 0f)
		{
			timerDuration -= deltaTime;
			if (timerDuration <= 0f)
			{
				Remove();
			}
		}
	}

	protected override void RemoveEffect()
	{
		if ((Object)(object)particle != (Object)null)
		{
			ObjectPool.PoolObject(particle);
			particle = null;
		}
	}

	protected override void CleanUp()
	{
		owner = null;
	}

	protected override void InitSaveData(StatusEffectSaveData saveData)
	{
		saveData.startingData.intValue1 = healAmount;
		saveData.startingData.floatValue1 = tickRate;
		saveData.startingData.floatValue2 = duration;
		saveData.startingData.boolValue1 = tickImmediately;
		saveData.data.intValue1 = healAmount;
		saveData.data.floatValue1 = timerTick;
		saveData.data.floatValue2 = timerDuration;
		saveData.data.boolValue1 = false;
	}

	public sealed override void LoadSaveData(StatusEffectData data)
	{
		timerTick = data.floatValue1;
		timerDuration = data.floatValue2;
		tickImmediately = data.boolValue1;
	}

	public override bool Equals(object obj)
	{
		if (object.ReferenceEquals(this, obj))
		{
			return true;
		}
		return false;
	}
}
