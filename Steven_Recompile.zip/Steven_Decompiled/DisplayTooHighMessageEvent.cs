public class DisplayTooHighMessageEvent : GameEvent
{
	public ITargetable target { get; private set; }

	public DisplayTooHighMessageEvent(ITargetable target)
	{
		this.target = target;
	}
}
