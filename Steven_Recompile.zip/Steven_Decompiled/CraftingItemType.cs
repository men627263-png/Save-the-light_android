public enum CraftingItemType
{
	None,
	LightShard,
	Schematic
}
