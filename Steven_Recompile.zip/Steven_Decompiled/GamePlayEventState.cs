public enum GamePlayEventState
{
	Unassigned,
	Active,
	Complete,
	ActiveCount
}
