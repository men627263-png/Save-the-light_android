using UnityEngine;

[ExecuteInEditMode]
public class AnimatedUVMaterial : MonoBehaviour
{
	[Range(0f, 1f)]
	public float offsetX;

	[Range(1f, 0f)]
	public float offsetY;

	private Renderer renderer;

	private void Awake()
	{
		renderer = ((Component)this).GetComponent<Renderer>();
	}

	private void LateUpdate()
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)renderer != (Object)null)
		{
			if (Application.isPlaying)
			{
				renderer.material.SetTextureOffset("_MainTex", new Vector2(offsetX, offsetY));
			}
			else
			{
				renderer.sharedMaterial.SetTextureOffset("_MainTex", new Vector2(offsetX, offsetY));
			}
		}
	}
}
