public enum InstigateBattleReason
{
	None,
	Attack,
	Ambush
}
