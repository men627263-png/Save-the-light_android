public class StartLoadingSceneEvent : GameEvent
{
	public string sceneName { get; private set; }

	public StartLoadingSceneEvent(string sceneName)
	{
		this.sceneName = sceneName;
	}
}
