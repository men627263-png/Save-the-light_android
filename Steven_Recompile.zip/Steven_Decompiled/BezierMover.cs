using Pathfinding;
using UnityEngine;

[HelpURL("http://arongranberg.com/astar/docs/class_bezier_mover.php")]
public class BezierMover : MonoBehaviour
{
	public Transform[] points;

	public float tangentLengths = 5f;

	public float speed = 1f;

	private float time;

	private void Update()
	{
		Move(progress: true);
	}

	private Vector3 Plot(float t)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		int num = points.Length;
		int num2 = Mathf.FloorToInt(t);
		Vector3 val = points[(num2 + 1) % num].position - points[num2 % num].position;
		Vector3 normalized = val.normalized;
		Vector3 val2 = points[(num2 - 1 + num) % num].position - points[num2 % num].position;
		Vector3 val3 = normalized - val2.normalized;
		Vector3 normalized2 = val3.normalized;
		Vector3 val4 = points[(num2 + 2) % num].position - points[(num2 + 1) % num].position;
		Vector3 normalized3 = val4.normalized;
		Vector3 val5 = points[(num2 + num) % num].position - points[(num2 + 1) % num].position;
		Vector3 val6 = normalized3 - val5.normalized;
		Vector3 normalized4 = val6.normalized;
		Debug.DrawLine(points[num2 % num].position, points[num2 % num].position + normalized2 * tangentLengths, Color.red);
		Debug.DrawLine(points[(num2 + 1) % num].position - normalized4 * tangentLengths, points[(num2 + 1) % num].position, Color.green);
		return AstarSplines.CubicBezier(points[num2 % num].position, points[num2 % num].position + normalized2 * tangentLengths, points[(num2 + 1) % num].position - normalized4 * tangentLengths, points[(num2 + 1) % num].position, t - (float)num2);
	}

	private void Move(bool progress)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		float num = time;
		float num2 = time + 1f;
		while (num2 - num > 0.0001f)
		{
			float num3 = (num + num2) / 2f;
			Vector3 val = Plot(num3);
			Vector3 val2 = val - ((Component)this).transform.position;
			if (val2.sqrMagnitude > speed * Time.deltaTime * (speed * Time.deltaTime))
			{
				num2 = num3;
			}
			else
			{
				num = num3;
			}
		}
		time = (num + num2) / 2f;
		Vector3 val3 = Plot(time);
		Vector3 val4 = Plot(time + 0.001f);
		((Component)this).transform.position = val3;
		((Component)this).transform.rotation = Quaternion.LookRotation(val4 - val3);
	}

	public void OnDrawGizmos()
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		if (points.Length < 3)
		{
			return;
		}
		for (int i = 0; i < points.Length; i++)
		{
			if ((Object)(object)points[i] == (Object)null)
			{
				return;
			}
		}
		for (int j = 0; j < points.Length; j++)
		{
			int num = points.Length;
			Vector3 val = points[(j + 1) % num].position - points[j].position;
			Vector3 normalized = val.normalized;
			Vector3 val2 = points[(j - 1 + num) % num].position - points[j].position;
			Vector3 val3 = normalized - val2.normalized;
			Vector3 normalized2 = val3.normalized;
			Vector3 val4 = points[(j + 2) % num].position - points[(j + 1) % num].position;
			Vector3 normalized3 = val4.normalized;
			Vector3 val5 = points[(j + num) % num].position - points[(j + 1) % num].position;
			Vector3 val6 = normalized3 - val5.normalized;
			Vector3 normalized4 = val6.normalized;
			Vector3 val7 = points[j].position;
			for (int k = 1; k <= 100; k++)
			{
				Vector3 val8 = AstarSplines.CubicBezier(points[j].position, points[j].position + normalized2 * tangentLengths, points[(j + 1) % num].position - normalized4 * tangentLengths, points[(j + 1) % num].position, (float)k / 100f);
				Gizmos.DrawLine(val7, val8);
				val7 = val8;
			}
		}
	}
}
