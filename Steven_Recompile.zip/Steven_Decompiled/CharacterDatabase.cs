using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class CharacterDatabase : ScriptableObject
{
	[SerializeField]
	private List<CharacterDefinition> _characters;

	[SerializeField]
	private int _nextId = -1;

	public int totalCharacters => _characters.Count;

	public List<CharacterDefinition> characters => _characters;

	private int nextId
	{
		get
		{
			_nextId++;
			return _nextId;
		}
	}

	public CharacterDefinition GetCharacter(int uid)
	{
		int count = _characters.Count;
		for (int i = 0; i < count; i++)
		{
			if (_characters[i].uid == uid)
			{
				return _characters[i];
			}
		}
		return null;
	}

	public CharacterDefinition GetCharacter(string characterName)
	{
		int count = _characters.Count;
		for (int i = 0; i < count; i++)
		{
			if (_characters[i].characterName.ToString().Equals(characterName))
			{
				return _characters[i];
			}
		}
		return null;
	}
}
