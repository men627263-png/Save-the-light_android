using System;
using UnityEngine;

[RequireComponent(typeof(Collider))]
public class ZoneTrigger : MonoBehaviour
{
	[SerializeField]
	private Collider collider;

	public event Action<ZoneTrigger, Collider> Entered;

	public event Action<ZoneTrigger, Collider> Exited;

	private void Awake()
	{
		if ((Object)(object)collider == (Object)null)
		{
			collider = ((Component)this).GetComponent<Collider>();
		}
		collider.isTrigger = true;
		((Component)this).gameObject.layer = LayerMask.NameToLayer("Ignore Raycast");
	}

	private void OnTriggerEnter(Collider other)
	{
		if (Entered != null)
		{
			Entered(this, other);
		}
	}

	private void OnTriggerExit(Collider other)
	{
		if (Exited != null)
		{
			Exited(this, other);
		}
	}
}
