using UnityEngine;

public class ShockwaveStatusEffect : Shockwave
{
	[Space]
	[SerializeField]
	private StatusEffectInfo statusEffect;

	[SerializeField]
	private DelayedAudioEvent soundEffectOnTargetReached;

	protected override void OnTargetReached(ITargetable target, float progress)
	{
		target.StatusEffectManager.AddStatusEffect(statusEffect);
		if ((Object)(object)soundEffectOnTargetReached.audioEvent != (Object)null)
		{
			soundEffectOnTargetReached.Play();
		}
	}
}
