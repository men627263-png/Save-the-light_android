using System.Collections.Generic;
using UnityEngine;

public class SpeedZone : Zone
{
	[Range(0f, 2f)]
	public float speedFactorExploration = 1f;

	[Range(0f, 2f)]
	public float speedFactorBattle = 1f;

	private float activeSpeedFactor;

	private CharacterStatModifier explorationModifier;

	private CharacterStatModifier battleModifier;

	private CharacterStatModifier activeModifier;

	private bool inBattle;

	private List<BaseCharacter> charactersInZone = new List<BaseCharacter>();

	protected sealed override void Awake()
	{
		base.Awake();
		explorationModifier = new CharacterStatModifier(CharacterStatModifier.Types.BaseValueAdd, CharacterStatType.MovementSpeed, Mathf.RoundToInt((speedFactorExploration - 1f) * 100f), string.Empty);
		battleModifier = new CharacterStatModifier(CharacterStatModifier.Types.BaseValueAdd, CharacterStatType.MovementSpeed, Mathf.RoundToInt((speedFactorBattle - 1f) * 100f), string.Empty);
		activeModifier = explorationModifier;
		EventMessenger.Instance.AddListener<BattleStartedEvent>(HandleBattleStartedEvent);
		EventMessenger.Instance.AddListener<BattleFinishedEvent>(HandleBattleFinishedEvent);
	}

	private void OnDestroy()
	{
		EventMessenger.Instance.RemoveListener<BattleStartedEvent>(HandleBattleStartedEvent);
		EventMessenger.Instance.RemoveListener<BattleFinishedEvent>(HandleBattleFinishedEvent);
	}

	private void OnGUI()
	{
	}

	protected sealed override void OnEntered(Transform collider)
	{
		base.OnEntered(collider);
		if (((Component)collider).tag == "Player")
		{
			BaseCharacter component = ((Component)collider).GetComponent<BaseCharacter>();
			component.Stats.AddStatModifier(activeModifier);
			charactersInZone.Add(component);
		}
	}

	protected sealed override void OnExited(Transform collider)
	{
		base.OnExited(collider);
		if (((Component)collider).tag == "Player")
		{
			BaseCharacter component = ((Component)collider).GetComponent<BaseCharacter>();
			component.Stats.RemoveStatModifier(activeModifier);
			charactersInZone.Remove(component);
		}
	}

	private void Refresh()
	{
		int count = charactersInZone.Count;
		for (int i = 0; i < count; i++)
		{
			charactersInZone[i].Stats.AddStatModifier(activeModifier);
		}
	}

	private void HandleBattleStartedEvent(BattleStartedEvent evt)
	{
		inBattle = true;
		activeModifier = battleModifier;
		Refresh();
	}

	private void HandleBattleFinishedEvent(BattleFinishedEvent evt)
	{
		inBattle = false;
		activeModifier = explorationModifier;
		Refresh();
	}
}
