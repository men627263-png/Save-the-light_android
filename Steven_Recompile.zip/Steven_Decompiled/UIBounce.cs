using UnityEngine;

public class UIBounce : MonoBehaviour
{
	public float bounceSpeed;

	public float bounceAmount;

	private float timer;

	private void Update()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		timer += Time.unscaledDeltaTime;
		((Component)this).transform.localScale = Vector3.one * (1f + Mathf.Abs(Mathf.Sin(timer * bounceSpeed)) * bounceAmount);
	}
}
