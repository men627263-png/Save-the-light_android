public enum LightBitType
{
	SmallBit,
	MediumBit,
	LargeBit
}
