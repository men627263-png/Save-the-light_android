using System.Collections.Generic;
using Grumpyface;
using UnityEngine;

public class CharacterStatBuff : StatusEffect
{
	private static Dictionary<ITargetable, CharacterStatBuffFX> activeBuffFX = new Dictionary<ITargetable, CharacterStatBuffFX>();

	private CharacterStatType statType;

	private float multiplierBonus;

	private float duration;

	private float timer;

	private CharacterStatBuffFX statBuffFX;

	public sealed override StatusEffectName effectName => StatusEffectName.CharacterStatBuff;

	public sealed override bool isResettable => false;

	public sealed override bool isStackable => false;

	public sealed override bool isPersistent => true;

	public override bool isSavable => true;

	public sealed override StatusEffectType type => (multiplierBonus > 0f) ? StatusEffectType.Buff : StatusEffectType.Debuff;

	public override bool isOwnerValid => true;

	public CharacterStatType StatType => statType;

	public CharacterStatBuff(ITargetable owner, CharacterStatType statType, float multiplierBonus, float duration)
		: base(owner)
	{
		this.statType = statType;
		this.multiplierBonus = multiplierBonus;
		this.duration = duration;
	}

	protected sealed override void InitEffect()
	{
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)"Init Character Stat Buff");
		timer = duration;
		owner.Stats.AddStatModifier(new CharacterStatModifier(CharacterStatModifier.Types.BaseValuePercent, statType, multiplierBonus, string.Empty));
		if (duration > 0f)
		{
			if (activeBuffFX.ContainsKey(owner))
			{
				statBuffFX = activeBuffFX[owner];
			}
			else
			{
				statBuffFX = ObjectPool.GetObject<CharacterStatBuffFX>("CharacterStatBuff_FX", default(Vector3), true);
				((Component)statBuffFX).transform.parent = owner.transform;
				((Component)statBuffFX).transform.localPosition = Vector3.zero;
				((Component)statBuffFX).transform.localScale = Vector3.one;
				activeBuffFX.Add(owner, statBuffFX);
			}
			if ((Object)(object)statBuffFX != (Object)null)
			{
				statBuffFX.Show(statType, multiplierBonus > 0f);
			}
		}
	}

	protected sealed override void UpdateEffect()
	{
		if (duration > 0f)
		{
			timer -= Time.deltaTime;
			if (timer <= 0f)
			{
				Remove();
			}
		}
	}

	protected sealed override void RemoveEffect()
	{
		owner.Stats.RemoveStatModifier(new CharacterStatModifier(CharacterStatModifier.Types.BaseValuePercent, statType, multiplierBonus, string.Empty));
		if ((Object)(object)statBuffFX != (Object)null)
		{
			statBuffFX.Hide(statType);
		}
	}

	protected sealed override void ResetEffect()
	{
	}

	protected sealed override void CleanUp()
	{
		owner = null;
	}

	protected sealed override void InitSaveData(StatusEffectSaveData saveData)
	{
		saveData.startingData.intValue1 = (int)statType;
		saveData.startingData.floatValue1 = duration;
		saveData.startingData.floatValue2 = multiplierBonus;
		saveData.data.intValue1 = (int)statType;
		saveData.data.floatValue1 = timer;
		saveData.data.floatValue2 = multiplierBonus;
	}

	public sealed override void LoadSaveData(StatusEffectData data)
	{
		timer = data.floatValue1;
	}

	public sealed override bool Equals(object obj)
	{
		if (object.ReferenceEquals(this, obj))
		{
			return true;
		}
		if (object.ReferenceEquals(obj, null) || (object)GetType() != obj.GetType())
		{
			return false;
		}
		CharacterStatBuff characterStatBuff = (CharacterStatBuff)obj;
		return characterStatBuff.statType == statType;
	}

	public sealed override int GetHashCode()
	{
		return base.GetHashCode() ^ statType.GetHashCode();
	}
}
