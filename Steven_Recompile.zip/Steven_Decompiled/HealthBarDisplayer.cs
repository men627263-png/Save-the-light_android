using Grumpyface;
using UnityEngine;

[DisallowMultipleComponent]
public class HealthBarDisplayer : MonoBehaviour
{
	[SerializeField]
	protected GameObject healthBarPrefab;

	[SerializeField]
	[Tooltip("[Optional] Offset that may or may not be used by a HealthBar instance")]
	protected Vector3 offset;

	[SerializeField]
	[Tooltip("If TRUE, the health bar will be displayed whenever the target's health changes from damage or healing. It will then hide itself after the number of seconds specified in the 'Auto Hide Delay' field below.")]
	protected bool autoDisplay = true;

	[SerializeField]
	protected float autoHideDelay = 3f;

	protected ITargetable targetable;

	protected HealthBar activeHealthBar;

	private float autoHideDelayTimer;

	private bool shownAutomatically;

	public bool AutoDisplay
	{
		get
		{
			return autoDisplay;
		}
		set
		{
			autoDisplay = value;
		}
	}

	public GameObject overrideHealthBarPrefab { get; set; }

	public bool ignoreGameEvents { get; set; }

	private void Awake()
	{
		targetable = ((Component)this).GetComponent<ITargetable>();
		if (targetable == null || (Object)(object)healthBarPrefab == (Object)null)
		{
			Object.Destroy((Object)(object)this);
		}
	}

	protected virtual void OnEnable()
	{
		EventMessenger.Instance.AddListener<HealthBarDisplayerShowEvent>(HandleHealthBarDisplayerShowEvent);
		EventMessenger.Instance.AddListener<HealthBarDisplayerHideEvent>(HandleHealthBarDisplayerHideEvent);
		EventMessenger.Instance.AddListener<HealthBarDisplayerShowAllEvent>(HandleHealthBarDisplayerShowAllEvent);
		EventMessenger.Instance.AddListener<HealthBarDisplayerHideAllEvent>(HandleHealthBarDisplayerHideAllEvent);
		targetable.damageReceiver.DamageReceived += HandleDamageReceived;
		targetable.damageReceiver.HealReceived += HandleHealReceived;
	}

	protected virtual void OnDisable()
	{
		EventMessenger.Instance.RemoveListener<HealthBarDisplayerShowEvent>(HandleHealthBarDisplayerShowEvent);
		EventMessenger.Instance.RemoveListener<HealthBarDisplayerHideEvent>(HandleHealthBarDisplayerHideEvent);
		EventMessenger.Instance.RemoveListener<HealthBarDisplayerShowAllEvent>(HandleHealthBarDisplayerShowAllEvent);
		EventMessenger.Instance.RemoveListener<HealthBarDisplayerHideAllEvent>(HandleHealthBarDisplayerHideAllEvent);
		targetable.damageReceiver.DamageReceived -= HandleDamageReceived;
		targetable.damageReceiver.HealReceived -= HandleHealReceived;
		shownAutomatically = false;
	}

	protected virtual void Update()
	{
		if ((Object)(object)activeHealthBar != (Object)null && autoDisplay && shownAutomatically && autoHideDelayTimer > 0f)
		{
			autoHideDelayTimer -= Time.deltaTime;
			if (autoHideDelayTimer <= 0f)
			{
				Hide();
			}
		}
	}

	public void Show()
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		if (targetable.IsAlive)
		{
			if ((Object)(object)activeHealthBar == (Object)null)
			{
				GameObject val = ((!((Object)(object)overrideHealthBarPrefab != (Object)null)) ? healthBarPrefab : overrideHealthBarPrefab);
				activeHealthBar = ObjectPool.GetObject<HealthBar>(val, val.transform.localPosition, true);
				activeHealthBar.HideComplete += HandleHideComplete;
				activeHealthBar.Init(targetable, offset);
			}
			activeHealthBar.Show();
			autoHideDelayTimer = autoHideDelay;
			shownAutomatically = false;
		}
	}

	public void Hide()
	{
		if ((Object)(object)activeHealthBar != (Object)null)
		{
			activeHealthBar.Hide();
			autoHideDelayTimer = 0f;
		}
	}

	public void Hide(bool instant)
	{
		if (instant && (Object)(object)activeHealthBar != (Object)null)
		{
			HandleHideComplete();
		}
		else
		{
			Hide();
		}
	}

	protected virtual void HandleHealthBarDisplayerShowEvent(HealthBarDisplayerShowEvent evt)
	{
		if (!ignoreGameEvents && evt.targetable == targetable)
		{
			Show();
		}
	}

	protected virtual void HandleHealthBarDisplayerHideEvent(HealthBarDisplayerHideEvent evt)
	{
		if (!ignoreGameEvents && evt.targetable == targetable)
		{
			Hide(evt.instant);
		}
	}

	protected virtual void HandleHealthBarDisplayerShowAllEvent(HealthBarDisplayerShowAllEvent evt)
	{
		if (!ignoreGameEvents)
		{
			Show();
		}
	}

	protected virtual void HandleHealthBarDisplayerHideAllEvent(HealthBarDisplayerHideAllEvent evt)
	{
		if (!ignoreGameEvents)
		{
			Hide(evt.instant);
		}
	}

	private void HandleDamageReceived(DamageResult damageResult)
	{
		HandleHealthChanged();
	}

	private void HandleHealReceived(HealResult result)
	{
		HandleHealthChanged();
	}

	private void HandleHealthChanged()
	{
		if (autoDisplay)
		{
			if (targetable.IsAlive)
			{
				Show();
				shownAutomatically = true;
			}
			else if ((Object)(object)activeHealthBar != (Object)null)
			{
				HandleHideComplete();
			}
		}
	}

	private void HandleHideComplete()
	{
		activeHealthBar.HideComplete -= HandleHideComplete;
		ObjectPool.PoolObject(((Component)activeHealthBar).gameObject);
		activeHealthBar = null;
	}
}
