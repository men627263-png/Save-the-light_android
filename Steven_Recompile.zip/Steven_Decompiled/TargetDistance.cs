public enum TargetDistance
{
	Melee,
	Ranged
}
