using UnityEngine;

[ExecuteInEditMode]
public class tk2dAnimationAdapter : MonoBehaviour
{
	public bool overrideColor;

	public bool overrideColorChildren;

	public bool overrideTintColor;

	public bool overrideScale;

	public bool overrideDimensions;

	public bool overrideClipRect;

	public Color color = Color.white;

	public Color colorChildren = Color.white;

	public Color tintColor = Color.clear;

	public Vector3 scale = Vector3.one;

	public Vector2 dimensions = Vector2.zero;

	public Rect clipRect = new Rect(0f, 0f, 1f, 1f);

	[SerializeField]
	private tk2dBaseSprite sprite;

	[SerializeField]
	private tk2dBaseSprite[] childSprites;

	private tk2dTintAdapter tintAdapter;

	private tk2dSlicedSprite slicedSprite;

	private tk2dClippedSprite clippedSprite;

	public tk2dBaseSprite Sprite
	{
		get
		{
			if ((Object)(object)sprite == (Object)null)
			{
				sprite = ((Component)this).GetComponent<tk2dBaseSprite>();
			}
			return sprite;
		}
	}

	public tk2dSlicedSprite SlicedSprite
	{
		get
		{
			if ((Object)(object)slicedSprite == (Object)null && sprite is tk2dSlicedSprite)
			{
				slicedSprite = (tk2dSlicedSprite)sprite;
			}
			return slicedSprite;
		}
	}

	public tk2dClippedSprite ClippedSprite
	{
		get
		{
			if ((Object)(object)clippedSprite == (Object)null && sprite is tk2dClippedSprite)
			{
				clippedSprite = (tk2dClippedSprite)sprite;
			}
			return clippedSprite;
		}
	}

	public tk2dAnimationAdapter()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Awake()
	{
		if ((Object)(object)sprite == (Object)null)
		{
			sprite = ((Component)this).GetComponent<tk2dBaseSprite>();
		}
		if (childSprites == null)
		{
			childSprites = ((Component)this).GetComponentsInChildren<tk2dBaseSprite>(true);
			if (childSprites.Contains(sprite))
			{
				childSprites.RemoveAt(ref childSprites, childSprites.IndexOf(sprite));
			}
		}
		if (sprite is tk2dSlicedSprite)
		{
			slicedSprite = (tk2dSlicedSprite)sprite;
		}
		else if (sprite is tk2dClippedSprite)
		{
			clippedSprite = (tk2dClippedSprite)sprite;
		}
		tintAdapter = ((Component)this).GetComponent<tk2dTintAdapter>();
		if ((Object)(object)tintAdapter == (Object)null && overrideTintColor)
		{
			tintAdapter = ((Component)this).gameObject.AddComponent<tk2dTintAdapter>();
		}
	}

	private void Start()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		if (overrideColor)
		{
			Sprite.color = color;
		}
		if (overrideColorChildren)
		{
			int num = childSprites.Length;
			for (int i = 0; i < num; i++)
			{
				childSprites[i].color = colorChildren;
			}
		}
		if (overrideTintColor)
		{
			tintAdapter.tintColor = tintColor;
		}
		if (overrideScale)
		{
			Sprite.scale = scale;
		}
		if (overrideDimensions)
		{
			SlicedSprite.dimensions = dimensions;
		}
		else if (overrideClipRect)
		{
			ClippedSprite.ClipRect = clipRect;
		}
	}

	private void LateUpdate()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)Sprite != (Object)null && Sprite.CurrentSprite == null)
		{
			return;
		}
		if (overrideColor && Sprite.color != color)
		{
			Sprite.color = color;
		}
		if (overrideColorChildren)
		{
			int num = childSprites.Length;
			for (int i = 0; i < num; i++)
			{
				childSprites[i].color = colorChildren;
			}
		}
		if (Application.isPlaying && overrideTintColor && tintAdapter.tintColor != tintColor)
		{
			tintAdapter.tintColor = tintColor;
		}
		if (overrideScale && Sprite.scale != scale)
		{
			Sprite.scale = scale;
		}
		if (overrideDimensions)
		{
			SlicedSprite.dimensions = dimensions;
		}
		else if (overrideClipRect)
		{
			ClippedSprite.ClipRect = clipRect;
		}
	}
}
