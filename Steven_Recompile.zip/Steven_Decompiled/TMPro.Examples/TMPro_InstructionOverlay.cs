using UnityEngine;

namespace TMPro.Examples;

public class TMPro_InstructionOverlay : MonoBehaviour
{
	public enum FpsCounterAnchorPositions
	{
		TopLeft,
		BottomLeft,
		TopRight,
		BottomRight
	}

	public FpsCounterAnchorPositions AnchorPosition = FpsCounterAnchorPositions.BottomLeft;

	private const string instructions = "Camera Control - <#ffff00>Shift + RMB\n</color>Zoom - <#ffff00>Mouse wheel.";

	private TextMeshPro m_TextMeshPro;

	private TextContainer m_textContainer;

	private Transform m_frameCounter_transform;

	private Camera m_camera;

	private void Awake()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Expected Obj, but got Unknown
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		if (((Behaviour)this).enabled)
		{
			m_camera = Camera.main;
			GameObject val = new GameObject("Frame Counter");
			m_frameCounter_transform = val.transform;
			m_frameCounter_transform.parent = ((Component)m_camera).transform;
			m_frameCounter_transform.localRotation = Quaternion.identity;
			m_TextMeshPro = val.AddComponent<TextMeshPro>();
			m_TextMeshPro.font = Resources.Load("Fonts & Materials/ARIAL SDF", typeof(TMP_FontAsset)) as TMP_FontAsset;
			TextMeshPro textMeshPro = m_TextMeshPro;
			Object val2 = Resources.Load("Fonts & Materials/ARIAL SDF Overlay", typeof(Material));
			textMeshPro.fontSharedMaterial = (Material)(object)((val2 is Material) ? val2 : null);
			m_TextMeshPro.fontSize = 30f;
			m_TextMeshPro.isOverlay = true;
			m_textContainer = val.GetComponent<TextContainer>();
			Set_FrameCounter_Position(AnchorPosition);
			m_TextMeshPro.text = "Camera Control - <#ffff00>Shift + RMB\n</color>Zoom - <#ffff00>Mouse wheel.";
		}
	}

	private void Set_FrameCounter_Position(FpsCounterAnchorPositions anchor_position)
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		switch (anchor_position)
		{
		case FpsCounterAnchorPositions.TopLeft:
			m_textContainer.anchorPosition = TextContainerAnchors.TopLeft;
			m_frameCounter_transform.position = m_camera.ViewportToWorldPoint(new Vector3(0f, 1f, 100f));
			break;
		case FpsCounterAnchorPositions.BottomLeft:
			m_textContainer.anchorPosition = TextContainerAnchors.BottomLeft;
			m_frameCounter_transform.position = m_camera.ViewportToWorldPoint(new Vector3(0f, 0f, 100f));
			break;
		case FpsCounterAnchorPositions.TopRight:
			m_textContainer.anchorPosition = TextContainerAnchors.TopRight;
			m_frameCounter_transform.position = m_camera.ViewportToWorldPoint(new Vector3(1f, 1f, 100f));
			break;
		case FpsCounterAnchorPositions.BottomRight:
			m_textContainer.anchorPosition = TextContainerAnchors.BottomRight;
			m_frameCounter_transform.position = m_camera.ViewportToWorldPoint(new Vector3(1f, 0f, 100f));
			break;
		}
	}
}
