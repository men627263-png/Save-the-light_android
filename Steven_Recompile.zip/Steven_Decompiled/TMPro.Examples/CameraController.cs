using UnityEngine;

namespace TMPro.Examples;

public class CameraController : MonoBehaviour
{
	public enum CameraModes
	{
		Follow,
		Isometric,
		Free
	}

	private Transform cameraTransform;

	private Transform dummyTarget;

	public Transform CameraTarget;

	public float FollowDistance = 30f;

	public float MaxFollowDistance = 100f;

	public float MinFollowDistance = 2f;

	public float ElevationAngle = 30f;

	public float MaxElevationAngle = 85f;

	public float MinElevationAngle;

	public float OrbitalAngle;

	public CameraModes CameraMode;

	public bool MovementSmoothing = true;

	public bool RotationSmoothing;

	private bool previousSmoothing;

	public float MovementSmoothingValue = 25f;

	public float RotationSmoothingValue = 5f;

	public float MoveSensitivity = 2f;

	private Vector3 currentVelocity = Vector3.zero;

	private Vector3 desiredPosition;

	private float mouseX;

	private float mouseY;

	private Vector3 moveVector;

	private float mouseWheel;

	private const string event_SmoothingValue = "Slider - Smoothing Value";

	private const string event_FollowDistance = "Slider - Camera Zoom";

	public CameraController()
	{
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Awake()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Invalid comparison between Unknown and I4
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Invalid comparison between Unknown and I4
		if (QualitySettings.vSyncCount > 0)
		{
			Application.targetFrameRate = 60;
		}
		else
		{
			Application.targetFrameRate = -1;
		}
		if ((int)Application.platform == 8 || (int)Application.platform == 11)
		{
			Input.simulateMouseWithTouches = false;
		}
		cameraTransform = ((Component)this).transform;
		previousSmoothing = MovementSmoothing;
	}

	private void Start()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)CameraTarget == (Object)null)
		{
			dummyTarget = new GameObject("Camera Target").transform;
			CameraTarget = dummyTarget;
		}
	}

	private void LateUpdate()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		GetPlayerInput();
		if ((Object)(object)CameraTarget != (Object)null)
		{
			if (CameraMode == CameraModes.Isometric)
			{
				desiredPosition = CameraTarget.position + Quaternion.Euler(ElevationAngle, OrbitalAngle, 0f) * new Vector3(0f, 0f, 0f - FollowDistance);
			}
			else if (CameraMode == CameraModes.Follow)
			{
				desiredPosition = CameraTarget.position + CameraTarget.TransformDirection(Quaternion.Euler(ElevationAngle, OrbitalAngle, 0f) * new Vector3(0f, 0f, 0f - FollowDistance));
			}
			if (MovementSmoothing)
			{
				cameraTransform.position = Vector3.SmoothDamp(cameraTransform.position, desiredPosition, ref currentVelocity, MovementSmoothingValue * Time.fixedDeltaTime);
			}
			else
			{
				cameraTransform.position = desiredPosition;
			}
			if (RotationSmoothing)
			{
				cameraTransform.rotation = Quaternion.Lerp(cameraTransform.rotation, Quaternion.LookRotation(CameraTarget.position - cameraTransform.position), RotationSmoothingValue * Time.deltaTime);
			}
			else
			{
				cameraTransform.LookAt(CameraTarget);
			}
		}
	}

	private void GetPlayerInput()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_046b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0470: Unknown result type (might be due to invalid IL or missing references)
		//IL_0473: Unknown result type (might be due to invalid IL or missing references)
		//IL_0478: Unknown result type (might be due to invalid IL or missing references)
		//IL_047c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0483: Unknown result type (might be due to invalid IL or missing references)
		//IL_0488: Unknown result type (might be due to invalid IL or missing references)
		//IL_048d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0491: Unknown result type (might be due to invalid IL or missing references)
		//IL_0498: Unknown result type (might be due to invalid IL or missing references)
		//IL_049d: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Invalid comparison between Unknown and I4
		//IL_02b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0346: Unknown result type (might be due to invalid IL or missing references)
		//IL_0361: Unknown result type (might be due to invalid IL or missing references)
		//IL_0377: Unknown result type (might be due to invalid IL or missing references)
		//IL_043e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0443: Unknown result type (might be due to invalid IL or missing references)
		//IL_044f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0454: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03dd: Unknown result type (might be due to invalid IL or missing references)
		moveVector = Vector3.zero;
		mouseWheel = Input.GetAxis("Mouse ScrollWheel");
		float num = Input.touchCount;
		if (Input.GetKey((KeyCode)304) || Input.GetKey((KeyCode)303) || num > 0f)
		{
			mouseWheel *= 10f;
			if (Input.GetKeyDown((KeyCode)105))
			{
				CameraMode = CameraModes.Isometric;
			}
			if (Input.GetKeyDown((KeyCode)102))
			{
				CameraMode = CameraModes.Follow;
			}
			if (Input.GetKeyDown((KeyCode)115))
			{
				MovementSmoothing = !MovementSmoothing;
			}
			if (Input.GetMouseButton(1))
			{
				mouseY = Input.GetAxis("Mouse Y");
				mouseX = Input.GetAxis("Mouse X");
				if (mouseY > 0.01f || mouseY < -0.01f)
				{
					ElevationAngle -= mouseY * MoveSensitivity;
					ElevationAngle = Mathf.Clamp(ElevationAngle, MinElevationAngle, MaxElevationAngle);
				}
				if (mouseX > 0.01f || mouseX < -0.01f)
				{
					OrbitalAngle += mouseX * MoveSensitivity;
					if (OrbitalAngle > 360f)
					{
						OrbitalAngle -= 360f;
					}
					if (OrbitalAngle < 0f)
					{
						OrbitalAngle += 360f;
					}
				}
			}
			if (num == 1f)
			{
				Touch touch = Input.GetTouch(0);
				if ((int)touch.phase == 1)
				{
					Touch touch2 = Input.GetTouch(0);
					Vector2 deltaPosition = touch2.deltaPosition;
					if (deltaPosition.y > 0.01f || deltaPosition.y < -0.01f)
					{
						ElevationAngle -= deltaPosition.y * 0.1f;
						ElevationAngle = Mathf.Clamp(ElevationAngle, MinElevationAngle, MaxElevationAngle);
					}
					if (deltaPosition.x > 0.01f || deltaPosition.x < -0.01f)
					{
						OrbitalAngle += deltaPosition.x * 0.1f;
						if (OrbitalAngle > 360f)
						{
							OrbitalAngle -= 360f;
						}
						if (OrbitalAngle < 0f)
						{
							OrbitalAngle += 360f;
						}
					}
				}
			}
			if (Input.GetMouseButton(0))
			{
				Ray val = Camera.main.ScreenPointToRay(Input.mousePosition);
				RaycastHit val2 = default;
				if (Physics.Raycast(val, ref val2, 300f, 23552))
				{
					if ((Object)(object)val2.transform == (Object)(object)CameraTarget)
					{
						OrbitalAngle = 0f;
					}
					else
					{
						CameraTarget = val2.transform;
						OrbitalAngle = 0f;
						MovementSmoothing = previousSmoothing;
					}
				}
			}
			if (Input.GetMouseButton(2))
			{
				if ((Object)(object)dummyTarget == (Object)null)
				{
					dummyTarget = new GameObject("Camera Target").transform;
					dummyTarget.position = CameraTarget.position;
					dummyTarget.rotation = CameraTarget.rotation;
					CameraTarget = dummyTarget;
					previousSmoothing = MovementSmoothing;
					MovementSmoothing = false;
				}
				else if ((Object)(object)dummyTarget != (Object)(object)CameraTarget)
				{
					dummyTarget.position = CameraTarget.position;
					dummyTarget.rotation = CameraTarget.rotation;
					CameraTarget = dummyTarget;
					previousSmoothing = MovementSmoothing;
					MovementSmoothing = false;
				}
				mouseY = Input.GetAxis("Mouse Y");
				mouseX = Input.GetAxis("Mouse X");
				moveVector = cameraTransform.TransformDirection(mouseX, mouseY, 0f);
				dummyTarget.Translate(-moveVector, (Space)0);
			}
		}
		if (num == 2f)
		{
			Touch touch3 = Input.GetTouch(0);
			Touch touch4 = Input.GetTouch(1);
			Vector2 val3 = touch3.position - touch3.deltaPosition;
			Vector2 val4 = touch4.position - touch4.deltaPosition;
			Vector2 val5 = val3 - val4;
			float magnitude = val5.magnitude;
			Vector2 val6 = touch3.position - touch4.position;
			float magnitude2 = val6.magnitude;
			float num2 = magnitude - magnitude2;
			if (num2 > 0.01f || num2 < -0.01f)
			{
				FollowDistance += num2 * 0.25f;
				FollowDistance = Mathf.Clamp(FollowDistance, MinFollowDistance, MaxFollowDistance);
			}
		}
		if (mouseWheel < -0.01f || mouseWheel > 0.01f)
		{
			FollowDistance -= mouseWheel * 5f;
			FollowDistance = Mathf.Clamp(FollowDistance, MinFollowDistance, MaxFollowDistance);
		}
	}
}
