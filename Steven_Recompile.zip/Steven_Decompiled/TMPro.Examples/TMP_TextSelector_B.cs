using UnityEngine;
using UnityEngine.EventSystems;

namespace TMPro.Examples;

public class TMP_TextSelector_B : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler, IPointerUpHandler, IEventSystemHandler
{
	public RectTransform TextPopup_Prefab_01;

	private RectTransform m_TextPopup_RectTransform;

	private TextMeshProUGUI m_TextPopup_TMPComponent;

	private const string k_LinkText = "You have selected link <#ffff00>";

	private const string k_WordText = "Word Index: <#ffff00>";

	private TextMeshProUGUI m_TextMeshPro;

	private Canvas m_Canvas;

	private Camera m_Camera;

	private bool isHoveringObject;

	private int m_selectedWord = -1;

	private int m_selectedLink = -1;

	private int m_lastIndex = -1;

	private Matrix4x4 m_matrix;

	private TMP_MeshInfo[] m_cachedMeshInfoVertexData;

	private void Awake()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		m_TextMeshPro = ((Component)this).gameObject.GetComponent<TextMeshProUGUI>();
		m_Canvas = ((Component)this).gameObject.GetComponentInParent<Canvas>();
		if ((int)m_Canvas.renderMode == 0)
		{
			m_Camera = null;
		}
		else
		{
			m_Camera = m_Canvas.worldCamera;
		}
		m_TextPopup_RectTransform = Object.Instantiate<RectTransform>(TextPopup_Prefab_01);
		((Transform)m_TextPopup_RectTransform).SetParent(((Component)m_Canvas).transform, false);
		m_TextPopup_TMPComponent = ((Component)m_TextPopup_RectTransform).GetComponentInChildren<TextMeshProUGUI>();
		((Component)m_TextPopup_RectTransform).gameObject.SetActive(false);
	}

	private void OnEnable()
	{
		TMPro_EventManager.TEXT_CHANGED_EVENT.Add(ON_TEXT_CHANGED);
	}

	private void OnDisable()
	{
		TMPro_EventManager.TEXT_CHANGED_EVENT.Remove(ON_TEXT_CHANGED);
	}

	private void ON_TEXT_CHANGED(Object obj)
	{
		if (obj == (Object)(object)m_TextMeshPro)
		{
			m_cachedMeshInfoVertexData = m_TextMeshPro.textInfo.CopyMeshInfoVertexData();
		}
	}

	private void LateUpdate()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_039c: Unknown result type (might be due to invalid IL or missing references)
		//IL_064c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_024c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0251: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0270: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_028c: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02af: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_032f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0331: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_0353: Unknown result type (might be due to invalid IL or missing references)
		//IL_0479: Unknown result type (might be due to invalid IL or missing references)
		//IL_0483: Unknown result type (might be due to invalid IL or missing references)
		//IL_0488: Unknown result type (might be due to invalid IL or missing references)
		//IL_0493: Unknown result type (might be due to invalid IL or missing references)
		//IL_0495: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05da: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0609: Unknown result type (might be due to invalid IL or missing references)
		//IL_060b: Unknown result type (might be due to invalid IL or missing references)
		//IL_061b: Unknown result type (might be due to invalid IL or missing references)
		//IL_061d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0739: Unknown result type (might be due to invalid IL or missing references)
		//IL_076c: Unknown result type (might be due to invalid IL or missing references)
		if (isHoveringObject)
		{
			int num = TMP_TextUtilities.FindIntersectingCharacter(m_TextMeshPro, Input.mousePosition, m_Camera, visibleOnly: true);
			if (num == -1 || num != m_lastIndex)
			{
				RestoreCachedVertexAttributes(m_lastIndex);
				m_lastIndex = -1;
			}
			if (num != -1 && num != m_lastIndex && (Input.GetKey((KeyCode)304) || Input.GetKey((KeyCode)303)))
			{
				m_lastIndex = num;
				int materialReferenceIndex = m_TextMeshPro.textInfo.characterInfo[num].materialReferenceIndex;
				int vertexIndex = m_TextMeshPro.textInfo.characterInfo[num].vertexIndex;
				Vector3[] vertices = m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex].vertices;
				Vector2 val = Vector2.op_Implicit((vertices[vertexIndex] + vertices[vertexIndex + 2]) / 2f);
				Vector3 val2 = Vector2.op_Implicit(val);
				ref Vector3 reference = ref vertices[vertexIndex];
				reference = vertices[vertexIndex] - val2;
				ref Vector3 reference2 = ref vertices[vertexIndex + 1];
				reference2 = vertices[vertexIndex + 1] - val2;
				ref Vector3 reference3 = ref vertices[vertexIndex + 2];
				reference3 = vertices[vertexIndex + 2] - val2;
				ref Vector3 reference4 = ref vertices[vertexIndex + 3];
				reference4 = vertices[vertexIndex + 3] - val2;
				float num2 = 1.5f;
				m_matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, Vector3.one * num2);
				ref Vector3 reference5 = ref vertices[vertexIndex];
				reference5 = m_matrix.MultiplyPoint3x4(vertices[vertexIndex]);
				ref Vector3 reference6 = ref vertices[vertexIndex + 1];
				reference6 = m_matrix.MultiplyPoint3x4(vertices[vertexIndex + 1]);
				ref Vector3 reference7 = ref vertices[vertexIndex + 2];
				reference7 = m_matrix.MultiplyPoint3x4(vertices[vertexIndex + 2]);
				ref Vector3 reference8 = ref vertices[vertexIndex + 3];
				reference8 = m_matrix.MultiplyPoint3x4(vertices[vertexIndex + 3]);
				ref Vector3 reference9 = ref vertices[vertexIndex];
				reference9 = vertices[vertexIndex] + val2;
				ref Vector3 reference10 = ref vertices[vertexIndex + 1];
				reference10 = vertices[vertexIndex + 1] + val2;
				ref Vector3 reference11 = ref vertices[vertexIndex + 2];
				reference11 = vertices[vertexIndex + 2] + val2;
				ref Vector3 reference12 = ref vertices[vertexIndex + 3];
				reference12 = vertices[vertexIndex + 3] + val2;
				Color32 val3 = new Color32(byte.MaxValue, byte.MaxValue, (byte)192, byte.MaxValue);
				Color32[] colors = m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex].colors32;
				colors[vertexIndex] = val3;
				colors[vertexIndex + 1] = val3;
				colors[vertexIndex + 2] = val3;
				colors[vertexIndex + 3] = val3;
				TMP_MeshInfo tMP_MeshInfo = m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex];
				int dst = vertices.Length - 4;
				tMP_MeshInfo.SwapVertexData(vertexIndex, dst);
				m_TextMeshPro.UpdateVertexData(TMP_VertexDataUpdateFlags.All);
			}
			int num3 = TMP_TextUtilities.FindIntersectingWord(m_TextMeshPro, Input.mousePosition, m_Camera);
			if ((Object)(object)m_TextPopup_RectTransform != (Object)null && m_selectedWord != -1 && (num3 == -1 || num3 != m_selectedWord))
			{
				TMP_WordInfo tMP_WordInfo = m_TextMeshPro.textInfo.wordInfo[m_selectedWord];
				for (int i = 0; i < tMP_WordInfo.characterCount; i++)
				{
					int num4 = tMP_WordInfo.firstCharacterIndex + i;
					int materialReferenceIndex2 = m_TextMeshPro.textInfo.characterInfo[num4].materialReferenceIndex;
					int vertexIndex2 = m_TextMeshPro.textInfo.characterInfo[num4].vertexIndex;
					Color32[] colors2 = m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex2].colors32;
					Color32 val4 = colors2[vertexIndex2].Tint(1.33333f);
					colors2[vertexIndex2] = val4;
					colors2[vertexIndex2 + 1] = val4;
					colors2[vertexIndex2 + 2] = val4;
					colors2[vertexIndex2 + 3] = val4;
				}
				m_TextMeshPro.UpdateVertexData(TMP_VertexDataUpdateFlags.All);
				m_selectedWord = -1;
			}
			if (num3 != -1 && num3 != m_selectedWord && !Input.GetKey((KeyCode)304) && !Input.GetKey((KeyCode)303))
			{
				m_selectedWord = num3;
				TMP_WordInfo tMP_WordInfo2 = m_TextMeshPro.textInfo.wordInfo[num3];
				for (int j = 0; j < tMP_WordInfo2.characterCount; j++)
				{
					int num5 = tMP_WordInfo2.firstCharacterIndex + j;
					int materialReferenceIndex3 = m_TextMeshPro.textInfo.characterInfo[num5].materialReferenceIndex;
					int vertexIndex3 = m_TextMeshPro.textInfo.characterInfo[num5].vertexIndex;
					Color32[] colors3 = m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex3].colors32;
					Color32 val5 = colors3[vertexIndex3].Tint(0.75f);
					colors3[vertexIndex3] = val5;
					colors3[vertexIndex3 + 1] = val5;
					colors3[vertexIndex3 + 2] = val5;
					colors3[vertexIndex3 + 3] = val5;
				}
				m_TextMeshPro.UpdateVertexData(TMP_VertexDataUpdateFlags.All);
			}
			int num6 = TMP_TextUtilities.FindIntersectingLink(m_TextMeshPro, Input.mousePosition, m_Camera);
			if ((num6 == -1 && m_selectedLink != -1) || num6 != m_selectedLink)
			{
				((Component)m_TextPopup_RectTransform).gameObject.SetActive(false);
				m_selectedLink = -1;
			}
			if (num6 != -1 && num6 != m_selectedLink)
			{
				m_selectedLink = num6;
				TMP_LinkInfo tMP_LinkInfo = m_TextMeshPro.textInfo.linkInfo[num6];
				Vector3 zero = Vector3.zero;
				RectTransformUtility.ScreenPointToWorldPointInRectangle(m_TextMeshPro.rectTransform, Vector2.op_Implicit(Input.mousePosition), m_Camera, ref zero);
				switch (tMP_LinkInfo.GetLinkID())
				{
				case "id_01":
					((Transform)m_TextPopup_RectTransform).position = zero;
					((Component)m_TextPopup_RectTransform).gameObject.SetActive(true);
					m_TextPopup_TMPComponent.text = "You have selected link <#ffff00> ID 01";
					break;
				case "id_02":
					((Transform)m_TextPopup_RectTransform).position = zero;
					((Component)m_TextPopup_RectTransform).gameObject.SetActive(true);
					m_TextPopup_TMPComponent.text = "You have selected link <#ffff00> ID 02";
					break;
				}
			}
		}
		else if (m_lastIndex != -1)
		{
			RestoreCachedVertexAttributes(m_lastIndex);
			m_lastIndex = -1;
		}
	}

	public void OnPointerEnter(PointerEventData eventData)
	{
		isHoveringObject = true;
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		isHoveringObject = false;
	}

	public void OnPointerClick(PointerEventData eventData)
	{
	}

	public void OnPointerUp(PointerEventData eventData)
	{
	}

	private void RestoreCachedVertexAttributes(int index)
	{
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_027a: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0317: Unknown result type (might be due to invalid IL or missing references)
		//IL_031c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0335: Unknown result type (might be due to invalid IL or missing references)
		//IL_033a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0353: Unknown result type (might be due to invalid IL or missing references)
		//IL_0358: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03df: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0404: Unknown result type (might be due to invalid IL or missing references)
		//IL_044b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0450: Unknown result type (might be due to invalid IL or missing references)
		//IL_046b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0470: Unknown result type (might be due to invalid IL or missing references)
		//IL_048b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0490: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0517: Unknown result type (might be due to invalid IL or missing references)
		//IL_051c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0537: Unknown result type (might be due to invalid IL or missing references)
		//IL_053c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0557: Unknown result type (might be due to invalid IL or missing references)
		//IL_055c: Unknown result type (might be due to invalid IL or missing references)
		if (index != -1 && index <= m_TextMeshPro.textInfo.characterCount - 1)
		{
			int materialReferenceIndex = m_TextMeshPro.textInfo.characterInfo[index].materialReferenceIndex;
			int vertexIndex = m_TextMeshPro.textInfo.characterInfo[index].vertexIndex;
			Vector3[] vertices = m_cachedMeshInfoVertexData[materialReferenceIndex].vertices;
			Vector3[] vertices2 = m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex].vertices;
			ref Vector3 reference = ref vertices2[vertexIndex];
			reference = vertices[vertexIndex];
			ref Vector3 reference2 = ref vertices2[vertexIndex + 1];
			reference2 = vertices[vertexIndex + 1];
			ref Vector3 reference3 = ref vertices2[vertexIndex + 2];
			reference3 = vertices[vertexIndex + 2];
			ref Vector3 reference4 = ref vertices2[vertexIndex + 3];
			reference4 = vertices[vertexIndex + 3];
			Color32[] colors = m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex].colors32;
			Color32[] colors2 = m_cachedMeshInfoVertexData[materialReferenceIndex].colors32;
			ref Color32 reference5 = ref colors[vertexIndex];
			reference5 = colors2[vertexIndex];
			ref Color32 reference6 = ref colors[vertexIndex + 1];
			reference6 = colors2[vertexIndex + 1];
			ref Color32 reference7 = ref colors[vertexIndex + 2];
			reference7 = colors2[vertexIndex + 2];
			ref Color32 reference8 = ref colors[vertexIndex + 3];
			reference8 = colors2[vertexIndex + 3];
			Vector2[] uvs = m_cachedMeshInfoVertexData[materialReferenceIndex].uvs0;
			Vector2[] uvs2 = m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex].uvs0;
			ref Vector2 reference9 = ref uvs2[vertexIndex];
			reference9 = uvs[vertexIndex];
			ref Vector2 reference10 = ref uvs2[vertexIndex + 1];
			reference10 = uvs[vertexIndex + 1];
			ref Vector2 reference11 = ref uvs2[vertexIndex + 2];
			reference11 = uvs[vertexIndex + 2];
			ref Vector2 reference12 = ref uvs2[vertexIndex + 3];
			reference12 = uvs[vertexIndex + 3];
			Vector2[] uvs3 = m_cachedMeshInfoVertexData[materialReferenceIndex].uvs2;
			Vector2[] uvs4 = m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex].uvs2;
			ref Vector2 reference13 = ref uvs4[vertexIndex];
			reference13 = uvs3[vertexIndex];
			ref Vector2 reference14 = ref uvs4[vertexIndex + 1];
			reference14 = uvs3[vertexIndex + 1];
			ref Vector2 reference15 = ref uvs4[vertexIndex + 2];
			reference15 = uvs3[vertexIndex + 2];
			ref Vector2 reference16 = ref uvs4[vertexIndex + 3];
			reference16 = uvs3[vertexIndex + 3];
			int num = (vertices.Length / 4 - 1) * 4;
			ref Vector3 reference17 = ref vertices2[num];
			reference17 = vertices[num];
			ref Vector3 reference18 = ref vertices2[num + 1];
			reference18 = vertices[num + 1];
			ref Vector3 reference19 = ref vertices2[num + 2];
			reference19 = vertices[num + 2];
			ref Vector3 reference20 = ref vertices2[num + 3];
			reference20 = vertices[num + 3];
			colors2 = m_cachedMeshInfoVertexData[materialReferenceIndex].colors32;
			colors = m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex].colors32;
			ref Color32 reference21 = ref colors[num];
			reference21 = colors2[num];
			ref Color32 reference22 = ref colors[num + 1];
			reference22 = colors2[num + 1];
			ref Color32 reference23 = ref colors[num + 2];
			reference23 = colors2[num + 2];
			ref Color32 reference24 = ref colors[num + 3];
			reference24 = colors2[num + 3];
			uvs = m_cachedMeshInfoVertexData[materialReferenceIndex].uvs0;
			uvs2 = m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex].uvs0;
			ref Vector2 reference25 = ref uvs2[num];
			reference25 = uvs[num];
			ref Vector2 reference26 = ref uvs2[num + 1];
			reference26 = uvs[num + 1];
			ref Vector2 reference27 = ref uvs2[num + 2];
			reference27 = uvs[num + 2];
			ref Vector2 reference28 = ref uvs2[num + 3];
			reference28 = uvs[num + 3];
			uvs3 = m_cachedMeshInfoVertexData[materialReferenceIndex].uvs2;
			uvs4 = m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex].uvs2;
			ref Vector2 reference29 = ref uvs4[num];
			reference29 = uvs3[num];
			ref Vector2 reference30 = ref uvs4[num + 1];
			reference30 = uvs3[num + 1];
			ref Vector2 reference31 = ref uvs4[num + 2];
			reference31 = uvs3[num + 2];
			ref Vector2 reference32 = ref uvs4[num + 3];
			reference32 = uvs3[num + 3];
			m_TextMeshPro.UpdateVertexData(TMP_VertexDataUpdateFlags.All);
		}
	}
}
