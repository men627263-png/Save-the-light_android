using UnityEngine;
using UnityEngine.UI;

namespace TMPro.Examples;

public class Benchmark03 : MonoBehaviour
{
	public int SpawnType;

	public int NumberOfNPC = 12;

	public Font TheFont;

	private void Awake()
	{
	}

	private void Start()
	{
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Expected Obj, but got Unknown
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Expected Obj, but got Unknown
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < NumberOfNPC; i++)
		{
			if (SpawnType == 0)
			{
				GameObject val = new GameObject();
				val.transform.position = new Vector3(0f, 0f, 0f);
				TextMeshPro textMeshPro = val.AddComponent<TextMeshPro>();
				textMeshPro.alignment = TextAlignmentOptions.Center;
				textMeshPro.fontSize = 96f;
				textMeshPro.text = "@";
				((Graphic)textMeshPro).color = Color32.op_Implicit(new Color32(byte.MaxValue, byte.MaxValue, (byte)0, byte.MaxValue));
			}
			else
			{
				GameObject val2 = new GameObject();
				val2.transform.position = new Vector3(0f, 0f, 0f);
				TextMesh val3 = val2.AddComponent<TextMesh>();
				((Component)val3).GetComponent<Renderer>().sharedMaterial = TheFont.material;
				val3.font = TheFont;
				val3.anchor = (TextAnchor)4;
				val3.fontSize = 96;
				val3.color = Color32.op_Implicit(new Color32(byte.MaxValue, byte.MaxValue, (byte)0, byte.MaxValue));
				val3.text = "@";
			}
		}
	}
}
