using UnityEngine;
using UnityEngine.UI;

namespace TMPro.Examples;

public class Benchmark04 : MonoBehaviour
{
	public int SpawnType;

	public int MinPointSize = 12;

	public int MaxPointSize = 64;

	public int Steps = 4;

	private Transform m_Transform;

	private void Start()
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Expected Obj, but got Unknown
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		m_Transform = ((Component)this).transform;
		float num = 0f;
		float num2 = Screen.height / 2;
		Camera.main.orthographicSize = num2;
		float num3 = num2;
		float num4 = (float)Screen.width / (float)Screen.height;
		for (int i = MinPointSize; i <= MaxPointSize; i += Steps)
		{
			if (SpawnType == 0)
			{
				GameObject val = new GameObject("Arial " + i);
				if (num > num3 * 2f)
				{
					break;
				}
				val.transform.position = m_Transform.position + new Vector3(num4 * (0f - num3) * 0.975f, num3 * 0.975f - num, 0f);
				TextMeshPro textMeshPro = val.AddComponent<TextMeshPro>();
				TextContainer component = val.GetComponent<TextContainer>();
				component.anchorPosition = TextContainerAnchors.Left;
				textMeshPro.enableWordWrapping = false;
				textMeshPro.extraPadding = true;
				textMeshPro.isOrthographic = true;
				textMeshPro.fontSize = i;
				textMeshPro.text = i + " pts - Lorem ipsum dolor sit...";
				((Graphic)textMeshPro).color = Color32.op_Implicit(new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue));
				num += (float)i;
			}
		}
	}
}
