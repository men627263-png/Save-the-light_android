using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace TMPro.Examples;

public class TextMeshProFloatingText : MonoBehaviour
{
	public Font TheFont;

	private GameObject m_floatingText;

	private TextMeshPro m_textMeshPro;

	private TextContainer m_textContainer;

	private TextMesh m_textMesh;

	private Transform m_transform;

	private Transform m_floatingText_Transform;

	private Transform m_cameraTransform;

	private Vector3 lastPOS = Vector3.zero;

	private Quaternion lastRotation = Quaternion.identity;

	public int SpawnType;

	public TextMeshProFloatingText()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Awake()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Expected Obj, but got Unknown
		m_transform = ((Component)this).transform;
		m_floatingText = new GameObject(((Object)this).name + " floating text");
		m_cameraTransform = ((Component)Camera.main).transform;
	}

	private void Start()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		if (SpawnType == 0)
		{
			m_textMeshPro = m_floatingText.AddComponent<TextMeshPro>();
			m_textContainer = m_floatingText.GetComponent<TextContainer>();
			m_floatingText_Transform = m_floatingText.transform;
			m_floatingText_Transform.position = m_transform.position + new Vector3(0f, 15f, 0f);
			m_textContainer.isAutoFitting = false;
			m_textMeshPro.alignment = TextAlignmentOptions.Center;
			((Graphic)m_textMeshPro).color = Color32.op_Implicit(new Color32((byte)Random.Range(0, 255), (byte)Random.Range(0, 255), (byte)Random.Range(0, 255), byte.MaxValue));
			m_textMeshPro.fontSize = 24f;
			m_textMeshPro.text = string.Empty;
			((MonoBehaviour)this).StartCoroutine(DisplayTextMeshProFloatingText());
		}
		else if (SpawnType == 1)
		{
			m_floatingText_Transform = m_floatingText.transform;
			m_floatingText_Transform.position = m_transform.position + new Vector3(0f, 15f, 0f);
			m_textMesh = m_floatingText.AddComponent<TextMesh>();
			TextMesh textMesh = m_textMesh;
			Object val = Resources.Load("Fonts/ARIAL", typeof(Font));
			textMesh.font = (Font)(object)((val is Font) ? val : null);
			((Component)m_textMesh).GetComponent<Renderer>().sharedMaterial = m_textMesh.font.material;
			m_textMesh.color = Color32.op_Implicit(new Color32((byte)Random.Range(0, 255), (byte)Random.Range(0, 255), (byte)Random.Range(0, 255), byte.MaxValue));
			m_textMesh.anchor = (TextAnchor)7;
			m_textMesh.fontSize = 24;
			((MonoBehaviour)this).StartCoroutine(DisplayTextMeshFloatingText());
		}
		else if (SpawnType != 2)
		{
		}
	}

	public IEnumerator DisplayTextMeshProFloatingText()
	{
		float CountDuration = 2f;
		float starting_Count = Random.Range(5f, 20f);
		float current_Count = starting_Count;
		Vector3 start_pos = m_floatingText_Transform.position;
		Color32 start_color = Color32.op_Implicit(((Graphic)m_textMeshPro).color);
		float alpha = 255f;
		float fadeDuration = 3f / starting_Count * CountDuration;
		while (current_Count > 0f)
		{
			current_Count -= Time.deltaTime / CountDuration * starting_Count;
			if (current_Count <= 3f)
			{
				alpha = Mathf.Clamp(alpha - Time.deltaTime / fadeDuration * 255f, 0f, 255f);
			}
			m_textMeshPro.SetText("{0}", (int)current_Count);
			((Graphic)m_textMeshPro).color = Color32.op_Implicit(new Color32(start_color.r, start_color.g, start_color.b, (byte)alpha));
			Transform floatingText_Transform = m_floatingText_Transform;
			floatingText_Transform.position += new Vector3(0f, starting_Count * Time.deltaTime, 0f);
			if (!lastPOS.Compare(m_cameraTransform.position, 1000) || !lastRotation.Compare(m_cameraTransform.rotation, 1000))
			{
				lastPOS = m_cameraTransform.position;
				lastRotation = m_cameraTransform.rotation;
				m_floatingText_Transform.rotation = lastRotation;
				Vector3 val = m_transform.position - lastPOS;
				m_transform.forward = new Vector3(val.x, 0f, val.z);
			}
			yield return (object)new WaitForEndOfFrame();
		}
		yield return (object)new WaitForSeconds(Random.Range(0.1f, 1f));
		m_floatingText_Transform.position = start_pos;
		((MonoBehaviour)this).StartCoroutine(DisplayTextMeshProFloatingText());
	}

	public IEnumerator DisplayTextMeshFloatingText()
	{
		float CountDuration = 2f;
		float starting_Count = Random.Range(5f, 20f);
		float current_Count = starting_Count;
		Vector3 start_pos = m_floatingText_Transform.position;
		Color32 start_color = Color32.op_Implicit(m_textMesh.color);
		float alpha = 255f;
		int int_counter = 0;
		float fadeDuration = 3f / starting_Count * CountDuration;
		while (current_Count > 0f)
		{
			current_Count -= Time.deltaTime / CountDuration * starting_Count;
			if (current_Count <= 3f)
			{
				alpha = Mathf.Clamp(alpha - Time.deltaTime / fadeDuration * 255f, 0f, 255f);
			}
			m_textMesh.text = ((int)current_Count/*cast due to constrained. prefix*/).ToString();
			m_textMesh.color = Color32.op_Implicit(new Color32(start_color.r, start_color.g, start_color.b, (byte)alpha));
			Transform floatingText_Transform = m_floatingText_Transform;
			floatingText_Transform.position += new Vector3(0f, starting_Count * Time.deltaTime, 0f);
			if (!lastPOS.Compare(m_cameraTransform.position, 1000) || !lastRotation.Compare(m_cameraTransform.rotation, 1000))
			{
				lastPOS = m_cameraTransform.position;
				lastRotation = m_cameraTransform.rotation;
				m_floatingText_Transform.rotation = lastRotation;
				Vector3 val = m_transform.position - lastPOS;
				m_transform.forward = new Vector3(val.x, 0f, val.z);
			}
			yield return (object)new WaitForEndOfFrame();
		}
		yield return (object)new WaitForSeconds(Random.Range(0.1f, 1f));
		m_floatingText_Transform.position = start_pos;
		((MonoBehaviour)this).StartCoroutine(DisplayTextMeshFloatingText());
	}
}
