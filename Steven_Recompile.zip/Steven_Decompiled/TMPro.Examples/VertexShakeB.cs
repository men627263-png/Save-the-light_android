using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace TMPro.Examples;

public class VertexShakeB : MonoBehaviour
{
	public float AngleMultiplier = 1f;

	public float SpeedMultiplier = 1f;

	public float CurveScale = 1f;

	private TMP_Text m_TextComponent;

	private bool hasTextChanged;

	private void Awake()
	{
		m_TextComponent = ((Component)this).GetComponent<TMP_Text>();
	}

	private void OnEnable()
	{
		TMPro_EventManager.TEXT_CHANGED_EVENT.Add(ON_TEXT_CHANGED);
	}

	private void OnDisable()
	{
		TMPro_EventManager.TEXT_CHANGED_EVENT.Remove(ON_TEXT_CHANGED);
	}

	private void Start()
	{
		((MonoBehaviour)this).StartCoroutine(AnimateVertexColors());
	}

	private void ON_TEXT_CHANGED(Object obj)
	{
		if (Object.op_Implicit(obj = (Object)(object)m_TextComponent))
		{
			hasTextChanged = true;
		}
	}

	private IEnumerator AnimateVertexColors()
	{
		m_TextComponent.ForceMeshUpdate();
		TMP_TextInfo textInfo = m_TextComponent.textInfo;
		List<Vector3[]> copyOfVertices = new List<Vector3[]>();
		hasTextChanged = true;
		while (true)
		{
			if (hasTextChanged)
			{
				if (copyOfVertices.Count < textInfo.meshInfo.Length)
				{
					copyOfVertices = new List<Vector3[]>();
					for (int i = 0; i < textInfo.meshInfo.Length; i++)
					{
						copyOfVertices.Add(null);
					}
				}
				for (int j = 0; j < textInfo.meshInfo.Length; j++)
				{
					int num = textInfo.meshInfo[j].vertices.Length;
					copyOfVertices[j] = new Vector3[num];
				}
				hasTextChanged = false;
			}
			if (textInfo.characterCount == 0)
			{
				yield return (object)new WaitForSeconds(0.25f);
				continue;
			}
			int lineCount = textInfo.lineCount;
			for (int k = 0; k < lineCount; k++)
			{
				int firstCharacterIndex = textInfo.lineInfo[k].firstCharacterIndex;
				int lastCharacterIndex = textInfo.lineInfo[k].lastCharacterIndex;
				Vector3 val = (textInfo.characterInfo[firstCharacterIndex].bottomLeft + textInfo.characterInfo[lastCharacterIndex].topRight) / 2f;
				Quaternion val2 = Quaternion.Euler(0f, 0f, Random.Range(-0.25f, 0.25f));
				for (int l = firstCharacterIndex; l <= lastCharacterIndex; l++)
				{
					if (textInfo.characterInfo[l].isVisible)
					{
						int materialReferenceIndex = textInfo.characterInfo[l].materialReferenceIndex;
						int vertexIndex = textInfo.characterInfo[l].vertexIndex;
						Vector3[] vertices = textInfo.meshInfo[materialReferenceIndex].vertices;
						Vector3 val3 = (vertices[vertexIndex] + vertices[vertexIndex + 2]) / 2f;
						ref Vector3 reference = ref copyOfVertices[materialReferenceIndex][vertexIndex];
						reference = vertices[vertexIndex] - val3;
						ref Vector3 reference2 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 1];
						reference2 = vertices[vertexIndex + 1] - val3;
						ref Vector3 reference3 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 2];
						reference3 = vertices[vertexIndex + 2] - val3;
						ref Vector3 reference4 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 3];
						reference4 = vertices[vertexIndex + 3] - val3;
						float num2 = Random.Range(0.95f, 1.05f);
						Matrix4x4 matrix = Matrix4x4.TRS(Vector3.one, Quaternion.identity, Vector3.one * num2);
						ref Vector3 reference5 = ref copyOfVertices[materialReferenceIndex][vertexIndex];
						reference5 = matrix.MultiplyPoint3x4(copyOfVertices[materialReferenceIndex][vertexIndex]);
						ref Vector3 reference6 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 1];
						reference6 = matrix.MultiplyPoint3x4(copyOfVertices[materialReferenceIndex][vertexIndex + 1]);
						ref Vector3 reference7 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 2];
						reference7 = matrix.MultiplyPoint3x4(copyOfVertices[materialReferenceIndex][vertexIndex + 2]);
						ref Vector3 reference8 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 3];
						reference8 = matrix.MultiplyPoint3x4(copyOfVertices[materialReferenceIndex][vertexIndex + 3]);
						ref Vector3 reference9 = ref copyOfVertices[materialReferenceIndex][vertexIndex];
						reference9 += val3;
						ref Vector3 reference10 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 1];
						reference10 += val3;
						ref Vector3 reference11 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 2];
						reference11 += val3;
						ref Vector3 reference12 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 3];
						reference12 += val3;
						ref Vector3 reference13 = ref copyOfVertices[materialReferenceIndex][vertexIndex];
						reference13 -= val;
						ref Vector3 reference14 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 1];
						reference14 -= val;
						ref Vector3 reference15 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 2];
						reference15 -= val;
						ref Vector3 reference16 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 3];
						reference16 -= val;
						matrix = Matrix4x4.TRS(Vector3.one, val2, Vector3.one);
						ref Vector3 reference17 = ref copyOfVertices[materialReferenceIndex][vertexIndex];
						reference17 = matrix.MultiplyPoint3x4(copyOfVertices[materialReferenceIndex][vertexIndex]);
						ref Vector3 reference18 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 1];
						reference18 = matrix.MultiplyPoint3x4(copyOfVertices[materialReferenceIndex][vertexIndex + 1]);
						ref Vector3 reference19 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 2];
						reference19 = matrix.MultiplyPoint3x4(copyOfVertices[materialReferenceIndex][vertexIndex + 2]);
						ref Vector3 reference20 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 3];
						reference20 = matrix.MultiplyPoint3x4(copyOfVertices[materialReferenceIndex][vertexIndex + 3]);
						ref Vector3 reference21 = ref copyOfVertices[materialReferenceIndex][vertexIndex];
						reference21 += val;
						ref Vector3 reference22 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 1];
						reference22 += val;
						ref Vector3 reference23 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 2];
						reference23 += val;
						ref Vector3 reference24 = ref copyOfVertices[materialReferenceIndex][vertexIndex + 3];
						reference24 += val;
					}
				}
			}
			for (int m = 0; m < textInfo.meshInfo.Length; m++)
			{
				textInfo.meshInfo[m].mesh.vertices = copyOfVertices[m];
				m_TextComponent.UpdateGeometry(textInfo.meshInfo[m].mesh, m);
			}
			yield return (object)new WaitForSeconds(0.1f);
		}
	}
}
