using UnityEngine;
using UnityEngine.EventSystems;

namespace TMPro.Examples;

public class TMP_TextSelector_A : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IEventSystemHandler
{
	private TextMeshPro m_TextMeshPro;

	private Camera m_Camera;

	private bool m_isHoveringObject;

	private int m_selectedLink = -1;

	private int m_lastCharIndex = -1;

	private int m_lastWordIndex = -1;

	private void Awake()
	{
		m_TextMeshPro = ((Component)this).gameObject.GetComponent<TextMeshPro>();
		m_Camera = Camera.main;
		m_TextMeshPro.ForceMeshUpdate();
	}

	private void LateUpdate()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_031a: Unknown result type (might be due to invalid IL or missing references)
		//IL_031f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0369: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03db: Unknown result type (might be due to invalid IL or missing references)
		//IL_03dd: Unknown result type (might be due to invalid IL or missing references)
		m_isHoveringObject = false;
		if (TMP_TextUtilities.IsIntersectingRectTransform(m_TextMeshPro.rectTransform, Input.mousePosition, Camera.main))
		{
			m_isHoveringObject = true;
		}
		if (!m_isHoveringObject)
		{
			return;
		}
		int num = TMP_TextUtilities.FindIntersectingCharacter(m_TextMeshPro, Input.mousePosition, Camera.main, visibleOnly: true);
		if (num != -1 && num != m_lastCharIndex && (Input.GetKey((KeyCode)304) || Input.GetKey((KeyCode)303)))
		{
			m_lastCharIndex = num;
			int materialReferenceIndex = m_TextMeshPro.textInfo.characterInfo[num].materialReferenceIndex;
			int vertexIndex = m_TextMeshPro.textInfo.characterInfo[num].vertexIndex;
			Color32 val = new Color32((byte)Random.Range(0, 255), (byte)Random.Range(0, 255), (byte)Random.Range(0, 255), byte.MaxValue);
			Color32[] colors = m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex].colors32;
			colors[vertexIndex] = val;
			colors[vertexIndex + 1] = val;
			colors[vertexIndex + 2] = val;
			colors[vertexIndex + 3] = val;
			m_TextMeshPro.textInfo.meshInfo[materialReferenceIndex].mesh.colors32 = colors;
		}
		int num2 = TMP_TextUtilities.FindIntersectingLink(m_TextMeshPro, Input.mousePosition, m_Camera);
		if ((num2 == -1 && m_selectedLink != -1) || num2 != m_selectedLink)
		{
			m_selectedLink = -1;
		}
		if (num2 != -1 && num2 != m_selectedLink)
		{
			m_selectedLink = num2;
			TMP_LinkInfo tMP_LinkInfo = m_TextMeshPro.textInfo.linkInfo[num2];
			Debug.Log((object)("Link ID: \"" + tMP_LinkInfo.GetLinkID() + "\"   Link Text: \"" + tMP_LinkInfo.GetLinkText() + "\""));
			Vector3 zero = Vector3.zero;
			RectTransformUtility.ScreenPointToWorldPointInRectangle(m_TextMeshPro.rectTransform, Vector2.op_Implicit(Input.mousePosition), m_Camera, ref zero);
			switch (tMP_LinkInfo.GetLinkID())
			{
			}
		}
		int num3 = TMP_TextUtilities.FindIntersectingWord(m_TextMeshPro, Input.mousePosition, Camera.main);
		if (num3 != -1 && num3 != m_lastWordIndex)
		{
			m_lastWordIndex = num3;
			TMP_WordInfo tMP_WordInfo = m_TextMeshPro.textInfo.wordInfo[num3];
			Vector3 val2 = m_TextMeshPro.transform.TransformPoint(m_TextMeshPro.textInfo.characterInfo[tMP_WordInfo.firstCharacterIndex].bottomLeft);
			val2 = Camera.main.WorldToScreenPoint(val2);
			Color32[] colors2 = m_TextMeshPro.textInfo.meshInfo[0].colors32;
			Color32 val3 = new Color32((byte)Random.Range(0, 255), (byte)Random.Range(0, 255), (byte)Random.Range(0, 255), byte.MaxValue);
			for (int i = 0; i < tMP_WordInfo.characterCount; i++)
			{
				int vertexIndex2 = m_TextMeshPro.textInfo.characterInfo[tMP_WordInfo.firstCharacterIndex + i].vertexIndex;
				colors2[vertexIndex2] = val3;
				colors2[vertexIndex2 + 1] = val3;
				colors2[vertexIndex2 + 2] = val3;
				colors2[vertexIndex2 + 3] = val3;
			}
			m_TextMeshPro.mesh.colors32 = colors2;
		}
	}

	public void OnPointerEnter(PointerEventData eventData)
	{
		Debug.Log((object)"OnPointerEnter()");
		m_isHoveringObject = true;
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		Debug.Log((object)"OnPointerExit()");
		m_isHoveringObject = false;
	}
}
