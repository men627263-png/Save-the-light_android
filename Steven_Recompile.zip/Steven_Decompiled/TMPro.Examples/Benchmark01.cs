using System.Collections;
using UnityEngine;

namespace TMPro.Examples;

public class Benchmark01 : MonoBehaviour
{
	public int BenchmarkType;

	public TMP_FontAsset TMProFont;

	public Font TextMeshFont;

	private TextMeshPro m_textMeshPro;

	private TextContainer m_textContainer;

	private TextMesh m_textMesh;

	private const string label01 = "The <#0050FF>count is: </color>{0}";

	private const string label02 = "The <color=#0050FF>count is: </color>";

	private Material m_material01;

	private Material m_material02;

	private IEnumerator Start()
	{
		if (BenchmarkType == 0)
		{
			m_textMeshPro = ((Component)this).gameObject.AddComponent<TextMeshPro>();
			m_textContainer = ((Component)this).GetComponent<TextContainer>();
			m_textContainer.isAutoFitting = true;
			if ((Object)(object)TMProFont != (Object)null)
			{
				m_textMeshPro.font = TMProFont;
			}
			m_textMeshPro.fontSize = 48f;
			m_textMeshPro.alignment = TextAlignmentOptions.Center;
			m_textMeshPro.extraPadding = true;
			m_textMeshPro.enableWordWrapping = false;
			m_material01 = m_textMeshPro.font.material;
			Benchmark01 benchmark = this;
			Object val = Resources.Load("Fonts & Materials/ARIAL SDF - Drop Shadow", typeof(Material));
			benchmark.m_material02 = (Material)(object)((val is Material) ? val : null);
		}
		else if (BenchmarkType == 1)
		{
			m_textMesh = ((Component)this).gameObject.AddComponent<TextMesh>();
			if ((Object)(object)TextMeshFont != (Object)null)
			{
				m_textMesh.font = TextMeshFont;
				((Component)m_textMesh).GetComponent<Renderer>().sharedMaterial = m_textMesh.font.material;
			}
			else
			{
				TextMesh textMesh = m_textMesh;
				Object val2 = Resources.Load("Fonts/ARIAL", typeof(Font));
				textMesh.font = (Font)(object)((val2 is Font) ? val2 : null);
				((Component)m_textMesh).GetComponent<Renderer>().sharedMaterial = m_textMesh.font.material;
			}
			m_textMesh.fontSize = 48;
			m_textMesh.anchor = (TextAnchor)4;
		}
		for (int i = 0; i <= 1000000; i++)
		{
			if (BenchmarkType == 0)
			{
				m_textMeshPro.SetText("The <#0050FF>count is: </color>{0}", i % 1000);
				if (i % 1000 == 999)
				{
					TextMeshPro textMeshPro = m_textMeshPro;
					Material fontSharedMaterial;
					if ((Object)(object)m_textMeshPro.fontSharedMaterial == (Object)(object)m_material01)
					{
						Material material = m_material02;
						m_textMeshPro.fontSharedMaterial = material;
						fontSharedMaterial = material;
					}
					else
					{
						Material material = m_material01;
						m_textMeshPro.fontSharedMaterial = material;
						fontSharedMaterial = material;
					}
					textMeshPro.fontSharedMaterial = fontSharedMaterial;
				}
			}
			else if (BenchmarkType == 1)
			{
				m_textMesh.text = "The <color=#0050FF>count is: </color>" + i % 1000;
			}
			yield return null;
		}
		yield return null;
	}
}
