using UnityEngine;

namespace TMPro.Examples;

public class TMP_FrameRateCounter : MonoBehaviour
{
	public enum FpsCounterAnchorPositions
	{
		TopLeft,
		BottomLeft,
		TopRight,
		BottomRight
	}

	public float UpdateInterval = 5f;

	private float m_LastInterval;

	private int m_Frames;

	public FpsCounterAnchorPositions AnchorPosition = FpsCounterAnchorPositions.TopRight;

	private string htmlColorTag;

	private const string fpsLabel = "{0:2}</color> FPS \n{1:2} <#8080ff>MS";

	private TextMeshPro m_TextMeshPro;

	private TextContainer m_textContainer;

	private Transform m_frameCounter_transform;

	private Camera m_camera;

	private FpsCounterAnchorPositions last_AnchorPosition;

	private void Awake()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Expected Obj, but got Unknown
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		if (((Behaviour)this).enabled)
		{
			m_camera = Camera.main;
			Application.targetFrameRate = -1;
			GameObject val = new GameObject("Frame Counter");
			m_TextMeshPro = val.AddComponent<TextMeshPro>();
			m_TextMeshPro.font = Resources.Load("Fonts & Materials/ARIAL SDF", typeof(TMP_FontAsset)) as TMP_FontAsset;
			TextMeshPro textMeshPro = m_TextMeshPro;
			Object val2 = Resources.Load("Fonts & Materials/ARIAL SDF Overlay", typeof(Material));
			textMeshPro.fontSharedMaterial = (Material)(object)((val2 is Material) ? val2 : null);
			m_frameCounter_transform = val.transform;
			m_frameCounter_transform.SetParent(((Component)m_camera).transform);
			m_frameCounter_transform.localRotation = Quaternion.identity;
			m_TextMeshPro.enableWordWrapping = false;
			m_TextMeshPro.fontSize = 24f;
			m_TextMeshPro.isOverlay = true;
			m_textContainer = val.GetComponent<TextContainer>();
			Set_FrameCounter_Position(AnchorPosition);
			last_AnchorPosition = AnchorPosition;
		}
	}

	private void Start()
	{
		m_LastInterval = Time.realtimeSinceStartup;
		m_Frames = 0;
	}

	private void Update()
	{
		if (AnchorPosition != last_AnchorPosition)
		{
			Set_FrameCounter_Position(AnchorPosition);
		}
		last_AnchorPosition = AnchorPosition;
		m_Frames++;
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		if (realtimeSinceStartup > m_LastInterval + UpdateInterval)
		{
			float num = (float)m_Frames / (realtimeSinceStartup - m_LastInterval);
			float arg = 1000f / Mathf.Max(num, 1E-05f);
			if (num < 30f)
			{
				htmlColorTag = "<color=yellow>";
			}
			else if (num < 10f)
			{
				htmlColorTag = "<color=red>";
			}
			else
			{
				htmlColorTag = "<color=green>";
			}
			m_TextMeshPro.SetText(htmlColorTag + "{0:2}</color> FPS \n{1:2} <#8080ff>MS", num, arg);
			m_Frames = 0;
			m_LastInterval = realtimeSinceStartup;
		}
	}

	private void Set_FrameCounter_Position(FpsCounterAnchorPositions anchor_position)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		m_textContainer.margins = new Vector4(1f, 1f, 1f, 1f);
		switch (anchor_position)
		{
		case FpsCounterAnchorPositions.TopLeft:
			m_TextMeshPro.alignment = TextAlignmentOptions.TopLeft;
			m_textContainer.anchorPosition = TextContainerAnchors.TopLeft;
			m_frameCounter_transform.position = m_camera.ViewportToWorldPoint(new Vector3(0f, 1f, 100f));
			break;
		case FpsCounterAnchorPositions.BottomLeft:
			m_TextMeshPro.alignment = TextAlignmentOptions.BottomLeft;
			m_textContainer.anchorPosition = TextContainerAnchors.BottomLeft;
			m_frameCounter_transform.position = m_camera.ViewportToWorldPoint(new Vector3(0f, 0f, 100f));
			break;
		case FpsCounterAnchorPositions.TopRight:
			m_TextMeshPro.alignment = TextAlignmentOptions.TopRight;
			m_textContainer.anchorPosition = TextContainerAnchors.TopRight;
			m_frameCounter_transform.position = m_camera.ViewportToWorldPoint(new Vector3(1f, 1f, 100f));
			break;
		case FpsCounterAnchorPositions.BottomRight:
			m_TextMeshPro.alignment = TextAlignmentOptions.BottomRight;
			m_textContainer.anchorPosition = TextContainerAnchors.BottomRight;
			m_frameCounter_transform.position = m_camera.ViewportToWorldPoint(new Vector3(1f, 0f, 100f));
			break;
		}
	}
}
