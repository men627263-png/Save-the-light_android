using System.Collections;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

namespace TMPro.Examples;

public class FloatingText : MonoBehaviour
{
	private GameObject m_floatingText;

	private TextMeshPro m_textMeshPro;

	private TextMesh m_textMesh;

	private NavMeshAgent m_navAgent;

	private Transform m_transform;

	private Transform m_floatingText_Transform;

	private Transform m_cameraTransform;

	private Vector3 lastPOS = Vector3.zero;

	private Quaternion lastRotation = Quaternion.identity;

	public int SpawnType;

	public FloatingText()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
	}

	private void Awake()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Expected Obj, but got Unknown
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		m_transform = ((Component)this).transform;
		m_navAgent = ((Component)this).GetComponent<NavMeshAgent>();
		m_floatingText = new GameObject(((Object)m_transform).name + " floating text");
		m_floatingText_Transform = m_floatingText.transform;
		m_floatingText_Transform.parent = m_transform;
		m_floatingText_Transform.localPosition = new Vector3(0f, 1f, 0f);
		m_cameraTransform = ((Component)Camera.main).transform;
	}

	private void Start()
	{
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		if (SpawnType == 0)
		{
			m_textMeshPro = m_floatingText.AddComponent<TextMeshPro>();
			((Graphic)m_textMeshPro).color = Color32.op_Implicit(new Color32((byte)Random.Range(0, 255), (byte)Random.Range(0, 255), (byte)Random.Range(0, 255), byte.MaxValue));
			m_textMeshPro.fontSize = 16f;
			m_textMeshPro.text = string.Empty;
			((MonoBehaviour)this).StartCoroutine(DisplayTextMeshProFloatingText());
		}
		else
		{
			m_textMesh = m_floatingText.AddComponent<TextMesh>();
			TextMesh textMesh = m_textMesh;
			Object val = Resources.Load("Fonts/ARIAL", typeof(Font));
			textMesh.font = (Font)(object)((val is Font) ? val : null);
			((Component)m_textMesh).GetComponent<Renderer>().sharedMaterial = m_textMesh.font.material;
			m_textMesh.color = Color32.op_Implicit(new Color32((byte)Random.Range(0, 255), (byte)Random.Range(0, 255), (byte)Random.Range(0, 255), byte.MaxValue));
			m_textMesh.anchor = (TextAnchor)7;
			m_textMesh.fontSize = 16;
			((MonoBehaviour)this).StartCoroutine(DisplayTextMeshFloatingText());
		}
	}

	public IEnumerator DisplayTextMeshProFloatingText()
	{
		while (true)
		{
			m_textMeshPro.text = m_navAgent.remainingDistance.ToString("f2");
			if (!lastPOS.Compare(m_cameraTransform.position, 1000) || !lastRotation.Compare(m_cameraTransform.rotation, 1000))
			{
				lastPOS = m_cameraTransform.position;
				lastRotation = m_cameraTransform.rotation;
				m_floatingText_Transform.rotation = lastRotation;
			}
			yield return (object)new WaitForEndOfFrame();
		}
	}

	public IEnumerator DisplayTextMeshFloatingText()
	{
		while (true)
		{
			m_textMesh.text = m_navAgent.remainingDistance.ToString("f2");
			if (!lastPOS.Compare(m_cameraTransform.position, 1000) || !lastRotation.Compare(m_cameraTransform.rotation, 1000))
			{
				lastPOS = m_cameraTransform.position;
				lastRotation = m_cameraTransform.rotation;
				m_floatingText_Transform.rotation = lastRotation;
			}
			yield return (object)new WaitForEndOfFrame();
		}
	}
}
