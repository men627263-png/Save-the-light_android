using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace TMPro.Examples;

public class Benchmark01_UGUI : MonoBehaviour
{
	public int BenchmarkType;

	public Canvas canvas;

	public TMP_FontAsset TMProFont;

	public Font TextMeshFont;

	private TextMeshProUGUI m_textMeshPro;

	private Text m_textMesh;

	private const string label01 = "The <#0050FF>count is: </color>";

	private const string label02 = "The <color=#0050FF>count is: </color>";

	private Material m_material01;

	private Material m_material02;

	private IEnumerator Start()
	{
		if (BenchmarkType == 0)
		{
			m_textMeshPro = ((Component)this).gameObject.AddComponent<TextMeshProUGUI>();
			if ((Object)(object)TMProFont != (Object)null)
			{
				m_textMeshPro.font = TMProFont;
			}
			m_textMeshPro.fontSize = 48f;
			m_textMeshPro.alignment = TextAlignmentOptions.Center;
			m_textMeshPro.extraPadding = true;
			m_material01 = m_textMeshPro.font.material;
			Benchmark01_UGUI benchmark01_UGUI = this;
			Object val = Resources.Load("Fonts & Materials/ARIAL SDF BEVEL", typeof(Material));
			benchmark01_UGUI.m_material02 = (Material)(object)((val is Material) ? val : null);
		}
		else if (BenchmarkType == 1)
		{
			m_textMesh = ((Component)this).gameObject.AddComponent<Text>();
			if ((Object)(object)TextMeshFont != (Object)null)
			{
				m_textMesh.font = TextMeshFont;
			}
			m_textMesh.fontSize = 48;
			m_textMesh.alignment = (TextAnchor)4;
		}
		for (int i = 0; i <= 1000000; i++)
		{
			if (BenchmarkType == 0)
			{
				m_textMeshPro.text = "The <#0050FF>count is: </color>" + i % 1000;
				if (i % 1000 == 999)
				{
					TextMeshProUGUI textMeshPro = m_textMeshPro;
					Material fontSharedMaterial;
					if ((Object)(object)m_textMeshPro.fontSharedMaterial == (Object)(object)m_material01)
					{
						Material material = m_material02;
						m_textMeshPro.fontSharedMaterial = material;
						fontSharedMaterial = material;
					}
					else
					{
						Material material = m_material01;
						m_textMeshPro.fontSharedMaterial = material;
						fontSharedMaterial = material;
					}
					textMeshPro.fontSharedMaterial = fontSharedMaterial;
				}
			}
			else if (BenchmarkType == 1)
			{
				m_textMesh.text = "The <color=#0050FF>count is: </color>" + i % 1000;
			}
			yield return null;
		}
		yield return null;
	}
}
