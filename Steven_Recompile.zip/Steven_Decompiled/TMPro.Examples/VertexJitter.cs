using System.Collections;
using UnityEngine;

namespace TMPro.Examples;

public class VertexJitter : MonoBehaviour
{
	private struct VertexAnim
	{
		public float angleRange;

		public float angle;

		public float speed;
	}

	public float AngleMultiplier = 1f;

	public float SpeedMultiplier = 1f;

	public float CurveScale = 1f;

	private TMP_Text m_TextComponent;

	private bool hasTextChanged;

	private void Awake()
	{
		m_TextComponent = ((Component)this).GetComponent<TMP_Text>();
	}

	private void OnEnable()
	{
		TMPro_EventManager.TEXT_CHANGED_EVENT.Add(ON_TEXT_CHANGED);
	}

	private void OnDisable()
	{
		TMPro_EventManager.TEXT_CHANGED_EVENT.Remove(ON_TEXT_CHANGED);
	}

	private void Start()
	{
		((MonoBehaviour)this).StartCoroutine(AnimateVertexColors());
	}

	private void ON_TEXT_CHANGED(Object obj)
	{
		if (obj == (Object)(object)m_TextComponent)
		{
			hasTextChanged = true;
		}
	}

	private IEnumerator AnimateVertexColors()
	{
		m_TextComponent.ForceMeshUpdate();
		TMP_TextInfo textInfo = m_TextComponent.textInfo;
		int loopCount = 0;
		hasTextChanged = true;
		VertexAnim[] vertexAnim = new VertexAnim[1024];
		for (int i = 0; i < 1024; i++)
		{
			vertexAnim[i].angleRange = Random.Range(10f, 25f);
			vertexAnim[i].speed = Random.Range(1f, 3f);
		}
		TMP_MeshInfo[] cachedMeshInfo = textInfo.CopyMeshInfoVertexData();
		while (true)
		{
			if (hasTextChanged)
			{
				cachedMeshInfo = textInfo.CopyMeshInfoVertexData();
				hasTextChanged = false;
			}
			int characterCount = textInfo.characterCount;
			if (characterCount == 0)
			{
				yield return (object)new WaitForSeconds(0.25f);
				continue;
			}
			for (int j = 0; j < characterCount; j++)
			{
				TMP_CharacterInfo tMP_CharacterInfo = textInfo.characterInfo[j];
				if (tMP_CharacterInfo.isVisible)
				{
					VertexAnim vertexAnim2 = vertexAnim[j];
					int materialReferenceIndex = textInfo.characterInfo[j].materialReferenceIndex;
					int vertexIndex = textInfo.characterInfo[j].vertexIndex;
					Vector3[] vertices = cachedMeshInfo[materialReferenceIndex].vertices;
					Vector2 val = Vector2.op_Implicit((vertices[vertexIndex] + vertices[vertexIndex + 2]) / 2f);
					Vector3 val2 = Vector2.op_Implicit(val);
					Vector3[] vertices2 = textInfo.meshInfo[materialReferenceIndex].vertices;
					ref Vector3 reference = ref vertices2[vertexIndex];
					reference = vertices[vertexIndex] - val2;
					ref Vector3 reference2 = ref vertices2[vertexIndex + 1];
					reference2 = vertices[vertexIndex + 1] - val2;
					ref Vector3 reference3 = ref vertices2[vertexIndex + 2];
					reference3 = vertices[vertexIndex + 2] - val2;
					ref Vector3 reference4 = ref vertices2[vertexIndex + 3];
					reference4 = vertices[vertexIndex + 3] - val2;
					vertexAnim2.angle = Mathf.SmoothStep(0f - vertexAnim2.angleRange, vertexAnim2.angleRange, Mathf.PingPong((float)loopCount / 25f * vertexAnim2.speed, 1f));
					Vector3 val3 = new Vector3(Random.Range(-0.25f, 0.25f), Random.Range(-0.25f, 0.25f), 0f);
					Matrix4x4 matrix = Matrix4x4.TRS(val3 * CurveScale, Quaternion.Euler(0f, 0f, Random.Range(-5f, 5f) * AngleMultiplier), Vector3.one);
					ref Vector3 reference5 = ref vertices2[vertexIndex];
					reference5 = matrix.MultiplyPoint3x4(vertices2[vertexIndex]);
					ref Vector3 reference6 = ref vertices2[vertexIndex + 1];
					reference6 = matrix.MultiplyPoint3x4(vertices2[vertexIndex + 1]);
					ref Vector3 reference7 = ref vertices2[vertexIndex + 2];
					reference7 = matrix.MultiplyPoint3x4(vertices2[vertexIndex + 2]);
					ref Vector3 reference8 = ref vertices2[vertexIndex + 3];
					reference8 = matrix.MultiplyPoint3x4(vertices2[vertexIndex + 3]);
					ref Vector3 reference9 = ref vertices2[vertexIndex];
					reference9 += val2;
					ref Vector3 reference10 = ref vertices2[vertexIndex + 1];
					reference10 += val2;
					ref Vector3 reference11 = ref vertices2[vertexIndex + 2];
					reference11 += val2;
					ref Vector3 reference12 = ref vertices2[vertexIndex + 3];
					reference12 += val2;
					vertexAnim[j] = vertexAnim2;
				}
			}
			for (int k = 0; k < textInfo.meshInfo.Length; k++)
			{
				textInfo.meshInfo[k].mesh.vertices = textInfo.meshInfo[k].vertices;
				m_TextComponent.UpdateGeometry(textInfo.meshInfo[k].mesh, k);
			}
			loopCount++;
			yield return (object)new WaitForSeconds(0.1f);
		}
	}
}
