using UnityEngine;
using UnityEngine.UI;

namespace TMPro.Examples;

public class Benchmark02 : MonoBehaviour
{
	public int SpawnType;

	public int NumberOfNPC = 12;

	private TextMeshProFloatingText floatingText_Script;

	private void Start()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Expected Obj, but got Unknown
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Expected Obj, but got Unknown
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Expected Obj, but got Unknown
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < NumberOfNPC; i++)
		{
			if (SpawnType == 0)
			{
				GameObject val = new GameObject();
				val.transform.position = new Vector3(Random.Range(-95f, 95f), 0.25f, Random.Range(-95f, 95f));
				TextMeshPro textMeshPro = val.AddComponent<TextMeshPro>();
				TextContainer component = val.GetComponent<TextContainer>();
				component.isAutoFitting = false;
				textMeshPro.alignment = TextAlignmentOptions.Bottom;
				textMeshPro.fontSize = 96f;
				((Graphic)textMeshPro).color = Color32.op_Implicit(new Color32(byte.MaxValue, byte.MaxValue, (byte)0, byte.MaxValue));
				textMeshPro.text = "!";
				floatingText_Script = val.AddComponent<TextMeshProFloatingText>();
				floatingText_Script.SpawnType = 0;
			}
			else if (SpawnType == 1)
			{
				GameObject val2 = new GameObject();
				val2.transform.position = new Vector3(Random.Range(-95f, 95f), 0.25f, Random.Range(-95f, 95f));
				TextMesh val3 = val2.AddComponent<TextMesh>();
				Object val4 = Resources.Load("Fonts/ARIAL", typeof(Font));
				val3.font = (Font)(object)((val4 is Font) ? val4 : null);
				((Component)val3).GetComponent<Renderer>().sharedMaterial = val3.font.material;
				val3.anchor = (TextAnchor)7;
				val3.fontSize = 96;
				val3.color = Color32.op_Implicit(new Color32(byte.MaxValue, byte.MaxValue, (byte)0, byte.MaxValue));
				val3.text = "!";
				floatingText_Script = val2.AddComponent<TextMeshProFloatingText>();
				floatingText_Script.SpawnType = 1;
			}
			else if (SpawnType == 2)
			{
				GameObject val5 = new GameObject();
				Canvas val6 = val5.AddComponent<Canvas>();
				val6.worldCamera = Camera.main;
				val5.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
				val5.transform.position = new Vector3(Random.Range(-95f, 95f), 5f, Random.Range(-95f, 95f));
				TextMeshProUGUI textMeshProUGUI = new GameObject().AddComponent<TextMeshProUGUI>();
				((Transform)textMeshProUGUI.rectTransform).SetParent(val5.transform, false);
				((Graphic)textMeshProUGUI).color = Color32.op_Implicit(new Color32(byte.MaxValue, byte.MaxValue, (byte)0, byte.MaxValue));
				textMeshProUGUI.alignment = TextAlignmentOptions.Bottom;
				textMeshProUGUI.fontSize = 96f;
				textMeshProUGUI.text = "!";
				floatingText_Script = val5.AddComponent<TextMeshProFloatingText>();
				floatingText_Script.SpawnType = 0;
			}
		}
	}
}
