using Rewired.Utils;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper;

[AddComponentMenu("")]
[RequireComponent(typeof(Selectable))]
public class ScrollRectSelectableChild : MonoBehaviour, ISelectHandler, IEventSystemHandler
{
	public bool useCustomEdgePadding;

	public float customEdgePadding = 50f;

	private ScrollRect parentScrollRect;

	private Selectable _selectable;

	private RectTransform parentScrollRectContentTransform => parentScrollRect.content;

	private Selectable selectable => _selectable ?? (_selectable = ((Component)this).GetComponent<Selectable>());

	private RectTransform rectTransform
	{
		get
		{
			Transform transform = ((Component)this).transform;
			return (RectTransform)(object)((transform is RectTransform) ? transform : null);
		}
	}

	private void Start()
	{
		parentScrollRect = ((Component)((Component)this).transform).GetComponentInParent<ScrollRect>();
		if ((Object)(object)parentScrollRect == (Object)null)
		{
			Debug.LogError((object)"Rewired Control Mapper: No ScrollRect found! This component must be a child of a ScrollRect!");
		}
	}

	public void OnSelect(BaseEventData eventData)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)parentScrollRect == (Object)null)
		{
			return;
		}
		AxisEventData val = (AxisEventData)(object)((eventData is AxisEventData) ? eventData : null);
		if (val != null)
		{
			Transform transform = ((Component)parentScrollRect).transform;
			RectTransform val2 = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			Rect val3 = MathTools.TransformRect(rectTransform.rect, (Transform)(object)rectTransform, (Transform)(object)val2);
			Rect rect = val2.rect;
			Rect rect2 = val2.rect;
			float num = ((!useCustomEdgePadding) ? val3.height : customEdgePadding);
			rect2.yMax -= num;
			rect2.yMin += num;
			Vector2 val4 = default;
			if (!MathTools.RectContains(rect2, val3) && MathTools.GetOffsetToContainRect(rect2, val3, ref val4))
			{
				Vector2 anchoredPosition = parentScrollRectContentTransform.anchoredPosition;
				anchoredPosition.x = Mathf.Clamp(anchoredPosition.x + val4.x, 0f, Mathf.Abs(rect.width - parentScrollRectContentTransform.sizeDelta.x));
				anchoredPosition.y = Mathf.Clamp(anchoredPosition.y + val4.y, 0f, Mathf.Abs(rect.height - parentScrollRectContentTransform.sizeDelta.y));
				parentScrollRectContentTransform.anchoredPosition = anchoredPosition;
			}
		}
	}
}
