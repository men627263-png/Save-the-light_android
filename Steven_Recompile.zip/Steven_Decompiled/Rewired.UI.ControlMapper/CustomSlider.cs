using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper;

[AddComponentMenu("")]
public class CustomSlider : Slider, ICustomSelectable, ICancelHandler, IEventSystemHandler
{
	[SerializeField]
	private Sprite _disabledHighlightedSprite;

	[SerializeField]
	private Color _disabledHighlightedColor;

	[SerializeField]
	private string _disabledHighlightedTrigger;

	[SerializeField]
	private bool _autoNavUp = true;

	[SerializeField]
	private bool _autoNavDown = true;

	[SerializeField]
	private bool _autoNavLeft = true;

	[SerializeField]
	private bool _autoNavRight = true;

	private bool isHighlightDisabled;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private UnityAction m__CancelEvent;

	public Sprite disabledHighlightedSprite
	{
		get
		{
			return _disabledHighlightedSprite;
		}
		set
		{
			_disabledHighlightedSprite = value;
		}
	}

	public Color disabledHighlightedColor
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return _disabledHighlightedColor;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			_disabledHighlightedColor = value;
		}
	}

	public string disabledHighlightedTrigger
	{
		get
		{
			return _disabledHighlightedTrigger;
		}
		set
		{
			_disabledHighlightedTrigger = value;
		}
	}

	public bool autoNavUp
	{
		get
		{
			return _autoNavUp;
		}
		set
		{
			_autoNavUp = value;
		}
	}

	public bool autoNavDown
	{
		get
		{
			return _autoNavDown;
		}
		set
		{
			_autoNavDown = value;
		}
	}

	public bool autoNavLeft
	{
		get
		{
			return _autoNavLeft;
		}
		set
		{
			_autoNavLeft = value;
		}
	}

	public bool autoNavRight
	{
		get
		{
			return _autoNavRight;
		}
		set
		{
			_autoNavRight = value;
		}
	}

	private bool isDisabled => !((Selectable)this).IsInteractable();

	private event UnityAction _CancelEvent
	{
		add
		{
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			//IL_0021: Expected Obj, but got Unknown
			UnityAction val = this.m__CancelEvent;
			UnityAction val2;
			do
			{
				val2 = val;
				val = Interlocked.CompareExchange(ref this.m__CancelEvent, (UnityAction)Delegate.Combine((Delegate?)(object)val2, (Delegate?)(object)value), val);
			}
			while (val != val2);
		}
		remove
		{
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			//IL_0021: Expected Obj, but got Unknown
			UnityAction val = this.m__CancelEvent;
			UnityAction val2;
			do
			{
				val2 = val;
				val = Interlocked.CompareExchange(ref this.m__CancelEvent, (UnityAction)Delegate.Remove((Delegate?)(object)val2, (Delegate?)(object)value), val);
			}
			while (val != val2);
		}
	}

	public event UnityAction CancelEvent
	{
		add
		{
			_CancelEvent += value;
		}
		remove
		{
			_CancelEvent -= value;
		}
	}

	public override Selectable FindSelectableOnLeft()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		Navigation navigation = ((Selectable)this).navigation;
		if ((navigation.mode & 1) != 0 || _autoNavLeft)
		{
			return UISelectionUtility.FindNextSelectable((Selectable)(object)this, ((Component)this).transform, Selectable.allSelectables, Vector3.left);
		}
		return ((Slider)this).FindSelectableOnLeft();
	}

	public override Selectable FindSelectableOnRight()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		Navigation navigation = ((Selectable)this).navigation;
		if ((navigation.mode & 1) != 0 || _autoNavRight)
		{
			return UISelectionUtility.FindNextSelectable((Selectable)(object)this, ((Component)this).transform, Selectable.allSelectables, Vector3.right);
		}
		return ((Slider)this).FindSelectableOnRight();
	}

	public override Selectable FindSelectableOnUp()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		Navigation navigation = ((Selectable)this).navigation;
		if ((navigation.mode & 2) != 0 || _autoNavUp)
		{
			return UISelectionUtility.FindNextSelectable((Selectable)(object)this, ((Component)this).transform, Selectable.allSelectables, Vector3.up);
		}
		return ((Slider)this).FindSelectableOnUp();
	}

	public override Selectable FindSelectableOnDown()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		Navigation navigation = ((Selectable)this).navigation;
		if ((navigation.mode & 2) != 0 || _autoNavDown)
		{
			return UISelectionUtility.FindNextSelectable((Selectable)(object)this, ((Component)this).transform, Selectable.allSelectables, Vector3.down);
		}
		return ((Slider)this).FindSelectableOnDown();
	}

	protected override void OnCanvasGroupChanged()
	{
		((Selectable)this).OnCanvasGroupChanged();
		if (!((Object)(object)EventSystem.current == (Object)null))
		{
			EvaluateHightlightDisabled((Object)(object)EventSystem.current.currentSelectedGameObject == (Object)(object)((Component)this).gameObject);
		}
	}

	protected override void DoStateTransition(SelectionState state, bool instant)
	{
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Invalid comparison between Unknown and I4
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Invalid comparison between Unknown and I4
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Invalid comparison between Unknown and I4
		if (isHighlightDisabled)
		{
			Color val = _disabledHighlightedColor;
			Sprite newSprite = _disabledHighlightedSprite;
			string triggername = _disabledHighlightedTrigger;
			if (!((Component)this).gameObject.activeInHierarchy)
			{
				return;
			}
			Transition transition = ((Selectable)this).transition;
			if ((int)transition != 1)
			{
				if ((int)transition != 2)
				{
					if ((int)transition == 3)
					{
						TriggerAnimation(triggername);
					}
				}
				else
				{
					DoSpriteSwap(newSprite);
				}
			}
			else
			{
				ColorBlock colors = ((Selectable)this).colors;
				StartColorTween(val * colors.colorMultiplier, instant);
			}
		}
		else
		{
			((Selectable)this).DoStateTransition(state, instant);
		}
	}

	private void StartColorTween(Color targetColor, bool instant)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)((Selectable)this).targetGraphic == (Object)null))
		{
			Graphic targetGraphic = ((Selectable)this).targetGraphic;
			float num;
			if (instant)
			{
				num = 0f;
			}
			else
			{
				ColorBlock colors = ((Selectable)this).colors;
				num = colors.fadeDuration;
			}
			targetGraphic.CrossFadeColor(targetColor, num, true, true);
		}
	}

	private void DoSpriteSwap(Sprite newSprite)
	{
		if (!((Object)(object)((Selectable)this).image == (Object)null))
		{
			((Selectable)this).image.overrideSprite = newSprite;
		}
	}

	private void TriggerAnimation(string triggername)
	{
		if (!((Object)(object)((Selectable)this).animator == (Object)null) && ((Behaviour)((Selectable)this).animator).enabled && ((Behaviour)((Selectable)this).animator).isActiveAndEnabled && !((Object)(object)((Selectable)this).animator.runtimeAnimatorController == (Object)null) && !string.IsNullOrEmpty(triggername))
		{
			((Selectable)this).animator.ResetTrigger(_disabledHighlightedTrigger);
			((Selectable)this).animator.SetTrigger(triggername);
		}
	}

	public override void OnSelect(BaseEventData eventData)
	{
		((Selectable)this).OnSelect(eventData);
		EvaluateHightlightDisabled(isSelected: true);
	}

	public override void OnDeselect(BaseEventData eventData)
	{
		((Selectable)this).OnDeselect(eventData);
		EvaluateHightlightDisabled(isSelected: false);
	}

	private void EvaluateHightlightDisabled(bool isSelected)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		if (!isSelected)
		{
			if (isHighlightDisabled)
			{
				isHighlightDisabled = false;
				SelectionState val = (SelectionState)(isDisabled ? 3 : ((int)((Selectable)this).currentSelectionState));
				((Selectable)this).DoStateTransition(val, false);
			}
		}
		else if (isDisabled)
		{
			isHighlightDisabled = true;
			((Selectable)this).DoStateTransition((SelectionState)3, false);
		}
	}

	public void OnCancel(BaseEventData eventData)
	{
		if (this.m__CancelEvent != null)
		{
			this.m__CancelEvent.Invoke();
		}
	}
}
