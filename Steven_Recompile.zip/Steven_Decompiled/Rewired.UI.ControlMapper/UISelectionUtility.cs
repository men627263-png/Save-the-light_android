using System.Collections.Generic;
using Rewired.Utils;
using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper;

public static class UISelectionUtility
{
	public static Selectable FindNextSelectable(Selectable selectable, Transform transform, List<Selectable> allSelectables, Vector3 direction)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		RectTransform val = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		if ((Object)(object)val == (Object)null)
		{
			return null;
		}
		direction.Normalize();
		Vector2 val2 = Vector2.op_Implicit(direction);
		Vector2 val3 = Vector2.op_Implicit(UITools.GetPointOnRectEdge(val, val2));
		bool flag = val2 == Vector2.right * -1f || val2 == Vector2.right;
		float num = float.PositiveInfinity;
		float num2 = float.PositiveInfinity;
		Selectable val4 = null;
		Selectable val5 = null;
		Vector2 val6 = val3 + val2 * 999999f;
		float num3 = default;
		for (int i = 0; i < allSelectables.Count; i++)
		{
			Selectable val7 = allSelectables[i];
			if ((Object)(object)val7 == (Object)(object)selectable || (Object)(object)val7 == (Object)null)
			{
				continue;
			}
			Navigation navigation = val7.navigation;
			if ((int)navigation.mode == 0 || (!val7.IsInteractable() && !ReflectionTools.GetPrivateField<Selectable, bool>(val7, "m_GroupsAllowInteraction")))
			{
				continue;
			}
			Transform transform2 = ((Component)val7).transform;
			RectTransform val8 = (RectTransform)(object)((transform2 is RectTransform) ? transform2 : null);
			if ((Object)(object)val8 == (Object)null)
			{
				continue;
			}
			Rect val9 = UITools.InvertY(UITools.TransformRectTo((Transform)(object)val8, transform, val8.rect));
			if (MathTools.LineIntersectsRect(val3, val6, val9, ref num3))
			{
				if (flag)
				{
					num3 *= 0.25f;
				}
				if (num3 < num2)
				{
					num2 = num3;
					val5 = val7;
				}
			}
			Rect rect = val8.rect;
			Vector2 val10 = Vector2.op_Implicit(UnityTools.TransformPoint((Transform)(object)val8, transform, Vector2.op_Implicit(rect.center)));
			Vector2 val11 = val10 - val3;
			float num4 = Mathf.Abs(Vector2.Angle(val2, val11));
			if (!(num4 > 75f))
			{
				float sqrMagnitude = val11.sqrMagnitude;
				if (sqrMagnitude < num)
				{
					num = sqrMagnitude;
					val4 = val7;
				}
			}
		}
		if ((Object)(object)val5 != (Object)null && (Object)(object)val4 != (Object)null)
		{
			if (num2 > num)
			{
				return val4;
			}
			return val5;
		}
		return val5 ?? val4;
	}
}
