using UnityEngine;
using UnityEngine.UI;

namespace Rewired.UI.ControlMapper;

[AddComponentMenu("")]
public class UIGroup : MonoBehaviour
{
	[SerializeField]
	private Text _label;

	[SerializeField]
	private Transform _content;

	public string labelText
	{
		get
		{
			return (!((Object)(object)_label != (Object)null)) ? string.Empty : _label.text;
		}
		set
		{
			if (!((Object)(object)_label == (Object)null))
			{
				_label.text = value;
			}
		}
	}

	public Transform content => _content;

	public void SetLabelActive(bool state)
	{
		if (!((Object)(object)_label == (Object)null))
		{
			((Component)_label).gameObject.SetActive(state);
		}
	}
}
