using System;
using System.Collections;
using System.Collections.Generic;
using Grumpyface;
using UnityEngine;

[CreateAssetMenu(menuName = "Save the Light/Abilities/Enemies/Axe/Multi Axe Toss")]
public class Axe_MultiAxeToss : BaseAbility
{
	[Serializable]
	private class AbilityData
	{
		[Header("Prefabs")]
		public GameObject axePrefab;

		[Header("Animations")]
		public CharacterAnimationNamePair attackAnim = default;

		[Header("Tweakables")]
		public int numTosses = 3;

		[Tooltip("Time in seconds to wait after tossing an axe before tossing the next axe")]
		public float tossDelay = 1f;

		public DamageInfo damagePerAxe;

		[Header("Sounds")]
		public DelayedAudioEvent attackSound = default;

		[Header("Visual/Force Feedback")]
		[Range(0f, 1f)]
		public float axeCameraInfluence = 0.5f;
	}

	[SerializeField]
	private BonusStarData bonusStarData;

	[SerializeField]
	private AbilityData abilityData;

	[NonSerialized]
	private List<ITargetable> chosenTargets;

	[NonSerialized]
	private Vector3 originalPosition;

	[NonSerialized]
	private Vector3 originalDirection;

	[NonSerialized]
	private AxeEnemy axeEnemy;

	[NonSerialized]
	private List<AxeProjectile> axes;

	[NonSerialized]
	private float prevTimeScale = -1f;

	protected sealed override void OnInit()
	{
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		base.OnInit();
		int num = 0;
		chosenTargets = new List<ITargetable>();
		while (chosenTargets.Count < abilityData.numTosses)
		{
			chosenTargets.Add(targets[num]);
			num++;
			if (num == targets.Count)
			{
				num = 0;
			}
		}
		chosenTargets.Shuffle();
		axeEnemy = (AxeEnemy)caster;
		axes = new List<AxeProjectile>();
		Vector3 battleStartPosition = caster.battleStartPosition;
		caster.battlePosition = battleStartPosition;
		originalPosition = battleStartPosition;
		originalDirection = caster.directionVector;
		prevTimeScale = -1f;
	}

	public override IEnumerator Play()
	{
		EventMessenger.Instance.Raise(new RemoveAllCameraInfluenceEvent());
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)caster).transform, 1f)));
		EventMessenger.Instance.Raise(new CameraZoomEvent(1.1f));
		ITargetable prevTarget = null;
		ITargetable nextTarget = null;
		while (chosenTargets.Count > 0)
		{
			nextTarget = chosenTargets.Pop();
			if (!nextTarget.IsDead)
			{
				if (prevTarget != null && prevTarget != nextTarget)
				{
					EventMessenger.Instance.Raise(new RemoveCameraInfluenceEvent(prevTarget.transform));
				}
				EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(nextTarget.transform, 1f)));
				caster.PlayAnimFromFrame(abilityData.attackAnim, 0, clearQueue: true);
				caster.AddAnimToQueue(caster.GetIdleAnimation());
				abilityData.attackSound.Play(((Component)caster).transform.position);
				int throwFrame = caster.animatorTk2d.CurrentClip.GetFrameWithEventInfo("FireBullet");
				yield return (object)new WaitWhile((Func<bool>)(() => caster.animatorTk2d.CurrentFrame < throwFrame));
				((MonoBehaviour)caster).StartCoroutine(TossAxe(nextTarget));
				prevTarget = nextTarget;
				if (chosenTargets.Count > 0)
				{
					yield return (object)new WaitForSeconds(abilityData.tossDelay);
				}
			}
		}
		yield return (object)new WaitWhile((Func<bool>)(() => axes.Count > 0));
		EventMessenger.Instance.Raise(new RemoveCameraInfluenceEvent(nextTarget.transform));
		caster.RichAI2D.MoveToPosition(originalPosition, caster.baseMovementSpeed);
		yield return (object)new WaitWhile((Func<bool>)(() => caster.RichAI2D.WaitingForPathCalc));
		if (caster.RichAI2D.IsMovingAlongPath)
		{
			yield return new WaitUntilAIReachedTarget(caster.RichAI2D);
		}
		caster.directionVector = originalDirection;
	}

	public override IEnumerator Cancel()
	{
		if (prevTimeScale > 0f)
		{
			Time.timeScale = prevTimeScale;
		}
		yield return (object)new WaitWhile((Func<bool>)(() => axes.Count > 0));
		yield return (object)new WaitWhile((Func<bool>)(() => caster.CurrentState.Equals(CharacterState.KnockedBack) || caster.CurrentState.Equals(CharacterState.Hurt)));
		if (caster.isAlive)
		{
			caster.RichAI2D.MoveToPosition(originalPosition, caster.baseMovementSpeed);
			yield return new WaitUntilAIReachedTarget(caster.RichAI2D);
			caster.directionVector = originalDirection;
		}
	}

	protected override void OnCleanUp()
	{
		base.OnCleanUp();
	}

	public override void ResetForReUse()
	{
		chosenTargets = null;
		axes = null;
		axeEnemy = null;
		base.ResetForReUse();
	}

	private IEnumerator TossAxe(ITargetable target)
	{
		AxeProjectile axeProjectile = ObjectPool.GetObject<AxeProjectile>(abilityData.axePrefab, default(Vector3), true);
		axeProjectile.Init(axeEnemy, target.damageReceiver, axeEnemy.ProjectileSpawnPoint.position, Vector3.zero);
		axes.Add(axeProjectile);
		EventMessenger.Instance.Raise(new AddCameraInfluenceEvent(new CameraInfluence(((Component)axeProjectile.animator).transform, new Vector3(0f, abilityData.axeCameraInfluence, 0f))));
		StarBonusCheck bonusCheck = StartBonusCheck(Time.time + axeProjectile.GetTweenDuration(), bonusStarData, new List<ITargetable> { target });
		yield return (object)new WaitUntil((Func<bool>)(() => axeProjectile.isTargetReached));
		LastFrameBonusCheck(bonusCheck);
		DamageResult result = BattleHelper.CalculateDamage(caster, target.damageReceiver, abilityData.damagePerAxe, allowDeath: true, this);
		result.source = axeProjectile;
		BattleHelper.DoDamage(result, bonusCheck);
		if (bonusCheck.isBonusPerfectSuccess)
		{
			EventMessenger.Instance.Raise(new PerfectAttackEvent(bonusStarMeterOnPerfect));
			if (!preventFreezeDuration)
			{
				yield return (object)new WaitWhile((Func<bool>)(() => Time.timeScale == 0f));
				prevTimeScale = Time.timeScale;
				Time.timeScale = 0f;
				yield return new WaitForSecondsIndependentUnpaused(bonusStarData.bonusPerfectFreezeDuration);
				Time.timeScale = prevTimeScale;
			}
		}
		yield return (object)new WaitUntil((Func<bool>)(() => axeProjectile.isTargetReached));
		EventMessenger.Instance.Raise(new RemoveCameraInfluenceEvent(((Component)axeProjectile).transform));
		axes.Remove(axeProjectile);
		ObjectPool.PoolObject(((Component)axeProjectile).gameObject);
	}
}
