using UnityEngine;

public class SceneBuilderUtility : ScriptableObject
{
	public bool hideColliderDrawers;

	public bool drawSelectedCollider;

	public bool drawChildrenColliders;

	public bool checkWarpPads;

	public Color selectedColliderColor = Color.green;

	public Color selectedColliderWireframeColor = Color.green;

	public SceneBuilderUtility()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
	}
}
