using System;
using UnityEngine;

public class AnimatorEventListener : MonoBehaviour
{
	public event Action<AnimationEvent> EventTriggered;

	public event Action<AnimationEvent, AnimatorEventListener> EventTriggeredListener;

	private void HandleEvent(AnimationEvent evt)
	{
		if (EventTriggered != null)
		{
			EventTriggered(evt);
		}
		if (EventTriggeredListener != null)
		{
			EventTriggeredListener(evt, this);
		}
	}

	private void PlayAudioEvent(AnimationEvent evt)
	{
		if (evt.objectReferenceParameter != (Object)null && evt.objectReferenceParameter is AudioEvent)
		{
			AudioEventManager.Instance.Play((AudioEvent)(object)evt.objectReferenceParameter);
		}
	}
}
