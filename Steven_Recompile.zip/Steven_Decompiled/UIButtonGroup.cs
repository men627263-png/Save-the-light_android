using UnityEngine;

public class UIButtonGroup : MonoBehaviour
{
	public RadialLayout radialLayout;

	protected BaseCharacter target;

	protected Canvas uiCanvas;

	protected Collider collider;

	protected virtual void Awake()
	{
		if ((Object)(object)radialLayout == (Object)null)
		{
			radialLayout = ((Component)this).GetComponent<RadialLayout>();
		}
	}

	public virtual void Init(BaseCharacter target, Canvas uiCanvas)
	{
		this.target = target;
		this.uiCanvas = uiCanvas;
		collider = ((Component)target).GetComponent<Collider>();
	}

	protected virtual void LateUpdate()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)uiCanvas == (Object)null) && !((Object)(object)target == (Object)null) && !((Object)(object)collider == (Object)null))
		{
			Transform transform = ((Component)this).transform;
			Canvas canvas = uiCanvas;
			Bounds bounds = collider.bounds;
			transform.localPosition = Vector2.op_Implicit(canvas.WorldToCanvas(bounds.center));
		}
	}
}
